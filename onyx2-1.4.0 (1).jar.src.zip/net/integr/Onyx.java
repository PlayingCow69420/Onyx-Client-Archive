/*     */ package net.integr;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.file.NoSuchFileException;
/*     */ import java.nio.file.Path;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.text.StringsKt;
/*     */ import net.fabricmc.api.ClientModInitializer;
/*     */ import net.fabricmc.api.ModInitializer;
/*     */ import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
/*     */ import net.fabricmc.loader.api.FabricLoader;
/*     */ import net.fabricmc.loader.api.ModContainer;
/*     */ import net.integr.commands.CommandRegistry;
/*     */ import net.integr.discord.PresenceHandler;
/*     */ import net.integr.event.ClientEndEvent;
/*     */ import net.integr.event.DoItemPickEvent;
/*     */ import net.integr.event.GetPlayerEntityScaleEvent;
/*     */ import net.integr.event.KeyEvent;
/*     */ import net.integr.event.RenderTitleScreenEvent;
/*     */ import net.integr.event.RenderWorldEvent;
/*     */ import net.integr.event.TitleScreenMouseClickedEvent;
/*     */ import net.integr.event.UnsafePreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.integr.eventsystem.Priority;
/*     */ import net.integr.friendsystem.FriendStorage;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.ModuleManager;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*     */ import net.integr.modules.management.settings.impl.KeyBindSetting;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.screens.AltManagerScreen;
/*     */ import net.integr.rendering.screens.GameScreen;
/*     */ import net.integr.rendering.screens.MenuScreen;
/*     */ import net.integr.rendering.shader.management.PostProcessShaderManager;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.Button;
/*     */ import net.integr.rendering.uisystem.UiLayout;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.integr.utilities.ClipboardHelper;
/*     */ import net.integr.utilities.LogUtils;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.integr.utilities.game.entity.EntityFinder;
/*     */ import net.integr.utilities.game.highlight.HighlightHandler;
/*     */ import net.integr.utilities.game.pathfind.auto.AutoPathTraverser;
/*     */ import net.integr.utilities.game.rotationfake.RotationFaker;
/*     */ import net.integr.utilities.locking.HWIDManager;
/*     */ import net.integr.utilities.locking.NotAuthedException;
/*     */ import net.integr.utilities.resourceload.ResourceLoader;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_304;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_3675;
/*     */ import net.minecraft.class_3966;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.system.MemoryUtil;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\n\002\020\b\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\002\n\002\030\002\n\002\b\007\030\000 =2\0020\0012\0020\002:\001=B\007¢\006\004\b\003\020\004J\017\020\006\032\0020\005H\002¢\006\004\b\006\020\004J\027\020\t\032\0020\0052\006\020\b\032\0020\007H\007¢\006\004\b\t\020\nJ\017\020\013\032\0020\005H\026¢\006\004\b\013\020\004J\017\020\f\032\0020\005H\026¢\006\004\b\f\020\004J\027\020\016\032\0020\0052\006\020\b\032\0020\rH\007¢\006\004\b\016\020\017J\027\020\021\032\0020\0052\006\020\b\032\0020\020H\007¢\006\004\b\021\020\022J\027\020\024\032\0020\0052\006\020\b\032\0020\023H\007¢\006\004\b\024\020\025J\027\020\027\032\0020\0052\006\020\b\032\0020\026H\007¢\006\004\b\027\020\030J\027\020\032\032\0020\0052\006\020\b\032\0020\031H\007¢\006\004\b\032\020\033J\027\020\035\032\0020\0052\006\020\b\032\0020\034H\007¢\006\004\b\035\020\036J\027\020 \032\0020\0052\006\020\b\032\0020\037H\007¢\006\004\b \020!J\025\020$\032\0020\0052\006\020#\032\0020\"¢\006\004\b$\020%J#\020*\032\0020\0052\b\b\002\020'\032\0020&2\b\b\002\020)\032\0020(H\002¢\006\004\b*\020+R\026\020-\032\0020,8\002@\002X\016¢\006\006\n\004\b-\020.R\026\0200\032\0020/8\002@\002X\016¢\006\006\n\004\b0\0201R\026\0202\032\0020(8\002@\002X\016¢\006\006\n\004\b2\0203R\026\0205\032\002048\002@\002X\016¢\006\006\n\004\b5\0206R\026\0208\032\002078\002@\002X\016¢\006\006\n\004\b8\0209R\026\020:\032\0020(8\002@\002X\016¢\006\006\n\004\b:\0203R\026\020;\032\002048\002@\002X\016¢\006\006\n\004\b;\0206R\026\020<\032\0020/8\002@\002X\016¢\006\006\n\004\b<\0201¨\006>"}, d2 = {"Lnet/integr/Onyx;", "Lnet/fabricmc/api/ClientModInitializer;", "Lnet/fabricmc/api/ModInitializer;", "<init>", "()V", "", "attemptSave", "Lnet/integr/event/GetPlayerEntityScaleEvent;", "event", "onGetPlayerEntityScale", "(Lnet/integr/event/GetPlayerEntityScaleEvent;)V", "onInitialize", "onInitializeClient", "Lnet/integr/event/DoItemPickEvent;", "onItemPick", "(Lnet/integr/event/DoItemPickEvent;)V", "Lnet/integr/event/KeyEvent;", "onKey", "(Lnet/integr/event/KeyEvent;)V", "Lnet/integr/event/RenderTitleScreenEvent;", "onRenderTitleScreen", "(Lnet/integr/event/RenderTitleScreenEvent;)V", "Lnet/integr/event/RenderWorldEvent;", "onRenderWorld", "(Lnet/integr/event/RenderWorldEvent;)V", "Lnet/integr/event/ClientEndEvent;", "onStop", "(Lnet/integr/event/ClientEndEvent;)V", "Lnet/integr/event/UnsafePreTickEvent;", "onTickPre", "(Lnet/integr/event/UnsafePreTickEvent;)V", "Lnet/integr/event/TitleScreenMouseClickedEvent;", "onTitleScreenMouseClicked", "(Lnet/integr/event/TitleScreenMouseClickedEvent;)V", "", "path", "setIcon", "(Ljava/lang/String;)V", "", "value", "", "rgb", "updateAccent", "(IZ)V", "Lnet/integr/rendering/uisystem/Button;", "altManagerButton", "Lnet/integr/rendering/uisystem/Button;", "Lnet/integr/rendering/uisystem/Box;", "branding", "Lnet/integr/rendering/uisystem/Box;", "iconSet", "Z", "", "lastSaveTime", "J", "Lnet/integr/rendering/uisystem/UiLayout;", "layout", "Lnet/integr/rendering/uisystem/UiLayout;", "shadersStarted", "startTime", "toolbar", "Companion", "onyx2"})
/*     */ public final class Onyx
/*     */   implements ClientModInitializer, ModInitializer
/*     */ {
/*     */   public Onyx() {
/* 105 */     this.lastSaveTime = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     this.layout = new UiLayout();
/*     */     
/* 240 */     Intrinsics.checkNotNull(this.layout.add((HelixUiElement)new Box(4, 49, 110, 40, null, false, true, false, 128, null)), "null cannot be cast to non-null type net.integr.rendering.uisystem.Box"); this.branding = (Box)this.layout.add((HelixUiElement)new Box(4, 49, 110, 40, null, false, true, false, 128, null));
/* 241 */     Intrinsics.checkNotNull(this.layout.add((HelixUiElement)new Box(4, 94, 110, 30, null, false, true, false, 128, null)), "null cannot be cast to non-null type net.integr.rendering.uisystem.Box"); this.toolbar = (Box)this.layout.add((HelixUiElement)new Box(4, 94, 110, 30, null, false, true, false, 128, null));
/*     */     
/* 243 */     Intrinsics.checkNotNull(this.layout.add((HelixUiElement)new Button(9, 99, 100, 20, "Alts", true, "Manage your Alt Accounts", false, this::altManagerButton$lambda$0)), "null cannot be cast to non-null type net.integr.rendering.uisystem.Button"); this.altManagerButton = (Button)this.layout.add((HelixUiElement)new Button(9, 99, 100, 20, "Alts", true, "Manage your Alt Accounts", false, this::altManagerButton$lambda$0));
/* 244 */   } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000<\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\006XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\006XT¢\006\006\n\004\b\007\020\006R\027\020\t\032\0020\b8\006¢\006\f\n\004\b\t\020\n\032\004\b\013\020\fR\"\020\016\032\0020\r8\006@\006X\016¢\006\022\n\004\b\016\020\017\032\004\b\020\020\021\"\004\b\022\020\023R\024\020\024\032\0020\0048\006XT¢\006\006\n\004\b\024\020\006R\027\020\026\032\0020\0258\006¢\006\f\n\004\b\026\020\027\032\004\b\030\020\031R\027\020\033\032\0020\0328\006¢\006\f\n\004\b\033\020\034\032\004\b\035\020\036R\027\020\037\032\0020\0048\006¢\006\f\n\004\b\037\020\006\032\004\b \020!R$\020#\032\004\030\0010\"8\006@\006X\016¢\006\022\n\004\b#\020$\032\004\b%\020&\"\004\b'\020(¨\006)"}, d2 = {"Lnet/integr/Onyx$Companion;", "", "<init>", "()V", "", "CLIENT_ID", "Ljava/lang/String;", "CLIENT_NAME", "Ljava/nio/file/Path;", "CONFIG", "Ljava/nio/file/Path;", "getCONFIG", "()Ljava/nio/file/Path;", "", "DEV_MODE", "Z", "getDEV_MODE", "()Z", "setDEV_MODE", "(Z)V", "DISCORD_ID", "Lorg/slf4j/Logger;", "LOGGER", "Lorg/slf4j/Logger;", "getLOGGER", "()Lorg/slf4j/Logger;", "Lnet/minecraft/class_310;", "MC", "Lnet/minecraft/class_310;", "getMC", "()Lnet/minecraft/class_310;", "VERSION", "getVERSION", "()Ljava/lang/String;", "Lnet/minecraft/class_304;", "openKey", "Lnet/minecraft/class_304;", "getOpenKey", "()Lnet/minecraft/class_304;", "setOpenKey", "(Lnet/minecraft/class_304;)V", "onyx2"}) public static final class Companion { private Companion() {} @NotNull public final class_310 getMC() { return Onyx.MC; } @NotNull public final Logger getLOGGER() { return Onyx.LOGGER; } @NotNull public final String getVERSION() { return Onyx.VERSION; } @NotNull public final Path getCONFIG() { return Onyx.CONFIG; } public final boolean getDEV_MODE() { return Onyx.DEV_MODE; } public final void setDEV_MODE(boolean <set-?>) { Onyx.DEV_MODE = <set-?>; } @Nullable public final class_304 getOpenKey() { return Onyx.openKey; } public final void setOpenKey(@Nullable class_304 <set-?>) { Onyx.openKey = <set-?>; } } @NotNull public static final Companion Companion = new Companion(null); private long startTime; private boolean iconSet; private long lastSaveTime; private boolean shadersStarted; @NotNull private UiLayout layout; @NotNull private Box branding; @NotNull private Box toolbar; @NotNull private Button altManagerButton; @NotNull public static final String CLIENT_NAME = "Onyx"; @NotNull public static final String CLIENT_ID = "onyx"; @NotNull private static final class_310 MC = class_310.method_1551(); static { Intrinsics.checkNotNullExpressionValue(class_310.method_1551(), "getInstance(...)"); } private static final void altManagerButton$lambda$0(Onyx this$0) { Intrinsics.checkNotNullParameter(this$0, "this$0"); this$0.layout.resetCursor();
/* 245 */     MC.method_1507((class_437)new AltManagerScreen()); }
/*     */   @NotNull private static final Logger LOGGER = LoggerFactory.getLogger("Onyx");
/*     */   static { Intrinsics.checkNotNullExpressionValue(LoggerFactory.getLogger("Onyx"), "getLogger(...)"); }
/*     */   @NotNull private static final String VERSION = ((ModContainer)FabricLoader.getInstance().getModContainer("onyx").get()).getMetadata().getVersion().toString();
/*     */   @NotNull private static final Path CONFIG = Path.of(StringsKt.substringBeforeLast$default(FabricLoader.getInstance().getConfigDir().toString(), "config", null, 2, null) + "onyx", new String[0]);
/* 250 */   @NotNull public static final String DISCORD_ID = "1246381680084910100"; private static boolean DEV_MODE; @Nullable private static class_304 openKey; static { Intrinsics.checkNotNullExpressionValue(Path.of(StringsKt.substringBeforeLast$default(FabricLoader.getInstance().getConfigDir().toString(), "config", null, 2, null) + "onyx", new String[0]), "of(...)"); } private final void attemptSave() { if (System.currentTimeMillis() - this.lastSaveTime < 120000L) return;  this.lastSaveTime = System.currentTimeMillis(); ModuleManager.Companion.save(); FriendStorage.Companion.save(); LogUtils.Companion.sendLog("Saved your settings [Periodic]!"); } public void onInitialize() { LogUtils.Companion.sendLog("Onyx startup..."); String activeSystemId = HWIDManager.Companion.getHwid(); LogUtils.Companion.sendLog("Active System: " + activeSystemId); if (!HWIDManager.Companion.isAuthed(activeSystemId)) { ClipboardHelper.Companion.copyToClipboard(activeSystemId); throw new NotAuthedException(activeSystemId); }  LogUtils.Companion.sendLog("Authorized from server response!"); openKey = KeyBindingHelper.registerKeyBinding(new class_304("key.onyx.openmenu", class_3675.class_307.field_1668, 344, "category.onyx")); this.startTime = System.currentTimeMillis(); ModuleManager.Companion.init(); EventSystem.Companion.register(this); EventSystem.Companion.register(GameScreen.Companion.getINSTANCE()); EventSystem.Companion.register(RotationFaker.Companion.getINSTANCE()); EventSystem.Companion.register(HighlightHandler.Companion.getINSTANCE()); EventSystem.Companion.register(PostProcessShaderManager.Companion.getINSTANCE()); EventSystem.Companion.register(AutoPathTraverser.Companion.getINSTANCE()); PresenceHandler.Companion.start(); CommandRegistry.Companion.init(); FriendStorage.Companion.load(); LogUtils.Companion.sendLog("Onyx started [" + System.currentTimeMillis() - this.startTime + "ms]"); } @EventListen(prio = Priority.FIRST) public final void onStop(@NotNull ClientEndEvent event) { Intrinsics.checkNotNullParameter(event, "event"); ModuleManager.Companion.save(); PresenceHandler.Companion.stop(); FriendStorage.Companion.save(); LogUtils.Companion.sendLog("Saved your settings [Game Stopped]!"); } @EventListen(prio = Priority.FIRST) public final void onItemPick(@NotNull DoItemPickEvent event) { Intrinsics.checkNotNullParameter(event, "event"); class_239 target = MC.field_1765; if (target != null && target.method_17783() == class_239.class_240.field_1331) { class_1297 entity = ((class_3966)target).method_17782(); if (entity != null && entity instanceof class_1657) { FriendStorage.Companion.handleMiddleClickFriend((class_1657)entity); event.cancel(); }  }  } @EventListen(prio = Priority.FIRST) public final void onTickPre(@NotNull UnsafePreTickEvent event) { Intrinsics.checkNotNullParameter(event, "event"); if (MC.method_22683() != null) { MC.method_22683().method_24286("Onyx [" + VERSION + "]"); if (!this.iconSet) { try { setIcon("assets/onyx/onyx.png"); } catch (NoSuchFileException e) { LogUtils.Companion.sendLog("Could not locate Icon... Returning to default!"); }  this.iconSet = true; }  }  if (!this.shadersStarted && MC.method_22940() != null) { PostProcessShaderManager.Companion.initShaders(); this.shadersStarted = true; }  Intrinsics.checkNotNull(openKey); if (openKey.method_1436()) MC.method_1507(MenuScreen.Companion.getINSTANCE());  Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("theme")); String str = ((CyclerSetting)Settings.Companion.getINSTANCE().getSettings().getById("theme")).getElement(); switch (str.hashCode()) { case 2227843: if (!str.equals("Gray")) break;  Variables.Companion.setGuiBack((new Color(201, 201, 201)).getRGB()); break;case 2073722: if (!str.equals("Blue")) break;  Variables.Companion.setGuiBack((new Color(3, 3, 40)).getRGB()); break;case 2122646: if (!str.equals("Dark")) break;  Variables.Companion.setGuiBack((new Color(25, 24, 24)).getRGB()); break;case 73417974: if (!str.equals("Light")) break;  Variables.Companion.setGuiBack((new Color(217, 217, 217)).getRGB()); break;case 74109858: if (!str.equals("Mango")) break;  Variables.Companion.setGuiBack((new Color(42, 24, 4)).getRGB()); break; }  Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("accent")); str = ((CyclerSetting)Settings.Companion.getINSTANCE().getSettings().getById("accent")).getElement(); switch (str.hashCode()) { case 82033: if (!str.equals("Red")) break;  updateAccent$default(this, (new Color(194, 0, 6)).getRGB(), false, 2, null); break;case 2487702: if (!str.equals("Pink")) break;  updateAccent$default(this, (new Color(213, 141, 203)).getRGB(), false, 2, null); break;case 2115395: if (!str.equals("Cyan")) break;  updateAccent$default(this, (new Color(159, 226, 224)).getRGB(), false, 2, null); break;case 83549193: if (!str.equals("White")) break;  updateAccent$default(this, (new Color(217, 217, 217)).getRGB(), false, 2, null); break;case -1650372460: if (!str.equals("Yellow")) break;  updateAccent$default(this, (new Color(187, 170, 0)).getRGB(), false, 2, null); break;case -1893076004: if (!str.equals("Purple")) break;  updateAccent$default(this, (new Color(129, 0, 249)).getRGB(), false, 2, null); break;case 2073722: if (!str.equals("Blue")) break;  updateAccent$default(this, (new Color(0, 87, 249)).getRGB(), false, 2, null); break;case 64266207: if (!str.equals("Black")) break;  updateAccent$default(this, (new Color(24, 24, 24)).getRGB(), false, 2, null); break;case 82093: if (!str.equals("Rgb")) break;  updateAccent$default(this, 0, true, 1, null); break;case -1924984242: if (!str.equals("Orange")) break;  updateAccent$default(this, (new Color(249, 141, 0)).getRGB(), false, 2, null); break;case 69066467: if (!str.equals("Green")) break;  updateAccent$default(this, (new Color(0, 175, 10)).getRGB(), false, 2, null); break; }  if (Variables.Companion.getGuiColorIsRgb()) { float[] rgbColor = RenderingEngine.Misc.Companion.getRainbowColor(); Variables.Companion.setGuiColor((new Color(rgbColor[0], rgbColor[1], rgbColor[2])).getRGB()); }  PresenceHandler.Companion.setDynamically(); attemptSave(); } private final void updateAccent(int value, boolean rgb) { Variables.Companion.setGuiColor(value); Variables.Companion.setGuiColorIsRgb(rgb); } @EventListen public final void onRenderTitleScreen(@NotNull RenderTitleScreenEvent event) { Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNullExpressionValue(event.context, "context"); this.branding.method_25394(event.context, event.mouseX, event.mouseY, event.delta);
/* 251 */     Intrinsics.checkNotNullExpressionValue(event.context, "context"); this.toolbar.method_25394(event.context, event.mouseX, event.mouseY, event.delta);
/*     */     
/* 253 */     boolean shouldReset = true;
/*     */     
/* 255 */     Intrinsics.checkNotNullExpressionValue(event.context, "context"); this.altManagerButton.method_25394(event.context, event.mouseX, event.mouseY, event.delta);
/* 256 */     Intrinsics.checkNotNullExpressionValue(event.context, "context"); if (this.altManagerButton.renderTooltip(event.context, event.mouseX, event.mouseY, event.delta)) shouldReset = false;
/*     */     
/* 258 */     if (shouldReset) this.layout.resetCursor();
/*     */     
/* 260 */     Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.Text.Companion.draw(event.context, class_124.field_1067.toString() + "Onyx", 8, 55, Variables.Companion.getGuiColor());
/* 261 */     Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.Text.Companion.draw(event.context, "by Integr", 8, 65, Variables.Companion.getGuiColor());
/* 262 */     Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.Text.Companion.draw(event.context, "v" + VERSION, 8, 75, Variables.Companion.getGuiColor()); }
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onTitleScreenMouseClicked(@NotNull TitleScreenMouseClickedEvent event) {
/* 267 */     Intrinsics.checkNotNullParameter(event, "event"); this.layout.onClick(event.mouseX, event.mouseY, event.button);
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onKey(@NotNull KeyEvent event) {
/* 272 */     Intrinsics.checkNotNullParameter(event, "event"); if (MC.field_1724 != null && MC.field_1755 == null && event.action == 1)
/* 273 */       for (Module m : ModuleManager.Companion.getModules()) {
/* 274 */         Intrinsics.checkNotNull(m.getSettings().getById("bind")); int i = event.key; if (((KeyBindSetting)m.getSettings().getById("bind")).getSetBind() == null) { ((KeyBindSetting)m.getSettings().getById("bind")).getSetBind(); } else if (((KeyBindSetting)m.getSettings().getById("bind")).getSetBind().intValue() == i)
/* 275 */         { m.toggle();
/* 276 */           MC.method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F)); }
/*     */ 
/*     */         
/* 279 */         m.onKeyEvent(event);
/*     */       }  
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onRenderWorld(@NotNull RenderWorldEvent event) {
/*     */     class_1657 player;
/* 286 */     Intrinsics.checkNotNullParameter(event, "event"); if (EntityFinder.Companion.getPlayerByName("Integr") == null) { EntityFinder.Companion.getPlayerByName("Integr"); return; }
/* 287 */      if (Intrinsics.areEqual(player, MC.field_1724))
/*     */       return; 
/* 289 */     Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("smol")); if (((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("smol")).isEnabled()) {
/* 290 */       class_243 pos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)player, event.tickDelta);
/* 291 */       Intrinsics.checkNotNullExpressionValue(pos.method_1031(0.0D, player.method_5829().method_17940() - 0.15D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(pos.method_1031(0.0D, player.method_5829().method_17940() - 0.15D, 0.0D), 0.1D, 0.7D, 0.2F, true, event.matrices, Variables.Companion.getGuiColor());
/*     */     } else {
/* 293 */       class_243 pos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)player, event.tickDelta);
/* 294 */       Intrinsics.checkNotNullExpressionValue(pos.method_1031(0.0D, player.method_5829().method_17940() + 0.2D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(pos.method_1031(0.0D, player.method_5829().method_17940() + 0.2D, 0.0D), 0.1D, 1.0D, 0.2F, true, event.matrices, Variables.Companion.getGuiColor());
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onGetPlayerEntityScale(@NotNull GetPlayerEntityScaleEvent event) {
/* 300 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("smol")); if (Intrinsics.areEqual(event.player.method_7334().getName(), "Integr") && ((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("smol")).isEnabled()) {
/* 301 */       event.matrices.method_22905(0.8975F, 0.8975F, 0.8975F);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onInitializeClient() {}
/*     */ 
/*     */   
/*     */   public final void setIcon(@NotNull String path) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc_w 'path'
/*     */     //   4: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   7: invokestatic assertOnRenderThreadOrInit : ()V
/*     */     //   10: invokestatic glfwGetPlatform : ()I
/*     */     //   13: istore_2
/*     */     //   14: iload_2
/*     */     //   15: tableswitch default -> 363, 393217 -> 48, 393218 -> 363, 393219 -> 360, 393220 -> 48, 393221 -> 360
/*     */     //   48: aload_1
/*     */     //   49: <illegal opcode> get : (Ljava/lang/String;)Lnet/minecraft/class_7367;
/*     */     //   54: invokestatic listOf : (Ljava/lang/Object;)Ljava/util/List;
/*     */     //   57: astore_3
/*     */     //   58: new java/util/ArrayList
/*     */     //   61: dup
/*     */     //   62: aload_3
/*     */     //   63: invokeinterface size : ()I
/*     */     //   68: invokespecial <init> : (I)V
/*     */     //   71: checkcast java/util/List
/*     */     //   74: astore #4
/*     */     //   76: nop
/*     */     //   77: invokestatic stackPush : ()Lorg/lwjgl/system/MemoryStack;
/*     */     //   80: astore #5
/*     */     //   82: nop
/*     */     //   83: aload_3
/*     */     //   84: invokeinterface size : ()I
/*     */     //   89: aload #5
/*     */     //   91: invokestatic malloc : (ILorg/lwjgl/system/MemoryStack;)Lorg/lwjgl/glfw/GLFWImage$Buffer;
/*     */     //   94: astore #6
/*     */     //   96: iconst_0
/*     */     //   97: istore #7
/*     */     //   99: iload #7
/*     */     //   101: aload_3
/*     */     //   102: invokeinterface size : ()I
/*     */     //   107: if_icmpge -> 276
/*     */     //   110: aload_3
/*     */     //   111: iload #7
/*     */     //   113: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   118: dup
/*     */     //   119: ldc_w 'null cannot be cast to non-null type net.minecraft.resource.InputSupplier<*>'
/*     */     //   122: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   125: checkcast net/minecraft/class_7367
/*     */     //   128: invokeinterface get : ()Ljava/lang/Object;
/*     */     //   133: dup
/*     */     //   134: ldc_w 'null cannot be cast to non-null type java.io.InputStream'
/*     */     //   137: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   140: checkcast java/io/InputStream
/*     */     //   143: invokestatic method_4309 : (Ljava/io/InputStream;)Lnet/minecraft/class_1011;
/*     */     //   146: astore #8
/*     */     //   148: nop
/*     */     //   149: aload #8
/*     */     //   151: dup
/*     */     //   152: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   155: invokevirtual method_4307 : ()I
/*     */     //   158: aload #8
/*     */     //   160: invokevirtual method_4323 : ()I
/*     */     //   163: imul
/*     */     //   164: iconst_4
/*     */     //   165: imul
/*     */     //   166: invokestatic memAlloc : (I)Ljava/nio/ByteBuffer;
/*     */     //   169: astore #9
/*     */     //   171: aload #4
/*     */     //   173: aload #9
/*     */     //   175: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   180: pop
/*     */     //   181: aload #9
/*     */     //   183: invokevirtual asIntBuffer : ()Ljava/nio/IntBuffer;
/*     */     //   186: aload #8
/*     */     //   188: invokevirtual method_48463 : ()[I
/*     */     //   191: invokevirtual put : ([I)Ljava/nio/IntBuffer;
/*     */     //   194: pop
/*     */     //   195: aload #6
/*     */     //   197: iload #7
/*     */     //   199: invokevirtual position : (I)Lorg/lwjgl/system/CustomBuffer;
/*     */     //   202: pop
/*     */     //   203: aload #6
/*     */     //   205: aload #8
/*     */     //   207: invokevirtual method_4307 : ()I
/*     */     //   210: invokevirtual width : (I)Lorg/lwjgl/glfw/GLFWImage$Buffer;
/*     */     //   213: pop
/*     */     //   214: aload #6
/*     */     //   216: aload #8
/*     */     //   218: invokevirtual method_4323 : ()I
/*     */     //   221: invokevirtual height : (I)Lorg/lwjgl/glfw/GLFWImage$Buffer;
/*     */     //   224: pop
/*     */     //   225: aload #6
/*     */     //   227: aload #9
/*     */     //   229: invokevirtual pixels : (Ljava/nio/ByteBuffer;)Lorg/lwjgl/glfw/GLFWImage$Buffer;
/*     */     //   232: pop
/*     */     //   233: goto -> 264
/*     */     //   236: astore #9
/*     */     //   238: aload #8
/*     */     //   240: ifnull -> 261
/*     */     //   243: nop
/*     */     //   244: aload #8
/*     */     //   246: invokevirtual close : ()V
/*     */     //   249: goto -> 261
/*     */     //   252: astore #10
/*     */     //   254: aload #9
/*     */     //   256: aload #10
/*     */     //   258: invokestatic addSuppressed : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
/*     */     //   261: aload #9
/*     */     //   263: athrow
/*     */     //   264: aload #8
/*     */     //   266: invokevirtual close : ()V
/*     */     //   269: iinc #7, 1
/*     */     //   272: nop
/*     */     //   273: goto -> 99
/*     */     //   276: getstatic net/integr/Onyx.MC : Lnet/minecraft/class_310;
/*     */     //   279: invokevirtual method_22683 : ()Lnet/minecraft/class_1041;
/*     */     //   282: invokevirtual method_4490 : ()J
/*     */     //   285: aload #6
/*     */     //   287: iconst_0
/*     */     //   288: invokevirtual position : (I)Lorg/lwjgl/system/CustomBuffer;
/*     */     //   291: checkcast org/lwjgl/glfw/GLFWImage$Buffer
/*     */     //   294: invokestatic glfwSetWindowIcon : (JLorg/lwjgl/glfw/GLFWImage$Buffer;)V
/*     */     //   297: goto -> 323
/*     */     //   300: astore #6
/*     */     //   302: nop
/*     */     //   303: aload #5
/*     */     //   305: invokevirtual close : ()V
/*     */     //   308: goto -> 320
/*     */     //   311: astore #7
/*     */     //   313: aload #6
/*     */     //   315: aload #7
/*     */     //   317: invokestatic addSuppressed : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
/*     */     //   320: aload #6
/*     */     //   322: athrow
/*     */     //   323: aload #5
/*     */     //   325: invokevirtual close : ()V
/*     */     //   328: aload #4
/*     */     //   330: <illegal opcode> accept : ()Ljava/util/function/Consumer;
/*     */     //   335: invokeinterface forEach : (Ljava/util/function/Consumer;)V
/*     */     //   340: goto -> 378
/*     */     //   343: astore #5
/*     */     //   345: aload #4
/*     */     //   347: <illegal opcode> accept : ()Ljava/util/function/Consumer;
/*     */     //   352: invokeinterface forEach : (Ljava/util/function/Consumer;)V
/*     */     //   357: aload #5
/*     */     //   359: athrow
/*     */     //   360: goto -> 378
/*     */     //   363: getstatic net/integr/Onyx.LOGGER : Lorg/slf4j/Logger;
/*     */     //   366: ldc_w 'Not setting icon for unrecognized platform: {}'
/*     */     //   369: iload_2
/*     */     //   370: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   373: invokeinterface warn : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   378: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #311	-> 7
/*     */     //   #312	-> 10
/*     */     //   #314	-> 48
/*     */     //   #315	-> 58
/*     */     //   #317	-> 76
/*     */     //   #318	-> 77
/*     */     //   #320	-> 82
/*     */     //   #321	-> 83
/*     */     //   #323	-> 96
/*     */     //   #324	-> 99
/*     */     //   #325	-> 110
/*     */     //   #327	-> 148
/*     */     //   #328	-> 149
/*     */     //   #329	-> 171
/*     */     //   #330	-> 181
/*     */     //   #331	-> 195
/*     */     //   #332	-> 203
/*     */     //   #333	-> 214
/*     */     //   #334	-> 225
/*     */     //   #335	-> 236
/*     */     //   #336	-> 238
/*     */     //   #337	-> 243
/*     */     //   #338	-> 244
/*     */     //   #339	-> 252
/*     */     //   #340	-> 254
/*     */     //   #344	-> 261
/*     */     //   #347	-> 264
/*     */     //   #348	-> 272
/*     */     //   #351	-> 276
/*     */     //   #352	-> 300
/*     */     //   #353	-> 302
/*     */     //   #354	-> 303
/*     */     //   #355	-> 311
/*     */     //   #356	-> 313
/*     */     //   #359	-> 320
/*     */     //   #361	-> 323
/*     */     //   #364	-> 328
/*     */     //   #369	-> 340
/*     */     //   #364	-> 343
/*     */     //   #372	-> 363
/*     */     //   #374	-> 378
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   171	62	9	byteBuffer	Ljava/nio/ByteBuffer;
/*     */     //   254	7	10	var19	Ljava/lang/Throwable;
/*     */     //   238	26	9	var20	Ljava/lang/Throwable;
/*     */     //   148	125	8	nativeImage	Lnet/minecraft/class_1011;
/*     */     //   96	201	6	buffer	Lorg/lwjgl/glfw/GLFWImage$Buffer;
/*     */     //   99	198	7	j	I
/*     */     //   313	7	7	var18	Ljava/lang/Throwable;
/*     */     //   302	21	6	var21	Ljava/lang/Throwable;
/*     */     //   82	246	5	memoryStack	Lorg/lwjgl/system/MemoryStack;
/*     */     //   58	302	3	list	Ljava/util/List;
/*     */     //   76	284	4	list2	Ljava/util/List;
/*     */     //   14	364	2	i	I
/*     */     //   0	379	0	this	Lnet/integr/Onyx;
/*     */     //   0	379	1	path	Ljava/lang/String;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   76	328	343	finally
/*     */     //   82	297	300	java/lang/Throwable
/*     */     //   148	233	236	java/lang/Throwable
/*     */     //   243	249	252	java/lang/Throwable
/*     */     //   302	308	311	java/lang/Throwable
/*     */     //   343	345	343	finally
/*     */   }
/*     */   
/*     */   private static final InputStream setIcon$lambda$1(String $path) {
/* 314 */     Intrinsics.checkNotNullParameter($path, "$path"); return ResourceLoader.Companion.loadResourceAsStream($path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void setIcon$lambda$2(ByteBuffer ptr) {
/* 365 */     MemoryUtil.memFree(
/* 366 */         ptr);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\Onyx.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */