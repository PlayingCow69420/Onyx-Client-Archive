/*     */ package net.integr.commands;
/*     */ 
/*     */ import com.mojang.brigadier.CommandDispatcher;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.arguments.StringArgumentType;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.suggestion.SuggestionProvider;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
/*     */ import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.commands.suggestors.PlayerStringSuggestionProvider;
/*     */ import net.integr.utilities.game.command.CommandUtils;
/*     */ import net.minecraft.class_7157;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/commands/CommandRegistry;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class CommandRegistry {
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\002\n\002\020!\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003J\017\020\006\032\0020\004H\002¢\006\004\b\006\020\003J\035\020\n\032\0020\0042\f\020\t\032\b\022\004\022\0020\b0\007H\002¢\006\004\b\n\020\013R\024\020\r\032\0020\f8\002XT¢\006\006\n\004\b\r\020\016R \020\020\032\016\022\n\022\b\022\004\022\0020\b0\0070\0178\002X\004¢\006\006\n\004\b\020\020\021¨\006\022"}, d2 = {"Lnet/integr/commands/CommandRegistry$Companion;", "", "<init>", "()V", "", "init", "reg", "Lcom/mojang/brigadier/builder/LiteralArgumentBuilder;", "Lnet/fabricmc/fabric/api/client/command/v2/FabricClientCommandSource;", "value", "register", "(Lcom/mojang/brigadier/builder/LiteralArgumentBuilder;)V", "", "PASS", "I", "", "commands", "Ljava/util/List;", "onyx2"})
/*     */   public static final class Companion {
/*     */     private Companion() {}
/*     */     
/*     */     private static final void reg$lambda$1$lambda$0(CommandContext $it) {
/*     */       ((FabricClientCommandSource)$it.getSource()).getClient().method_1507(MenuScreen.Companion.getINSTANCE());
/*     */     }
/*     */     
/*     */     private static final int reg$lambda$1(CommandContext it) {
/*     */       ((FabricClientCommandSource)it.getSource()).getClient().method_18858(it::reg$lambda$1$lambda$0);
/*     */       Intrinsics.checkNotNull(Onyx.Companion.getOpenKey());
/*     */       ((FabricClientCommandSource)it.getSource()).sendFeedback(LogUtils.Companion.getChatLog("Please remember you can also use the hotkey [" + class_2561.method_43471(Onyx.Companion.getOpenKey().method_1428()).getString() + "] to open the ui."));
/*     */       return 1;
/*     */     }
/*     */     
/*     */     private static final int reg$lambda$2(CommandContext it) {
/*     */       CommandUtils.Companion.sendCommand("gamemode creative");
/*     */       return 1;
/*     */     }
/*     */     
/*  41 */     private final void register(LiteralArgumentBuilder value) { CommandRegistry.commands.add(value); }
/*     */     private static final int reg$lambda$3(CommandContext it) { String arg = StringArgumentType.getString(it, "player");
/*     */       CommandUtils.Companion.sendCommand("gamemode creative " + arg);
/*     */       return 1; }
/*     */     private static final int reg$lambda$4(CommandContext it) { CommandUtils.Companion.sendCommand("gamemode survival");
/*     */       return 1; }
/*  47 */     private final void reg() { Intrinsics.checkNotNullExpressionValue(ClientCommandManager.literal("onyx").executes(Companion::reg$lambda$1), "executes(...)"); register((LiteralArgumentBuilder<FabricClientCommandSource>)ClientCommandManager.literal("onyx").executes(Companion::reg$lambda$1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  60 */       Intrinsics.checkNotNullExpressionValue(((LiteralArgumentBuilder)ClientCommandManager.literal("gmc").executes(Companion::reg$lambda$2)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string())
/*  61 */             .suggests((SuggestionProvider)new PlayerStringSuggestionProvider())
/*  62 */             .executes(Companion::reg$lambda$3)), "then(...)"); register((LiteralArgumentBuilder<FabricClientCommandSource>)((LiteralArgumentBuilder)ClientCommandManager.literal("gmc").executes(Companion::reg$lambda$2)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string()).suggests((SuggestionProvider)new PlayerStringSuggestionProvider()).executes(Companion::reg$lambda$3)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       Intrinsics.checkNotNullExpressionValue(((LiteralArgumentBuilder)ClientCommandManager.literal("gms").executes(Companion::reg$lambda$4)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string())
/*  77 */             .suggests((SuggestionProvider)new PlayerStringSuggestionProvider())
/*  78 */             .executes(Companion::reg$lambda$5)), "then(...)"); register((LiteralArgumentBuilder<FabricClientCommandSource>)((LiteralArgumentBuilder)ClientCommandManager.literal("gms").executes(Companion::reg$lambda$4)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string()).suggests((SuggestionProvider)new PlayerStringSuggestionProvider()).executes(Companion::reg$lambda$5)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       Intrinsics.checkNotNullExpressionValue(((LiteralArgumentBuilder)ClientCommandManager.literal("gmsp").executes(Companion::reg$lambda$6)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string())
/*  93 */             .suggests((SuggestionProvider)new PlayerStringSuggestionProvider())
/*  94 */             .executes(Companion::reg$lambda$7)), "then(...)"); register((LiteralArgumentBuilder<FabricClientCommandSource>)((LiteralArgumentBuilder)ClientCommandManager.literal("gmsp").executes(Companion::reg$lambda$6)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string()).suggests((SuggestionProvider)new PlayerStringSuggestionProvider()).executes(Companion::reg$lambda$7)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       Intrinsics.checkNotNullExpressionValue(((LiteralArgumentBuilder)ClientCommandManager.literal("gma").executes(Companion::reg$lambda$8)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string())
/* 109 */             .suggests((SuggestionProvider)new PlayerStringSuggestionProvider())
/* 110 */             .executes(Companion::reg$lambda$9)), "then(...)"); register((LiteralArgumentBuilder<FabricClientCommandSource>)((LiteralArgumentBuilder)ClientCommandManager.literal("gma").executes(Companion::reg$lambda$8)).then(ClientCommandManager.argument("player", (ArgumentType)StringArgumentType.string()).suggests((SuggestionProvider)new PlayerStringSuggestionProvider()).executes(Companion::reg$lambda$9))); }
/* 111 */     private static final int reg$lambda$5(CommandContext it) { String arg = StringArgumentType.getString(it, "player"); CommandUtils.Companion.sendCommand("gamemode survival " + arg); return 1; } private static final int reg$lambda$9(CommandContext it) { String arg = StringArgumentType.getString(it, "player");
/* 112 */       CommandUtils.Companion.sendCommand("gamemode adventure " + arg);
/* 113 */       return 1; }
/*     */     private static final int reg$lambda$6(CommandContext it) { CommandUtils.Companion.sendCommand("gamemode spectator");
/*     */       return 1; }
/*     */     private static final int reg$lambda$7(CommandContext it) { String arg = StringArgumentType.getString(it, "player");
/*     */       CommandUtils.Companion.sendCommand("gamemode spectator " + arg);
/*     */       return 1; }
/*     */     private static final int reg$lambda$8(CommandContext it) { CommandUtils.Companion.sendCommand("gamemode adventure");
/* 120 */       return 1; } public final void init() { reg();
/* 121 */       ClientCommandRegistrationCallback.EVENT.register(Companion::init$lambda$10); } private static final void init$lambda$10(CommandDispatcher dispatcher, class_7157 param1class_7157) {
/* 122 */       Intrinsics.checkNotNullParameter(dispatcher, "dispatcher"); Intrinsics.checkNotNullParameter(param1class_7157, "<anonymous parameter 1>"); for (LiteralArgumentBuilder cmd : CommandRegistry.commands)
/* 123 */         dispatcher.register(cmd); 
/*     */     }
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   private static final int PASS = 1;
/*     */   @NotNull
/*     */   private static final List<LiteralArgumentBuilder<FabricClientCommandSource>> commands = new ArrayList<>();
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\commands\CommandRegistry.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */