/*    */ package net.integr.commands.suggestors;
/*    */ 
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.suggestion.SuggestionProvider;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
/*    */ import net.integr.Onyx;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\007¢\006\004\b\003\020\004J+\020\013\032\b\022\004\022\0020\n0\t2\f\020\006\032\b\022\004\022\0020\0020\0052\006\020\b\032\0020\007H\026¢\006\004\b\013\020\f¨\006\r"}, d2 = {"Lnet/integr/commands/suggestors/PlayerStringSuggestionProvider;", "Lcom/mojang/brigadier/suggestion/SuggestionProvider;", "Lnet/fabricmc/fabric/api/client/command/v2/FabricClientCommandSource;", "<init>", "()V", "Lcom/mojang/brigadier/context/CommandContext;", "context", "Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;", "builder", "Ljava/util/concurrent/CompletableFuture;", "Lcom/mojang/brigadier/suggestion/Suggestions;", "getSuggestions", "(Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture;", "onyx2"})
/*    */ public final class PlayerStringSuggestionProvider
/*    */   implements SuggestionProvider<FabricClientCommandSource>
/*    */ {
/*    */   @NotNull
/*    */   public CompletableFuture<Suggestions> getSuggestions(@NotNull CommandContext context, @NotNull SuggestionsBuilder builder) {
/* 29 */     Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNullParameter(builder, "builder"); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1576()); Intrinsics.checkNotNullExpressionValue(Onyx.Companion.getMC().method_1576().method_3858(), "getPlayerNames(...)"); String[] arrayOfString; byte b; int i; for (arrayOfString = Onyx.Companion.getMC().method_1576().method_3858(), b = 0, i = arrayOfString.length; b < i; ) { String p = arrayOfString[b]; builder.suggest(p); b++; }
/*    */     
/* 31 */     Intrinsics.checkNotNullExpressionValue(builder.buildFuture(), "buildFuture(...)"); return builder.buildFuture();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\commands\suggestors\PlayerStringSuggestionProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */