/*    */ package net.integr.commands.suggestors;
/*    */ 
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.suggestion.SuggestionProvider;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020 \n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\004\030\0002\b\022\004\022\0020\0020\001B\025\022\f\020\005\032\b\022\004\022\0020\0040\003¢\006\004\b\006\020\007J+\020\016\032\b\022\004\022\0020\r0\f2\f\020\t\032\b\022\004\022\0020\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\016\020\017R\032\020\005\032\b\022\004\022\0020\0040\0038\002X\004¢\006\006\n\004\b\005\020\020¨\006\021"}, d2 = {"Lnet/integr/commands/suggestors/StringSuggestionProvider;", "Lcom/mojang/brigadier/suggestion/SuggestionProvider;", "Lnet/fabricmc/fabric/api/client/command/v2/FabricClientCommandSource;", "", "", "suggestions", "<init>", "(Ljava/util/List;)V", "Lcom/mojang/brigadier/context/CommandContext;", "context", "Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;", "builder", "Ljava/util/concurrent/CompletableFuture;", "Lcom/mojang/brigadier/suggestion/Suggestions;", "getSuggestions", "(Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture;", "Ljava/util/List;", "onyx2"})
/*    */ public final class StringSuggestionProvider
/*    */   implements SuggestionProvider<FabricClientCommandSource>
/*    */ {
/*    */   @NotNull
/*    */   private final List<String> suggestions;
/*    */   
/*    */   public StringSuggestionProvider(@NotNull List<String> suggestions) {
/* 28 */     this.suggestions = suggestions; } @NotNull
/*    */   public CompletableFuture<Suggestions> getSuggestions(@NotNull CommandContext context, @NotNull SuggestionsBuilder builder) {
/* 30 */     Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNullParameter(builder, "builder"); for (String s : this.suggestions) {
/* 31 */       builder.suggest(s);
/*    */     }
/*    */     
/* 34 */     Intrinsics.checkNotNullExpressionValue(builder.buildFuture(), "buildFuture(...)"); return builder.buildFuture();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\commands\suggestors\StringSuggestionProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */