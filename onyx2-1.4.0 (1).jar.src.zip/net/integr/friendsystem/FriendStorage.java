/*    */ package net.integr.friendsystem;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonArray;
/*    */ import com.google.gson.JsonElement;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.LinkOption;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.attribute.FileAttribute;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import kotlin.text.Charsets;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.utilities.LogUtils;
/*    */ import net.integr.utilities.game.notification.NotificationHandler;
/*    */ import net.minecraft.class_1657;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/friendsystem/FriendStorage;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class FriendStorage
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\004\n\002\020\002\n\002\b\004\n\002\020\016\n\002\b\005\n\002\020 \n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\002¢\006\004\b\t\020\nJ\025\020\f\032\0020\0132\006\020\005\032\0020\004¢\006\004\b\f\020\rJ\025\020\016\032\0020\0132\006\020\005\032\0020\004¢\006\004\b\016\020\rJ\r\020\017\032\0020\013¢\006\004\b\017\020\003J\027\020\022\032\0020\0132\006\020\021\032\0020\020H\002¢\006\004\b\022\020\023J\025\020\024\032\0020\0132\006\020\005\032\0020\004¢\006\004\b\024\020\rJ\r\020\025\032\0020\013¢\006\004\b\025\020\003R\034\020\027\032\b\022\004\022\0020\0200\0268\002@\002X\016¢\006\006\n\004\b\027\020\030¨\006\031"}, d2 = {"Lnet/integr/friendsystem/FriendStorage$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_1657;", "player", "", "contains", "(Lnet/minecraft/class_1657;)Z", "exists", "()Z", "", "handleMiddleClickFriend", "(Lnet/minecraft/class_1657;)V", "insert", "load", "", "json", "loadJson", "(Ljava/lang/String;)V", "remove", "save", "", "friends", "Ljava/util/List;", "onyx2"})
/*    */   @SourceDebugExtension({"SMAP\nFriendStorage.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FriendStorage.kt\nnet/integr/friendsystem/FriendStorage$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,93:1\n1549#2:94\n1620#2,3:95\n*S KotlinDebug\n*F\n+ 1 FriendStorage.kt\nnet/integr/friendsystem/FriendStorage$Companion\n*L\n39#1:94\n39#1:95,3\n*E\n"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     private final void loadJson(String json) {
/* 39 */       Intrinsics.checkNotNullExpressionValue((new Gson()).fromJson(json, JsonArray.class), "fromJson(...)"); Iterable $this$map$iv = (Iterable)(new Gson()).fromJson(json, JsonArray.class); int $i$f$map = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 94 */       Iterable iterable1 = $this$map$iv; Collection<String> destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)); int $i$f$mapTo = 0;
/* 95 */       for (Object item$iv$iv : iterable1) {
/* 96 */         JsonElement jsonElement = (JsonElement)item$iv$iv; Collection<String> collection = destination$iv$iv; int $i$a$-map-FriendStorage$Companion$loadJson$1 = 0; collection.add(jsonElement.getAsString());
/* 97 */       }  FriendStorage.friends = (List)destination$iv$iv;
/*    */     }
/*    */     
/*    */     public final void save() {
/*    */       String json = (new GsonBuilder()).setPrettyPrinting().create().toJson(FriendStorage.friends);
/*    */       try {
/*    */         Files.createDirectories(Path.of("" + Onyx.Companion.getCONFIG() + "/friends", new String[0]), (FileAttribute<?>[])new FileAttribute[0]);
/*    */         Intrinsics.checkNotNull(json);
/*    */         String str = json;
/*    */         Intrinsics.checkNotNullExpressionValue(str.getBytes(Charsets.UTF_8), "getBytes(...)");
/*    */         Files.write(Path.of("" + Onyx.Companion.getCONFIG() + "/friends/friends.json", new String[0]), str.getBytes(Charsets.UTF_8), new java.nio.file.OpenOption[0]);
/*    */       } catch (IOException e) {
/*    */         LogUtils.Companion.sendLog("Could not save friends!");
/*    */         e.printStackTrace();
/*    */       } 
/*    */     }
/*    */     
/*    */     private final boolean exists() {
/*    */       Intrinsics.checkNotNullExpressionValue(Path.of("" + Onyx.Companion.getCONFIG() + "/friends/friends.json", new String[0]), "of(...)");
/*    */       Path path = Path.of("" + Onyx.Companion.getCONFIG() + "/friends/friends.json", new String[0]);
/*    */       LinkOption[] arrayOfLinkOption = new LinkOption[0];
/*    */       return Files.exists(path, Arrays.<LinkOption>copyOf(arrayOfLinkOption, arrayOfLinkOption.length));
/*    */     }
/*    */     
/*    */     public final void load() {
/*    */       if (exists()) {
/*    */         String json = Files.readString(Path.of("" + Onyx.Companion.getCONFIG() + "/friends/friends.json", new String[0]));
/*    */         Intrinsics.checkNotNull(json);
/*    */         loadJson(json);
/*    */       } else {
/*    */         save();
/*    */       } 
/*    */       LogUtils.Companion.sendLog("Loaded " + FriendStorage.friends.size() + " friends from saved file!");
/*    */     }
/*    */     
/*    */     public final void insert(@NotNull class_1657 player) {
/*    */       Intrinsics.checkNotNullParameter(player, "player");
/*    */       String name = player.method_7334().getName();
/*    */       if (!FriendStorage.friends.contains(name))
/*    */         FriendStorage.friends = CollectionsKt.plus(FriendStorage.friends, name); 
/*    */     }
/*    */     
/*    */     public final void remove(@NotNull class_1657 player) {
/*    */       Intrinsics.checkNotNullParameter(player, "player");
/*    */       String name = player.method_7334().getName();
/*    */       if (FriendStorage.friends.contains(name))
/*    */         FriendStorage.friends = CollectionsKt.minus(FriendStorage.friends, name); 
/*    */     }
/*    */     
/*    */     public final boolean contains(@NotNull class_1657 player) {
/*    */       Intrinsics.checkNotNullParameter(player, "player");
/*    */       String name = player.method_7334().getName();
/*    */       return FriendStorage.friends.contains(name);
/*    */     }
/*    */     
/*    */     public final void handleMiddleClickFriend(@NotNull class_1657 player) {
/*    */       Intrinsics.checkNotNullParameter(player, "player");
/*    */       String name = player.method_7334().getName();
/*    */       if (FriendStorage.friends.contains(name)) {
/*    */         FriendStorage.friends = CollectionsKt.minus(FriendStorage.friends, name);
/*    */         NotificationHandler.Companion.notify("Removed " + name + " as a Friend");
/*    */       } else {
/*    */         FriendStorage.friends = CollectionsKt.plus(FriendStorage.friends, name);
/*    */         NotificationHandler.Companion.notify("Added " + name + " as a Friend");
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   @NotNull
/*    */   private static List<String> friends = CollectionsKt.emptyList();
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\friendsystem\FriendStorage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */