/*    */ package net.integr;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import net.minecraft.class_1309;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/Variables;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class Variables
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\t\n\002\020\013\n\002\b\b\n\002\030\002\n\002\b\007\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020\006\032\004\b\007\020\b\"\004\b\t\020\nR\"\020\013\032\0020\0048\006@\006X\016¢\006\022\n\004\b\013\020\006\032\004\b\f\020\b\"\004\b\r\020\nR\"\020\017\032\0020\0168\006@\006X\016¢\006\022\n\004\b\017\020\020\032\004\b\021\020\022\"\004\b\023\020\024R\027\020\025\032\0020\0048\006¢\006\f\n\004\b\025\020\006\032\004\b\026\020\bR$\020\030\032\004\030\0010\0278\006@\006X\016¢\006\022\n\004\b\030\020\031\032\004\b\032\020\033\"\004\b\034\020\035¨\006\036"}, d2 = {"Lnet/integr/Variables$Companion;", "", "<init>", "()V", "", "guiBack", "I", "getGuiBack", "()I", "setGuiBack", "(I)V", "guiColor", "getGuiColor", "setGuiColor", "", "guiColorIsRgb", "Z", "getGuiColorIsRgb", "()Z", "setGuiColorIsRgb", "(Z)V", "guiDisabled", "getGuiDisabled", "Lnet/minecraft/class_1309;", "target", "Lnet/minecraft/class_1309;", "getTarget", "()Lnet/minecraft/class_1309;", "setTarget", "(Lnet/minecraft/class_1309;)V", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final int getGuiColor() {
/* 24 */       return Variables.guiColor; } public final void setGuiColor(int <set-?>) { Variables.guiColor = <set-?>; }
/* 25 */     public final int getGuiBack() { return Variables.guiBack; } public final void setGuiBack(int <set-?>) { Variables.guiBack = <set-?>; } public final int getGuiDisabled() {
/* 26 */       return Variables.guiDisabled;
/*    */     }
/* 28 */     public final boolean getGuiColorIsRgb() { return Variables.guiColorIsRgb; } public final void setGuiColorIsRgb(boolean <set-?>) { Variables.guiColorIsRgb = <set-?>; }
/*    */     @Nullable
/* 30 */     public final class_1309 getTarget() { return Variables.target; } public final void setTarget(@Nullable class_1309 <set-?>) { Variables.target = <set-?>; }
/*    */   
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   private static int guiColor = (new Color(0, 0, 0)).getRGB();
/*    */   private static int guiBack = (new Color(25, 24, 24)).getRGB();
/*    */   private static final int guiDisabled = (new Color(151, 151, 151)).getRGB();
/*    */   private static boolean guiColorIsRgb = true;
/*    */   @Nullable
/*    */   private static class_1309 target;
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\Variables.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */