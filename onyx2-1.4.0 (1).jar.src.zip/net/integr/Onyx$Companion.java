/*    */ package net.integr;
/*    */ 
/*    */ import java.nio.file.Path;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import net.minecraft.class_304;
/*    */ import net.minecraft.class_310;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000<\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\006XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\006XT¢\006\006\n\004\b\007\020\006R\027\020\t\032\0020\b8\006¢\006\f\n\004\b\t\020\n\032\004\b\013\020\fR\"\020\016\032\0020\r8\006@\006X\016¢\006\022\n\004\b\016\020\017\032\004\b\020\020\021\"\004\b\022\020\023R\024\020\024\032\0020\0048\006XT¢\006\006\n\004\b\024\020\006R\027\020\026\032\0020\0258\006¢\006\f\n\004\b\026\020\027\032\004\b\030\020\031R\027\020\033\032\0020\0328\006¢\006\f\n\004\b\033\020\034\032\004\b\035\020\036R\027\020\037\032\0020\0048\006¢\006\f\n\004\b\037\020\006\032\004\b \020!R$\020#\032\004\030\0010\"8\006@\006X\016¢\006\022\n\004\b#\020$\032\004\b%\020&\"\004\b'\020(¨\006)"}, d2 = {"Lnet/integr/Onyx$Companion;", "", "<init>", "()V", "", "CLIENT_ID", "Ljava/lang/String;", "CLIENT_NAME", "Ljava/nio/file/Path;", "CONFIG", "Ljava/nio/file/Path;", "getCONFIG", "()Ljava/nio/file/Path;", "", "DEV_MODE", "Z", "getDEV_MODE", "()Z", "setDEV_MODE", "(Z)V", "DISCORD_ID", "Lorg/slf4j/Logger;", "LOGGER", "Lorg/slf4j/Logger;", "getLOGGER", "()Lorg/slf4j/Logger;", "Lnet/minecraft/class_310;", "MC", "Lnet/minecraft/class_310;", "getMC", "()Lnet/minecraft/class_310;", "VERSION", "getVERSION", "()Ljava/lang/String;", "Lnet/minecraft/class_304;", "openKey", "Lnet/minecraft/class_304;", "getOpenKey", "()Lnet/minecraft/class_304;", "setOpenKey", "(Lnet/minecraft/class_304;)V", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final class_310 getMC() {
/* 89 */     return Onyx.access$getMC$cp(); } @NotNull
/* 90 */   public final Logger getLOGGER() { return Onyx.access$getLOGGER$cp(); } @NotNull
/* 91 */   public final String getVERSION() { return Onyx.access$getVERSION$cp(); } @NotNull
/* 92 */   public final Path getCONFIG() { return Onyx.access$getCONFIG$cp(); }
/*    */ 
/*    */   
/*    */   public final boolean getDEV_MODE() {
/* 96 */     return Onyx.access$getDEV_MODE$cp(); } public final void setDEV_MODE(boolean <set-?>) { Onyx.access$setDEV_MODE$cp(<set-?>); }
/*    */   @Nullable
/* 98 */   public final class_304 getOpenKey() { return Onyx.access$getOpenKey$cp(); } public final void setOpenKey(@Nullable class_304 <set-?>) { Onyx.access$setOpenKey$cp(<set-?>); }
/*    */ 
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\Onyx$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */