/*     */ package net.integr.eventsystem;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Reflection;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.text.StringsKt;
/*     */ import net.integr.utilities.LogUtils;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020%\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\006\032\004\030\0010\0012\006\020\005\032\0020\004¢\006\004\b\006\020\007J\025\020\n\032\0020\t2\006\020\b\032\0020\001¢\006\004\b\n\020\013J\031\020\n\032\0020\t2\n\020\r\032\006\022\002\b\0030\f¢\006\004\b\n\020\016J!\020\n\032\0020\t2\n\020\r\032\006\022\002\b\0030\f2\006\020\b\032\0020\001¢\006\004\b\n\020\017J\025\020\020\032\0020\t2\006\020\b\032\0020\001¢\006\004\b\020\020\013J\031\020\020\032\0020\t2\n\020\r\032\006\022\002\b\0030\f¢\006\004\b\020\020\016R&\020\023\032\022\022\b\022\006\022\002\b\0030\022\022\004\022\0020\0010\0218\002@\002X\016¢\006\006\n\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/eventsystem/EventSystem$Companion;", "", "<init>", "()V", "Lnet/integr/eventsystem/Event;", "event", "post", "(Lnet/integr/eventsystem/Event;)Ljava/lang/Object;", "instance", "", "register", "(Ljava/lang/Object;)V", "Lkotlin/reflect/KClass;", "klass", "(Lkotlin/reflect/KClass;)V", "(Lkotlin/reflect/KClass;Ljava/lang/Object;)V", "unRegister", "", "Lkotlin/reflect/KCallable;", "receivers", "Ljava/util/Map;", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nEventSystem.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EventSystem.kt\nnet/integr/eventsystem/EventSystem$Companion\n+ 2 KAnnotatedElements.kt\nkotlin/reflect/full/KAnnotatedElements\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,95:1\n29#2:96\n20#2:97\n29#2:100\n20#2:101\n29#2:104\n20#2:105\n29#2:108\n20#2:109\n29#2:112\n20#2:113\n288#3,2:98\n288#3,2:102\n288#3,2:106\n288#3,2:110\n288#3,2:114\n1045#3:116\n*S KotlinDebug\n*F\n+ 1 EventSystem.kt\nnet/integr/eventsystem/EventSystem$Companion\n*L\n35#1:96\n35#1:97\n43#1:100\n43#1:101\n51#1:104\n51#1:105\n59#1:108\n59#1:109\n67#1:112\n67#1:113\n35#1:98,2\n43#1:102,2\n51#1:106,2\n59#1:110,2\n67#1:114,2\n75#1:116\n*E\n"})
/*     */ public final class Companion
/*     */ {
/*     */   private Companion() {}
/*     */   
/*     */   public final void register(@NotNull KClass klass) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'klass'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_1
/*     */     //   7: invokeinterface getMembers : ()Ljava/util/Collection;
/*     */     //   12: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   17: astore_2
/*     */     //   18: aload_2
/*     */     //   19: invokeinterface hasNext : ()Z
/*     */     //   24: ifeq -> 156
/*     */     //   27: aload_2
/*     */     //   28: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   33: checkcast kotlin/reflect/KCallable
/*     */     //   36: astore_3
/*     */     //   37: aload_3
/*     */     //   38: checkcast kotlin/reflect/KAnnotatedElement
/*     */     //   41: astore #4
/*     */     //   43: iconst_0
/*     */     //   44: istore #5
/*     */     //   46: aload #4
/*     */     //   48: astore #6
/*     */     //   50: iconst_0
/*     */     //   51: istore #7
/*     */     //   53: aload #6
/*     */     //   55: invokeinterface getAnnotations : ()Ljava/util/List;
/*     */     //   60: checkcast java/lang/Iterable
/*     */     //   63: astore #8
/*     */     //   65: iconst_0
/*     */     //   66: istore #9
/*     */     //   68: aload #8
/*     */     //   70: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   75: astore #10
/*     */     //   77: aload #10
/*     */     //   79: invokeinterface hasNext : ()Z
/*     */     //   84: ifeq -> 119
/*     */     //   87: aload #10
/*     */     //   89: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   94: astore #11
/*     */     //   96: aload #11
/*     */     //   98: checkcast java/lang/annotation/Annotation
/*     */     //   101: astore #12
/*     */     //   103: iconst_0
/*     */     //   104: istore #13
/*     */     //   106: aload #12
/*     */     //   108: instanceof net/integr/eventsystem/EventListen
/*     */     //   111: ifeq -> 77
/*     */     //   114: aload #11
/*     */     //   116: goto -> 120
/*     */     //   119: aconst_null
/*     */     //   120: checkcast net/integr/eventsystem/EventListen
/*     */     //   123: checkcast java/lang/annotation/Annotation
/*     */     //   126: nop
/*     */     //   127: ifnull -> 134
/*     */     //   130: iconst_1
/*     */     //   131: goto -> 135
/*     */     //   134: iconst_0
/*     */     //   135: nop
/*     */     //   136: ifeq -> 18
/*     */     //   139: invokestatic access$getReceivers$cp : ()Ljava/util/Map;
/*     */     //   142: aload_3
/*     */     //   143: aload_1
/*     */     //   144: invokestatic createInstance : (Lkotlin/reflect/KClass;)Ljava/lang/Object;
/*     */     //   147: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   152: pop
/*     */     //   153: goto -> 18
/*     */     //   156: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #34	-> 6
/*     */     //   #35	-> 37
/*     */     //   #96	-> 46
/*     */     //   #97	-> 53
/*     */     //   #98	-> 68
/*     */     //   #97	-> 106
/*     */     //   #98	-> 111
/*     */     //   #99	-> 119
/*     */     //   #97	-> 126
/*     */     //   #96	-> 135
/*     */     //   #35	-> 136
/*     */     //   #36	-> 139
/*     */     //   #39	-> 156
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   43	93	4	$this$hasAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   46	90	5	$i$f$hasAnnotation	I
/*     */     //   50	77	6	$this$findAnnotation$iv$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   53	74	7	$i$f$findAnnotation	I
/*     */     //   65	55	8	$this$firstOrNull$iv$iv$iv	Ljava/lang/Iterable;
/*     */     //   68	52	9	$i$f$firstOrNull	I
/*     */     //   96	23	11	element$iv$iv$iv	Ljava/lang/Object;
/*     */     //   103	8	12	it$iv$iv	Ljava/lang/annotation/Annotation;
/*     */     //   106	5	13	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv$iv	I
/*     */     //   37	116	3	m	Lkotlin/reflect/KCallable;
/*     */     //   0	157	0	this	Lnet/integr/eventsystem/EventSystem$Companion;
/*     */     //   0	157	1	klass	Lkotlin/reflect/KClass;
/*     */   }
/*     */   
/*     */   public final void register(@NotNull KClass klass, @NotNull Object instance) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'klass'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_2
/*     */     //   7: ldc 'instance'
/*     */     //   9: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   12: aload_1
/*     */     //   13: invokeinterface getMembers : ()Ljava/util/Collection;
/*     */     //   18: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   23: astore_3
/*     */     //   24: aload_3
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 162
/*     */     //   33: aload_3
/*     */     //   34: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   39: checkcast kotlin/reflect/KCallable
/*     */     //   42: astore #4
/*     */     //   44: aload #4
/*     */     //   46: checkcast kotlin/reflect/KAnnotatedElement
/*     */     //   49: astore #5
/*     */     //   51: iconst_0
/*     */     //   52: istore #6
/*     */     //   54: aload #5
/*     */     //   56: astore #7
/*     */     //   58: iconst_0
/*     */     //   59: istore #8
/*     */     //   61: aload #7
/*     */     //   63: invokeinterface getAnnotations : ()Ljava/util/List;
/*     */     //   68: checkcast java/lang/Iterable
/*     */     //   71: astore #9
/*     */     //   73: iconst_0
/*     */     //   74: istore #10
/*     */     //   76: aload #9
/*     */     //   78: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   83: astore #11
/*     */     //   85: aload #11
/*     */     //   87: invokeinterface hasNext : ()Z
/*     */     //   92: ifeq -> 127
/*     */     //   95: aload #11
/*     */     //   97: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   102: astore #12
/*     */     //   104: aload #12
/*     */     //   106: checkcast java/lang/annotation/Annotation
/*     */     //   109: astore #13
/*     */     //   111: iconst_0
/*     */     //   112: istore #14
/*     */     //   114: aload #13
/*     */     //   116: instanceof net/integr/eventsystem/EventListen
/*     */     //   119: ifeq -> 85
/*     */     //   122: aload #12
/*     */     //   124: goto -> 128
/*     */     //   127: aconst_null
/*     */     //   128: checkcast net/integr/eventsystem/EventListen
/*     */     //   131: checkcast java/lang/annotation/Annotation
/*     */     //   134: nop
/*     */     //   135: ifnull -> 142
/*     */     //   138: iconst_1
/*     */     //   139: goto -> 143
/*     */     //   142: iconst_0
/*     */     //   143: nop
/*     */     //   144: ifeq -> 24
/*     */     //   147: invokestatic access$getReceivers$cp : ()Ljava/util/Map;
/*     */     //   150: aload #4
/*     */     //   152: aload_2
/*     */     //   153: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   158: pop
/*     */     //   159: goto -> 24
/*     */     //   162: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #42	-> 12
/*     */     //   #43	-> 44
/*     */     //   #100	-> 54
/*     */     //   #101	-> 61
/*     */     //   #102	-> 76
/*     */     //   #101	-> 114
/*     */     //   #102	-> 119
/*     */     //   #103	-> 127
/*     */     //   #101	-> 134
/*     */     //   #100	-> 143
/*     */     //   #43	-> 144
/*     */     //   #44	-> 147
/*     */     //   #47	-> 162
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   51	93	5	$this$hasAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   54	90	6	$i$f$hasAnnotation	I
/*     */     //   58	77	7	$this$findAnnotation$iv$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   61	74	8	$i$f$findAnnotation	I
/*     */     //   73	55	9	$this$firstOrNull$iv$iv$iv	Ljava/lang/Iterable;
/*     */     //   76	52	10	$i$f$firstOrNull	I
/*     */     //   104	23	12	element$iv$iv$iv	Ljava/lang/Object;
/*     */     //   111	8	13	it$iv$iv	Ljava/lang/annotation/Annotation;
/*     */     //   114	5	14	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv$iv	I
/*     */     //   44	115	4	m	Lkotlin/reflect/KCallable;
/*     */     //   0	163	0	this	Lnet/integr/eventsystem/EventSystem$Companion;
/*     */     //   0	163	1	klass	Lkotlin/reflect/KClass;
/*     */     //   0	163	2	instance	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public final void register(@NotNull Object instance) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'instance'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_1
/*     */     //   7: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   10: invokestatic getOrCreateKotlinClass : (Ljava/lang/Class;)Lkotlin/reflect/KClass;
/*     */     //   13: invokeinterface getMembers : ()Ljava/util/Collection;
/*     */     //   18: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   23: astore_2
/*     */     //   24: aload_2
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 159
/*     */     //   33: aload_2
/*     */     //   34: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   39: checkcast kotlin/reflect/KCallable
/*     */     //   42: astore_3
/*     */     //   43: aload_3
/*     */     //   44: checkcast kotlin/reflect/KAnnotatedElement
/*     */     //   47: astore #4
/*     */     //   49: iconst_0
/*     */     //   50: istore #5
/*     */     //   52: aload #4
/*     */     //   54: astore #6
/*     */     //   56: iconst_0
/*     */     //   57: istore #7
/*     */     //   59: aload #6
/*     */     //   61: invokeinterface getAnnotations : ()Ljava/util/List;
/*     */     //   66: checkcast java/lang/Iterable
/*     */     //   69: astore #8
/*     */     //   71: iconst_0
/*     */     //   72: istore #9
/*     */     //   74: aload #8
/*     */     //   76: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   81: astore #10
/*     */     //   83: aload #10
/*     */     //   85: invokeinterface hasNext : ()Z
/*     */     //   90: ifeq -> 125
/*     */     //   93: aload #10
/*     */     //   95: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   100: astore #11
/*     */     //   102: aload #11
/*     */     //   104: checkcast java/lang/annotation/Annotation
/*     */     //   107: astore #12
/*     */     //   109: iconst_0
/*     */     //   110: istore #13
/*     */     //   112: aload #12
/*     */     //   114: instanceof net/integr/eventsystem/EventListen
/*     */     //   117: ifeq -> 83
/*     */     //   120: aload #11
/*     */     //   122: goto -> 126
/*     */     //   125: aconst_null
/*     */     //   126: checkcast net/integr/eventsystem/EventListen
/*     */     //   129: checkcast java/lang/annotation/Annotation
/*     */     //   132: nop
/*     */     //   133: ifnull -> 140
/*     */     //   136: iconst_1
/*     */     //   137: goto -> 141
/*     */     //   140: iconst_0
/*     */     //   141: nop
/*     */     //   142: ifeq -> 24
/*     */     //   145: invokestatic access$getReceivers$cp : ()Ljava/util/Map;
/*     */     //   148: aload_3
/*     */     //   149: aload_1
/*     */     //   150: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   155: pop
/*     */     //   156: goto -> 24
/*     */     //   159: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #50	-> 6
/*     */     //   #51	-> 43
/*     */     //   #104	-> 52
/*     */     //   #105	-> 59
/*     */     //   #106	-> 74
/*     */     //   #105	-> 112
/*     */     //   #106	-> 117
/*     */     //   #107	-> 125
/*     */     //   #105	-> 132
/*     */     //   #104	-> 141
/*     */     //   #51	-> 142
/*     */     //   #52	-> 145
/*     */     //   #55	-> 159
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   49	93	4	$this$hasAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   52	90	5	$i$f$hasAnnotation	I
/*     */     //   56	77	6	$this$findAnnotation$iv$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   59	74	7	$i$f$findAnnotation	I
/*     */     //   71	55	8	$this$firstOrNull$iv$iv$iv	Ljava/lang/Iterable;
/*     */     //   74	52	9	$i$f$firstOrNull	I
/*     */     //   102	23	11	element$iv$iv$iv	Ljava/lang/Object;
/*     */     //   109	8	12	it$iv$iv	Ljava/lang/annotation/Annotation;
/*     */     //   112	5	13	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv$iv	I
/*     */     //   43	113	3	m	Lkotlin/reflect/KCallable;
/*     */     //   0	160	0	this	Lnet/integr/eventsystem/EventSystem$Companion;
/*     */     //   0	160	1	instance	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public final void unRegister(@NotNull KClass klass) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'klass'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_1
/*     */     //   7: invokeinterface getMembers : ()Ljava/util/Collection;
/*     */     //   12: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   17: astore_2
/*     */     //   18: aload_2
/*     */     //   19: invokeinterface hasNext : ()Z
/*     */     //   24: ifeq -> 152
/*     */     //   27: aload_2
/*     */     //   28: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   33: checkcast kotlin/reflect/KCallable
/*     */     //   36: astore_3
/*     */     //   37: aload_3
/*     */     //   38: checkcast kotlin/reflect/KAnnotatedElement
/*     */     //   41: astore #4
/*     */     //   43: iconst_0
/*     */     //   44: istore #5
/*     */     //   46: aload #4
/*     */     //   48: astore #6
/*     */     //   50: iconst_0
/*     */     //   51: istore #7
/*     */     //   53: aload #6
/*     */     //   55: invokeinterface getAnnotations : ()Ljava/util/List;
/*     */     //   60: checkcast java/lang/Iterable
/*     */     //   63: astore #8
/*     */     //   65: iconst_0
/*     */     //   66: istore #9
/*     */     //   68: aload #8
/*     */     //   70: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   75: astore #10
/*     */     //   77: aload #10
/*     */     //   79: invokeinterface hasNext : ()Z
/*     */     //   84: ifeq -> 119
/*     */     //   87: aload #10
/*     */     //   89: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   94: astore #11
/*     */     //   96: aload #11
/*     */     //   98: checkcast java/lang/annotation/Annotation
/*     */     //   101: astore #12
/*     */     //   103: iconst_0
/*     */     //   104: istore #13
/*     */     //   106: aload #12
/*     */     //   108: instanceof net/integr/eventsystem/EventListen
/*     */     //   111: ifeq -> 77
/*     */     //   114: aload #11
/*     */     //   116: goto -> 120
/*     */     //   119: aconst_null
/*     */     //   120: checkcast net/integr/eventsystem/EventListen
/*     */     //   123: checkcast java/lang/annotation/Annotation
/*     */     //   126: nop
/*     */     //   127: ifnull -> 134
/*     */     //   130: iconst_1
/*     */     //   131: goto -> 135
/*     */     //   134: iconst_0
/*     */     //   135: nop
/*     */     //   136: ifeq -> 18
/*     */     //   139: invokestatic access$getReceivers$cp : ()Ljava/util/Map;
/*     */     //   142: aload_3
/*     */     //   143: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   148: pop
/*     */     //   149: goto -> 18
/*     */     //   152: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #58	-> 6
/*     */     //   #59	-> 37
/*     */     //   #108	-> 46
/*     */     //   #109	-> 53
/*     */     //   #110	-> 68
/*     */     //   #109	-> 106
/*     */     //   #110	-> 111
/*     */     //   #111	-> 119
/*     */     //   #109	-> 126
/*     */     //   #108	-> 135
/*     */     //   #59	-> 136
/*     */     //   #60	-> 139
/*     */     //   #63	-> 152
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   43	93	4	$this$hasAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   46	90	5	$i$f$hasAnnotation	I
/*     */     //   50	77	6	$this$findAnnotation$iv$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   53	74	7	$i$f$findAnnotation	I
/*     */     //   65	55	8	$this$firstOrNull$iv$iv$iv	Ljava/lang/Iterable;
/*     */     //   68	52	9	$i$f$firstOrNull	I
/*     */     //   96	23	11	element$iv$iv$iv	Ljava/lang/Object;
/*     */     //   103	8	12	it$iv$iv	Ljava/lang/annotation/Annotation;
/*     */     //   106	5	13	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv$iv	I
/*     */     //   37	112	3	m	Lkotlin/reflect/KCallable;
/*     */     //   0	153	0	this	Lnet/integr/eventsystem/EventSystem$Companion;
/*     */     //   0	153	1	klass	Lkotlin/reflect/KClass;
/*     */   }
/*     */   
/*     */   public final void unRegister(@NotNull Object instance) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'instance'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_1
/*     */     //   7: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   10: invokestatic getOrCreateKotlinClass : (Ljava/lang/Class;)Lkotlin/reflect/KClass;
/*     */     //   13: invokeinterface getMembers : ()Ljava/util/Collection;
/*     */     //   18: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   23: astore_2
/*     */     //   24: aload_2
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 158
/*     */     //   33: aload_2
/*     */     //   34: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   39: checkcast kotlin/reflect/KCallable
/*     */     //   42: astore_3
/*     */     //   43: aload_3
/*     */     //   44: checkcast kotlin/reflect/KAnnotatedElement
/*     */     //   47: astore #4
/*     */     //   49: iconst_0
/*     */     //   50: istore #5
/*     */     //   52: aload #4
/*     */     //   54: astore #6
/*     */     //   56: iconst_0
/*     */     //   57: istore #7
/*     */     //   59: aload #6
/*     */     //   61: invokeinterface getAnnotations : ()Ljava/util/List;
/*     */     //   66: checkcast java/lang/Iterable
/*     */     //   69: astore #8
/*     */     //   71: iconst_0
/*     */     //   72: istore #9
/*     */     //   74: aload #8
/*     */     //   76: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   81: astore #10
/*     */     //   83: aload #10
/*     */     //   85: invokeinterface hasNext : ()Z
/*     */     //   90: ifeq -> 125
/*     */     //   93: aload #10
/*     */     //   95: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   100: astore #11
/*     */     //   102: aload #11
/*     */     //   104: checkcast java/lang/annotation/Annotation
/*     */     //   107: astore #12
/*     */     //   109: iconst_0
/*     */     //   110: istore #13
/*     */     //   112: aload #12
/*     */     //   114: instanceof net/integr/eventsystem/EventListen
/*     */     //   117: ifeq -> 83
/*     */     //   120: aload #11
/*     */     //   122: goto -> 126
/*     */     //   125: aconst_null
/*     */     //   126: checkcast net/integr/eventsystem/EventListen
/*     */     //   129: checkcast java/lang/annotation/Annotation
/*     */     //   132: nop
/*     */     //   133: ifnull -> 140
/*     */     //   136: iconst_1
/*     */     //   137: goto -> 141
/*     */     //   140: iconst_0
/*     */     //   141: nop
/*     */     //   142: ifeq -> 24
/*     */     //   145: invokestatic access$getReceivers$cp : ()Ljava/util/Map;
/*     */     //   148: aload_3
/*     */     //   149: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   154: pop
/*     */     //   155: goto -> 24
/*     */     //   158: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #66	-> 6
/*     */     //   #67	-> 43
/*     */     //   #112	-> 52
/*     */     //   #113	-> 59
/*     */     //   #114	-> 74
/*     */     //   #113	-> 112
/*     */     //   #114	-> 117
/*     */     //   #115	-> 125
/*     */     //   #113	-> 132
/*     */     //   #112	-> 141
/*     */     //   #67	-> 142
/*     */     //   #68	-> 145
/*     */     //   #71	-> 158
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   49	93	4	$this$hasAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   52	90	5	$i$f$hasAnnotation	I
/*     */     //   56	77	6	$this$findAnnotation$iv$iv	Lkotlin/reflect/KAnnotatedElement;
/*     */     //   59	74	7	$i$f$findAnnotation	I
/*     */     //   71	55	8	$this$firstOrNull$iv$iv$iv	Ljava/lang/Iterable;
/*     */     //   74	52	9	$i$f$firstOrNull	I
/*     */     //   102	23	11	element$iv$iv$iv	Ljava/lang/Object;
/*     */     //   109	8	12	it$iv$iv	Ljava/lang/annotation/Annotation;
/*     */     //   112	5	13	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv$iv	I
/*     */     //   43	112	3	m	Lkotlin/reflect/KCallable;
/*     */     //   0	159	0	this	Lnet/integr/eventsystem/EventSystem$Companion;
/*     */     //   0	159	1	instance	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public final Object post(@NotNull Event event) {
/*  74 */     Intrinsics.checkNotNullParameter(event, "event"); try {
/*  75 */       Iterable $this$sortedBy$iv = EventSystem.access$getReceivers$cp().keySet(); int $i$f$sortedBy = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       for (KCallable m : CollectionsKt.sortedWith($this$sortedBy$iv, new EventSystem$Companion$post$$inlined$sortedBy$1())) {
/*     */         if (m.getParameters().size() > 2) {
/*     */           Intrinsics.checkNotNullExpressionValue(m.getClass().getDeclaringClass(), "getDeclaringClass(...)");
/*     */           throw new IllegalArgumentException("Only one parameter is allowed at " + JvmClassMappingKt.getKotlinClass(m.getClass().getDeclaringClass()).getSimpleName() + "." + m.getName() + "()");
/*     */         } 
/*     */         if (Intrinsics.areEqual(StringsKt.substringAfterLast$default(((KParameter)m.getParameters().get(1)).getType().toString(), '.', null, 2, null), Reflection.getOrCreateKotlinClass(event.getClass()).getSimpleName())) {
/*     */           try {
/*     */             Object[] arrayOfObject = new Object[2];
/*     */             arrayOfObject[0] = EventSystem.access$getReceivers$cp().get(m);
/*     */             arrayOfObject[1] = event;
/*     */             m.call(arrayOfObject);
/*     */           } catch (InvocationTargetException ex) {
/*     */             LogUtils.Companion.sendLog("Fatal Error during event!");
/*     */             ex.getTargetException().printStackTrace();
/*     */           } 
/*     */           if (event.isCancelled())
/*     */             break; 
/*     */         } 
/*     */       } 
/*     */       return event.getCallback();
/*     */     } catch (Exception exception) {
/*     */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\eventsystem\EventSystem$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */