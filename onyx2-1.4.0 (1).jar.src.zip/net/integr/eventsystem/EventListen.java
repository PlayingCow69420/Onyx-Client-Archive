package net.integr.eventsystem;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;
import kotlin.annotation.AnnotationTarget;
import kotlin.annotation.Target;

@Target(allowedTargets = {AnnotationTarget.FUNCTION})
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
@Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\020\033\n\002\030\002\n\002\b\005\b\002\030\0002\0020\001B\021\022\b\b\002\020\003\032\0020\002¢\006\004\b\004\020\005R\021\020\003\032\0020\0028\006¢\006\006\032\004\b\003\020\006¨\006\007"}, d2 = {"Lnet/integr/eventsystem/EventListen;", "", "Lnet/integr/eventsystem/Priority;", "prio", "<init>", "(Lnet/integr/eventsystem/Priority;)V", "()Lnet/integr/eventsystem/Priority;", "onyx2"})
public @interface EventListen {
  Priority prio() default Priority.NORMAL;
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\eventsystem\EventListen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */