package net.integr.eventsystem;

import java.util.Comparator;
import kotlin.Metadata;
import kotlin.jvm.internal.SourceDebugExtension;

@Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\b\004\n\002\020\b\n\002\b\004\020\b\032\0020\004\"\004\b\000\020\0002\016\020\002\032\n \001*\004\030\0018\0008\0002\016\020\003\032\n \001*\004\030\0018\0008\000H\n¢\006\004\b\005\020\006¨\006\007"}, d2 = {"T", "kotlin.jvm.PlatformType", "a", "b", "", "compare", "(Ljava/lang/Object;Ljava/lang/Object;)I", "kotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2", "<anonymous>"})
@SourceDebugExtension({"SMAP\nComparisons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Comparisons.kt\nkotlin/comparisons/ComparisonsKt__ComparisonsKt$compareBy$2\n+ 2 EventSystem.kt\nnet/integr/eventsystem/EventSystem$Companion\n+ 3 KAnnotatedElements.kt\nkotlin/reflect/full/KAnnotatedElements\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,328:1\n75#2:329\n20#3:330\n288#4,2:331\n*S KotlinDebug\n*F\n+ 1 EventSystem.kt\nnet/integr/eventsystem/EventSystem$Companion\n*L\n75#1:330\n75#1:331,2\n*E\n"})
public final class EventSystem$Companion$post$$inlined$sortedBy$1<T> implements Comparator {
  public final int compare(Object a, Object b) {
    // Byte code:
    //   0: aload_1
    //   1: checkcast kotlin/reflect/KCallable
    //   4: astore_3
    //   5: iconst_0
    //   6: istore #4
    //   8: aload_3
    //   9: checkcast kotlin/reflect/KAnnotatedElement
    //   12: astore #5
    //   14: iconst_0
    //   15: istore #6
    //   17: aload #5
    //   19: invokeinterface getAnnotations : ()Ljava/util/List;
    //   24: checkcast java/lang/Iterable
    //   27: astore #7
    //   29: iconst_0
    //   30: istore #8
    //   32: aload #7
    //   34: invokeinterface iterator : ()Ljava/util/Iterator;
    //   39: astore #9
    //   41: aload #9
    //   43: invokeinterface hasNext : ()Z
    //   48: ifeq -> 83
    //   51: aload #9
    //   53: invokeinterface next : ()Ljava/lang/Object;
    //   58: astore #10
    //   60: aload #10
    //   62: checkcast java/lang/annotation/Annotation
    //   65: astore #11
    //   67: iconst_0
    //   68: istore #12
    //   70: aload #11
    //   72: instanceof net/integr/eventsystem/EventListen
    //   75: ifeq -> 41
    //   78: aload #10
    //   80: goto -> 84
    //   83: aconst_null
    //   84: checkcast net/integr/eventsystem/EventListen
    //   87: checkcast java/lang/annotation/Annotation
    //   90: nop
    //   91: checkcast net/integr/eventsystem/EventListen
    //   94: dup
    //   95: ifnull -> 106
    //   98: invokeinterface prio : ()Lnet/integr/eventsystem/Priority;
    //   103: goto -> 108
    //   106: pop
    //   107: aconst_null
    //   108: checkcast java/lang/Comparable
    //   111: aload_2
    //   112: checkcast kotlin/reflect/KCallable
    //   115: astore_3
    //   116: astore #13
    //   118: iconst_0
    //   119: istore #4
    //   121: aload_3
    //   122: checkcast kotlin/reflect/KAnnotatedElement
    //   125: astore #5
    //   127: iconst_0
    //   128: istore #6
    //   130: aload #5
    //   132: invokeinterface getAnnotations : ()Ljava/util/List;
    //   137: checkcast java/lang/Iterable
    //   140: astore #7
    //   142: iconst_0
    //   143: istore #8
    //   145: aload #7
    //   147: invokeinterface iterator : ()Ljava/util/Iterator;
    //   152: astore #9
    //   154: aload #9
    //   156: invokeinterface hasNext : ()Z
    //   161: ifeq -> 196
    //   164: aload #9
    //   166: invokeinterface next : ()Ljava/lang/Object;
    //   171: astore #10
    //   173: aload #10
    //   175: checkcast java/lang/annotation/Annotation
    //   178: astore #11
    //   180: iconst_0
    //   181: istore #12
    //   183: aload #11
    //   185: instanceof net/integr/eventsystem/EventListen
    //   188: ifeq -> 154
    //   191: aload #10
    //   193: goto -> 197
    //   196: aconst_null
    //   197: checkcast net/integr/eventsystem/EventListen
    //   200: checkcast java/lang/annotation/Annotation
    //   203: nop
    //   204: checkcast net/integr/eventsystem/EventListen
    //   207: dup
    //   208: ifnull -> 219
    //   211: invokeinterface prio : ()Lnet/integr/eventsystem/Priority;
    //   216: goto -> 221
    //   219: pop
    //   220: aconst_null
    //   221: aload #13
    //   223: swap
    //   224: checkcast java/lang/Comparable
    //   227: invokestatic compareValues : (Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    //   230: ireturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #102	-> 0
    //   #329	-> 8
    //   #330	-> 17
    //   #331	-> 32
    //   #330	-> 70
    //   #331	-> 75
    //   #332	-> 83
    //   #330	-> 90
    //   #329	-> 91
    //   #102	-> 108
    //   #329	-> 121
    //   #330	-> 130
    //   #331	-> 145
    //   #330	-> 183
    //   #331	-> 188
    //   #332	-> 196
    //   #330	-> 203
    //   #329	-> 204
    //   #102	-> 224
    //   #102	-> 230
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   14	77	5	$this$findAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
    //   17	74	6	$i$f$findAnnotation	I
    //   29	55	7	$this$firstOrNull$iv$iv	Ljava/lang/Iterable;
    //   32	52	8	$i$f$firstOrNull	I
    //   60	23	10	element$iv$iv	Ljava/lang/Object;
    //   67	8	11	it$iv	Ljava/lang/annotation/Annotation;
    //   70	5	12	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv	I
    //   8	100	4	$i$a$-sortedBy-EventSystem$Companion$post$1	I
    //   5	103	3	it	Lkotlin/reflect/KCallable;
    //   127	77	5	$this$findAnnotation$iv	Lkotlin/reflect/KAnnotatedElement;
    //   130	74	6	$i$f$findAnnotation	I
    //   142	55	7	$this$firstOrNull$iv$iv	Ljava/lang/Iterable;
    //   145	52	8	$i$f$firstOrNull	I
    //   173	23	10	element$iv$iv	Ljava/lang/Object;
    //   180	8	11	it$iv	Ljava/lang/annotation/Annotation;
    //   183	5	12	$i$a$-firstOrNull-KAnnotatedElements$findAnnotation$1$iv	I
    //   121	100	4	$i$a$-sortedBy-EventSystem$Companion$post$1	I
    //   118	103	3	it	Lkotlin/reflect/KCallable;
    //   0	231	0	this	Lnet/integr/eventsystem/EventSystem$Companion$post$$inlined$sortedBy$1;
    //   0	231	1	a	Ljava/lang/Object;
    //   0	231	2	b	Ljava/lang/Object;
  }
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\eventsystem\EventSystem$Companion$post$$inlined$sortedBy$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */