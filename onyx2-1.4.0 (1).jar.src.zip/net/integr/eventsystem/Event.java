/*    */ package net.integr.eventsystem;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\002\b\003\n\002\020\013\n\002\b\t\b\026\030\0002\0020\001B\007¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003J\017\020\006\032\004\030\0010\001¢\006\004\b\006\020\007J\r\020\t\032\0020\b¢\006\004\b\t\020\nJ\027\020\f\032\0020\0042\b\020\013\032\004\030\0010\001¢\006\004\b\f\020\rR\030\020\016\032\004\030\0010\0018\002@\002X\016¢\006\006\n\004\b\016\020\017R\026\020\t\032\0020\b8\002@\002X\016¢\006\006\n\004\b\t\020\020¨\006\021"}, d2 = {"Lnet/integr/eventsystem/Event;", "", "<init>", "()V", "", "cancel", "getCallback", "()Ljava/lang/Object;", "", "isCancelled", "()Z", "v", "setCallback", "(Ljava/lang/Object;)V", "callback", "Ljava/lang/Object;", "Z", "onyx2"})
/*    */ public class Event
/*    */ {
/*    */   @Nullable
/*    */   private Object callback;
/*    */   private boolean isCancelled;
/*    */   
/*    */   public final void setCallback(@Nullable Object v) {
/* 24 */     this.callback = v;
/*    */   }
/*    */   
/*    */   public final void cancel() {
/* 28 */     this.isCancelled = true;
/*    */   } @Nullable
/*    */   public final Object getCallback() {
/* 31 */     return this.callback;
/*    */   } public final boolean isCancelled() {
/* 33 */     return this.isCancelled;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\eventsystem\Event.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */