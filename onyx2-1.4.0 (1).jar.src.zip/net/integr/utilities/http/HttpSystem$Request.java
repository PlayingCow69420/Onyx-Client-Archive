/*     */ package net.integr.utilities.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.http.HttpRequest;
/*     */ import java.net.http.HttpResponse;
/*     */ import java.util.stream.Stream;
/*     */ import javax.annotation.Nullable;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000V\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\016\n\002\b\020\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\025\020\t\032\0020\0002\006\020\b\032\0020\004¢\006\004\b\t\020\nJ\027\020\f\032\0020\0002\b\020\013\032\004\030\0010\004¢\006\004\b\f\020\nJ\027\020\016\032\0020\0002\b\020\r\032\004\030\0010\001¢\006\004\b\016\020\017J\027\020\016\032\0020\0002\b\020\013\032\004\030\0010\004¢\006\004\b\016\020\nJ\027\020\020\032\0020\0002\b\020\013\032\004\030\0010\004¢\006\004\b\020\020\nJ!\020\023\032\0020\0002\b\020\021\032\004\030\0010\0042\b\020\022\032\004\030\0010\004¢\006\004\b\023\020\024J\r\020\026\032\0020\025¢\006\004\b\026\020\027J\017\020\031\032\0020\030H\007¢\006\004\b\031\020\032J\023\020\034\032\b\022\004\022\0020\0300\033¢\006\004\b\034\020\035J\037\020!\032\004\030\0018\000\"\004\b\000\020\0362\b\020 \032\004\030\0010\037¢\006\004\b!\020\"J\025\020$\032\b\022\004\022\0020\0040#H\007¢\006\004\b$\020%J\031\020&\032\016\022\n\022\b\022\004\022\0020\0040#0\033¢\006\004\b&\020\035J\023\020(\032\b\022\004\022\0020'0\033¢\006\004\b(\020\035J\021\020)\032\004\030\0010\004H\007¢\006\004\b)\020*J\023\020+\032\b\022\004\022\0020\0040\033¢\006\004\b+\020\035J-\020/\032\004\030\0018\000\"\004\b\000\020\0362\006\020,\032\0020\0042\f\020.\032\b\022\004\022\0028\0000-H\003¢\006\004\b/\0200J3\0201\032\n\022\004\022\0028\000\030\0010\033\"\004\b\000\020\0362\006\020,\032\0020\0042\f\020.\032\b\022\004\022\0028\0000-H\002¢\006\004\b1\0202R\030\0204\032\004\030\001038\002@\002X\016¢\006\006\n\004\b4\0205R\030\020\003\032\004\030\0010\0028\002@\002X\016¢\006\006\n\004\b\003\0206¨\0067"}, d2 = {"Lnet/integr/utilities/http/HttpSystem$Request;", "", "Lnet/integr/utilities/http/HttpSystem$Method;", "method", "", "url", "<init>", "(Lnet/integr/utilities/http/HttpSystem$Method;Ljava/lang/String;)V", "token", "bearer", "(Ljava/lang/String;)Lnet/integr/utilities/http/HttpSystem$Request;", "string", "bodyForm", "object", "bodyJson", "(Ljava/lang/Object;)Lnet/integr/utilities/http/HttpSystem$Request;", "bodyString", "name", "value", "header", "(Ljava/lang/String;Ljava/lang/String;)Lnet/integr/utilities/http/HttpSystem$Request;", "", "receive", "()V", "Ljava/io/InputStream;", "receiveInputStream", "()Ljava/io/InputStream;", "Ljava/net/http/HttpResponse;", "receiveInputStreamResponse", "()Ljava/net/http/HttpResponse;", "T", "Ljava/lang/reflect/Type;", "type", "receiveJson", "(Ljava/lang/reflect/Type;)Ljava/lang/Object;", "Ljava/util/stream/Stream;", "receiveLines", "()Ljava/util/stream/Stream;", "receiveLinesResponse", "Ljava/lang/Void;", "receiveResponse", "receiveString", "()Ljava/lang/String;", "receiveStringResponse", "accept", "Ljava/net/http/HttpResponse$BodyHandler;", "responseBodyHandler", "send", "(Ljava/lang/String;Ljava/net/http/HttpResponse$BodyHandler;)Ljava/lang/Object;", "sendResponse", "(Ljava/lang/String;Ljava/net/http/HttpResponse$BodyHandler;)Ljava/net/http/HttpResponse;", "Ljava/net/http/HttpRequest$Builder;", "builder", "Ljava/net/http/HttpRequest$Builder;", "Lnet/integr/utilities/http/HttpSystem$Method;", "onyx2"})
/*     */ public final class Request
/*     */ {
/*     */   @Nullable
/*     */   private HttpRequest.Builder builder;
/*     */   @Nullable
/*     */   private HttpSystem.Method method;
/*     */   
/*     */   public Request(@NotNull HttpSystem.Method method, @NotNull String url) {
/*     */     try {
/*  65 */       this.builder = HttpRequest.newBuilder().uri(new URI(url)).header(
/*  66 */           "User-Agent", 
/*  67 */           "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36");
/*     */       
/*  69 */       this.method = method;
/*  70 */     } catch (URISyntaxException e) {
/*  71 */       throw new IllegalArgumentException((Throwable)e);
/*     */     } 
/*     */   }
/*     */   @NotNull
/*     */   public final Request header(@Nullable String name, @Nullable String value) {
/*  76 */     Intrinsics.checkNotNull(this.builder); this.builder.header(name, value);
/*     */     
/*  78 */     return this;
/*     */   }
/*     */   @NotNull
/*     */   public final Request bearer(@NotNull String token) {
/*  82 */     Intrinsics.checkNotNullParameter(token, "token"); Intrinsics.checkNotNull(this.builder); this.builder.header("Authorization", "Bearer " + token);
/*     */     
/*  84 */     return this;
/*     */   }
/*     */   @NotNull
/*     */   public final Request bodyString(@Nullable String string) {
/*  88 */     Intrinsics.checkNotNull(this.builder); this.builder.header("Content-Type", "text/plain");
/*  89 */     Intrinsics.checkNotNull(this.builder); Intrinsics.checkNotNull(this.method); this.builder.method(this.method.name(), HttpRequest.BodyPublishers.ofString(string));
/*  90 */     this.method = null;
/*     */     
/*  92 */     return this;
/*     */   }
/*     */   @NotNull
/*     */   public final Request bodyForm(@Nullable String string) {
/*  96 */     Intrinsics.checkNotNull(this.builder); this.builder.header("Content-Type", "application/x-www-form-urlencoded");
/*  97 */     Intrinsics.checkNotNull(this.builder); Intrinsics.checkNotNull(this.method); this.builder.method(this.method.name(), HttpRequest.BodyPublishers.ofString(string));
/*  98 */     this.method = null;
/*     */     
/* 100 */     return this;
/*     */   }
/*     */   @NotNull
/*     */   public final Request bodyJson(@Nullable String string) {
/* 104 */     Intrinsics.checkNotNull(this.builder); this.builder.header("Content-Type", "application/json");
/* 105 */     Intrinsics.checkNotNull(this.builder); Intrinsics.checkNotNull(this.method); this.builder.method(this.method.name(), HttpRequest.BodyPublishers.ofString(string));
/* 106 */     this.method = null;
/*     */     
/* 108 */     return this;
/*     */   }
/*     */   @NotNull
/*     */   public final Request bodyJson(@Nullable Object object) {
/* 112 */     Intrinsics.checkNotNull(this.builder); this.builder.header("Content-Type", "application/json");
/* 113 */     Intrinsics.checkNotNull(this.builder); Intrinsics.checkNotNull(this.method); this.builder.method(this.method.name(), HttpRequest.BodyPublishers.ofString(HttpSystem.access$getGSON$p().toJson(object)));
/* 114 */     this.method = null;
/*     */     
/* 116 */     return this;
/*     */   }
/*     */   
/*     */   private final <T> HttpResponse<T> sendResponse(String accept, HttpResponse.BodyHandler responseBodyHandler) {
/* 120 */     Intrinsics.checkNotNull(this.builder); this.builder.header("Accept", accept);
/* 121 */     if (this.method != null) { Intrinsics.checkNotNull(this.builder); Intrinsics.checkNotNull(this.method); this.builder.method(this.method.name(), HttpRequest.BodyPublishers.noBody()); }
/*     */     
/* 123 */     Intrinsics.checkNotNull(this.builder); Intrinsics.checkNotNullExpressionValue(this.builder.build(), "build(...)"); HttpRequest request = this.builder.build();
/*     */     
/*     */     try {
/* 126 */       return HttpSystem.access$getCLIENT$p().send(request, responseBodyHandler);
/* 127 */     } catch (IOException e) {
/* 128 */       e.printStackTrace();
/* 129 */       return null;
/* 130 */     } catch (InterruptedException e) {
/* 131 */       e.printStackTrace();
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   private final <T> T send(String accept, HttpResponse.BodyHandler<?> responseBodyHandler) {
/*     */     HttpResponse<?> res;
/* 138 */     if (sendResponse(accept, responseBodyHandler) == null) { sendResponse(accept, responseBodyHandler); return null; }
/* 139 */      return (res.statusCode() == 200) ? (T)res.body() : null;
/*     */   }
/*     */   
/*     */   public final void receive() {
/* 143 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.discarding(), "discarding(...)"); send("*/*", HttpResponse.BodyHandlers.discarding());
/*     */   }
/*     */   @NotNull
/*     */   public final HttpResponse<Void> receiveResponse() {
/* 147 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.discarding(), "discarding(...)"); Intrinsics.checkNotNull(sendResponse("*/*", HttpResponse.BodyHandlers.discarding())); return (HttpResponse)sendResponse("*/*", HttpResponse.BodyHandlers.discarding());
/*     */   }
/*     */   @Nullable
/*     */   @NotNull
/*     */   public final InputStream receiveInputStream() {
/* 152 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofInputStream(), "ofInputStream(...)"); Intrinsics.checkNotNull(send("*/*", HttpResponse.BodyHandlers.ofInputStream())); return (InputStream)send("*/*", HttpResponse.BodyHandlers.ofInputStream());
/*     */   }
/*     */   @NotNull
/*     */   public final HttpResponse<InputStream> receiveInputStreamResponse() {
/* 156 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofInputStream(), "ofInputStream(...)"); Intrinsics.checkNotNull(sendResponse("*/*", HttpResponse.BodyHandlers.ofInputStream())); return (HttpResponse)sendResponse("*/*", HttpResponse.BodyHandlers.ofInputStream());
/*     */   }
/*     */   @Nullable
/*     */   @Nullable
/*     */   public final String receiveString() {
/* 161 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofString(), "ofString(...)"); return send("*/*", HttpResponse.BodyHandlers.ofString());
/*     */   }
/*     */   @NotNull
/*     */   public final HttpResponse<String> receiveStringResponse() {
/* 165 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofString(), "ofString(...)"); Intrinsics.checkNotNull(sendResponse("*/*", HttpResponse.BodyHandlers.ofString())); return (HttpResponse)sendResponse("*/*", HttpResponse.BodyHandlers.ofString());
/*     */   }
/*     */   @Nullable
/*     */   @NotNull
/*     */   public final Stream<String> receiveLines() {
/* 170 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofLines(), "ofLines(...)"); Intrinsics.checkNotNull(send("*/*", HttpResponse.BodyHandlers.ofLines())); return (Stream<String>)send("*/*", HttpResponse.BodyHandlers.ofLines());
/*     */   }
/*     */   @NotNull
/*     */   public final HttpResponse<Stream<String>> receiveLinesResponse() {
/* 174 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofLines(), "ofLines(...)"); Intrinsics.checkNotNull(sendResponse("*/*", HttpResponse.BodyHandlers.ofLines())); return (HttpResponse)sendResponse("*/*", HttpResponse.BodyHandlers.ofLines());
/*     */   } @Nullable
/*     */   public final <T> T receiveJson(@Nullable Type type) {
/*     */     InputStream input;
/* 178 */     Intrinsics.checkNotNullExpressionValue(HttpResponse.BodyHandlers.ofInputStream(), "ofInputStream(...)"); if ((InputStream)send("application/json", HttpResponse.BodyHandlers.ofInputStream()) == null) { (InputStream)send("application/json", HttpResponse.BodyHandlers.ofInputStream()); return null; }
/* 179 */      return (T)HttpSystem.access$getGSON$p().fromJson(new InputStreamReader(input), type);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\http\HttpSystem$Request.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */