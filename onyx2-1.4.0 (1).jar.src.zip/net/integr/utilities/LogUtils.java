/*    */ package net.integr.utilities;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Variables;
/*    */ import net.minecraft.class_124;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_5250;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/LogUtils;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class LogUtils
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\t\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\025\020\n\032\0020\t2\006\020\005\032\0020\004¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\002¢\006\004\b\r\020\016J\017\020\017\032\0020\fH\002¢\006\004\b\017\020\016J\035\020\021\032\0020\0062\006\020\005\032\0020\0042\006\020\020\032\0020\004¢\006\004\b\021\020\022J\025\020\023\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\023\020\bJ\025\020\024\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\024\020\b¨\006\025"}, d2 = {"Lnet/integr/utilities/LogUtils$Companion;", "", "<init>", "()V", "", "str", "", "assistantMessage", "(Ljava/lang/String;)V", "Lnet/minecraft/class_2561;", "getChatLog", "(Ljava/lang/String;)Lnet/minecraft/class_2561;", "Lnet/minecraft/class_5250;", "getFormatForUiColor", "()Lnet/minecraft/class_5250;", "getFormatForUiColorDarken", "prefix", "prefixedChatMessage", "(Ljava/lang/String;Ljava/lang/String;)V", "sendChatLog", "sendLog", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final void sendChatLog(@NotNull String str) {
/* 32 */       Intrinsics.checkNotNullParameter(str, "str"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_43496((class_2561)getFormatForUiColor().method_10852((class_2561)class_2561.method_43470("Onyx" + class_124.field_1063 + " > " + class_124.field_1080 + str)));
/*    */     }
/*    */     @NotNull
/*    */     public final class_2561 getChatLog(@NotNull String str) {
/* 36 */       Intrinsics.checkNotNullParameter(str, "str"); Intrinsics.checkNotNullExpressionValue(class_2561.method_43470("" + getFormatForUiColor() + "Onyx" + getFormatForUiColor() + " > " + class_124.field_1063 + class_124.field_1080), "literal(...)"); return (class_2561)class_2561.method_43470("" + getFormatForUiColor() + "Onyx" + getFormatForUiColor() + " > " + class_124.field_1063 + class_124.field_1080);
/*    */     }
/*    */     
/*    */     public final void sendLog(@NotNull String str) {
/* 40 */       Intrinsics.checkNotNullParameter(str, "str"); Onyx.Companion.getLOGGER().info("Onyx > " + str);
/*    */     }
/*    */     
/*    */     public final void assistantMessage(@NotNull String str) {
/* 44 */       Intrinsics.checkNotNullParameter(str, "str"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_43496((class_2561)getFormatForUiColor().method_10852((class_2561)class_2561.method_43470("Onyx" + class_124.field_1063 + " > ").method_10852((class_2561)getFormatForUiColorDarken().method_10852((class_2561)class_2561.method_43470("Assistant" + class_124.field_1063 + " > " + class_124.field_1080 + str)))));
/*    */     }
/*    */     
/*    */     public final void prefixedChatMessage(@NotNull String str, @NotNull String prefix) {
/* 48 */       Intrinsics.checkNotNullParameter(str, "str"); Intrinsics.checkNotNullParameter(prefix, "prefix"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_43496((class_2561)getFormatForUiColor().method_10852((class_2561)class_2561.method_43470("Onyx" + class_124.field_1063 + " > ").method_10852((class_2561)getFormatForUiColorDarken().method_10852((class_2561)class_2561.method_43470(prefix + prefix + " > " + class_124.field_1063 + class_124.field_1080)))));
/*    */     }
/*    */     
/*    */     private final class_5250 getFormatForUiColor() {
/* 52 */       int color = Variables.Companion.getGuiColor();
/*    */       
/* 54 */       class_5250 txt = class_2561.method_43470("").method_54663(color);
/*    */       
/* 56 */       Intrinsics.checkNotNull(txt); return txt;
/*    */     }
/*    */     
/*    */     private final class_5250 getFormatForUiColorDarken() {
/* 60 */       Color colorI = new Color(Variables.Companion.getGuiColor());
/* 61 */       int color = (new Color(Math.max(0, colorI.getRed() - 50), Math.max(0, colorI.getGreen() - 50), Math.max(0, colorI.getBlue() - 50))).getRGB();
/*    */ 
/*    */       
/* 64 */       class_5250 txt = class_2561.method_43470("").method_54663(color);
/*    */       
/* 66 */       Intrinsics.checkNotNull(txt); return txt;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\LogUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */