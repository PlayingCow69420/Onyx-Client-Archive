/*    */ package net.integr.utilities;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\000\f\n\002\020\006\n\002\020\b\n\002\b\004\032\031\020\003\032\0020\000*\0020\0002\006\020\002\032\0020\001¢\006\004\b\003\020\004¨\006\005"}, d2 = {"", "", "decimals", "round", "(DI)D", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Extensions.kt\nnet/integr/utilities/ExtensionsKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,24:1\n1#2:25\n*E\n"})
/*    */ public final class ExtensionsKt
/*    */ {
/*    */   public static final double round(double $this$round, int decimals) {
/* 20 */     double multiplier = 0.0D; multiplier = 1.0D;
/* 21 */     for (byte b = 0; b < decimals; ) { int it = b;
/*    */ 
/*    */ 
/*    */       
/* 25 */       int $i$a$-repeat-ExtensionsKt$round$1 = 0;
/*    */       multiplier *= 10;
/*    */       b++; }
/*    */     
/*    */     return Math.rint($this$round * multiplier) / multiplier;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\ExtensionsKt.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */