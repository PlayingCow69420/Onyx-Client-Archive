/*    */ package net.integr.utilities.locking;
/*    */ 
/*    */ import com.google.common.hash.Hashing;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.text.Charsets;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.utilities.http.HttpSystem;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import oshi.SystemInfo;
/*    */ import oshi.hardware.CentralProcessor;
/*    */ import oshi.hardware.ComputerSystem;
/*    */ import oshi.hardware.HardwareAbstractionLayer;
/*    */ import oshi.software.os.OperatingSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\007\n\002\020\013\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\006J\r\020\007\032\0020\004¢\006\004\b\007\020\006J\027\020\t\032\0020\0042\006\020\b\032\0020\004H\002¢\006\004\b\t\020\nJ\025\020\r\032\0020\f2\006\020\013\032\0020\004¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/utilities/locking/HWIDManager$Companion;", "", "<init>", "()V", "", "getData", "()Ljava/lang/String;", "getHwid", "data", "hashData", "(Ljava/lang/String;)Ljava/lang/String;", "hwid", "", "isAuthed", "(Ljava/lang/String;)Z", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final String getHwid() {
/* 30 */     return hashData(getData());
/*    */   }
/*    */   
/*    */   public final boolean isAuthed(@NotNull String hwid) {
/* 34 */     Intrinsics.checkNotNullParameter(hwid, "hwid"); if (Onyx.Companion.getDEV_MODE()) return true;
/*    */     
/* 36 */     String res = HttpSystem.INSTANCE
/* 37 */       .get("https://ceptea.xyz/onyx/checkhwid/" + hwid)
/* 38 */       .receiveString();
/*    */     
/* 40 */     boolean authed = Boolean.parseBoolean(res);
/* 41 */     return authed;
/*    */   }
/*    */   
/*    */   private final String getData() {
/* 45 */     SystemInfo systemInfo = new SystemInfo();
/* 46 */     Intrinsics.checkNotNullExpressionValue(systemInfo.getOperatingSystem(), "getOperatingSystem(...)"); OperatingSystem operatingSystem = systemInfo.getOperatingSystem();
/* 47 */     HardwareAbstractionLayer hardwareAbstractionLayer = systemInfo.getHardware();
/* 48 */     CentralProcessor centralProcessor = hardwareAbstractionLayer.getProcessor();
/* 49 */     ComputerSystem computerSystem = hardwareAbstractionLayer.getComputerSystem();
/*    */     
/* 51 */     Intrinsics.checkNotNullExpressionValue(operatingSystem.getManufacturer(), "getManufacturer(...)"); String vendor = operatingSystem.getManufacturer();
/* 52 */     String processorSerialNumber = computerSystem.getSerialNumber();
/* 53 */     Intrinsics.checkNotNullExpressionValue(centralProcessor.getProcessorIdentifier().getProcessorID(), "getProcessorID(...)"); String processorIdentifier = centralProcessor.getProcessorIdentifier().getProcessorID();
/* 54 */     int processors = centralProcessor.getLogicalProcessorCount();
/*    */     
/* 56 */     String delimiter = "#";
/*    */     
/* 58 */     return vendor + vendor + delimiter + processorSerialNumber + delimiter + processorIdentifier + delimiter;
/*    */   }
/*    */   
/*    */   private final String hashData(String data) {
/* 62 */     Intrinsics.checkNotNullExpressionValue(Hashing.sha512().hashString(data, Charsets.UTF_8).toString(), "toString(...)"); return Hashing.sha512().hashString(data, Charsets.UTF_8).toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\locking\HWIDManager$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */