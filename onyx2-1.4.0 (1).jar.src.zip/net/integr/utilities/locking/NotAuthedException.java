/*    */ package net.integr.utilities.locking;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\004\030\0002\0060\001j\002`\002B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Lnet/integr/utilities/locking/NotAuthedException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "", "hwid", "<init>", "(Ljava/lang/String;)V", "onyx2"})
/*    */ public final class NotAuthedException
/*    */   extends Exception
/*    */ {
/*    */   public NotAuthedException(@NotNull String hwid) {
/* 19 */     super("Not authorized to use Onyx! Your unique system id is not authorized on our servers. Please contact support. (https://dcg.gg/onx) The id (" + hwid + ") has been copied to the clipboard.");
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\locking\NotAuthedException.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */