/*    */ package net.integr.utilities.file;
/*    */ 
/*    */ import java.io.File;
/*    */ import jnafilechooser.api.JnaFileChooser;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/file/FileSelector;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class FileSelector
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\006\032\004\030\0010\0042\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\b\032\004\030\0010\0042\006\020\005\032\0020\004¢\006\004\b\b\020\007¨\006\t"}, d2 = {"Lnet/integr/utilities/file/FileSelector$Companion;", "", "<init>", "()V", "", "start", "getExportPath", "(Ljava/lang/String;)Ljava/lang/String;", "getImportableFile", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     @Nullable
/*    */     public final String getImportableFile(@NotNull String start) {
/* 28 */       Intrinsics.checkNotNullParameter(start, "start"); JnaFileChooser fileChooser = new JnaFileChooser();
/* 29 */       fileChooser.setMode(JnaFileChooser.Mode.Files);
/* 30 */       fileChooser.setTitle("Select a file to import");
/* 31 */       fileChooser.setCurrentDirectory(start);
/* 32 */       fileChooser.setMultiSelectionEnabled(false);
/* 33 */       String[] arrayOfString = new String[1]; arrayOfString[0] = "ocg"; fileChooser.addFilter("Onyx Config Files", arrayOfString);
/*    */       
/* 35 */       boolean ac = fileChooser.showOpenDialog(null);
/*    */       
/* 37 */       if (ac) {
/* 38 */         File file = fileChooser.getSelectedFile();
/* 39 */         return file.getAbsolutePath();
/*    */       } 
/*    */       
/* 42 */       return null;
/*    */     }
/*    */     @Nullable
/*    */     public final String getExportPath(@NotNull String start) {
/* 46 */       Intrinsics.checkNotNullParameter(start, "start"); JnaFileChooser fileChooser = new JnaFileChooser();
/* 47 */       fileChooser.setMode(JnaFileChooser.Mode.Files);
/* 48 */       fileChooser.setTitle("Select a export destination");
/* 49 */       fileChooser.setCurrentDirectory(start);
/* 50 */       fileChooser.setMultiSelectionEnabled(false);
/* 51 */       fileChooser.setDefaultFileName("config.ocg");
/* 52 */       String[] arrayOfString = new String[1]; arrayOfString[0] = "ocg"; fileChooser.addFilter("Onyx Config Files", arrayOfString);
/*    */       
/* 54 */       boolean ac = fileChooser.showSaveDialog(null);
/*    */       
/* 56 */       if (ac) {
/* 57 */         File file = fileChooser.getSelectedFile();
/* 58 */         return file.getAbsolutePath();
/*    */       } 
/*    */       
/* 61 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\file\FileSelector.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */