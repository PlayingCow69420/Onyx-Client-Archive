/*    */ package net.integr.utilities.resourceload;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\004\030\0010\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\027\020\n\032\004\030\0010\t2\006\020\005\032\0020\004¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/utilities/resourceload/ResourceLoader$Companion;", "", "<init>", "()V", "", "path", "Ljava/net/URL;", "loadResource", "(Ljava/lang/String;)Ljava/net/URL;", "Ljava/io/InputStream;", "loadResourceAsStream", "(Ljava/lang/String;)Ljava/io/InputStream;", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @Nullable
/*    */   public final InputStream loadResourceAsStream(@NotNull String path) {
/* 26 */     Intrinsics.checkNotNullParameter(path, "path"); return Onyx.class.getClassLoader().getResourceAsStream(path);
/*    */   }
/*    */   @Nullable
/*    */   public final URL loadResource(@NotNull String path) {
/* 30 */     Intrinsics.checkNotNullParameter(path, "path"); return Onyx.class.getClassLoader().getResource(path);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\resourceload\ResourceLoader$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */