/*    */ package net.integr.utilities.game.polar;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.utilities.game.interaction.RotationUtils;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\002\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006J\r\020\007\032\0020\004¢\006\004\b\007\020\006J\r\020\t\032\0020\b¢\006\004\b\t\020\nJ\r\020\f\032\0020\013¢\006\004\b\f\020\003J\025\020\016\032\0020\0132\006\020\r\032\0020\004¢\006\004\b\016\020\017R\030\020\r\032\004\030\0010\0048\002@\002X\016¢\006\006\n\004\b\r\020\020¨\006\021"}, d2 = {"Lnet/integr/utilities/game/polar/PolarSystem$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_243;", "getForward", "()Lnet/minecraft/class_243;", "getSide", "", "isActive", "()Z", "", "resetCenter", "center", "setCenter", "(Lnet/minecraft/class_243;)V", "Lnet/minecraft/class_243;", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final class_243 getForward() {
/* 30 */     if (PolarSystem.access$getCenter$cp() != null) {
/* 31 */       Intrinsics.checkNotNull(PolarSystem.access$getCenter$cp()); float needed = ((Number)RotationUtils.Companion.getNeededRotations(PolarSystem.access$getCenter$cp()).getFirst()).floatValue();
/* 32 */       Intrinsics.checkNotNullExpressionValue(class_243.method_1030(0.0F, needed), "fromPolar(...)"); return class_243.method_1030(0.0F, needed);
/*    */     } 
/* 34 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(class_243.method_1030(0.0F, (Onyx.Companion.getMC()).field_1724.method_36454()), "fromPolar(...)"); return class_243.method_1030(0.0F, (Onyx.Companion.getMC()).field_1724.method_36454());
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final class_243 getSide() {
/* 39 */     if (PolarSystem.access$getCenter$cp() != null) {
/* 40 */       Intrinsics.checkNotNull(PolarSystem.access$getCenter$cp()); float needed = ((Number)RotationUtils.Companion.getNeededRotations(PolarSystem.access$getCenter$cp()).getFirst()).floatValue();
/* 41 */       Intrinsics.checkNotNullExpressionValue(class_243.method_1030(0.0F, needed + 90), "fromPolar(...)"); return class_243.method_1030(0.0F, needed + 90);
/*    */     } 
/* 43 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(class_243.method_1030(0.0F, (Onyx.Companion.getMC()).field_1724.method_36454() + 90), "fromPolar(...)"); return class_243.method_1030(0.0F, (Onyx.Companion.getMC()).field_1724.method_36454() + 90);
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean isActive() {
/* 48 */     return (PolarSystem.access$getCenter$cp() != null);
/*    */   }
/*    */   
/*    */   public final void setCenter(@NotNull class_243 center) {
/* 52 */     Intrinsics.checkNotNullParameter(center, "center"); PolarSystem.access$setCenter$cp(center);
/*    */   }
/*    */   
/*    */   public final void resetCenter() {
/* 56 */     PolarSystem.access$setCenter$cp(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\polar\PolarSystem$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */