/*    */ package net.integr.utilities.game.notification;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import net.integr.Onyx;
/*    */ import net.minecraft.class_1109;
/*    */ import net.minecraft.class_1113;
/*    */ import net.minecraft.class_3417;
/*    */ import net.minecraft.class_6880;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/notification/NotificationHandler;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class NotificationHandler
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\030\002\n\002\b\007\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\r\020\t\032\0020\006¢\006\004\b\t\020\003R@\020\r\032 \022\034\022\032\022\004\022\0020\004\022\020\022\016\022\004\022\0020\f\022\004\022\0020\f0\0130\0130\n8\006@\006X\016¢\006\022\n\004\b\r\020\016\032\004\b\017\020\020\"\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/utilities/game/notification/NotificationHandler$Companion;", "", "<init>", "()V", "", "string", "", "notify", "(Ljava/lang/String;)V", "ping", "", "Lkotlin/Pair;", "Ljava/util/concurrent/atomic/AtomicInteger;", "notifications", "Ljava/util/List;", "getNotifications", "()Ljava/util/List;", "setNotifications", "(Ljava/util/List;)V", "onyx2"})
/*    */   @SourceDebugExtension({"SMAP\nNotificationHandler.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NotificationHandler.kt\nnet/integr/utilities/game/notification/NotificationHandler$Companion\n+ 2 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n*L\n1#1,40:1\n71#2,7:41\n*S KotlinDebug\n*F\n+ 1 NotificationHandler.kt\nnet/integr/utilities/game/notification/NotificationHandler$Companion\n*L\n32#1:41,7\n*E\n"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     @NotNull
/*    */     public final List<Pair<String, Pair<AtomicInteger, AtomicInteger>>> getNotifications() {
/* 29 */       return (List)NotificationHandler.notifications; } public final void setNotifications(@NotNull List <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); NotificationHandler.notifications = <set-?>; }
/*    */ 
/*    */     
/*    */     public final void notify(@NotNull String string) {
/*    */       // Byte code:
/*    */       //   0: aload_1
/*    */       //   1: ldc 'string'
/*    */       //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */       //   6: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*    */       //   9: astore_2
/*    */       //   10: iconst_0
/*    */       //   11: istore_3
/*    */       //   12: aload_2
/*    */       //   13: invokevirtual getModules : ()Ljava/util/List;
/*    */       //   16: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */       //   21: astore #4
/*    */       //   23: aload #4
/*    */       //   25: invokeinterface hasNext : ()Z
/*    */       //   30: ifeq -> 83
/*    */       //   33: aload #4
/*    */       //   35: invokeinterface next : ()Ljava/lang/Object;
/*    */       //   40: checkcast net/integr/modules/management/Module
/*    */       //   43: astore #5
/*    */       //   45: aload #5
/*    */       //   47: invokevirtual getClass : ()Ljava/lang/Class;
/*    */       //   50: ldc net/integr/modules/impl/NotificationModule
/*    */       //   52: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */       //   55: ifeq -> 23
/*    */       //   58: aload #5
/*    */       //   60: dup
/*    */       //   61: ifnonnull -> 74
/*    */       //   64: new java/lang/NullPointerException
/*    */       //   67: dup
/*    */       //   68: ldc 'null cannot be cast to non-null type net.integr.modules.impl.NotificationModule'
/*    */       //   70: invokespecial <init> : (Ljava/lang/String;)V
/*    */       //   73: athrow
/*    */       //   74: checkcast net/integr/modules/impl/NotificationModule
/*    */       //   77: checkcast net/integr/modules/management/Module
/*    */       //   80: goto -> 84
/*    */       //   83: aconst_null
/*    */       //   84: dup
/*    */       //   85: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */       //   88: checkcast net/integr/modules/impl/NotificationModule
/*    */       //   91: invokevirtual isEnabled : ()Z
/*    */       //   94: ifeq -> 148
/*    */       //   97: aload_0
/*    */       //   98: aload_0
/*    */       //   99: invokevirtual getNotifications : ()Ljava/util/List;
/*    */       //   102: checkcast java/util/Collection
/*    */       //   105: new kotlin/Pair
/*    */       //   108: dup
/*    */       //   109: aload_1
/*    */       //   110: new kotlin/Pair
/*    */       //   113: dup
/*    */       //   114: new java/util/concurrent/atomic/AtomicInteger
/*    */       //   117: dup
/*    */       //   118: bipush #20
/*    */       //   120: invokespecial <init> : (I)V
/*    */       //   123: new java/util/concurrent/atomic/AtomicInteger
/*    */       //   126: dup
/*    */       //   127: sipush #200
/*    */       //   130: invokespecial <init> : (I)V
/*    */       //   133: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
/*    */       //   136: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
/*    */       //   139: invokestatic plus : (Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;
/*    */       //   142: invokevirtual setNotifications : (Ljava/util/List;)V
/*    */       //   145: goto -> 155
/*    */       //   148: getstatic net/integr/utilities/LogUtils.Companion : Lnet/integr/utilities/LogUtils$Companion;
/*    */       //   151: aload_1
/*    */       //   152: invokevirtual sendChatLog : (Ljava/lang/String;)V
/*    */       //   155: return
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #32	-> 6
/*    */       //   #41	-> 12
/*    */       //   #42	-> 45
/*    */       //   #43	-> 58
/*    */       //   #47	-> 83
/*    */       //   #32	-> 84
/*    */       //   #33	-> 148
/*    */       //   #34	-> 155
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   45	38	5	m$iv	Lnet/integr/modules/management/Module;
/*    */       //   12	72	3	$i$f$getByClass	I
/*    */       //   10	74	2	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*    */       //   0	156	0	this	Lnet/integr/utilities/game/notification/NotificationHandler$Companion;
/*    */       //   0	156	1	string	Ljava/lang/String;
/*    */     }
/*    */     
/*    */     public final void ping() {
/* 37 */       Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_14793, 1.0F));
/*    */     }
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   @NotNull
/*    */   private static List<? extends Pair<String, ? extends Pair<? extends AtomicInteger, ? extends AtomicInteger>>> notifications = new ArrayList<>();
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\notification\NotificationHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */