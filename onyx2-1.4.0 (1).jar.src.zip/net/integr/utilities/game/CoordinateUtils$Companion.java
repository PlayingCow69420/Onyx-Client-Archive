/*     */ package net.integr.utilities.game;
/*     */ 
/*     */ import fi.dy.masa.litematica.data.DataManager;
/*     */ import fi.dy.masa.litematica.world.WorldSchematic;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.utilities.game.entity.EntityFinder;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1511;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4538;
/*     */ import net.minecraft.class_746;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000l\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\006\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020 \n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\005\n\002\020\007\n\002\b\006\n\002\030\002\n\002\b\007\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\035\020\r\032\0020\f2\006\020\n\032\0020\t2\006\020\013\032\0020\t¢\006\004\b\r\020\016J\025\020\020\032\0020\f2\006\020\017\032\0020\t¢\006\004\b\020\020\021J\035\020\025\032\0020\0242\006\020\022\032\0020\0042\006\020\023\032\0020\004¢\006\004\b\025\020\026J\035\020\027\032\0020\0042\006\020\022\032\0020\0042\006\020\023\032\0020\004¢\006\004\b\027\020\030J\025\020\034\032\0020\0332\006\020\032\032\0020\031¢\006\004\b\034\020\035J3\020#\032\b\022\004\022\0020\0040\"2\006\020\032\032\0020\0312\006\020\037\032\0020\0362\006\020 \032\0020\0062\006\020!\032\0020\f¢\006\004\b#\020$J+\020%\032\b\022\004\022\0020\0040\"2\006\020\037\032\0020\0362\006\020 \032\0020\0062\006\020!\032\0020\f¢\006\004\b%\020&J%\020*\032\0020\f2\026\020)\032\022\022\004\022\0020\t0'j\b\022\004\022\0020\t`(¢\006\004\b*\020+J%\020,\032\0020\f2\026\020)\032\022\022\004\022\0020\t0'j\b\022\004\022\0020\t`(¢\006\004\b,\020+J%\020-\032\0020\f2\026\020)\032\022\022\004\022\0020\t0'j\b\022\004\022\0020\t`(¢\006\004\b-\020+J\035\0200\032\0020\t2\006\020\032\032\0020\0312\006\020/\032\0020.¢\006\004\b0\0201J%\0202\032\0020\f2\026\020)\032\022\022\004\022\0020\t0'j\b\022\004\022\0020\t`(¢\006\004\b2\020+J%\0203\032\0020\f2\026\020)\032\022\022\004\022\0020\t0'j\b\022\004\022\0020\t`(¢\006\004\b3\020+J%\0204\032\0020\f2\026\020)\032\022\022\004\022\0020\t0'j\b\022\004\022\0020\t`(¢\006\004\b4\020+J\037\0207\032\004\030\0010\0042\006\020\037\032\0020\0362\006\0206\032\00205¢\006\004\b7\0208J%\0209\032\0020\t2\006\020\022\032\0020\t2\006\020\023\032\0020\t2\006\020/\032\0020.¢\006\004\b9\020:J\025\020;\032\0020\0062\006\020\005\032\0020\004¢\006\004\b;\020\b¨\006<"}, d2 = {"Lnet/integr/utilities/game/CoordinateUtils$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2338;", "bp", "", "crystalIsBlockedByEntity", "(Lnet/minecraft/class_2338;)Z", "Lnet/minecraft/class_243;", "block1", "block2", "", "distanceBetween", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)D", "block", "distanceTo", "(Lnet/minecraft/class_243;)D", "bp1", "bp2", "Lnet/minecraft/class_2350;", "getDirectionOfBlockToBlock", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2338;)Lnet/minecraft/class_2350;", "getDirectionOfBlockToBlockAsVector", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2338;)Lnet/minecraft/class_2338;", "Lnet/minecraft/class_1297;", "e", "Lnet/minecraft/class_238;", "getEntityBox", "(Lnet/minecraft/class_1297;)Lnet/minecraft/class_238;", "", "radius", "checkPlayerAccessible", "accessRange", "", "getGridAroundEntity", "(Lnet/minecraft/class_1297;IZD)Ljava/util/List;", "getGridAroundPlayer", "(IZD)Ljava/util/List;", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "blocks", "getHighestX", "(Ljava/util/ArrayList;)D", "getHighestY", "getHighestZ", "", "partialTicks", "getLerpedEntityPos", "(Lnet/minecraft/class_1297;F)Lnet/minecraft/class_243;", "getLowestX", "getLowestY", "getLowestZ", "Lfi/dy/masa/litematica/world/WorldSchematic;", "schematic", "getNextSchematicPos", "(ILfi/dy/masa/litematica/world/WorldSchematic;)Lnet/minecraft/class_2338;", "lerpPositionBetween", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;F)Lnet/minecraft/class_243;", "positionIsBlockedByEntity", "onyx2"})
/*     */ public final class Companion
/*     */ {
/*     */   private Companion() {}
/*     */   
/*     */   public final double getLowestX(@NotNull ArrayList blocks) {
/*  42 */     Intrinsics.checkNotNullParameter(blocks, "blocks"); double lowestX = 9.99999999E8D;
/*  43 */     for (class_243 v : blocks) {
/*  44 */       if (v.method_10216() < lowestX) {
/*  45 */         lowestX = v.method_10216();
/*     */       }
/*     */     } 
/*  48 */     return lowestX;
/*     */   }
/*     */   
/*     */   public final double getLowestY(@NotNull ArrayList blocks) {
/*  52 */     Intrinsics.checkNotNullParameter(blocks, "blocks"); double lowestY = 9.99999999E8D;
/*  53 */     for (class_243 v : blocks) {
/*  54 */       if (v.method_10214() < lowestY) {
/*  55 */         lowestY = v.method_10214();
/*     */       }
/*     */     } 
/*  58 */     return lowestY;
/*     */   }
/*     */   
/*     */   public final double getLowestZ(@NotNull ArrayList blocks) {
/*  62 */     Intrinsics.checkNotNullParameter(blocks, "blocks"); double lowestZ = 9.99999999E8D;
/*  63 */     for (class_243 v : blocks) {
/*  64 */       if (v.method_10215() < lowestZ) {
/*  65 */         lowestZ = v.method_10215();
/*     */       }
/*     */     } 
/*  68 */     return lowestZ;
/*     */   }
/*     */   
/*     */   public final double getHighestX(@NotNull ArrayList blocks) {
/*  72 */     Intrinsics.checkNotNullParameter(blocks, "blocks"); double maxX = -9.99999999E8D;
/*  73 */     for (class_243 v : blocks) {
/*  74 */       if (v.method_10216() > maxX) {
/*  75 */         maxX = v.method_10216();
/*     */       }
/*     */     } 
/*  78 */     return maxX;
/*     */   }
/*     */   
/*     */   public final double getHighestY(@NotNull ArrayList blocks) {
/*  82 */     Intrinsics.checkNotNullParameter(blocks, "blocks"); double maxY = -9.99999999E8D;
/*  83 */     for (class_243 v : blocks) {
/*  84 */       if (v.method_10214() > maxY) {
/*  85 */         maxY = v.method_10214();
/*     */       }
/*     */     } 
/*  88 */     return maxY;
/*     */   }
/*     */   
/*     */   public final double getHighestZ(@NotNull ArrayList blocks) {
/*  92 */     Intrinsics.checkNotNullParameter(blocks, "blocks"); double maxZ = -9.99999999E8D;
/*  93 */     for (class_243 v : blocks) {
/*  94 */       if (v.method_10215() > maxZ) {
/*  95 */         maxZ = v.method_10215();
/*     */       }
/*     */     } 
/*  98 */     return maxZ;
/*     */   }
/*     */   @NotNull
/*     */   public final class_243 getLerpedEntityPos(@NotNull class_1297 e, float partialTicks) {
/* 102 */     Intrinsics.checkNotNullParameter(e, "e"); if (e.method_31481()) { Intrinsics.checkNotNullExpressionValue(e.method_19538(), "getPos(...)"); return e.method_19538(); }
/*     */     
/* 104 */     double x = class_3532.method_16436(partialTicks, e.field_6038, e.method_23317());
/* 105 */     double y = class_3532.method_16436(partialTicks, e.field_5971, e.method_23318());
/* 106 */     double z = class_3532.method_16436(partialTicks, e.field_5989, e.method_23321());
/* 107 */     return new class_243(x, y, z);
/*     */   }
/*     */   @NotNull
/*     */   public final class_238 getEntityBox(@NotNull class_1297 e) {
/* 111 */     Intrinsics.checkNotNullParameter(e, "e"); return new class_238(-(e.method_5829().method_17939() / 2), 0.0D, -(e.method_5829().method_17941() / 2), e.method_5829().method_17939() / 2, e.method_5829().method_17940(), e.method_5829().method_17941() / 2);
/*     */   }
/*     */   @NotNull
/*     */   public final List<class_2338> getGridAroundEntity(@NotNull class_1297 e, int radius, boolean checkPlayerAccessible, double accessRange) {
/* 115 */     Intrinsics.checkNotNullParameter(e, "e"); List<class_2338> returnList = new ArrayList();
/*     */     
/* 117 */     int i = -radius; if (i <= radius)
/* 118 */       while (true) { int j = -radius; if (j <= radius)
/* 119 */           while (true) { int k = -radius; if (k <= radius)
/* 120 */               while (true) { class_2338 bp = new class_2338(e.method_31477() + i, e.method_31478() + j, e.method_31479() + k);
/*     */                 
/* 122 */                 if (checkPlayerAccessible)
/* 123 */                 { Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)"); if (distanceTo(bp.method_46558()) <= accessRange) returnList.add(bp);  }
/* 124 */                 else { returnList.add(bp); }  if (k != radius) { k++; continue; }
/*     */                  break; }
/*     */                 if (j != radius) { j++; continue; }
/*     */              break; }
/*     */             if (i != radius) { i++; continue; }
/*     */          break; }
/* 130 */         return returnList;
/*     */   }
/*     */   @NotNull
/*     */   public final List<class_2338> getGridAroundPlayer(int radius, boolean checkPlayerAccessible, double accessRange) {
/* 134 */     List<class_2338> returnList = new ArrayList();
/*     */     
/* 136 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_746 e = (Onyx.Companion.getMC()).field_1724;
/*     */     
/* 138 */     int i = -radius; if (i <= radius)
/* 139 */       while (true) { int j = -radius; if (j <= radius)
/* 140 */           while (true) { int k = -radius; if (k <= radius)
/* 141 */               while (true) { class_2338 bp = new class_2338(e.method_31477() + i, e.method_31478() + j, e.method_31479() + k);
/*     */                 
/* 143 */                 if (checkPlayerAccessible)
/* 144 */                 { Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)"); if (distanceTo(bp.method_46558()) <= accessRange) returnList.add(bp);  }
/* 145 */                 else { returnList.add(bp); }  if (k != radius) { k++; continue; }
/*     */                  break; }
/*     */                 if (j != radius) { j++; continue; }
/*     */              break; }
/*     */             if (i != radius) { i++; continue; }
/*     */          break; }
/* 151 */         return returnList;
/*     */   }
/*     */   @Nullable
/*     */   public final class_2338 getNextSchematicPos(int radius, @NotNull WorldSchematic schematic) {
/* 155 */     Intrinsics.checkNotNullParameter(schematic, "schematic"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_746 e = (Onyx.Companion.getMC()).field_1724;
/*     */     
/* 157 */     int y = -radius; if (y <= radius)
/* 158 */       while (true) { int x = -radius; if (x <= radius)
/* 159 */           while (true) { int z = -radius; if (z <= radius)
/* 160 */               while (true) { class_2338 bp = new class_2338(e.method_31477() + x, e.method_31478() + y, e.method_31479() + z);
/*     */                 
/* 162 */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); class_2680 actualBlock = (Onyx.Companion.getMC()).field_1687.method_8320(bp);
/* 163 */                 class_2680 requiredBlock = schematic.method_8320(bp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 171 */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (actualBlock.method_45474() && !requiredBlock.method_51176() && !requiredBlock.method_26215() && !Intrinsics.areEqual(actualBlock.method_26204(), requiredBlock.method_26204()) && DataManager.getRenderLayerRange().isPositionWithinRange(bp) && !(Onyx.Companion.getMC()).field_1724.method_5829().method_993(class_243.method_24954((class_2382)bp), class_243.method_24954((class_2382)bp).method_1031(1.0D, 1.0D, 1.0D)) && 
/* 172 */                   requiredBlock.method_26184((class_4538)(Onyx.Companion.getMC()).field_1687, bp))
/*     */                 {
/* 174 */                   return bp; }  if (z != radius) { z++; continue; }
/*     */                  break; }
/*     */                 if (x != radius) { x++; continue; }
/*     */              break; }
/*     */             if (y != radius) { y++; continue; }
/*     */          break; }
/* 180 */         return null;
/*     */   }
/*     */   
/*     */   public final double distanceTo(@NotNull class_243 block) {
/* 184 */     Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double d = (Onyx.Companion.getMC()).field_1724.method_23317() - block.field_1352;
/* 185 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double e = (Onyx.Companion.getMC()).field_1724.method_23318() - block.field_1351;
/* 186 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double f = (Onyx.Companion.getMC()).field_1724.method_23321() - block.field_1350;
/* 187 */     return Math.sqrt(d * d + e * e + f * f);
/*     */   }
/*     */   
/*     */   public final double distanceBetween(@NotNull class_243 block1, @NotNull class_243 block2) {
/* 191 */     Intrinsics.checkNotNullParameter(block1, "block1"); Intrinsics.checkNotNullParameter(block2, "block2"); double d = block1.field_1352 - block2.field_1352;
/* 192 */     double e = block1.field_1351 - block2.field_1351;
/* 193 */     double f = block1.field_1350 - block2.field_1350;
/* 194 */     return Math.sqrt(d * d + e * e + f * f);
/*     */   }
/*     */   public final boolean positionIsBlockedByEntity(@NotNull class_2338 bp) {
/*     */     class_1297 closest;
/* 198 */     Intrinsics.checkNotNullParameter(bp, "bp"); Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)"); if (EntityFinder.Companion.getClosestAround(bp.method_46558()) == null) { EntityFinder.Companion.getClosestAround(bp.method_46558()); return false; }
/*     */     
/* 200 */     return (new class_238(bp)).method_994(closest.method_5829());
/*     */   }
/*     */   public final boolean crystalIsBlockedByEntity(@NotNull class_2338 bp) {
/*     */     class_1297 closest;
/* 204 */     Intrinsics.checkNotNullParameter(bp, "bp"); Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)"); if (EntityFinder.Companion.getClosestAround(bp.method_46558()) == null) { EntityFinder.Companion.getClosestAround(bp.method_46558()); return false; }
/*     */     
/* 206 */     if (closest instanceof class_1657) return (new class_238(bp)).method_994(((class_1657)closest).method_5829());
/*     */     
/* 208 */     return (new class_1511((class_1937)(Onyx.Companion.getMC()).field_1687, (bp.method_46558()).field_1352, (bp.method_46558()).field_1351, (bp.method_46558()).field_1350)).method_5829().method_994(closest.method_5829());
/*     */   }
/*     */   @NotNull
/*     */   public final class_243 lerpPositionBetween(@NotNull class_243 bp1, @NotNull class_243 bp2, float partialTicks) {
/* 212 */     Intrinsics.checkNotNullParameter(bp1, "bp1"); Intrinsics.checkNotNullParameter(bp2, "bp2"); double x = class_3532.method_16436(partialTicks, bp1.field_1352, bp2.field_1352);
/* 213 */     double y = class_3532.method_16436(partialTicks, bp1.field_1351, bp2.field_1351);
/* 214 */     double z = class_3532.method_16436(partialTicks, bp1.field_1350, bp2.field_1350);
/* 215 */     return new class_243(x, y, z);
/*     */   }
/*     */   @NotNull
/*     */   public final class_2350 getDirectionOfBlockToBlock(@NotNull class_2338 bp1, @NotNull class_2338 bp2) {
/* 219 */     Intrinsics.checkNotNullParameter(bp1, "bp1"); Intrinsics.checkNotNullParameter(bp2, "bp2"); Intrinsics.checkNotNull(class_2350.method_50026(bp2.method_10263() - bp1.method_10263(), bp2.method_10264() - bp1.method_10264(), bp2.method_10260() - bp1.method_10260())); return class_2350.method_50026(bp2.method_10263() - bp1.method_10263(), bp2.method_10264() - bp1.method_10264(), bp2.method_10260() - bp1.method_10260());
/*     */   }
/*     */   @NotNull
/*     */   public final class_2338 getDirectionOfBlockToBlockAsVector(@NotNull class_2338 bp1, @NotNull class_2338 bp2) {
/* 223 */     Intrinsics.checkNotNullParameter(bp1, "bp1"); Intrinsics.checkNotNullParameter(bp2, "bp2"); return new class_2338(bp2.method_10263() - bp1.method_10263(), bp2.method_10264() - bp1.method_10264(), bp2.method_10260() - bp1.method_10260());
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\CoordinateUtils$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */