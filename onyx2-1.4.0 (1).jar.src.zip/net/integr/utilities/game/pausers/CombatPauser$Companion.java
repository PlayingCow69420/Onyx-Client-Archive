/*    */ package net.integr.utilities.game.pausers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006J\r\020\b\032\0020\007¢\006\004\b\b\020\003J\r\020\t\032\0020\007¢\006\004\b\t\020\003R\026\020\n\032\0020\0048\002@\002X\016¢\006\006\n\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/utilities/game/pausers/CombatPauser$Companion;", "", "<init>", "()V", "", "isPaused", "()Z", "", "pause", "resume", "paused", "Z", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   public final void pause() {
/* 24 */     CombatPauser.access$setPaused$cp(true);
/*    */   }
/*    */   
/*    */   public final void resume() {
/* 28 */     CombatPauser.access$setPaused$cp(false);
/*    */   }
/*    */   public final boolean isPaused() {
/* 31 */     return CombatPauser.access$getPaused$cp();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pausers\CombatPauser$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */