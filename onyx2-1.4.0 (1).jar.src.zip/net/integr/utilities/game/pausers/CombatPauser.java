/*    */ package net.integr.utilities.game.pausers;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/pausers/CombatPauser;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class CombatPauser
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   private static boolean paused;
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006J\r\020\b\032\0020\007¢\006\004\b\b\020\003J\r\020\t\032\0020\007¢\006\004\b\t\020\003R\026\020\n\032\0020\0048\002@\002X\016¢\006\006\n\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/utilities/game/pausers/CombatPauser$Companion;", "", "<init>", "()V", "", "isPaused", "()Z", "", "pause", "resume", "paused", "Z", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final void pause() {
/* 24 */       CombatPauser.paused = true;
/*    */     }
/*    */     
/*    */     public final void resume() {
/* 28 */       CombatPauser.paused = false;
/*    */     }
/*    */     public final boolean isPaused() {
/* 31 */       return CombatPauser.paused;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pausers\CombatPauser.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */