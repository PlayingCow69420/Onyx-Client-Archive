/*    */ package net.integr.utilities.game;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_6880;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/EnchantmentUtil;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class EnchantmentUtil {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\013\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J#\020\n\032\0020\t2\f\020\006\032\b\022\004\022\0020\0050\0042\006\020\b\032\0020\007¢\006\004\b\n\020\013J#\020\r\032\0020\f2\f\020\006\032\b\022\004\022\0020\0050\0042\006\020\b\032\0020\007¢\006\004\b\r\020\016J\r\020\017\032\0020\f¢\006\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/utilities/game/EnchantmentUtil$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_5321;", "Lnet/minecraft/class_1887;", "enchantment", "Lnet/minecraft/class_1799;", "itemStack", "", "getLevel", "(Lnet/minecraft/class_5321;Lnet/minecraft/class_1799;)I", "", "has", "(Lnet/minecraft/class_5321;Lnet/minecraft/class_1799;)Z", "playerHasAquaAffinity", "()Z", "onyx2"})
/*    */   public static final class Companion {
/*    */     private Companion() {}
/*    */     
/*    */     private static final Integer getLevel$lambda$0(Function1 $tmp0, Object p0) {
/*    */       Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
/*    */       return (Integer)$tmp0.invoke(p0);
/*    */     }
/*    */     
/*    */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\020\007\032\n \002*\004\030\0010\0040\0042\032\020\003\032\026\022\004\022\0020\001 \002*\n\022\004\022\0020\001\030\0010\0000\000H\n¢\006\004\b\005\020\006"}, d2 = {"Lnet/minecraft/class_6880$class_6883;", "Lnet/minecraft/class_1887;", "kotlin.jvm.PlatformType", "entry", "", "invoke", "(Lnet/minecraft/class_6880$class_6883;)Ljava/lang/Integer;", "<anonymous>"})
/*    */     static final class EnchantmentUtil$Companion$getLevel$level$1 extends Lambda implements Function1<class_6880.class_6883<class_1887>, Integer> {
/*    */       EnchantmentUtil$Companion$getLevel$level$1(class_1799 $itemStack) {
/*    */         super(1);
/*    */       }
/*    */       
/*    */       public final Integer invoke(class_6880.class_6883 entry) {
/*    */         return Integer.valueOf(class_1890.method_8225((class_6880)entry, this.$itemStack));
/*    */       }
/*    */     }
/*    */     
/*    */     public final int getLevel(@NotNull class_5321 enchantment, @NotNull class_1799 itemStack) {
/* 33 */       Intrinsics.checkNotNullParameter(enchantment, "enchantment"); Intrinsics.checkNotNullParameter(itemStack, "itemStack"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_30349().method_30530(class_7924.field_41265), "get(...)"); class_2378 registry = (Onyx.Companion.getMC()).field_1687.method_30349().method_30530(class_7924.field_41265);
/*    */       
/* 35 */       Intrinsics.checkNotNullExpressionValue(registry.method_40264(enchantment), "getEntry(...)"); Optional enchant = registry.method_40264(enchantment);
/*    */       
/* 37 */       Integer level = enchant
/* 38 */         .map(new EnchantmentUtil$Companion$getLevel$level$1(itemStack)::getLevel$lambda$0)
/* 39 */         .orElse(Integer.valueOf(0));
/*    */       
/* 41 */       Intrinsics.checkNotNull(level); return level.intValue();
/*    */     }
/*    */     
/*    */     public final boolean has(@NotNull class_5321 enchantment, @NotNull class_1799 itemStack) {
/* 45 */       Intrinsics.checkNotNullParameter(enchantment, "enchantment"); Intrinsics.checkNotNullParameter(itemStack, "itemStack"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_30349().method_30530(class_7924.field_41265), "get(...)"); class_2378 registry = (Onyx.Companion.getMC()).field_1687.method_30349().method_30530(class_7924.field_41265);
/*    */       
/* 47 */       Intrinsics.checkNotNullExpressionValue(registry.method_40264(enchantment), "getEntry(...)"); Optional enchant = registry.method_40264(enchantment);
/*    */       
/* 49 */       Integer level = enchant
/* 50 */         .map(new EnchantmentUtil$Companion$has$level$1(itemStack)::has$lambda$1)
/* 51 */         .orElse(Integer.valueOf(-1));
/*    */       
/* 53 */       byte b = -1; if (level == null) {  } else { if (level.intValue() != b); return false; }
/*    */        } private static final Integer has$lambda$1(Function1 $tmp0, Object p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
/*    */       return (Integer)$tmp0.invoke(p0); }
/*    */     public final boolean playerHasAquaAffinity() {
/* 57 */       Intrinsics.checkNotNullExpressionValue(class_1893.field_9105, "AQUA_AFFINITY"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_6047(), "getMainHandStack(...)"); return has(class_1893.field_9105, (Onyx.Companion.getMC()).field_1724.method_6047());
/*    */     }
/*    */     
/*    */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\020\007\032\n \002*\004\030\0010\0040\0042\032\020\003\032\026\022\004\022\0020\001 \002*\n\022\004\022\0020\001\030\0010\0000\000H\n¢\006\004\b\005\020\006"}, d2 = {"Lnet/minecraft/class_6880$class_6883;", "Lnet/minecraft/class_1887;", "kotlin.jvm.PlatformType", "entry", "", "invoke", "(Lnet/minecraft/class_6880$class_6883;)Ljava/lang/Integer;", "<anonymous>"})
/*    */     static final class EnchantmentUtil$Companion$has$level$1 extends Lambda implements Function1<class_6880.class_6883<class_1887>, Integer> {
/*    */       EnchantmentUtil$Companion$has$level$1(class_1799 $itemStack) {
/*    */         super(1);
/*    */       }
/*    */       
/*    */       public final Integer invoke(class_6880.class_6883 entry) {
/*    */         return Integer.valueOf(class_1890.method_8225((class_6880)entry, this.$itemStack));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\EnchantmentUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */