/*     */ package net.integr.utilities.game.entity;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\t\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\016\n\002\b\004\b\b\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002¢\006\004\b\005\020\006J\020\020\007\032\0020\002HÆ\003¢\006\004\b\007\020\bJ\020\020\t\032\0020\002HÆ\003¢\006\004\b\t\020\bJ$\020\n\032\0020\0002\b\b\002\020\003\032\0020\0022\b\b\002\020\004\032\0020\002HÆ\001¢\006\004\b\n\020\013J\032\020\017\032\0020\0162\b\020\r\032\004\030\0010\fHÖ\003¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\020\020\025\032\0020\024HÖ\001¢\006\004\b\025\020\026R\027\020\004\032\0020\0028\006¢\006\f\n\004\b\004\020\027\032\004\b\004\020\bR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\027\032\004\b\003\020\b¨\006\030"}, d2 = {"Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "Ljava/lang/Record;", "Lnet/minecraft/class_243;", "start", "end", "<init>", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "component1", "()Lnet/minecraft/class_243;", "component2", "copy", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "Lnet/minecraft/class_243;", "onyx2"})
/*     */ public final class ExposureRaycastContext
/*     */   extends Record
/*     */ {
/*     */   @NotNull
/*     */   private final class_243 start;
/*     */   @NotNull
/*     */   private final class_243 end;
/*     */   
/*     */   public ExposureRaycastContext(@NotNull class_243 start, @NotNull class_243 end) {
/* 192 */     this.start = start; this.end = end; } @NotNull public final class_243 start() { return this.start; } @NotNull public final class_243 end() { return this.end; }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final class_243 component1() {
/*     */     return this.start;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final class_243 component2() {
/*     */     return this.end;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ExposureRaycastContext copy(@NotNull class_243 start, @NotNull class_243 end) {
/*     */     Intrinsics.checkNotNullParameter(start, "start");
/*     */     Intrinsics.checkNotNullParameter(end, "end");
/*     */     return new ExposureRaycastContext(start, end);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String toString() {
/*     */     return "ExposureRaycastContext(start=" + this.start + ", end=" + this.end + ")";
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     result = this.start.hashCode();
/*     */     return result * 31 + this.end.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     if (this == other)
/*     */       return true; 
/*     */     if (!(other instanceof ExposureRaycastContext))
/*     */       return false; 
/*     */     ExposureRaycastContext exposureRaycastContext = (ExposureRaycastContext)other;
/*     */     return !Intrinsics.areEqual(this.start, exposureRaycastContext.start) ? false : (!!Intrinsics.areEqual(this.end, exposureRaycastContext.end));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\entity\DamageUtil$Companion$ExposureRaycastContext.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */