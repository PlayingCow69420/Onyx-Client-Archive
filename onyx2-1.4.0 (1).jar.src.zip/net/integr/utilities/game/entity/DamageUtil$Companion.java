/*     */ package net.integr.utilities.game.entity;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.minecraft.class_1267;
/*     */ import net.minecraft.class_1280;
/*     */ import net.minecraft.class_1282;
/*     */ import net.minecraft.class_1293;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_5134;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000Z\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\007\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\t\n\002\030\002\n\000\n\002\030\002\n\002\b\b\b\003\030\0002\0020\001:\00289B\t\b\002¢\006\004\b\002\020\003J'\020\n\032\0020\0042\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\t\032\0020\bH\002¢\006\004\b\n\020\013J-\020\023\032\0020\0042\006\020\f\032\0020\0062\006\020\016\032\0020\r2\006\020\020\032\0020\0172\006\020\022\032\0020\021¢\006\004\b\023\020\024JA\020\034\032\0020\0042\006\020\f\032\0020\0062\006\020\025\032\0020\r2\006\020\027\032\0020\0262\006\020\030\032\0020\r2\006\020\031\032\0020\0042\b\020\033\032\004\030\0010\032H\002¢\006\004\b\034\020\035J9\020\034\032\0020\0042\b\020\f\032\004\030\0010\0062\006\020\030\032\0020\r2\006\020\031\032\0020\0042\006\020\020\032\0020\0172\006\020\033\032\0020\032H\002¢\006\004\b\034\020\036J\027\020\037\032\0020\0042\006\020\007\032\0020\006H\002¢\006\004\b\037\020 J'\020#\032\0020\0042\006\020!\032\0020\r2\006\020\"\032\0020\0262\006\020\033\032\0020\032H\002¢\006\004\b#\020$J\037\020(\032\0020\0322\006\020%\032\0020\0212\006\020'\032\0020&H\002¢\006\004\b(\020)J?\020*\032\0020\0042\006\020\f\032\0020\0062\006\020\030\032\0020\r2\006\020\031\032\0020\0042\006\020\020\032\0020\0172\006\020%\032\0020\0212\006\020'\032\0020&H\002¢\006\004\b*\020+J'\020.\032\0020\0042\006\020,\032\0020\0062\006\020-\032\0020\0042\006\020!\032\0020\bH\002¢\006\004\b.\020/J!\0203\032\004\030\001022\006\0201\032\002002\006\020\033\032\0020\032H\002¢\006\004\b3\0204J%\0205\032\0020\0042\006\020-\032\0020\0042\006\020\f\032\0020\0062\006\020!\032\0020\b¢\006\004\b5\020\013J\037\0206\032\0020\0042\006\020,\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b6\0207¨\006:"}, d2 = {"Lnet/integr/utilities/game/entity/DamageUtil$Companion;", "", "<init>", "()V", "", "damageI", "Lnet/minecraft/class_1309;", "entity", "Lnet/minecraft/class_1282;", "damageSource", "calculateReductions", "(FLnet/minecraft/class_1309;Lnet/minecraft/class_1282;)F", "target", "Lnet/minecraft/class_243;", "crystal", "", "predictMovement", "Lnet/minecraft/class_2338;", "obsidianPos", "crystalDamage", "(Lnet/minecraft/class_1309;Lnet/minecraft/class_243;ZLnet/minecraft/class_2338;)F", "targetPos", "Lnet/minecraft/class_238;", "targetBox", "explosionPos", "power", "Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;", "raycastFactory", "explosionDamage", "(Lnet/minecraft/class_1309;Lnet/minecraft/class_243;Lnet/minecraft/class_238;Lnet/minecraft/class_243;FLnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;)F", "(Lnet/minecraft/class_1309;Lnet/minecraft/class_243;FZLnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;)F", "getArmor", "(Lnet/minecraft/class_1309;)F", "source", "box", "getExposure", "(Lnet/minecraft/class_243;Lnet/minecraft/class_238;Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;)F", "overridePos", "Lnet/minecraft/class_2680;", "overrideState", "getOverridingHitFactory", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2680;)Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;", "overridingExplosionDamage", "(Lnet/minecraft/class_1309;Lnet/minecraft/class_243;FZLnet/minecraft/class_2338;Lnet/minecraft/class_2680;)F", "player", "damage", "protectionReduction", "(Lnet/minecraft/class_1309;FLnet/minecraft/class_1282;)F", "Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "context", "Lnet/minecraft/class_3965;", "raycast", "(Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;)Lnet/minecraft/class_3965;", "reduceDamage", "resistanceReduction", "(Lnet/minecraft/class_1309;F)F", "ExposureRaycastContext", "RaycastFactory", "onyx2"})
/*     */ public final class Companion
/*     */ {
/*     */   private Companion() {}
/*     */   
/*     */   public final float reduceDamage(float damage, @NotNull class_1309 target, @NotNull class_1282 source) {
/*  47 */     Intrinsics.checkNotNullParameter(target, "target"); Intrinsics.checkNotNullParameter(source, "source"); return calculateReductions(damage, target, source);
/*     */   }
/*     */   
/*     */   public final float crystalDamage(@NotNull class_1309 target, @NotNull class_243 crystal, boolean predictMovement, @NotNull class_2338 obsidianPos) {
/*  51 */     Intrinsics.checkNotNullParameter(target, "target"); Intrinsics.checkNotNullParameter(crystal, "crystal"); Intrinsics.checkNotNullParameter(obsidianPos, "obsidianPos"); Intrinsics.checkNotNullExpressionValue(class_2246.field_10540.method_9564(), "getDefaultState(...)"); return overridingExplosionDamage(target, crystal, 12.0F, predictMovement, obsidianPos, class_2246.field_10540.method_9564());
/*     */   }
/*     */   
/*     */   private final float calculateReductions(float damageI, class_1309 entity, class_1282 damageSource) {
/*  55 */     float damage = damageI;
/*  56 */     if (damageSource.method_5514()) {
/*  57 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); (Onyx.Companion.getMC()).field_1687.method_8407(); switch (((Onyx.Companion.getMC()).field_1687.method_8407() == null) ? -1 : WhenMappings.$EnumSwitchMapping$0[(Onyx.Companion.getMC()).field_1687.method_8407().ordinal()]) { case true:
/*  58 */           damage = (float)Math.min((damage / 2 + true), damage); break;
/*  59 */         case true: damage *= 1.5F;
/*     */           break; }
/*     */ 
/*     */     
/*     */     } 
/*  64 */     damage = class_1280.method_5496((class_1309)(Onyx.Companion.getMC()).field_1724, damage, damageSource, getArmor(entity), (float)entity.method_45325(class_5134.field_23725));
/*     */     
/*  66 */     damage = resistanceReduction(entity, damage);
/*     */     
/*  68 */     damage = protectionReduction(entity, damage, damageSource);
/*     */     
/*  70 */     return (float)Math.max(damage, 0.0D);
/*     */   }
/*     */   
/*     */   private final float getArmor(class_1309 entity) {
/*  74 */     return (float)Math.floor(entity.method_45325(class_5134.field_23724));
/*     */   }
/*     */ 
/*     */   
/*     */   private final float protectionReduction(class_1309 player, float damage, class_1282 source) {
/*  79 */     return class_1280.method_5497(damage, 0.0F);
/*     */   }
/*     */   
/*     */   private final float resistanceReduction(class_1309 player, float damageI) {
/*  83 */     float damage = damageI;
/*  84 */     class_1293 resistance = player.method_6112(class_1294.field_5907);
/*  85 */     if (resistance != null) {
/*  86 */       int lvl = resistance.method_5578() + 1;
/*  87 */       damage *= true - lvl * 0.2F;
/*     */     } 
/*     */     
/*  90 */     return (float)Math.max(damage, 0.0D);
/*     */   }
/*     */   
/*     */   private final float overridingExplosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement, class_2338 overridePos, class_2680 overrideState) {
/*  94 */     return explosionDamage(target, explosionPos, power, predictMovement, getOverridingHitFactory(overridePos, overrideState));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final float explosionDamage(class_1309 target, class_243 targetPos, class_238 targetBox, class_243 explosionPos, float power, RaycastFactory raycastFactory) {
/* 100 */     double modDistance = CoordinateUtils.Companion.distanceBetween(
/* 101 */         new class_243(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350), 
/* 102 */         new class_243(explosionPos.field_1352, explosionPos.field_1351, explosionPos.field_1350));
/*     */     
/* 104 */     if (modDistance > power) return 0.0F;
/*     */     
/* 106 */     Intrinsics.checkNotNull(raycastFactory); double exposure = getExposure(explosionPos, targetBox, raycastFactory);
/* 107 */     double impact = (true - modDistance / power) * exposure;
/* 108 */     float damage = (int)((impact * impact + impact) / 2 * 7 * 12 + true);
/*     */     
/* 110 */     return damage;
/*     */   } private final RaycastFactory getOverridingHitFactory(class_2338 overridePos, class_2680 overrideState) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: aload_2
/*     */     //   2: <illegal opcode> apply : (Lnet/minecraft/class_2338;Lnet/minecraft/class_2680;)Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;
/*     */     //   7: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #114	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lnet/integr/utilities/game/entity/DamageUtil$Companion;
/*     */     //   0	8	1	overridePos	Lnet/minecraft/class_2338;
/*     */     //   0	8	2	overrideState	Lnet/minecraft/class_2680;
/*     */   }
/*     */   private static final class_3965 getOverridingHitFactory$lambda$0(class_2338 $overridePos, class_2680 $overrideState, ExposureRaycastContext context, class_2338 blockPos) {
/* 115 */     Intrinsics.checkNotNullParameter($overridePos, "$overridePos"); Intrinsics.checkNotNullParameter($overrideState, "$overrideState"); Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNullParameter(blockPos, "blockPos"); class_2680 blockState = null;
/* 116 */     if (Intrinsics.areEqual(blockPos, $overridePos)) { blockState = $overrideState; }
/*     */     else
/* 118 */     { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(blockPos), "getBlockState(...)"); blockState = (Onyx.Companion.getMC()).field_1687.method_8320(blockPos);
/* 119 */       if (blockState.method_26204().method_9520() < 600.0F) return null;  }
/*     */     
/* 121 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); return blockState.method_26220((class_1922)(Onyx.Companion.getMC()).field_1687, blockPos).method_1092(context.start(), context.end(), blockPos);
/*     */   }
/*     */ 
/*     */   
/*     */   private final float explosionDamage(class_1309 target, class_243 explosionPos, float power, boolean predictMovement, RaycastFactory raycastFactory) {
/* 126 */     if (target == null) return 0.0F;
/*     */     
/* 128 */     class_243 position = predictMovement ? target.method_19538().method_1019(target.method_18798()) : target.method_19538();
/*     */     
/* 130 */     class_238 box = target.method_5829();
/* 131 */     if (predictMovement) box = box.method_997(target.method_18798());
/*     */     
/* 133 */     Intrinsics.checkNotNull(position); class_238 class_2381 = box; Intrinsics.checkNotNull(class_2381); return explosionDamage(target, position, class_2381, explosionPos, power, raycastFactory);
/*     */   }
/*     */   
/*     */   private final float getExposure(class_243 source, class_238 box, RaycastFactory raycastFactory) {
/* 137 */     double xDiff = box.field_1320 - box.field_1323;
/* 138 */     double yDiff = box.field_1325 - box.field_1322;
/* 139 */     double zDiff = box.field_1324 - box.field_1321;
/*     */     
/* 141 */     double xStep = true / (xDiff * 2 + true);
/* 142 */     double yStep = true / (yDiff * 2 + true);
/* 143 */     double zStep = true / (zDiff * 2 + true);
/*     */     
/* 145 */     if (xStep > 0.0D && yStep > 0.0D && zStep > 0.0D) {
/* 146 */       int misses = 0;
/* 147 */       int hits = 0;
/*     */       
/* 149 */       double xOffset = (true - Math.floor(true / xStep) * xStep) * 0.5D;
/* 150 */       double zOffset = (true - Math.floor(true / zStep) * zStep) * 0.5D;
/*     */       
/* 152 */       xStep *= xDiff;
/* 153 */       yStep *= yDiff;
/* 154 */       zStep *= zDiff;
/*     */       
/* 156 */       double startX = box.field_1323 + xOffset;
/* 157 */       double startY = box.field_1322;
/* 158 */       double startZ = box.field_1321 + zOffset;
/* 159 */       double endX = box.field_1320 + xOffset;
/* 160 */       double endY = box.field_1325;
/* 161 */       double endZ = box.field_1324 + zOffset;
/*     */       
/* 163 */       double x = startX;
/* 164 */       while (x <= endX) {
/* 165 */         double y = startY;
/* 166 */         while (y <= endY) {
/* 167 */           double z = startZ;
/* 168 */           while (z <= endZ) {
/* 169 */             class_243 position = new class_243(x, y, z);
/*     */             
/* 171 */             if (raycast(new ExposureRaycastContext(position, source), raycastFactory) == null) misses++;
/*     */             
/* 173 */             hits++;
/* 174 */             z += zStep;
/*     */           } 
/* 176 */           y += yStep;
/*     */         } 
/* 178 */         x += xStep;
/*     */       } 
/*     */       
/* 181 */       return misses / hits;
/*     */     } 
/*     */     
/* 184 */     return 0.0F;
/*     */   }
/*     */   
/*     */   private final class_3965 raycast(ExposureRaycastContext context, RaycastFactory raycastFactory) {
/* 188 */     return (class_3965)class_1922.method_17744(context.start(), context.end(), context, raycastFactory, Companion::raycast$lambda$1); } private static final class_3965 raycast$lambda$1(ExposureRaycastContext it) { return null; }
/*     */    @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\t\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\016\n\002\b\004\b\b\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002¢\006\004\b\005\020\006J\020\020\007\032\0020\002HÆ\003¢\006\004\b\007\020\bJ\020\020\t\032\0020\002HÆ\003¢\006\004\b\t\020\bJ$\020\n\032\0020\0002\b\b\002\020\003\032\0020\0022\b\b\002\020\004\032\0020\002HÆ\001¢\006\004\b\n\020\013J\032\020\017\032\0020\0162\b\020\r\032\004\030\0010\fHÖ\003¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\020\020\025\032\0020\024HÖ\001¢\006\004\b\025\020\026R\027\020\004\032\0020\0028\006¢\006\f\n\004\b\004\020\027\032\004\b\004\020\bR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\027\032\004\b\003\020\b¨\006\030"}, d2 = {"Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "Ljava/lang/Record;", "Lnet/minecraft/class_243;", "start", "end", "<init>", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "component1", "()Lnet/minecraft/class_243;", "component2", "copy", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "Lnet/minecraft/class_243;", "onyx2"})
/*     */   public static final class ExposureRaycastContext extends Record {
/*     */     @NotNull
/* 192 */     private final class_243 start; public ExposureRaycastContext(@NotNull class_243 start, @NotNull class_243 end) { this.start = start; this.end = end; } @NotNull private final class_243 end; @NotNull public final class_243 start() { return this.start; } @NotNull public final class_243 end() { return this.end; }
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     public final class_243 component1() {
/*     */       return this.start;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final class_243 component2() {
/*     */       return this.end;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final ExposureRaycastContext copy(@NotNull class_243 start, @NotNull class_243 end) {
/*     */       Intrinsics.checkNotNullParameter(start, "start");
/*     */       Intrinsics.checkNotNullParameter(end, "end");
/*     */       return new ExposureRaycastContext(start, end);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public String toString() {
/*     */       return "ExposureRaycastContext(start=" + this.start + ", end=" + this.end + ")";
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       result = this.start.hashCode();
/*     */       return result * 31 + this.end.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/*     */       if (this == other)
/*     */         return true; 
/*     */       if (!(other instanceof ExposureRaycastContext))
/*     */         return false; 
/*     */       ExposureRaycastContext exposureRaycastContext = (ExposureRaycastContext)other;
/*     */       return !Intrinsics.areEqual(this.start, exposureRaycastContext.start) ? false : (!!Intrinsics.areEqual(this.end, exposureRaycastContext.end));
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\bç\001\030\0002\026\022\004\022\0020\002\022\004\022\0020\003\022\006\022\004\030\0010\0040\001¨\006\005"}, d2 = {"Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;", "Ljava/util/function/BiFunction;", "Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "Lnet/minecraft/class_2338;", "Lnet/minecraft/class_3965;", "onyx2"})
/*     */   public static interface RaycastFactory extends BiFunction<ExposureRaycastContext, class_2338, class_3965> {}
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\entity\DamageUtil$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */