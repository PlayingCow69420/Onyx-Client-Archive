package net.integr.utilities.game.entity;

import kotlin.Metadata;
import net.minecraft.class_1267;



/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\entity\DamageUtil$Companion$WhenMappings.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */