/*     */ package net.integr.utilities.game.entity;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.minecraft.class_1309;
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/entity/EntityFinder;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class EntityFinder { @NotNull
/*     */   public static final Companion Companion = new Companion(null); @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000N\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\006\n\000\n\002\020\016\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\t\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\b\032\0020\0072\006\020\005\032\0020\0042\006\020\006\032\0020\004¢\006\004\b\b\020\tJ-\020\021\032\b\022\004\022\0020\0200\0172\006\020\013\032\0020\n2\006\020\r\032\0020\f2\b\b\002\020\016\032\0020\007¢\006\004\b\021\020\022J\027\020\025\032\004\030\0010\0042\006\020\024\032\0020\023¢\006\004\b\025\020\026J)\020\027\032\004\030\0010\0202\006\020\013\032\0020\n2\006\020\r\032\0020\f2\b\b\002\020\016\032\0020\007¢\006\004\b\027\020\030J\027\020\032\032\004\030\0010\0312\006\020\024\032\0020\023¢\006\004\b\032\020\033J\027\020\036\032\004\030\0010\0352\006\020\034\032\0020\f¢\006\004\b\036\020\037J\017\020 \032\004\030\0010\004¢\006\004\b \020!J\027\020\"\032\004\030\0010\0202\006\020\013\032\0020\n¢\006\004\b\"\020#J\025\020$\032\0020\0072\006\020\006\032\0020\004¢\006\004\b$\020%¨\006&"}, d2 = {"Lnet/integr/utilities/game/entity/EntityFinder$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_1297;", "toInspect", "entity", "", "entityCanSeeEntity", "(Lnet/minecraft/class_1297;Lnet/minecraft/class_1297;)Z", "", "range", "", "target", "checkSee", "", "Lnet/minecraft/class_1309;", "getAuraEntities", "(DLjava/lang/String;Z)Ljava/util/List;", "Lnet/minecraft/class_243;", "pos", "getClosestAround", "(Lnet/minecraft/class_243;)Lnet/minecraft/class_1297;", "getClosestAuraEntity", "(DLjava/lang/String;Z)Lnet/minecraft/class_1309;", "Lnet/minecraft/class_1511;", "getClosestCrystalAround", "(Lnet/minecraft/class_243;)Lnet/minecraft/class_1511;", "name", "Lnet/minecraft/class_1657;", "getPlayerByName", "(Ljava/lang/String;)Lnet/minecraft/class_1657;", "getRandomEntity", "()Lnet/minecraft/class_1297;", "getStaredAtEntity", "(D)Lnet/minecraft/class_1309;", "playerStaringAt", "(Lnet/minecraft/class_1297;)Z", "onyx2"})
/*     */   @SourceDebugExtension({"SMAP\nEntityFinder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EntityFinder.kt\nnet/integr/utilities/game/entity/EntityFinder$Companion\n+ 2 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,176:1\n473#2:177\n473#2:185\n473#2:254\n766#3:178\n857#3,2:179\n766#3:181\n857#3,2:182\n1045#3:184\n766#3:186\n857#3,2:187\n766#3:189\n857#3,2:190\n2333#3,14:192\n2333#3,14:206\n800#3,11:220\n766#3:231\n857#3,2:232\n2333#3,14:234\n1747#3,3:248\n766#3:251\n857#3,2:252\n1855#3,2:255\n288#3,2:257\n*S KotlinDebug\n*F\n+ 1 EntityFinder.kt\nnet/integr/utilities/game/entity/EntityFinder$Companion\n*L\n38#1:177\n71#1:185\n119#1:254\n61#1:178\n61#1:179,2\n62#1:181\n62#1:182,2\n65#1:184\n94#1:186\n94#1:187,2\n95#1:189\n95#1:190,2\n98#1:192,14\n102#1:206,14\n106#1:220,11\n106#1:231\n106#1:232,2\n109#1:234,14\n113#1:248,3\n113#1:251\n113#1:252,2\n138#1:255,2\n173#1:257,2\n*E\n"})
/*     */   public static final class Companion { private Companion() {}
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"})
/*     */     static final class EntityFinder$Companion$getAuraEntities$entities$1 extends Lambda implements Function1<class_1309, Boolean> { public static final EntityFinder$Companion$getAuraEntities$entities$1 INSTANCE = new EntityFinder$Companion$getAuraEntities$entities$1();
/*     */       @NotNull
/*     */       public final Boolean invoke(@NotNull class_1309 it) {
/*     */         Intrinsics.checkNotNullParameter(it, "it");
/*     */         return Boolean.valueOf((!Intrinsics.areEqual(it.method_5864(), class_1299.field_6043) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6131) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_28401) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6120) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6096) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6053) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6126) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6058) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6080) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6136) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6142) && !Intrinsics.areEqual(it, (Onyx.Companion.getMC()).field_1724) && it.method_5805()));
/*     */       }
/*     */       EntityFinder$Companion$getAuraEntities$entities$1() {
/*     */         super(1);
/*     */       } }
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"})
/*     */     static final class EntityFinder$Companion$getAuraEntities$entities$2 extends Lambda implements Function1<class_1309, Boolean> { EntityFinder$Companion$getAuraEntities$entities$2(double $range) {
/*     */         super(1);
/*     */       }
/*     */       @NotNull
/*     */       public final Boolean invoke(@NotNull class_1309 it) {
/*     */         Intrinsics.checkNotNullParameter(it, "it");
/*     */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */         return Boolean.valueOf(((Onyx.Companion.getMC()).field_1724.method_5739((class_1297)it) <= this.$range));
/*     */       } }
/*     */     @NotNull
/*     */     public final List<class_1309> getAuraEntities(double range, @NotNull String target, boolean checkSee) { List list1;
/*     */       Iterable $this$filter$iv;
/*     */       int $i$f$filter;
/*     */       Iterable iterable1, $this$filterTo$iv$iv;
/*     */       Collection<Object> collection1, destination$iv$iv;
/*     */       int $i$f$filterTo;
/*  36 */       Intrinsics.checkNotNullParameter(target, "target"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_18112(), "getEntities(...)");
/*  37 */       Sequence sequence = CollectionsKt.asSequence((Onyx.Companion.getMC()).field_1687.method_18112());
/*  38 */       int $i$f$filterIsInstance = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       Intrinsics.checkNotNull(SequencesKt.filter(sequence, EntityFinder$Companion$getAuraEntities$$inlined$filterIsInstance$1.INSTANCE), "null cannot be cast to non-null type kotlin.sequences.Sequence<R of kotlin.sequences.SequencesKt___SequencesKt.filterIsInstance>"); List entities = SequencesKt.toList(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(sequence, EntityFinder$Companion$getAuraEntities$$inlined$filterIsInstance$1.INSTANCE), EntityFinder$Companion$getAuraEntities$entities$1.INSTANCE), new EntityFinder$Companion$getAuraEntities$entities$2(range)), new EntityFinder$Companion$getAuraEntities$entities$3(checkSee)), EntityFinder$Companion$getAuraEntities$entities$4.INSTANCE)); List newEntities = CollectionsKt.emptyList(); String str = target; switch (str.hashCode()) { case 65921: if (!str.equals("All")) break;  list1 = entities; break;case 2403731: if (!str.equals("Mobs"))
/* 178 */             break;  $this$filter$iv = entities; $i$f$filter = 0; iterable1 = $this$filter$iv; collection1 = new ArrayList(); $i$f$filterTo = 0;
/* 179 */           for (Object element$iv$iv : iterable1) { class_1309 it = (class_1309)element$iv$iv; int $i$a$-filter-EntityFinder$Companion$getAuraEntities$1 = 0; if (!Intrinsics.areEqual(it.method_5864(), class_1299.field_6097)) collection1.add(element$iv$iv);  }
/* 180 */            list1 = (List)collection1; break;case 1171085714: if (!str.equals("Players"))
/* 181 */             break;  $this$filter$iv = entities; $i$f$filter = 0; $this$filterTo$iv$iv = $this$filter$iv; destination$iv$iv = new ArrayList(); $i$f$filterTo = 0;
/* 182 */           for (Object element$iv$iv : $this$filterTo$iv$iv) { class_1309 it = (class_1309)element$iv$iv; int $i$a$-filter-EntityFinder$Companion$getAuraEntities$2 = 0; if (Intrinsics.areEqual(it.method_5864(), class_1299.field_6097)) destination$iv$iv.add(element$iv$iv);  }
/* 183 */            list1 = (List)destination$iv$iv; break; }
/* 184 */        Iterable $this$sortedBy$iv = list1; int $i$f$sortedBy = 0; return CollectionsKt.sortedWith($this$sortedBy$iv, new EntityFinder$Companion$getAuraEntities$$inlined$sortedBy$1()); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"}) static final class EntityFinder$Companion$getAuraEntities$entities$3 extends Lambda implements Function1<class_1309, Boolean> {
/* 185 */       EntityFinder$Companion$getAuraEntities$entities$3(boolean $checkSee) { super(1); } @NotNull public final Boolean invoke(@NotNull class_1309 it) { Intrinsics.checkNotNullParameter(it, "it"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return Boolean.valueOf(this.$checkSee ? (Onyx.Companion.getMC()).field_1724.method_6057((class_1297)it) : true); } } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"}) static final class EntityFinder$Companion$getAuraEntities$entities$4 extends Lambda implements Function1<class_1309, Boolean> { public static final EntityFinder$Companion$getAuraEntities$entities$4 INSTANCE = new EntityFinder$Companion$getAuraEntities$entities$4(); EntityFinder$Companion$getAuraEntities$entities$4() { super(1); } @NotNull public final Boolean invoke(@NotNull class_1309 it) { Intrinsics.checkNotNullParameter(it, "it"); return Boolean.valueOf((it instanceof class_1657) ? (!FriendStorage.Companion.contains((class_1657)it)) : true); } } @Nullable public final class_1309 getClosestAuraEntity(double range, @NotNull String target, boolean checkSee) { List list1; Iterable $this$filter$iv; int $i$f$filter; Iterable iterable1, $this$filterTo$iv$iv; Collection<Object> collection1, destination$iv$iv; int $i$f$filterTo; Intrinsics.checkNotNullParameter(target, "target"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_18112(), "getEntities(...)"); Sequence sequence = CollectionsKt.asSequence((Onyx.Companion.getMC()).field_1687.method_18112()); int $i$f$filterIsInstance = 0; Intrinsics.checkNotNull(SequencesKt.filter(sequence, EntityFinder$Companion$getClosestAuraEntity$$inlined$filterIsInstance$1.INSTANCE), "null cannot be cast to non-null type kotlin.sequences.Sequence<R of kotlin.sequences.SequencesKt___SequencesKt.filterIsInstance>"); List entities = SequencesKt.toList(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(sequence, EntityFinder$Companion$getClosestAuraEntity$$inlined$filterIsInstance$1.INSTANCE), EntityFinder$Companion$getClosestAuraEntity$entities$1.INSTANCE), new EntityFinder$Companion$getClosestAuraEntity$entities$2(range)), EntityFinder$Companion$getClosestAuraEntity$entities$3.INSTANCE), new EntityFinder$Companion$getClosestAuraEntity$entities$4(checkSee))); List newEntities = CollectionsKt.emptyList(); String str = target; switch (str.hashCode()) { case 65921: if (!str.equals("All")) break;  list1 = entities; break;case 2403731: if (!str.equals("Mobs"))
/* 186 */             break;  $this$filter$iv = entities; $i$f$filter = 0; iterable1 = $this$filter$iv; collection1 = new ArrayList(); $i$f$filterTo = 0;
/* 187 */           for (Object element$iv$iv : iterable1) { class_1309 it = (class_1309)element$iv$iv; int $i$a$-filter-EntityFinder$Companion$getClosestAuraEntity$1 = 0; if (!Intrinsics.areEqual(it.method_5864(), class_1299.field_6097)) collection1.add(element$iv$iv);  }
/* 188 */            list1 = (List)collection1; break;case 1171085714: if (!str.equals("Players"))
/* 189 */             break;  $this$filter$iv = entities; $i$f$filter = 0; $this$filterTo$iv$iv = $this$filter$iv; destination$iv$iv = new ArrayList(); $i$f$filterTo = 0;
/* 190 */           for (Object element$iv$iv : $this$filterTo$iv$iv) { class_1309 it = (class_1309)element$iv$iv; int $i$a$-filter-EntityFinder$Companion$getClosestAuraEntity$2 = 0; if (Intrinsics.areEqual(it.method_5864(), class_1299.field_6097)) destination$iv$iv.add(element$iv$iv);  }
/* 191 */            list1 = (List)destination$iv$iv; break; }
/* 192 */        Iterable $this$minByOrNull$iv = list1; int $i$f$minByOrNull = 0; Iterator iterator$iv = $this$minByOrNull$iv.iterator();
/*     */       
/* 194 */       Object minElem$iv = iterator$iv.next();
/* 195 */       if (!iterator$iv.hasNext()) {  }
/* 196 */       else { class_1309 it = (class_1309)minElem$iv; int $i$a$-minByOrNull-EntityFinder$Companion$getClosestAuraEntity$3 = 0; Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); float minValue$iv = (Onyx.Companion.getMC()).field_1724.method_5739((class_1297)it); }  return !iterator$iv.hasNext() ? null : (class_1309)"JD-Core does not support Kotlin"; } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"}) static final class EntityFinder$Companion$getClosestAuraEntity$entities$1 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       public static final EntityFinder$Companion$getClosestAuraEntity$entities$1 INSTANCE = new EntityFinder$Companion$getClosestAuraEntity$entities$1(); @NotNull public final Boolean invoke(@NotNull class_1309 it) { Intrinsics.checkNotNullParameter(it, "it"); return Boolean.valueOf((!Intrinsics.areEqual(it.method_5864(), class_1299.field_6043) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6131) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_28401) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6120) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6096) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6053) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6126) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6058) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6080) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6136) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6142) && !Intrinsics.areEqual(it, (Onyx.Companion.getMC()).field_1724) && it.method_5805())); } EntityFinder$Companion$getClosestAuraEntity$entities$1() { super(1); } } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"}) static final class EntityFinder$Companion$getClosestAuraEntity$entities$2 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       EntityFinder$Companion$getClosestAuraEntity$entities$2(double $range) { super(1); } @NotNull public final Boolean invoke(@NotNull class_1309 it) { Intrinsics.checkNotNullParameter(it, "it"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return Boolean.valueOf(((Onyx.Companion.getMC()).field_1724.method_5739((class_1297)it) <= this.$range)); } }
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"}) static final class EntityFinder$Companion$getClosestAuraEntity$entities$3 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       public static final EntityFinder$Companion$getClosestAuraEntity$entities$3 INSTANCE = new EntityFinder$Companion$getClosestAuraEntity$entities$3();
/*     */       EntityFinder$Companion$getClosestAuraEntity$entities$3() { super(1); }
/*     */       @NotNull public final Boolean invoke(@NotNull class_1309 it) { Intrinsics.checkNotNullParameter(it, "it"); return Boolean.valueOf((it instanceof class_1657) ? (!FriendStorage.Companion.contains((class_1657)it)) : true); } }
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"}) static final class EntityFinder$Companion$getClosestAuraEntity$entities$4 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       EntityFinder$Companion$getClosestAuraEntity$entities$4(boolean $checkSee) { super(1); }
/*     */       @NotNull public final Boolean invoke(@NotNull class_1309 it) { Intrinsics.checkNotNullParameter(it, "it"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return Boolean.valueOf(this.$checkSee ? (Onyx.Companion.getMC()).field_1724.method_6057((class_1297)it) : true); } }
/* 206 */     @Nullable public final class_1297 getClosestAround(@NotNull class_243 pos) { Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_18112(), "getEntities(...)"); Iterable $this$minByOrNull$iv = (Onyx.Companion.getMC()).field_1687.method_18112(); int $i$f$minByOrNull = 0; Iterator iterator$iv = $this$minByOrNull$iv.iterator();
/*     */       
/* 208 */       Object minElem$iv = iterator$iv.next();
/* 209 */       if (!iterator$iv.hasNext()) {  }
/* 210 */       else { class_1297 it = (class_1297)minElem$iv; int $i$a$-minByOrNull-EntityFinder$Companion$getClosestAround$1 = 0; Intrinsics.checkNotNullExpressionValue(it.method_19538(), "getPos(...)"); double minValue$iv = CoordinateUtils.Companion.distanceBetween(pos, it.method_19538()); }
/*     */       
/*     */       return !iterator$iv.hasNext() ? null : (class_1297)"JD-Core does not support Kotlin"; }
/*     */      @Nullable
/*     */     public final class_1511 getClosestCrystalAround(@NotNull class_243 pos) {
/*     */       Intrinsics.checkNotNullParameter(pos, "pos");
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_18112(), "getEntities(...)");
/*     */       Iterable $this$filterIsInstance$iv = (Onyx.Companion.getMC()).field_1687.method_18112();
/*     */       int $i$f$filterIsInstance = 0;
/* 220 */       Iterable iterable1 = $this$filterIsInstance$iv; Collection<Object> collection1 = new ArrayList(); int $i$f$filterIsInstanceTo = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       for (Object element$iv$iv : iterable1) { if (element$iv$iv instanceof class_1511) collection1.add(element$iv$iv);  }
/* 230 */        $this$filterIsInstance$iv = collection1; int $i$f$filter = 0;
/* 231 */       Iterable $this$filterIsInstanceTo$iv$iv = $this$filterIsInstance$iv; Collection<Object> destination$iv$iv = new ArrayList(); int $i$f$filterTo = 0;
/* 232 */       for (Object element$iv$iv : $this$filterIsInstanceTo$iv$iv) { class_1511 it = (class_1511)element$iv$iv; int $i$a$-filter-EntityFinder$Companion$getClosestCrystalAround$1 = 0; Intrinsics.checkNotNullExpressionValue(it.method_19538(), "getPos(...)"); if ((CoordinateUtils.Companion.distanceBetween(pos, it.method_19538()) < 0.7D)) destination$iv$iv.add(element$iv$iv);  }
/* 233 */        Iterable $this$filter$iv = destination$iv$iv; int $i$f$minByOrNull = 0;
/* 234 */       Iterator iterator$iv = $this$filter$iv.iterator();
/*     */       
/* 236 */       Object minElem$iv = iterator$iv.next();
/* 237 */       if (!iterator$iv.hasNext()) {  }
/* 238 */       else { class_1511 it = (class_1511)minElem$iv; int $i$a$-minByOrNull-EntityFinder$Companion$getClosestCrystalAround$2 = 0; Intrinsics.checkNotNullExpressionValue(it.method_19538(), "getPos(...)"); double minValue$iv = CoordinateUtils.Companion.distanceBetween(pos, it.method_19538()); }
/*     */       
/*     */       return !iterator$iv.hasNext() ? null : (class_1511)"JD-Core does not support Kotlin";
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public final class_1297 getRandomEntity() {
/*     */       // Byte code:
/*     */       //   0: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */       //   3: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */       //   6: getfield field_1687 : Lnet/minecraft/class_638;
/*     */       //   9: dup
/*     */       //   10: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */       //   13: invokevirtual method_18112 : ()Ljava/lang/Iterable;
/*     */       //   16: dup
/*     */       //   17: ldc 'getEntities(...)'
/*     */       //   19: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */       //   22: astore_1
/*     */       //   23: iconst_0
/*     */       //   24: istore_2
/*     */       //   25: aload_1
/*     */       //   26: instanceof java/util/Collection
/*     */       //   29: ifeq -> 48
/*     */       //   32: aload_1
/*     */       //   33: checkcast java/util/Collection
/*     */       //   36: invokeinterface isEmpty : ()Z
/*     */       //   41: ifeq -> 48
/*     */       //   44: iconst_0
/*     */       //   45: goto -> 112
/*     */       //   48: aload_1
/*     */       //   49: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */       //   54: astore_3
/*     */       //   55: aload_3
/*     */       //   56: invokeinterface hasNext : ()Z
/*     */       //   61: ifeq -> 111
/*     */       //   64: aload_3
/*     */       //   65: invokeinterface next : ()Ljava/lang/Object;
/*     */       //   70: astore #4
/*     */       //   72: aload #4
/*     */       //   74: checkcast net/minecraft/class_1297
/*     */       //   77: astore #5
/*     */       //   79: iconst_0
/*     */       //   80: istore #6
/*     */       //   82: aload #5
/*     */       //   84: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */       //   87: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */       //   90: getfield field_1724 : Lnet/minecraft/class_746;
/*     */       //   93: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */       //   96: ifne -> 103
/*     */       //   99: iconst_1
/*     */       //   100: goto -> 104
/*     */       //   103: iconst_0
/*     */       //   104: ifeq -> 55
/*     */       //   107: iconst_1
/*     */       //   108: goto -> 112
/*     */       //   111: iconst_0
/*     */       //   112: ifeq -> 256
/*     */       //   115: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */       //   118: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */       //   121: getfield field_1687 : Lnet/minecraft/class_638;
/*     */       //   124: dup
/*     */       //   125: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */       //   128: invokevirtual method_18112 : ()Ljava/lang/Iterable;
/*     */       //   131: dup
/*     */       //   132: ldc 'getEntities(...)'
/*     */       //   134: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */       //   137: astore_1
/*     */       //   138: iconst_0
/*     */       //   139: istore_2
/*     */       //   140: aload_1
/*     */       //   141: astore_3
/*     */       //   142: new java/util/ArrayList
/*     */       //   145: dup
/*     */       //   146: invokespecial <init> : ()V
/*     */       //   149: checkcast java/util/Collection
/*     */       //   152: astore #4
/*     */       //   154: iconst_0
/*     */       //   155: istore #5
/*     */       //   157: aload_3
/*     */       //   158: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */       //   163: astore #6
/*     */       //   165: aload #6
/*     */       //   167: invokeinterface hasNext : ()Z
/*     */       //   172: ifeq -> 232
/*     */       //   175: aload #6
/*     */       //   177: invokeinterface next : ()Ljava/lang/Object;
/*     */       //   182: astore #7
/*     */       //   184: aload #7
/*     */       //   186: checkcast net/minecraft/class_1297
/*     */       //   189: astore #8
/*     */       //   191: iconst_0
/*     */       //   192: istore #9
/*     */       //   194: aload #8
/*     */       //   196: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */       //   199: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */       //   202: getfield field_1724 : Lnet/minecraft/class_746;
/*     */       //   205: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */       //   208: ifne -> 215
/*     */       //   211: iconst_1
/*     */       //   212: goto -> 216
/*     */       //   215: iconst_0
/*     */       //   216: ifeq -> 165
/*     */       //   219: aload #4
/*     */       //   221: aload #7
/*     */       //   223: invokeinterface add : (Ljava/lang/Object;)Z
/*     */       //   228: pop
/*     */       //   229: goto -> 165
/*     */       //   232: aload #4
/*     */       //   234: checkcast java/util/List
/*     */       //   237: nop
/*     */       //   238: checkcast java/util/Collection
/*     */       //   241: getstatic kotlin/random/Random.Default : Lkotlin/random/Random$Default;
/*     */       //   244: checkcast kotlin/random/Random
/*     */       //   247: invokestatic random : (Ljava/util/Collection;Lkotlin/random/Random;)Ljava/lang/Object;
/*     */       //   250: checkcast net/minecraft/class_1297
/*     */       //   253: goto -> 258
/*     */       //   256: aconst_null
/*     */       //   257: areturn
/*     */       //   258: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #113	-> 0
/*     */       //   #248	-> 25
/*     */       //   #249	-> 48
/*     */       //   #113	-> 82
/*     */       //   #249	-> 104
/*     */       //   #250	-> 111
/*     */       //   #113	-> 112
/*     */       //   #251	-> 140
/*     */       //   #252	-> 157
/*     */       //   #113	-> 194
/*     */       //   #252	-> 216
/*     */       //   #253	-> 232
/*     */       //   #251	-> 237
/*     */       //   #113	-> 241
/*     */       //   #113	-> 256
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   82	22	6	$i$a$-any-EntityFinder$Companion$getRandomEntity$1	I
/*     */       //   79	25	5	it	Lnet/minecraft/class_1297;
/*     */       //   72	39	4	element$iv	Ljava/lang/Object;
/*     */       //   25	87	2	$i$f$any	I
/*     */       //   23	89	1	$this$any$iv	Ljava/lang/Iterable;
/*     */       //   194	22	9	$i$a$-filter-EntityFinder$Companion$getRandomEntity$2	I
/*     */       //   191	25	8	it	Lnet/minecraft/class_1297;
/*     */       //   184	45	7	element$iv$iv	Ljava/lang/Object;
/*     */       //   157	77	5	$i$f$filterTo	I
/*     */       //   154	80	3	$this$filterTo$iv$iv	Ljava/lang/Iterable;
/*     */       //   154	80	4	destination$iv$iv	Ljava/util/Collection;
/*     */       //   140	98	2	$i$f$filter	I
/*     */       //   138	100	1	$this$filter$iv	Ljava/lang/Iterable;
/*     */       //   0	259	0	this	Lnet/integr/utilities/game/entity/EntityFinder$Companion;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public final class_1309 getStaredAtEntity(double range) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_18112(), "getEntities(...)");
/*     */       Sequence sequence = CollectionsKt.asSequence((Onyx.Companion.getMC()).field_1687.method_18112());
/*     */       int $i$f$filterIsInstance = 0;
/* 254 */       Intrinsics.checkNotNull(SequencesKt.filter(sequence, EntityFinder$Companion$getStaredAtEntity$$inlined$filterIsInstance$1.INSTANCE), "null cannot be cast to non-null type kotlin.sequences.Sequence<R of kotlin.sequences.SequencesKt___SequencesKt.filterIsInstance>"); List entities = SequencesKt.toList(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(SequencesKt.filter(sequence, EntityFinder$Companion$getStaredAtEntity$$inlined$filterIsInstance$1.INSTANCE), EntityFinder$Companion$getStaredAtEntity$entities$1.INSTANCE), new EntityFinder$Companion$getStaredAtEntity$entities$2(range)), EntityFinder$Companion$getStaredAtEntity$entities$3.INSTANCE)); Iterable $this$forEach$iv = entities; int $i$f$forEach = 0;
/* 255 */       Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); class_1309 it = (class_1309)element$iv; int $i$a$-forEach-EntityFinder$Companion$getStaredAtEntity$1 = 0;
/*     */         if (EntityFinder.Companion.playerStaringAt((class_1297)it))
/*     */           return it;  }
/*     */       
/*     */       return null;
/*     */     }
/*     */     
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"})
/*     */     static final class EntityFinder$Companion$getStaredAtEntity$entities$1 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       public static final EntityFinder$Companion$getStaredAtEntity$entities$1 INSTANCE = new EntityFinder$Companion$getStaredAtEntity$entities$1();
/*     */       
/*     */       @NotNull
/*     */       public final Boolean invoke(@NotNull class_1309 it) {
/*     */         Intrinsics.checkNotNullParameter(it, "it");
/*     */         return Boolean.valueOf((!Intrinsics.areEqual(it.method_5864(), class_1299.field_6043) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6131) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_28401) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6120) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6096) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6053) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6126) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6058) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6080) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6136) && !Intrinsics.areEqual(it.method_5864(), class_1299.field_6142) && !Intrinsics.areEqual(it, (Onyx.Companion.getMC()).field_1724) && it.method_5805()));
/*     */       }
/*     */       
/*     */       EntityFinder$Companion$getStaredAtEntity$entities$1() {
/*     */         super(1);
/*     */       }
/*     */     }
/*     */     
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"})
/*     */     static final class EntityFinder$Companion$getStaredAtEntity$entities$2 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       EntityFinder$Companion$getStaredAtEntity$entities$2(double $range) {
/*     */         super(1);
/*     */       }
/*     */       
/*     */       @NotNull
/*     */       public final Boolean invoke(@NotNull class_1309 it) {
/*     */         Intrinsics.checkNotNullParameter(it, "it");
/*     */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */         return Boolean.valueOf(((Onyx.Companion.getMC()).field_1724.method_5739((class_1297)it) <= this.$range));
/*     */       }
/*     */     }
/*     */     
/*     */     @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"})
/*     */     static final class EntityFinder$Companion$getStaredAtEntity$entities$3 extends Lambda implements Function1<class_1309, Boolean> {
/*     */       public static final EntityFinder$Companion$getStaredAtEntity$entities$3 INSTANCE = new EntityFinder$Companion$getStaredAtEntity$entities$3();
/*     */       
/*     */       EntityFinder$Companion$getStaredAtEntity$entities$3() {
/*     */         super(1);
/*     */       }
/*     */       
/*     */       @NotNull
/*     */       public final Boolean invoke(@NotNull class_1309 it) {
/*     */         Intrinsics.checkNotNullParameter(it, "it");
/*     */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */         return Boolean.valueOf((Onyx.Companion.getMC()).field_1724.method_6057((class_1297)it));
/*     */       }
/*     */     }
/*     */     
/*     */     public final boolean playerStaringAt(@NotNull class_1297 entity) {
/*     */       Intrinsics.checkNotNullParameter(entity, "entity");
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719);
/*     */       class_243 rotationVector = (Onyx.Companion.getMC()).field_1719.method_5828(1.0F).method_1029();
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719);
/*     */       class_243 vec3d2 = new class_243(entity.method_23317() - (Onyx.Companion.getMC()).field_1719.method_23317(), entity.method_23320() - (Onyx.Companion.getMC()).field_1719.method_23320(), entity.method_23321() - (Onyx.Companion.getMC()).field_1719.method_23321());
/*     */       double d = vec3d2.method_1033();
/*     */       Intrinsics.checkNotNullExpressionValue(vec3d2.method_1029(), "normalize(...)");
/*     */       vec3d2 = vec3d2.method_1029();
/*     */       double e = rotationVector.method_1026(vec3d2);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719);
/*     */       return (e > 1.0D - 0.025D / d) ? entityCanSeeEntity((Onyx.Companion.getMC()).field_1719, entity) : false;
/*     */     }
/*     */     
/*     */     public final boolean entityCanSeeEntity(@NotNull class_1297 toInspect, @NotNull class_1297 entity) {
/*     */       Intrinsics.checkNotNullParameter(toInspect, "toInspect");
/*     */       Intrinsics.checkNotNullParameter(entity, "entity");
/*     */       if (!Intrinsics.areEqual(entity.method_37908(), toInspect.method_37908()))
/*     */         return false; 
/*     */       class_243 vec3d = new class_243(toInspect.method_23317(), toInspect.method_23320(), toInspect.method_23321());
/*     */       class_243 vec3d2 = new class_243(entity.method_23317(), entity.method_23320(), entity.method_23321());
/*     */       return (vec3d2.method_1022(vec3d) > 128.0D) ? false : ((toInspect.method_37908().method_17742(new class_3959(vec3d, vec3d2, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, toInspect)).method_17783() == class_239.class_240.field_1333));
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public final class_1657 getPlayerByName(@NotNull String name) {
/*     */       // Byte code:
/*     */       //   0: aload_1
/*     */       //   1: ldc_w 'name'
/*     */       //   4: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */       //   7: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */       //   10: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */       //   13: getfield field_1687 : Lnet/minecraft/class_638;
/*     */       //   16: dup
/*     */       //   17: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */       //   20: invokevirtual method_18112 : ()Ljava/lang/Iterable;
/*     */       //   23: dup
/*     */       //   24: ldc 'getEntities(...)'
/*     */       //   26: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */       //   29: astore_2
/*     */       //   30: iconst_0
/*     */       //   31: istore_3
/*     */       //   32: aload_2
/*     */       //   33: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */       //   38: astore #4
/*     */       //   40: aload #4
/*     */       //   42: invokeinterface hasNext : ()Z
/*     */       //   47: ifeq -> 108
/*     */       //   50: aload #4
/*     */       //   52: invokeinterface next : ()Ljava/lang/Object;
/*     */       //   57: astore #5
/*     */       //   59: aload #5
/*     */       //   61: checkcast net/minecraft/class_1297
/*     */       //   64: astore #6
/*     */       //   66: iconst_0
/*     */       //   67: istore #7
/*     */       //   69: aload #6
/*     */       //   71: instanceof net/minecraft/class_1657
/*     */       //   74: ifeq -> 99
/*     */       //   77: aload #6
/*     */       //   79: checkcast net/minecraft/class_1657
/*     */       //   82: invokevirtual method_7334 : ()Lcom/mojang/authlib/GameProfile;
/*     */       //   85: invokevirtual getName : ()Ljava/lang/String;
/*     */       //   88: aload_1
/*     */       //   89: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */       //   92: ifeq -> 99
/*     */       //   95: iconst_1
/*     */       //   96: goto -> 100
/*     */       //   99: iconst_0
/*     */       //   100: ifeq -> 40
/*     */       //   103: aload #5
/*     */       //   105: goto -> 109
/*     */       //   108: aconst_null
/*     */       //   109: checkcast net/minecraft/class_1657
/*     */       //   112: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #173	-> 7
/*     */       //   #257	-> 32
/*     */       //   #173	-> 69
/*     */       //   #257	-> 100
/*     */       //   #258	-> 108
/*     */       //   #173	-> 112
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   69	31	7	$i$a$-firstOrNull-EntityFinder$Companion$getPlayerByName$1	I
/*     */       //   66	34	6	it	Lnet/minecraft/class_1297;
/*     */       //   59	49	5	element$iv	Ljava/lang/Object;
/*     */       //   32	77	3	$i$f$firstOrNull	I
/*     */       //   30	79	2	$this$firstOrNull$iv	Ljava/lang/Iterable;
/*     */       //   0	113	0	this	Lnet/integr/utilities/game/entity/EntityFinder$Companion;
/*     */       //   0	113	1	name	Ljava/lang/String;
/*     */     } }
/*     */    }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\entity\EntityFinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */