/*    */ package net.integr.utilities.game.entity;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.friendsystem.FriendStorage;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1657;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\006\032\0020\0032\013\020\002\032\0070\000¢\006\002\b\001H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1309;", "Lkotlin/internal/NoInfer;", "it", "", "invoke", "(Lnet/minecraft/class_1309;)Ljava/lang/Boolean;", "<anonymous>"})
/*    */ final class EntityFinder$Companion$getAuraEntities$entities$4
/*    */   extends Lambda
/*    */   implements Function1<class_1309, Boolean>
/*    */ {
/*    */   public static final EntityFinder$Companion$getAuraEntities$entities$4 INSTANCE = new EntityFinder$Companion$getAuraEntities$entities$4();
/*    */   
/*    */   EntityFinder$Companion$getAuraEntities$entities$4() {
/*    */     super(1);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final Boolean invoke(@NotNull class_1309 it) {
/* 55 */     Intrinsics.checkNotNullParameter(it, "it"); return Boolean.valueOf((it instanceof class_1657) ? (!FriendStorage.Companion.contains((class_1657)it)) : true);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\entity\EntityFinder$Companion$getAuraEntities$entities$4.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */