package net.integr.utilities.game.entity;

import java.util.function.BiFunction;
import kotlin.Metadata;
import net.minecraft.class_2338;
import net.minecraft.class_3965;

@FunctionalInterface
@Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\bç\001\030\0002\026\022\004\022\0020\002\022\004\022\0020\003\022\006\022\004\030\0010\0040\001¨\006\005"}, d2 = {"Lnet/integr/utilities/game/entity/DamageUtil$Companion$RaycastFactory;", "Ljava/util/function/BiFunction;", "Lnet/integr/utilities/game/entity/DamageUtil$Companion$ExposureRaycastContext;", "Lnet/minecraft/class_2338;", "Lnet/minecraft/class_3965;", "onyx2"})
public interface RaycastFactory extends BiFunction<DamageUtil.Companion.ExposureRaycastContext, class_2338, class_3965> {}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\entity\DamageUtil$Companion$RaycastFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */