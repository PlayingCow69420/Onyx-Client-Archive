/*     */ package net.integr.utilities.game.interaction;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.enums.EnumEntries;
/*     */ import kotlin.enums.EnumEntriesKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.utilities.game.EnchantmentUtil;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1292;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1893;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2535;
/*     */ import net.minecraft.class_259;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2846;
/*     */ import net.minecraft.class_3965;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/interaction/BlockUtil;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class BlockUtil
/*     */ {
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000J\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\007\n\002\b\007\n\002\020\002\n\002\b\013\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\025\020\007\032\0020\0062\006\020\n\032\0020\t¢\006\004\b\007\020\013J\027\020\r\032\0020\0062\b\020\f\032\004\030\0010\t¢\006\004\b\r\020\013J\037\020\r\032\0020\0062\b\020\f\032\004\030\0010\t2\006\020\017\032\0020\016¢\006\004\b\r\020\020J\027\020\022\032\004\030\0010\0212\006\020\n\032\0020\t¢\006\004\b\022\020\023J%\020\030\032\0020\0272\006\020\n\032\0020\t2\006\020\025\032\0020\0242\006\020\026\032\0020\006¢\006\004\b\030\020\031J'\020\032\032\0020\0272\006\020\017\032\0020\0162\006\020\025\032\0020\0242\006\020\026\032\0020\006H\002¢\006\004\b\032\020\033J'\020\034\032\0020\0272\006\020\n\032\0020\t2\006\020\025\032\0020\0242\006\020\026\032\0020\006H\002¢\006\004\b\034\020\031J%\020 \032\0020\0372\006\020\n\032\0020\t2\006\020\035\032\0020\0062\006\020\036\032\0020\006¢\006\004\b \020!J%\020\"\032\0020\0372\006\020\n\032\0020\t2\006\020\035\032\0020\0062\006\020\036\032\0020\006¢\006\004\b\"\020!J/\020%\032\0020\0372\006\020\n\032\0020\t2\006\020#\032\0020\0062\006\020$\032\0020\0062\b\b\002\020\036\032\0020\006¢\006\004\b%\020&J\027\020'\032\0020\0372\b\020\n\032\004\030\0010\t¢\006\004\b'\020(J\027\020)\032\0020\0372\b\020\n\032\004\030\0010\t¢\006\004\b)\020(¨\006*"}, d2 = {"Lnet/integr/utilities/game/interaction/BlockUtil$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2248;", "block", "", "canBeClicked", "(Lnet/minecraft/class_2248;)Z", "Lnet/minecraft/class_2338;", "pos", "(Lnet/minecraft/class_2338;)Z", "blockPos", "canBreak", "Lnet/minecraft/class_2680;", "state", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2680;)Z", "Lnet/minecraft/class_243;", "getLookArea", "(Lnet/minecraft/class_2338;)Lnet/minecraft/class_243;", "", "slot", "speedMod", "", "getMineTicks", "(Lnet/minecraft/class_2338;IZ)F", "getSpeed", "(Lnet/minecraft/class_2680;IZ)F", "getTime", "swing", "render", "", "minePosition", "(Lnet/minecraft/class_2338;ZZ)V", "minePositionStart", "rotate", "silent", "placeBlock", "(Lnet/minecraft/class_2338;ZZZ)V", "sendMine", "(Lnet/minecraft/class_2338;)V", "sendStartMine", "onyx2"})
/*     */   public static final class Companion
/*     */   {
/*     */     private Companion() {}
/*     */     
/*     */     public final void placeBlock(@NotNull class_2338 pos, boolean rotate, boolean silent, boolean render) {
/*  46 */       Intrinsics.checkNotNullParameter(pos, "pos"); class_3965 hitResult = new class_3965(pos.method_46558(), class_2350.field_11033, pos, false);
/*     */       
/*  48 */       if (rotate) {
/*  49 */         class_243 rotationVec = getLookArea(pos);
/*     */         
/*  51 */         if (rotationVec != null) { RotationUtils.Companion.lookAt$default(RotationUtils.Companion, rotationVec, false, 2, null); } else { Intrinsics.checkNotNullExpressionValue(pos.method_46558(), "toCenterPos(...)"); RotationUtils.Companion.lookAt$default(RotationUtils.Companion, pos.method_46558(), false, 2, null); }
/*     */       
/*     */       } 
/*  54 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2896((Onyx.Companion.getMC()).field_1724, class_1268.field_5808, hitResult);
/*     */ 
/*     */       
/*  57 */       if (render) Highlighter.Companion.renderBlock$default(Highlighter.Companion, pos, 0, 2, null);
/*     */       
/*  59 */       if (!silent) {
/*  60 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808);
/*     */       } 
/*     */     }
/*     */     @Nullable
/*     */     public final class_243 getLookArea(@NotNull class_2338 pos) {
/*  65 */       Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 eyesPos = (Onyx.Companion.getMC()).field_1724.method_33571();
/*     */       
/*  67 */       for (class_2350 side : EntriesMappings.entries$0) {
/*  68 */         Intrinsics.checkNotNullExpressionValue(pos.method_10093(side), "offset(...)"); class_2338 neighbor = pos.method_10093(side);
/*  69 */         class_2350 side2 = side.method_10153();
/*     */         
/*  71 */         if (eyesPos.method_1025(class_243.method_24953((class_2382)pos)) < eyesPos.method_1025(class_243.method_24953((class_2382)neighbor)) && 
/*  72 */           canBeClicked(neighbor)) {
/*     */           
/*  74 */           class_243 hitVec = class_243.method_24953((class_2382)neighbor).method_1019(class_243.method_24954(side2.method_10163()).method_1021(0.5D));
/*  75 */           if (eyesPos.method_1025(hitVec) <= 18.0625D)
/*     */           {
/*  77 */             return hitVec; } 
/*     */         } 
/*     */       } 
/*  80 */       return null;
/*     */     }
/*     */     
/*     */     public final boolean canBeClicked(@NotNull class_2338 pos) {
/*  84 */       Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); return !Intrinsics.areEqual((Onyx.Companion.getMC()).field_1687.method_8320(pos).method_26218((class_1922)(Onyx.Companion.getMC()).field_1687, pos), class_259.method_1073());
/*     */     }
/*     */     
/*     */     public final boolean canBeClicked(@NotNull class_2248 block) {
/*  88 */       Intrinsics.checkNotNullParameter(block, "block"); return !Intrinsics.areEqual(block.method_9564().method_26218((class_1922)(Onyx.Companion.getMC()).field_1687, class_2338.field_10980), class_259.method_1073());
/*     */     }
/*     */     
/*     */     public final boolean canBreak(@Nullable class_2338 blockPos, @NotNull class_2680 state) {
/*  92 */       Intrinsics.checkNotNullParameter(state, "state"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!(Onyx.Companion.getMC()).field_1724.method_7337() && state.method_26214((class_1922)(Onyx.Companion.getMC()).field_1687, blockPos) < 0.0F) return false; 
/*  93 */       return (state.method_26218((class_1922)(Onyx.Companion.getMC()).field_1687, blockPos) != class_259.method_1073());
/*     */     }
/*     */     
/*     */     public final boolean canBreak(@Nullable class_2338 blockPos) {
/*  97 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(blockPos), "getBlockState(...)"); return canBreak(blockPos, (Onyx.Companion.getMC()).field_1687.method_8320(blockPos));
/*     */     }
/*     */     
/*     */     public final void minePosition(@NotNull class_2338 pos, boolean swing, boolean render) {
/* 101 */       Intrinsics.checkNotNullParameter(pos, "pos"); sendMine(pos);
/* 102 */       if (swing) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808); }
/* 103 */        if (render) { Intrinsics.checkNotNullExpressionValue(pos.method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); Highlighter.Companion.renderBlockOutlined(pos.method_46558().method_1031(0.0D, -0.5D, 0.0D), 30); }
/*     */     
/*     */     }
/*     */     public final void minePositionStart(@NotNull class_2338 pos, boolean swing, boolean render) {
/* 107 */       Intrinsics.checkNotNullParameter(pos, "pos"); sendStartMine(pos);
/* 108 */       if (swing) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808); }
/* 109 */        if (render) { Intrinsics.checkNotNullExpressionValue(pos.method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); Highlighter.Companion.renderBlockOutlined(pos.method_46558().method_1031(0.0D, -0.5D, 0.0D), 30); }
/*     */     
/*     */     }
/*     */     public final void sendMine(@Nullable class_2338 pos) {
/* 113 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_2535 conn = (Onyx.Companion.getMC()).field_1724.field_3944.method_48296();
/*     */       
/* 115 */       class_2596 startBreak = (class_2596)new class_2846(class_2846.class_2847.field_12968, pos, class_2350.field_11036);
/* 116 */       class_2596 endBreak = (class_2596)new class_2846(class_2846.class_2847.field_12973, pos, class_2350.field_11036);
/*     */       
/* 118 */       conn.method_10752(startBreak, null);
/* 119 */       conn.method_10752(endBreak, null);
/*     */     }
/*     */     
/*     */     public final void sendStartMine(@Nullable class_2338 pos) {
/* 123 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_2535 conn = (Onyx.Companion.getMC()).field_1724.field_3944.method_48296();
/*     */       
/* 125 */       class_2596 startBreak = (class_2596)new class_2846(class_2846.class_2847.field_12968, pos, class_2350.field_11036);
/*     */       
/* 127 */       conn.method_10752(startBreak, null);
/*     */     }
/*     */     
/*     */     private final float getTime(class_2338 pos, int slot, boolean speedMod) {
/* 131 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(pos), "getBlockState(...)"); class_2680 state = (Onyx.Companion.getMC()).field_1687.method_8320(pos);
/* 132 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); float f = state.method_26214((class_1922)(Onyx.Companion.getMC()).field_1687, pos);
/* 133 */       if ((f == -1.0F)) {
/* 134 */         return 0.0F;
/*     */       }
/* 136 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); float i = ((!state.method_29291() || (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(slot).method_7951(state)) ? 30 : 100);
/* 137 */       return getSpeed(state, slot, speedMod) / f / i;
/*     */     }
/*     */ 
/*     */     
/*     */     public final float getMineTicks(@NotNull class_2338 pos, int slot, boolean speedMod) {
/* 142 */       Intrinsics.checkNotNullParameter(pos, "pos"); return (slot == -1) ? slot : (true / getTime(pos, slot, speedMod));
/*     */     }
/*     */     
/*     */     private final float getSpeed(class_2680 state, int slot, boolean speedMod) {
/* 146 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_31548().method_5438(slot), "getStack(...)"); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(slot);
/* 147 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); float f = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(slot).method_7924(state);
/* 148 */       if (f > 1.0D) {
/* 149 */         Intrinsics.checkNotNullExpressionValue(class_1893.field_9131, "EFFICIENCY"); int i = EnchantmentUtil.Companion.getLevel(class_1893.field_9131, stack);
/* 150 */         if (i > 0 && !stack.method_7960()) f += (i * i + 1);
/*     */       
/*     */       } 
/* 153 */       if (!speedMod) return f;
/*     */ 
/*     */       
/* 156 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (class_1292.method_5576((class_1309)(Onyx.Companion.getMC()).field_1724)) {
/* 157 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); f *= (float)(1.0D + ((class_1292.method_5575((class_1309)(Onyx.Companion.getMC()).field_1724) + 1) * 0.2F));
/*     */       } 
/* 159 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_6059(class_1294.field_5901)) {
/* 160 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724.method_6112(class_1294.field_5901)); f *= (float)Math.pow(0.3F, ((Onyx.Companion.getMC()).field_1724.method_6112(class_1294.field_5901).method_5578() + 1.0F));
/*     */       } 
/*     */ 
/*     */       
/* 164 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_5869() && !EnchantmentUtil.Companion.playerHasAquaAffinity()) {
/* 165 */         f /= 5.0F;
/*     */       }
/*     */       
/* 168 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!(Onyx.Companion.getMC()).field_1724.method_24828()) {
/* 169 */         f /= 5.0F;
/*     */       }
/*     */       
/* 172 */       return f;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\interaction\BlockUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */