/*    */ package net.integr.utilities.game.interaction;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_3965;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003J\r\020\006\032\0020\004¢\006\004\b\006\020\003J\r\020\007\032\0020\004¢\006\004\b\007\020\003J\r\020\b\032\0020\004¢\006\004\b\b\020\003¨\006\t"}, d2 = {"Lnet/integr/utilities/game/interaction/ClickUtils$Companion;", "", "<init>", "()V", "", "leftClick", "rightClick", "rightClickBlock", "stopRightClick", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   public final void rightClick() {
/* 27 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2919((class_1657)(Onyx.Companion.getMC()).field_1724, class_1268.field_5808);
/*    */   }
/*    */   
/*    */   public final void rightClickBlock() {
/* 31 */     class_239 t = (Onyx.Companion.getMC()).field_1765;
/* 32 */     if (t != null && t.method_17783() == class_239.class_240.field_1332 && t instanceof class_3965) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1765, "null cannot be cast to non-null type net.minecraft.util.hit.BlockHitResult"); (Onyx.Companion.getMC()).field_1761.method_2896((Onyx.Companion.getMC()).field_1724, class_1268.field_5808, (class_3965)(Onyx.Companion.getMC()).field_1765); }
/* 33 */      Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2919((class_1657)(Onyx.Companion.getMC()).field_1724, class_1268.field_5808);
/*    */   }
/*    */   
/*    */   public final void leftClick() {
/* 37 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808);
/*    */   }
/*    */   
/*    */   public final void stopRightClick() {
/* 41 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2897((class_1657)(Onyx.Companion.getMC()).field_1724);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\interaction\ClickUtils$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */