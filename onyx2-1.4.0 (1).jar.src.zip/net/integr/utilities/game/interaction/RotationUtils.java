/*    */ package net.integr.utilities.game.interaction;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.utilities.game.rotationfake.RotationFaker;
/*    */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2828;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/interaction/RotationUtils;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class RotationUtils
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\020\007\n\002\b\003\n\002\020\013\n\000\n\002\020\002\n\002\b\n\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J!\020\b\032\016\022\004\022\0020\007\022\004\022\0020\0070\0062\006\020\005\032\0020\004¢\006\004\b\b\020\tJ\037\020\016\032\0020\r2\006\020\n\032\0020\0042\b\b\002\020\f\032\0020\013¢\006\004\b\016\020\017J'\020\022\032\0020\r2\006\020\020\032\0020\0072\006\020\021\032\0020\0072\b\b\002\020\f\032\0020\013¢\006\004\b\022\020\023J\035\020\024\032\0020\r2\006\020\020\032\0020\0072\006\020\021\032\0020\007¢\006\004\b\024\020\025J\035\020\026\032\0020\r2\006\020\020\032\0020\0072\006\020\021\032\0020\007¢\006\004\b\026\020\025¨\006\027"}, d2 = {"Lnet/integr/utilities/game/interaction/RotationUtils$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_243;", "vec", "Lkotlin/Pair;", "", "getNeededRotations", "(Lnet/minecraft/class_243;)Lkotlin/Pair;", "pos", "", "setServerside", "", "lookAt", "(Lnet/minecraft/class_243;Z)V", "yaw", "pitch", "rotate", "(FFZ)V", "sendFullLookPacket", "(FF)V", "sendLookPacket", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final void lookAt(@NotNull class_243 pos, boolean setServerside) {
/* 32 */       Intrinsics.checkNotNullParameter(pos, "pos"); Pair<Float, Float> neededRotation = getNeededRotations(pos);
/*    */       
/* 34 */       if (RotationLocker.Companion.isLocked()) {
/* 35 */         RotationLocker.Companion.setFakeYaw(((Number)neededRotation.getFirst()).floatValue());
/* 36 */         RotationLocker.Companion.setFakePitch(((Number)neededRotation.getSecond()).floatValue());
/*    */ 
/*    */         
/* 39 */         if (setServerside)
/* 40 */         { RotationFaker.Companion.getINSTANCE().look(((Number)neededRotation.getFirst()).floatValue(), ((Number)neededRotation.getSecond()).floatValue()); }
/* 41 */         else { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationFaker.Companion.getINSTANCE().look((Onyx.Companion.getMC()).field_1724.method_36454(), (Onyx.Companion.getMC()).field_1724.method_36455()); }
/*    */       
/*    */       } else {
/* 44 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_36456(((Number)neededRotation.getFirst()).floatValue());
/* 45 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_36457(((Number)neededRotation.getSecond()).floatValue());
/*    */         
/* 47 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationLocker.Companion.setFakeYaw((Onyx.Companion.getMC()).field_1724.method_36454());
/* 48 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationLocker.Companion.setFakePitch((Onyx.Companion.getMC()).field_1724.method_36455());
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public final void rotate(float yaw, float pitch, boolean setServerside) {
/* 54 */       if (RotationLocker.Companion.isLocked()) {
/* 55 */         RotationLocker.Companion.setFakeYaw(yaw);
/* 56 */         RotationLocker.Companion.setFakePitch(pitch);
/*    */         
/* 58 */         if (setServerside)
/* 59 */         { RotationFaker.Companion.getINSTANCE().look(yaw, pitch); }
/* 60 */         else { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationFaker.Companion.getINSTANCE().look((Onyx.Companion.getMC()).field_1724.method_36454(), (Onyx.Companion.getMC()).field_1724.method_36455()); }
/*    */       
/*    */       } else {
/* 63 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_36456(yaw);
/* 64 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_36457(pitch);
/*    */         
/* 66 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationLocker.Companion.setFakeYaw((Onyx.Companion.getMC()).field_1724.method_36454());
/* 67 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationLocker.Companion.setFakePitch((Onyx.Companion.getMC()).field_1724.method_36455());
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     public final void sendLookPacket(float yaw, float pitch) {
/* 73 */       Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2828.class_2831(yaw, pitch, (Onyx.Companion.getMC()).field_1724.method_24828()));
/*    */     }
/*    */     
/*    */     public final void sendFullLookPacket(float yaw, float pitch) {
/* 77 */       Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2828.class_2830((Onyx.Companion.getMC()).field_1724.method_23317(), (Onyx.Companion.getMC()).field_1724.method_23318(), (Onyx.Companion.getMC()).field_1724.method_23321(), yaw, pitch, (Onyx.Companion.getMC()).field_1724.method_24828()));
/*    */     }
/*    */     @NotNull
/*    */     public final Pair<Float, Float> getNeededRotations(@NotNull class_243 vec) {
/* 81 */       Intrinsics.checkNotNullParameter(vec, "vec");
/* 82 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 83 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 84 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 eyesPos = new class_243((Onyx.Companion.getMC()).field_1724.method_23317(), (Onyx.Companion.getMC()).field_1724.method_23318() + (Onyx.Companion.getMC()).field_1724.method_18381((Onyx.Companion.getMC()).field_1724.method_18376()), (Onyx.Companion.getMC()).field_1724.method_23321());
/*    */ 
/*    */       
/* 87 */       double diffX = vec.field_1352 - eyesPos.field_1352;
/* 88 */       double diffY = vec.field_1351 - eyesPos.field_1351;
/* 89 */       double diffZ = vec.field_1350 - eyesPos.field_1350;
/*    */       
/* 91 */       double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*    */       
/* 93 */       float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/* 94 */       float pitch = -((float)Math.toDegrees(Math.atan2(diffY, diffXZ)));
/*    */       
/* 96 */       return new Pair(Float.valueOf(yaw), Float.valueOf(pitch));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\interaction\RotationUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */