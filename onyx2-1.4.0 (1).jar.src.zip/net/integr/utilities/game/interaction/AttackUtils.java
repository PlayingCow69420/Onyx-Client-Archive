/*    */ package net.integr.utilities.game.interaction;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_2535;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2824;
/*    */ import net.minecraft.class_2828;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/interaction/AttackUtils;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class AttackUtils
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\n\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006¢\006\004\b\t\020\nJ\025\020\f\032\0020\b2\006\020\005\032\0020\013¢\006\004\b\f\020\rJ'\020\017\032\0020\b2\006\020\005\032\0020\0132\006\020\007\032\0020\0062\b\b\002\020\016\032\0020\006¢\006\004\b\017\020\020J\r\020\021\032\0020\006¢\006\004\b\021\020\022J!\020\023\032\0020\b2\b\020\005\032\004\030\0010\0132\006\020\007\032\0020\006H\002¢\006\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/utilities/game/interaction/AttackUtils$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_1309;", "entity", "", "critical", "", "attack", "(Lnet/minecraft/class_1309;Z)V", "Lnet/minecraft/class_1297;", "attackViaManager", "(Lnet/minecraft/class_1297;)V", "swing", "attackWithoutReset", "(Lnet/minecraft/class_1297;ZZ)V", "canAttack", "()Z", "sendAttack", "(Lnet/minecraft/class_1297;Z)V", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final void attackViaManager(@NotNull class_1297 entity) {
/* 30 */       Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2918((class_1657)(Onyx.Companion.getMC()).field_1724, entity);
/*    */     }
/*    */     
/*    */     public final void attack(@NotNull class_1309 entity, boolean critical) {
/* 34 */       Intrinsics.checkNotNullParameter(entity, "entity"); sendAttack((class_1297)entity, critical);
/* 35 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_7350();
/*    */       
/* 37 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808);
/*    */     }
/*    */     
/*    */     public final void attackWithoutReset(@NotNull class_1297 entity, boolean critical, boolean swing) {
/* 41 */       Intrinsics.checkNotNullParameter(entity, "entity"); sendAttack(entity, critical);
/*    */       
/* 43 */       if (swing) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808); }
/*    */     
/*    */     } public final boolean canAttack() {
/* 46 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return ((Onyx.Companion.getMC()).field_1724.method_7261(0.5F) >= 1.0F);
/*    */     }
/*    */     private final void sendAttack(class_1297 entity, boolean critical) {
/* 49 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_2535 conn = (Onyx.Companion.getMC()).field_1724.field_3944.method_48296();
/*    */       
/* 51 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double posX = (Onyx.Companion.getMC()).field_1724.method_23317();
/* 52 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double posY = (Onyx.Companion.getMC()).field_1724.method_23318();
/* 53 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double posZ = (Onyx.Companion.getMC()).field_1724.method_23321();
/*    */       
/* 55 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(class_2824.method_34206(entity, (Onyx.Companion.getMC()).field_1724.method_5715()), "attack(...)"); class_2596 attackPacket = (class_2596)class_2824.method_34206(entity, (Onyx.Companion.getMC()).field_1724.method_5715());
/*    */       
/* 57 */       if (critical) {
/* 58 */         Intrinsics.checkNotNull(conn); conn.method_10743((class_2596)new class_2828.class_2829(posX, posY + 0.0625D, posZ, true));
/* 59 */         conn.method_10743((class_2596)new class_2828.class_2829(posX, posY, posZ, false));
/* 60 */         conn.method_10743((class_2596)new class_2828.class_2829(posX, posY + 1.1E-5D, posZ, false));
/* 61 */         conn.method_10743((class_2596)new class_2828.class_2829(posX, posY, posZ, false));
/* 62 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.field_6017 = 0.1F;
/*    */       } 
/*    */       
/* 65 */       Intrinsics.checkNotNull(conn); conn.method_10752(attackPacket, null);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\interaction\AttackUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */