/*    */ package net.integr.utilities.game.interaction;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function2;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Settings;
/*    */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*    */ import net.integr.utilities.game.pathfind.Path;
/*    */ import net.integr.utilities.game.pathfind.PathfindingManager;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2828;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000:\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\006\n\002\020\b\n\002\b\003\n\002\020\006\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\025\020\007\032\0020\0062\006\020\005\032\0020\t¢\006\004\b\007\020\nJ\025\020\013\032\0020\0062\006\020\005\032\0020\t¢\006\004\b\013\020\nJ\037\020\016\032\0020\0062\006\020\005\032\0020\t2\b\b\002\020\r\032\0020\f¢\006\004\b\016\020\017J\025\020\020\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\020\020\bJ\025\020\021\032\0020\0062\006\020\005\032\0020\t¢\006\004\b\021\020\nJ\025\020\022\032\0020\0062\006\020\005\032\0020\t¢\006\004\b\022\020\nJ\025\020\025\032\0020\0062\006\020\024\032\0020\023¢\006\004\b\025\020\026J\025\020\031\032\0020\0062\006\020\030\032\0020\027¢\006\004\b\031\020\032¨\006\033"}, d2 = {"Lnet/integr/utilities/game/interaction/MovementUtil$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2338;", "pos", "", "move", "(Lnet/minecraft/class_2338;)V", "Lnet/minecraft/class_243;", "(Lnet/minecraft/class_243;)V", "moveInDirection", "", "fakeGround", "moveViaPacket", "(Lnet/minecraft/class_243;Z)V", "moveViaPath", "pathMoveInDirection", "setVelocity", "", "amount", "spoofGroundOnly", "(I)V", "", "distance", "spoofGroundOnlyFromDistance", "(D)V", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   public final void moveViaPacket(@NotNull class_243 pos, boolean fakeGround) {
/* 34 */     Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, fakeGround ? false : (Onyx.Companion.getMC()).field_1724.method_24828()));
/*    */   }
/*    */ 
/*    */   
/*    */   public final void spoofGroundOnly(int amount) {
/*    */     // Byte code:
/*    */     //   0: iconst_0
/*    */     //   1: istore_2
/*    */     //   2: iload_2
/*    */     //   3: iload_1
/*    */     //   4: if_icmpge -> 46
/*    */     //   7: iload_2
/*    */     //   8: istore_3
/*    */     //   9: iconst_0
/*    */     //   10: istore #4
/*    */     //   12: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   15: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   18: invokevirtual method_1562 : ()Lnet/minecraft/class_634;
/*    */     //   21: dup
/*    */     //   22: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   25: new net/minecraft/class_2828$class_5911
/*    */     //   28: dup
/*    */     //   29: iconst_0
/*    */     //   30: invokespecial <init> : (Z)V
/*    */     //   33: checkcast net/minecraft/class_2596
/*    */     //   36: invokevirtual method_52787 : (Lnet/minecraft/class_2596;)V
/*    */     //   39: nop
/*    */     //   40: iinc #2, 1
/*    */     //   43: goto -> 2
/*    */     //   46: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #38	-> 0
/*    */     //   #39	-> 12
/*    */     //   #40	-> 39
/*    */     //   #38	-> 40
/*    */     //   #41	-> 46
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   12	28	4	$i$a$-repeat-MovementUtil$Companion$spoofGroundOnly$1	I
/*    */     //   9	31	3	it	I
/*    */     //   0	47	0	this	Lnet/integr/utilities/game/interaction/MovementUtil$Companion;
/*    */     //   0	47	1	amount	I
/*    */   }
/*    */ 
/*    */   
/*    */   public final void spoofGroundOnlyFromDistance(double distance) {
/* 44 */     spoofGroundOnly((int)(distance / 10) + 1);
/*    */   }
/*    */   
/*    */   public final void move(@NotNull class_243 pos) {
/* 48 */     Intrinsics.checkNotNullParameter(pos, "pos"); moveViaPacket$default(this, pos, false, 2, null);
/* 49 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
/*    */   }
/*    */   
/*    */   public final void move(@NotNull class_2338 pos) {
/* 53 */     Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNullExpressionValue(pos.method_46558(), "toCenterPos(...)"); moveViaPacket$default(this, pos.method_46558(), false, 2, null);
/* 54 */     class_243 pi = pos.method_46558();
/* 55 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5814(pi.field_1352, pi.field_1351 - 0.5D, pi.field_1350);
/*    */   }
/*    */   
/*    */   public final void moveViaPath(@NotNull class_2338 pos)
/*    */   {
/* 60 */     Intrinsics.checkNotNullParameter(pos, "pos"); Path path = PathfindingManager.Companion.getPathToBlock$default(PathfindingManager.Companion, pos, null, 2, null);
/*    */     
/* 62 */     path.iterate(MovementUtil$Companion$moveViaPath$1.INSTANCE); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"})
/* 63 */   static final class MovementUtil$Companion$moveViaPath$1 extends Lambda implements Function2<class_243, class_243, Unit> { public final void invoke(@NotNull class_243 param2class_2431, @NotNull class_243 current) { Intrinsics.checkNotNullParameter(param2class_2431, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(current, "current"); MovementUtil.Companion.move(current); }
/*    */      public static final MovementUtil$Companion$moveViaPath$1 INSTANCE = new MovementUtil$Companion$moveViaPath$1(); MovementUtil$Companion$moveViaPath$1() {
/*    */       super(2);
/*    */     } }
/*    */   public final void setVelocity(@NotNull class_243 pos) {
/* 68 */     Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(pos.field_1352, pos.field_1351, pos.field_1350);
/*    */   }
/*    */   
/*    */   public final void pathMoveInDirection(@NotNull class_243 pos) {
/* 72 */     Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("pathfindingSpeed")); int spd = ((IntSliderSetting)Settings.Companion.getINSTANCE().getSettings().getById("pathfindingSpeed")).getSetValue();
/* 73 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 74 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 75 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 76 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800((pos.field_1352 - (Onyx.Companion.getMC()).field_1724.method_23317()) / 10 * spd, (pos.field_1351 - 0.5D - (Onyx.Companion.getMC()).field_1724.method_23318()) / 10 * spd, (pos.field_1350 - (Onyx.Companion.getMC()).field_1724.method_23321()) / 10 * spd);
/*    */   }
/*    */ 
/*    */   
/*    */   public final void moveInDirection(@NotNull class_243 pos) {
/* 81 */     Intrinsics.checkNotNullParameter(pos, "pos"); int spd = 2;
/* 82 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 83 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 84 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 85 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5762((pos.field_1352 - (Onyx.Companion.getMC()).field_1724.method_23317()) / 10 * spd, (pos.field_1351 - 0.5D - (Onyx.Companion.getMC()).field_1724.method_23318()) / 10 * spd, (pos.field_1350 - (Onyx.Companion.getMC()).field_1724.method_23321()) / 10 * spd);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\interaction\MovementUtil$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */