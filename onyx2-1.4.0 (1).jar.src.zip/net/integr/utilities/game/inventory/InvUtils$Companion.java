/*    */ package net.integr.utilities.game.inventory;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2868;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\020\013\n\002\b\r\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\025\020\013\032\0020\0042\006\020\n\032\0020\t¢\006\004\b\013\020\fJ\025\020\r\032\0020\0042\006\020\n\032\0020\t¢\006\004\b\r\020\fJ\025\020\016\032\0020\0042\006\020\n\032\0020\t¢\006\004\b\016\020\fJ\r\020\017\032\0020\004¢\006\004\b\017\020\020J\025\020\022\032\0020\0212\006\020\005\032\0020\004¢\006\004\b\022\020\023J\035\020\026\032\0020\0062\006\020\024\032\0020\0042\006\020\025\032\0020\004¢\006\004\b\026\020\027J\025\020\030\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\030\020\bJ\025\020\031\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\031\020\bJ\035\020\033\032\0020\0062\006\020\005\032\0020\0042\006\020\032\032\0020\021¢\006\004\b\033\020\034J\025\020\035\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\035\020\b¨\006\036"}, d2 = {"Lnet/integr/utilities/game/inventory/InvUtils$Companion;", "", "<init>", "()V", "", "slot", "", "clickSlot", "(I)V", "Lnet/minecraft/class_1792;", "item", "countInHotbar", "(Lnet/minecraft/class_1792;)I", "find", "findInHotbar", "getSelectedSlot", "()I", "", "isHotbarSlot", "(I)Z", "from", "to", "moveItem", "(II)V", "quickMove", "selectSlot", "silent", "selectSlotOptionalSilent", "(IZ)V", "selectSlotPacket", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   public final boolean isHotbarSlot(int slot) {
/* 27 */     return (0 <= slot) ? ((slot < 9)) : false;
/*    */   }
/*    */   public final void selectSlotOptionalSilent(int slot, boolean silent) {
/* 30 */     if ((0 <= slot) ? ((slot < 9)) : false)
/* 31 */       if (silent) { selectSlotPacket(slot); }
/* 32 */       else { selectSlot(slot); }
/*    */        
/*    */   }
/*    */   public final void selectSlot(int slot) {
/* 36 */     if ((0 <= slot) ? ((slot < 9)) : false) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); ((Onyx.Companion.getMC()).field_1724.method_31548()).field_7545 = slot; }
/*    */   
/*    */   }
/*    */   public final void selectSlotPacket(int slot) {
/* 40 */     if ((0 <= slot) ? ((slot < 9)) : false) { Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2868(slot)); }
/*    */   
/*    */   }
/*    */   public final int getSelectedSlot() {
/* 44 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return ((Onyx.Companion.getMC()).field_1724.method_31548()).field_7545;
/*    */   }
/*    */   
/*    */   public final void moveItem(int from, int to) {
/* 48 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2906(0, from, 0, class_1713.field_7790, (class_1657)(Onyx.Companion.getMC()).field_1724);
/* 49 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2906(0, to, 0, class_1713.field_7790, (class_1657)(Onyx.Companion.getMC()).field_1724);
/*    */   }
/*    */   
/*    */   public final void clickSlot(int slot) {
/* 53 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2906(0, slot, 0, class_1713.field_7790, (class_1657)(Onyx.Companion.getMC()).field_1724);
/*    */   }
/*    */   
/*    */   public final void quickMove(int slot) {
/* 57 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761); (Onyx.Companion.getMC()).field_1761.method_2906(0, slot, 0, class_1713.field_7794, (class_1657)(Onyx.Companion.getMC()).field_1724);
/*    */   }
/*    */   
/*    */   public final int countInHotbar(@NotNull class_1792 item) {
/* 61 */     Intrinsics.checkNotNullParameter(item, "item"); int count = 0;
/* 62 */     for (int i = 0; i < 9; i++) {
/* 63 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*    */       
/* 65 */       Intrinsics.checkNotNull(stack); if (Intrinsics.areEqual(stack.method_7909(), item)) count += stack.method_7947();
/*    */     
/*    */     } 
/* 68 */     return count;
/*    */   }
/*    */   
/*    */   public final int findInHotbar(@NotNull class_1792 item) {
/* 72 */     Intrinsics.checkNotNullParameter(item, "item"); for (int i = 0; i < 9; i++) {
/* 73 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*    */       
/* 75 */       Intrinsics.checkNotNull(stack); if (Intrinsics.areEqual(stack.method_7909(), item)) return i;
/*    */     
/*    */     } 
/* 78 */     return -1;
/*    */   }
/*    */   
/*    */   public final int find(@NotNull class_1792 item) {
/* 82 */     Intrinsics.checkNotNullParameter(item, "item"); for (int i = 0; i < 36; i++) {
/* 83 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*    */       
/* 85 */       Intrinsics.checkNotNull(stack); if (Intrinsics.areEqual(stack.method_7909(), item)) return i;
/*    */     
/*    */     } 
/* 88 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\inventory\InvUtils$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */