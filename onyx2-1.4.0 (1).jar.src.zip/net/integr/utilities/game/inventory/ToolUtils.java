/*     */ package net.integr.utilities.game.inventory;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.enums.EnumEntries;
/*     */ import kotlin.enums.EnumEntriesKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.utilities.game.EnchantmentUtil;
/*     */ import net.integr.utilities.game.interaction.BlockUtil;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1829;
/*     */ import net.minecraft.class_1893;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_3481;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/inventory/ToolUtils;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class ToolUtils
/*     */ {
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\\\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\020\b\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\006\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020 \n\002\b\004\b\003\030\0002\0020\001:\001)B\t\b\002¢\006\004\b\002\020\003J;\020\f\032\0020\n2\006\020\005\032\0020\0042\b\b\002\020\007\032\0020\0062\b\b\002\020\b\032\0020\0062\b\b\002\020\t\032\0020\0062\006\020\013\032\0020\n¢\006\004\b\f\020\rJG\020\031\032\0020\0302\006\020\017\032\0020\0162\006\020\021\032\0020\0202\006\020\022\032\0020\0062\006\020\023\032\0020\0062\006\020\025\032\0020\0242\016\020\027\032\n\022\006\022\004\030\0010\0160\026H\002¢\006\004\b\031\020\032J\037\020\033\032\0020\0062\006\020\017\032\0020\0162\006\020\013\032\0020\nH\002¢\006\004\b\033\020\034J\027\020\037\032\0020\0062\006\020\036\032\0020\035H\002¢\006\004\b\037\020 J\031\020#\032\0020\0062\b\020\"\032\004\030\0010!H\002¢\006\004\b#\020$J\027\020#\032\0020\0062\006\020\017\032\0020\016H\002¢\006\004\b#\020%R\032\020'\032\b\022\004\022\0020\0350&8\002X\004¢\006\006\n\004\b'\020(¨\006*"}, d2 = {"Lnet/integr/utilities/game/inventory/ToolUtils$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2338;", "pos", "", "silkEnderChest", "fortuneCrops", "fortuneOverSilkTouch", "", "maxBreakPercent", "getBestSlotForBlock", "(Lnet/minecraft/class_2338;ZZZI)I", "Lnet/minecraft/class_1799;", "itemStack", "Lnet/minecraft/class_2680;", "state", "silkTouchEnderChest", "fortuneOre", "Lnet/integr/utilities/game/inventory/ToolUtils$Companion$EnchantPreference;", "enchantPreference", "Ljava/util/function/Predicate;", "good", "", "getScore", "(Lnet/minecraft/class_1799;Lnet/minecraft/class_2680;ZZLnet/integr/utilities/game/inventory/ToolUtils$Companion$EnchantPreference;Ljava/util/function/Predicate;)D", "isAlmostBroken", "(Lnet/minecraft/class_1799;I)Z", "Lnet/minecraft/class_2248;", "block", "isFortunable", "(Lnet/minecraft/class_2248;)Z", "Lnet/minecraft/class_1792;", "item", "isTool", "(Lnet/minecraft/class_1792;)Z", "(Lnet/minecraft/class_1799;)Z", "", "ORES", "Ljava/util/List;", "EnchantPreference", "onyx2"})
/*     */   public static final class Companion
/*     */   {
/*     */     private Companion() {}
/*     */     
/*     */     public final int getBestSlotForBlock(@NotNull class_2338 pos, boolean silkEnderChest, boolean fortuneCrops, boolean fortuneOverSilkTouch, int maxBreakPercent) {
/*  52 */       Intrinsics.checkNotNullParameter(pos, "pos"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(pos), "getBlockState(...)"); class_2680 blockState = (Onyx.Companion.getMC()).field_1687.method_8320(pos);
/*  53 */       if (!BlockUtil.Companion.canBreak(pos, blockState)) return InvUtils.Companion.getSelectedSlot();
/*     */       
/*  55 */       double bestScore = -1.0D;
/*  56 */       int bestSlot = -1;
/*     */       
/*  58 */       for (int i = 0; i < 9; i++) {
/*  59 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i), "getStack(...)"); class_1799 itemStack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*     */         
/*  61 */         double score = getScore(itemStack, blockState, silkEnderChest, fortuneCrops, fortuneOverSilkTouch ? EnchantPreference.Fortune : EnchantPreference.SilkTouch, maxBreakPercent::getBestSlotForBlock$lambda$0);
/*  62 */         if (score >= 0.0D)
/*     */         {
/*  64 */           if (score > bestScore) {
/*  65 */             bestScore = score;
/*  66 */             bestSlot = i;
/*     */           } 
/*     */         }
/*     */       } 
/*  70 */       return bestSlot;
/*     */     }
/*     */     
/*     */     private final boolean isAlmostBroken(class_1799 itemStack, int maxBreakPercent) {
/*  74 */       return (itemStack.method_7936() - itemStack.method_7919() < itemStack.method_7936() * maxBreakPercent / 100);
/*     */     }
/*     */ 
/*     */     
/*     */     private final double getScore(class_1799 itemStack, class_2680 state, boolean silkTouchEnderChest, boolean fortuneOre, EnchantPreference enchantPreference, Predicate<class_1799> good) {
/*  79 */       if (!good.test(itemStack) || !isTool(itemStack)) return -1.0D; 
/*  80 */       if (!itemStack.method_7951(state) && (!(itemStack.method_7909() instanceof class_1829) || (!(state.method_26204() instanceof net.minecraft.class_2211) && !(state.method_26204() instanceof net.minecraft.class_2202))) && (!(itemStack.method_7909() instanceof net.minecraft.class_1820) || !(state.method_26204() instanceof net.minecraft.class_2397)) && !state.method_26164(class_3481.field_15481)) return -1.0D;
/*     */       
/*  82 */       Intrinsics.checkNotNullExpressionValue(class_1893.field_9099, "SILK_TOUCH"); if (silkTouchEnderChest && state.method_26204() == class_2246.field_10443 && EnchantmentUtil.Companion.getLevel(class_1893.field_9099, itemStack) == 0) {
/*  83 */         return -1.0D;
/*     */       }
/*     */       
/*  86 */       Intrinsics.checkNotNullExpressionValue(state.method_26204(), "getBlock(...)"); Intrinsics.checkNotNullExpressionValue(class_1893.field_9130, "FORTUNE"); if (fortuneOre && isFortunable(state.method_26204()) && EnchantmentUtil.Companion.getLevel(class_1893.field_9130, itemStack) == 0) {
/*  87 */         return -1.0D;
/*     */       }
/*     */       
/*  90 */       double score = 0.0D;
/*     */       
/*  92 */       score += (itemStack.method_7924(state) * 'Ϩ');
/*  93 */       Intrinsics.checkNotNullExpressionValue(class_1893.field_9119, "UNBREAKING"); score += EnchantmentUtil.Companion.getLevel(class_1893.field_9119, itemStack);
/*  94 */       Intrinsics.checkNotNullExpressionValue(class_1893.field_9131, "EFFICIENCY"); score += EnchantmentUtil.Companion.getLevel(class_1893.field_9131, itemStack);
/*  95 */       Intrinsics.checkNotNullExpressionValue(class_1893.field_9101, "MENDING"); score += EnchantmentUtil.Companion.getLevel(class_1893.field_9101, itemStack);
/*     */       
/*  97 */       if (enchantPreference == EnchantPreference.Fortune) { Intrinsics.checkNotNullExpressionValue(class_1893.field_9130, "FORTUNE"); score += EnchantmentUtil.Companion.getLevel(class_1893.field_9130, itemStack); }
/*  98 */        if (enchantPreference == EnchantPreference.SilkTouch) { Intrinsics.checkNotNullExpressionValue(class_1893.field_9099, "SILK_TOUCH"); score += EnchantmentUtil.Companion.getLevel(class_1893.field_9099, itemStack); }
/*     */       
/* 100 */       if (itemStack.method_7909() instanceof class_1829) {
/* 101 */         Intrinsics.checkNotNull(itemStack.method_7909(), "null cannot be cast to non-null type net.minecraft.item.SwordItem"); class_1829 item = (class_1829)itemStack.method_7909();
/* 102 */         if (state.method_26204() instanceof net.minecraft.class_2211 || state.method_26204() instanceof net.minecraft.class_2202) score += ('⌨' + item.method_58404(itemStack, state) * 'Ϩ');
/*     */       
/*     */       } 
/* 105 */       return score; } private static final boolean getBestSlotForBlock$lambda$0(int $maxBreakPercent, class_1799 itemStack2) {
/*     */       Intrinsics.checkNotNull(itemStack2);
/*     */       return !ToolUtils.Companion.isAlmostBroken(itemStack2, $maxBreakPercent);
/*     */     } private final boolean isTool(class_1792 item) {
/* 109 */       return (item instanceof net.minecraft.class_1831 || item instanceof net.minecraft.class_1820);
/*     */     }
/*     */     
/*     */     private final boolean isTool(class_1799 itemStack) {
/* 113 */       return isTool(itemStack.method_7909());
/*     */     }
/*     */ 
/*     */     
/*     */     private final boolean isFortunable(class_2248 block) {
/* 118 */       if (Intrinsics.areEqual(block, class_2246.field_22109)) return false; 
/* 119 */       return (ToolUtils.ORES.contains(block) || block instanceof net.minecraft.class_2302);
/*     */     }
/*     */     
/*     */     @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\002\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Lnet/integr/utilities/game/inventory/ToolUtils$Companion$EnchantPreference;", "", "<init>", "(Ljava/lang/String;I)V", "None", "Fortune", "SilkTouch", "onyx2"})
/* 123 */     public enum EnchantPreference { None,
/* 124 */       Fortune,
/* 125 */       SilkTouch;
/*     */       
/*     */       @NotNull
/*     */       public static EnumEntries<EnchantPreference> getEntries() {
/*     */         return $ENTRIES;
/*     */       } }
/*     */   
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   @NotNull
/*     */   private static final List<class_2248> ORES;
/*     */   
/*     */   static {
/*     */     class_2248[] arrayOfClass_2248 = new class_2248[14];
/*     */     arrayOfClass_2248[0] = class_2246.field_10442;
/*     */     arrayOfClass_2248[1] = class_2246.field_29029;
/*     */     arrayOfClass_2248[2] = class_2246.field_10571;
/*     */     arrayOfClass_2248[3] = class_2246.field_29026;
/*     */     arrayOfClass_2248[4] = class_2246.field_10013;
/*     */     arrayOfClass_2248[5] = class_2246.field_29220;
/*     */     arrayOfClass_2248[6] = class_2246.field_10090;
/*     */     arrayOfClass_2248[7] = class_2246.field_29028;
/*     */     arrayOfClass_2248[8] = class_2246.field_10212;
/*     */     arrayOfClass_2248[9] = class_2246.field_29027;
/*     */     arrayOfClass_2248[10] = class_2246.field_10418;
/*     */     arrayOfClass_2248[11] = class_2246.field_29219;
/*     */     arrayOfClass_2248[12] = class_2246.field_10080;
/*     */     arrayOfClass_2248[13] = class_2246.field_29030;
/*     */     ORES = CollectionsKt.listOf((Object[])arrayOfClass_2248);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\inventory\ToolUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */