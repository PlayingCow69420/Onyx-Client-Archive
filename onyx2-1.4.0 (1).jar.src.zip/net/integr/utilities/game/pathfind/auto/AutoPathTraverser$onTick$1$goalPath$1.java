/*    */ package net.integr.utilities.game.pathfind.auto;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.minecraft.class_2338;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\013\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()Ljava/lang/Boolean;", "<anonymous>"})
/*    */ final class AutoPathTraverser$onTick$1$goalPath$1
/*    */   extends Lambda
/*    */   implements Function0<Boolean>
/*    */ {
/*    */   AutoPathTraverser$onTick$1$goalPath$1(class_2338 $startingGoal) {
/*    */     super(0);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final Boolean invoke() {
/* 62 */     return Boolean.valueOf((!AutoPathTraverser.access$getActive$p(AutoPathTraverser.this) || AutoPathTraverser.access$getGoal$p(AutoPathTraverser.this) == null || !Intrinsics.areEqual(AutoPathTraverser.access$getGoal$p(AutoPathTraverser.this), this.$startingGoal)));
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\auto\AutoPathTraverser$onTick$1$goalPath$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */