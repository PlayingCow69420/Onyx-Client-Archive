/*    */ package net.integr.utilities.game.pathfind.auto;
/*    */ 
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.utilities.game.interaction.MovementUtil;
/*    */ import net.integr.utilities.game.pathfind.Path;
/*    */ import net.integr.utilities.game.pathfind.PathfindingManager;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\007\030\000 \0332\0020\001:\001\033B\007¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003J\027\020\t\032\0020\b2\006\020\007\032\0020\006H\002¢\006\004\b\t\020\nJ\027\020\r\032\0020\0042\006\020\f\032\0020\013H\007¢\006\004\b\r\020\016J\025\020\021\032\0020\0042\006\020\020\032\0020\017¢\006\004\b\021\020\022R\026\020\023\032\0020\b8\002@\002X\016¢\006\006\n\004\b\023\020\024R\034\020\027\032\n \026*\004\030\0010\0250\0258\002X\004¢\006\006\n\004\b\027\020\030R\030\020\031\032\004\030\0010\0178\002@\002X\016¢\006\006\n\004\b\031\020\032¨\006\034"}, d2 = {"Lnet/integr/utilities/game/pathfind/auto/AutoPathTraverser;", "", "<init>", "()V", "", "cancel", "Lnet/minecraft/class_243;", "pos", "", "hasReached", "(Lnet/minecraft/class_243;)Z", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "Lnet/minecraft/class_2338;", "to", "traverse", "(Lnet/minecraft/class_2338;)V", "active", "Z", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "es", "Ljava/util/concurrent/ExecutorService;", "goal", "Lnet/minecraft/class_2338;", "Companion", "onyx2"})
/*    */ public final class AutoPathTraverser
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/utilities/game/pathfind/auto/AutoPathTraverser$Companion;", "", "<init>", "()V", "Lnet/integr/utilities/game/pathfind/auto/AutoPathTraverser;", "INSTANCE", "Lnet/integr/utilities/game/pathfind/auto/AutoPathTraverser;", "getINSTANCE", "()Lnet/integr/utilities/game/pathfind/auto/AutoPathTraverser;", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     @NotNull
/* 30 */     public final AutoPathTraverser getINSTANCE() { return AutoPathTraverser.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @NotNull private static final AutoPathTraverser INSTANCE = new AutoPathTraverser();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   private final ExecutorService es = Executors.newFixedThreadPool(1); @Nullable
/*    */   private class_2338 goal; private boolean active;
/*    */   public final void traverse(@NotNull class_2338 to) {
/* 39 */     Intrinsics.checkNotNullParameter(to, "to"); this.goal = to;
/* 40 */     this.active = true;
/*    */   }
/*    */   
/*    */   public final void cancel() {
/* 44 */     this.goal = null;
/* 45 */     this.active = false;
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PreTickEvent event)
/*    */   {
/* 51 */     Intrinsics.checkNotNullParameter(event, "event"); if (!this.active)
/*    */       return; 
/* 53 */     this.es.execute(this::onTick$lambda$0);
/* 54 */   } private static final void onTick$lambda$0(AutoPathTraverser this$0) { Intrinsics.checkNotNullParameter(this$0, "this$0"); if (this$0.goal == null) {
/* 55 */       this$0.active = false;
/*    */       
/*    */       return;
/*    */     } 
/* 59 */     class_2338 startingGoal = this$0.goal;
/*    */ 
/*    */     
/* 62 */     Intrinsics.checkNotNull(this$0.goal); Path goalPath = PathfindingManager.Companion.getPathToBlock(this$0.goal, new AutoPathTraverser$onTick$1$goalPath$1(startingGoal))
/* 63 */       .smoothened();
/*    */     
/* 65 */     Path.render$default(goalPath, 0, 5, 1, null);
/*    */     
/* 67 */     if (goalPath.getPath().size() < 2) {
/*    */       return;
/*    */     }
/*    */     
/* 71 */     Intrinsics.checkNotNullExpressionValue(((class_243)goalPath.getPath().get(1)).method_1031(0.0D, 0.58D, 0.0D), "add(...)"); MovementUtil.Companion.pathMoveInDirection(((class_243)goalPath.getPath().get(1)).method_1031(0.0D, 0.58D, 0.0D));
/*    */     
/* 73 */     Intrinsics.checkNotNull(this$0.goal); Intrinsics.checkNotNullExpressionValue(this$0.goal.method_46558(), "toCenterPos(...)"); if (this$0.hasReached(this$0.goal.method_46558())) {
/* 74 */       this$0.goal = null;
/* 75 */       this$0.active = false;
/*    */     }  }
/*    */ 
/*    */ 
/*    */   
/*    */   private final boolean hasReached(class_243 pos) {
/* 81 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return (pos.method_1022((Onyx.Companion.getMC()).field_1724.method_19538()) <= 0.95D);
/*    */   }
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\013\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()Ljava/lang/Boolean;", "<anonymous>"})
/*    */   static final class AutoPathTraverser$onTick$1$goalPath$1 extends Lambda implements Function0<Boolean> {
/*    */     AutoPathTraverser$onTick$1$goalPath$1(class_2338 $startingGoal) {
/*    */       super(0);
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public final Boolean invoke() {
/*    */       return Boolean.valueOf((!AutoPathTraverser.this.active || AutoPathTraverser.this.goal == null || !Intrinsics.areEqual(AutoPathTraverser.this.goal, this.$startingGoal)));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\auto\AutoPathTraverser.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */