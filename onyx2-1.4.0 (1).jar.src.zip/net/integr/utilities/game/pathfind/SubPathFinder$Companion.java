/*     */ package net.integr.utilities.game.pathfind;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\020\b\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\021\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\t\020\bJ/\020\017\032\0020\0062\006\020\013\032\0020\n2\006\020\f\032\0020\n2\006\020\r\032\0020\n2\006\020\016\032\0020\006H\002¢\006\004\b\017\020\020J\035\020\017\032\0020\0062\006\020\022\032\0020\0212\006\020\016\032\0020\006¢\006\004\b\017\020\023R\032\020\025\032\b\022\004\022\0020\0210\0248\002X\004¢\006\006\n\004\b\025\020\026¨\006\027"}, d2 = {"Lnet/integr/utilities/game/pathfind/SubPathFinder$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2338;", "block", "", "canWalkOn", "(Lnet/minecraft/class_2338;)Z", "isNotPassable", "", "x", "y", "z", "checkGround", "isValid", "(IIIZ)Z", "Lnet/minecraft/class_243;", "loc", "(Lnet/minecraft/class_243;Z)Z", "", "directions", "[Lnet/minecraft/class_243;", "onyx2"})
/*     */ public final class Companion
/*     */ {
/*     */   private Companion() {}
/*     */   
/*     */   public final boolean isValid(@NotNull class_243 loc, boolean checkGround) {
/* 150 */     Intrinsics.checkNotNullParameter(loc, "loc"); return isValid(
/* 151 */         (int)loc.method_10216(), (int)loc.method_10214(), (int)loc.method_10215(), 
/* 152 */         checkGround);
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean isValid(int x, int y, int z, boolean checkGround) {
/* 157 */     class_2338 block1 = new class_2338(x, y, z);
/* 158 */     class_2338 block2 = new class_2338(x, y + 1, z);
/* 159 */     class_2338 block3 = new class_2338(x, y - 1, z);
/* 160 */     return (!isNotPassable(block1) && !isNotPassable(block2) && (isNotPassable(block3) || !checkGround) && canWalkOn(
/* 161 */         block3));
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean isNotPassable(class_2338 block) {
/* 166 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204(), "getBlock(...)"); class_2248 b = (Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204();
/*     */     
/* 168 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return (b.method_9564().method_26234((Onyx.Companion.getMC()).field_1687.method_22338(((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181, ((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181), (Onyx.Companion.getMC()).field_1724.method_24515()) || 
/* 169 */       b instanceof net.minecraft.class_2482 || 
/* 170 */       b instanceof net.minecraft.class_2510 || 
/* 171 */       b instanceof net.minecraft.class_2266 || 
/* 172 */       b instanceof net.minecraft.class_2281 || 
/* 173 */       b instanceof net.minecraft.class_2336 || 
/* 174 */       b instanceof net.minecraft.class_2484 || 
/* 175 */       b instanceof net.minecraft.class_2389 || 
/* 176 */       b instanceof net.minecraft.class_2354 || 
/* 177 */       b instanceof net.minecraft.class_2544 || 
/* 178 */       b instanceof net.minecraft.class_2671 || 
/* 179 */       b instanceof net.minecraft.class_2667 || 
/* 180 */       b instanceof net.minecraft.class_2665 || 
/* 181 */       b instanceof net.minecraft.class_2506 || 
/* 182 */       b instanceof net.minecraft.class_2533 || 
/* 183 */       b instanceof net.minecraft.class_2333 || 
/* 184 */       b instanceof net.minecraft.class_2334 || 
/* 185 */       b instanceof net.minecraft.class_2244 || 
/* 186 */       b instanceof net.minecraft.class_2560 || 
/* 187 */       b instanceof net.minecraft.class_2213 || 
/* 188 */       b instanceof net.minecraft.class_2399 || 
/* 189 */       b instanceof net.minecraft.class_2577 || 
/* 190 */       b instanceof net.minecraft.class_2369 || 
/* 191 */       b instanceof net.minecraft.class_2323 || 
/* 192 */       b instanceof net.minecraft.class_2349 || 
/* 193 */       b instanceof net.minecraft.class_2377 || 
/* 194 */       b instanceof net.minecraft.class_2492 || 
/* 195 */       b instanceof net.minecraft.class_3962 || 
/* 196 */       b instanceof net.minecraft.class_2426 || 
/* 197 */       b instanceof net.minecraft.class_5551 || 
/* 198 */       b instanceof net.minecraft.class_3749 || 
/* 199 */       b instanceof net.minecraft.class_5546);
/*     */   }
/*     */   
/*     */   private final boolean canWalkOn(class_2338 block) {
/* 203 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/* 204 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); return (!((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204() instanceof net.minecraft.class_2354) && 
/* 205 */       !((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204() instanceof net.minecraft.class_2544));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\SubPathFinder$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */