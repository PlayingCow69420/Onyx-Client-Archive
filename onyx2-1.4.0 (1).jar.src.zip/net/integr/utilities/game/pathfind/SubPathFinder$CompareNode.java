/*     */ package net.integr.utilities.game.pathfind;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\007¢\006\004\b\003\020\004J\037\020\b\032\0020\0072\006\020\005\032\0020\0022\006\020\006\032\0020\002H\026¢\006\004\b\b\020\t¨\006\n"}, d2 = {"Lnet/integr/utilities/game/pathfind/SubPathFinder$CompareNode;", "Ljava/util/Comparator;", "Lnet/integr/utilities/game/pathfind/Node;", "<init>", "()V", "o1", "o2", "", "compare", "(Lnet/integr/utilities/game/pathfind/Node;Lnet/integr/utilities/game/pathfind/Node;)I", "onyx2"})
/*     */ public final class CompareNode
/*     */   implements Comparator<Node>
/*     */ {
/*     */   public int compare(@NotNull Node o1, @NotNull Node o2) {
/* 141 */     Intrinsics.checkNotNullParameter(o1, "o1"); Intrinsics.checkNotNullParameter(o2, "o2"); return (int)(o1.getSqDist() + o1.getMaxCost() - o2.getSqDist() + o2.getMaxCost());
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\SubPathFinder$CompareNode.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */