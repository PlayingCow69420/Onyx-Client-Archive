/*    */ package net.integr.utilities.game.pathfind;@Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\020\006\n\002\b\031\030\0002\0020\001B?\022\006\020\003\032\0020\002\022\026\020\006\032\022\022\004\022\0020\0020\004j\b\022\004\022\0020\002`\005\022\006\020\b\032\0020\007\022\006\020\t\032\0020\007\022\006\020\n\032\0020\007¢\006\004\b\013\020\fR\"\020\t\032\0020\0078\006@\006X\016¢\006\022\n\004\b\t\020\r\032\004\b\016\020\017\"\004\b\020\020\021R\"\020\003\032\0020\0028\006@\006X\016¢\006\022\n\004\b\003\020\022\032\004\b\023\020\024\"\004\b\025\020\026R\"\020\n\032\0020\0078\006@\006X\016¢\006\022\n\004\b\n\020\r\032\004\b\027\020\017\"\004\b\030\020\021R2\020\006\032\022\022\004\022\0020\0020\004j\b\022\004\022\0020\002`\0058\006@\006X\016¢\006\022\n\004\b\006\020\031\032\004\b\032\020\033\"\004\b\034\020\035R\"\020\b\032\0020\0078\006@\006X\016¢\006\022\n\004\b\b\020\r\032\004\b\036\020\017\"\004\b\037\020\021¨\006 "}, d2 = {"Lnet/integr/utilities/game/pathfind/Node;", "", "Lnet/minecraft/class_243;", "loc", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "pathway", "", "sqDist", "currentCost", "maxCost", "<init>", "(Lnet/minecraft/class_243;Ljava/util/ArrayList;DDD)V", "D", "getCurrentCost", "()D", "setCurrentCost", "(D)V", "Lnet/minecraft/class_243;", "getLoc", "()Lnet/minecraft/class_243;", "setLoc", "(Lnet/minecraft/class_243;)V", "getMaxCost", "setMaxCost", "Ljava/util/ArrayList;", "getPathway", "()Ljava/util/ArrayList;", "setPathway", "(Ljava/util/ArrayList;)V", "getSqDist", "setSqDist", "onyx2"})
/*    */ public final class Node { @NotNull
/*    */   private class_243 loc; @NotNull
/*    */   private ArrayList<class_243> pathway; private double sqDist; private double currentCost; private double maxCost;
/*    */   @NotNull
/*    */   public final class_243 getLoc() {
/*    */     return this.loc;
/*    */   }
/*    */   public final void setLoc(@NotNull class_243 <set-?>) {
/*    */     Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
/*    */     this.loc = <set-?>;
/*    */   }
/*    */   @NotNull
/*    */   public final ArrayList<class_243> getPathway() {
/*    */     return this.pathway;
/*    */   }
/*    */   public final void setPathway(@NotNull ArrayList<class_243> <set-?>) {
/*    */     Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
/*    */     this.pathway = <set-?>;
/*    */   }
/*    */   
/* 22 */   public Node(@NotNull class_243 loc, @NotNull ArrayList<class_243> pathway, double sqDist, double currentCost, double maxCost) { this.loc = loc;
/* 23 */     this.pathway = pathway;
/* 24 */     this.sqDist = sqDist;
/* 25 */     this.currentCost = currentCost;
/* 26 */     this.maxCost = maxCost; } public final double getSqDist() { return this.sqDist; } public final void setSqDist(double <set-?>) { this.sqDist = <set-?>; } public final double getMaxCost() { return this.maxCost; } public final double getCurrentCost() { return this.currentCost; } public final void setCurrentCost(double <set-?>) { this.currentCost = <set-?>; } public final void setMaxCost(double <set-?>) { this.maxCost = <set-?>; }
/*    */    }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\Node.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */