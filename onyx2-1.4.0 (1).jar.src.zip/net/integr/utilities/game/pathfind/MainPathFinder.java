/*     */ package net.integr.utilities.game.pathfind;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\030\002\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\b\030\0002\0020\001B\025\022\f\020\004\032\b\022\004\022\0020\0030\002¢\006\004\b\005\020\006J\027\020\t\032\0020\0032\006\020\b\032\0020\007H\002¢\006\004\b\t\020\nJ\027\020\f\032\0020\0032\006\020\013\032\0020\007H\002¢\006\004\b\f\020\nJ-\020\022\032\022\022\004\022\0020\r0\020j\b\022\004\022\0020\r`\0212\006\020\016\032\0020\r2\006\020\017\032\0020\r¢\006\004\b\022\020\023J\027\020\024\032\0020\0032\006\020\013\032\0020\007H\002¢\006\004\b\024\020\nJ/\020\032\032\0020\0032\006\020\026\032\0020\0252\006\020\027\032\0020\0252\006\020\030\032\0020\0252\006\020\031\032\0020\003H\002¢\006\004\b\032\020\033R\032\020\004\032\b\022\004\022\0020\0030\0028\002X\004¢\006\006\n\004\b\004\020\034¨\006\035"}, d2 = {"Lnet/integr/utilities/game/pathfind/MainPathFinder;", "", "Lkotlin/Function0;", "", "breakCondition", "<init>", "(Lkotlin/jvm/functions/Function0;)V", "Lnet/minecraft/class_2338;", "pos", "canPassThrough", "(Lnet/minecraft/class_2338;)Z", "block", "canWalkOn", "Lnet/minecraft/class_243;", "topFromI", "to", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "computePath", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Ljava/util/ArrayList;", "isNotPassable", "", "x", "y", "z", "checkGround", "isValid", "(IIIZ)Z", "Lkotlin/jvm/functions/Function0;", "onyx2"})
/*     */ public final class MainPathFinder
/*     */ {
/*     */   @NotNull
/*     */   private final Function0<Boolean> breakCondition;
/*     */   
/*     */   public MainPathFinder(@NotNull Function0<Boolean> breakCondition) {
/*  29 */     this.breakCondition = breakCondition;
/*     */   }
/*     */   private final boolean isValid(int x, int y, int z, boolean checkGround) {
/*  32 */     class_2338 block1 = new class_2338(x, y, z);
/*  33 */     class_2338 block2 = new class_2338(x, y + 1, z);
/*  34 */     class_2338 block3 = new class_2338(x, y - 1, z);
/*  35 */     return (!isNotPassable(block1) && !isNotPassable(block2) && (isNotPassable(block3) || !checkGround) && canWalkOn(
/*  36 */         block3));
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean isNotPassable(class_2338 block) {
/*  41 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204(), "getBlock(...)"); class_2248 b = (Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204();
/*     */     
/*  43 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return (b.method_9564().method_26234((Onyx.Companion.getMC()).field_1687.method_22338(((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181, ((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181), (Onyx.Companion.getMC()).field_1724.method_24515()) || 
/*  44 */       b instanceof net.minecraft.class_2482 || 
/*  45 */       b instanceof net.minecraft.class_2510 || 
/*  46 */       b instanceof net.minecraft.class_2266 || 
/*  47 */       b instanceof net.minecraft.class_2281 || 
/*  48 */       b instanceof net.minecraft.class_2336 || 
/*  49 */       b instanceof net.minecraft.class_2484 || 
/*  50 */       b instanceof net.minecraft.class_2389 || 
/*  51 */       b instanceof net.minecraft.class_2354 || 
/*  52 */       b instanceof net.minecraft.class_2544 || 
/*  53 */       b instanceof net.minecraft.class_2671 || 
/*  54 */       b instanceof net.minecraft.class_2667 || 
/*  55 */       b instanceof net.minecraft.class_2665 || 
/*  56 */       b instanceof net.minecraft.class_2506 || 
/*  57 */       b instanceof net.minecraft.class_2533 || 
/*  58 */       b instanceof net.minecraft.class_2333 || 
/*  59 */       b instanceof net.minecraft.class_2334 || 
/*  60 */       b instanceof net.minecraft.class_2244 || 
/*  61 */       b instanceof net.minecraft.class_2560 || 
/*  62 */       b instanceof net.minecraft.class_2213 || 
/*  63 */       b instanceof net.minecraft.class_2399 || 
/*  64 */       b instanceof net.minecraft.class_2577 || 
/*  65 */       b instanceof net.minecraft.class_2369 || 
/*  66 */       b instanceof net.minecraft.class_2323 || 
/*  67 */       b instanceof net.minecraft.class_2349 || 
/*  68 */       b instanceof net.minecraft.class_2377 || 
/*  69 */       b instanceof net.minecraft.class_2492 || 
/*  70 */       b instanceof net.minecraft.class_3962 || 
/*  71 */       b instanceof net.minecraft.class_2426 || 
/*  72 */       b instanceof net.minecraft.class_5551 || 
/*  73 */       b instanceof net.minecraft.class_3749 || 
/*  74 */       b instanceof net.minecraft.class_5546);
/*     */   }
/*     */   
/*     */   private final boolean canWalkOn(class_2338 block) {
/*  78 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*  79 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); return (!((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204() instanceof net.minecraft.class_2354) && 
/*  80 */       !((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204() instanceof net.minecraft.class_2544));
/*     */   }
/*     */   
/*     */   private final boolean canPassThrough(class_2338 pos) {
/*  84 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(pos.method_10263(), pos.method_10264(), pos.method_10260())).method_26204(), "getBlock(...)"); class_2248 block = (Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(pos.method_10263(), pos.method_10264(), pos.method_10260())).method_26204();
/*  85 */     return (block.method_9564().method_26215() || block instanceof net.minecraft.class_2261 || block instanceof net.minecraft.class_2541 || Intrinsics.areEqual(block, class_2246.field_9983) || Intrinsics.areEqual(block, class_2246.field_10382) || block instanceof net.minecraft.class_2508);
/*     */   }
/*     */   @NotNull
/*     */   public final ArrayList<class_243> computePath(@NotNull class_243 topFromI, @NotNull class_243 to) {
/*  89 */     Intrinsics.checkNotNullParameter(topFromI, "topFromI"); Intrinsics.checkNotNullParameter(to, "to"); class_243 topFrom = topFromI;
/*  90 */     Intrinsics.checkNotNullExpressionValue(class_2338.method_49637(topFrom.field_1352, topFrom.field_1351, topFrom.field_1350), "ofFloored(...)"); if (!canPassThrough(class_2338.method_49637(topFrom.field_1352, topFrom.field_1351, topFrom.field_1350))) {
/*  91 */       Intrinsics.checkNotNullExpressionValue(topFrom.method_1031(0.0D, 1.0D, 0.0D), "add(...)"); topFrom = topFrom.method_1031(0.0D, 1.0D, 0.0D);
/*     */     } 
/*     */     
/*  94 */     SubPathFinder pathfinder = new SubPathFinder(topFrom, to, this.breakCondition);
/*  95 */     class_243 lastLoc = null;
/*  96 */     class_243 lastDashLoc = null;
/*  97 */     ArrayList<class_243> path = new ArrayList();
/*  98 */     ArrayList pathFinderPath = SubPathFinder.computePath$default(pathfinder, 0, 0, 3, null); Iterator<class_243> iterator;
/*     */     int i;
/* 100 */     for (iterator = pathFinderPath.iterator(), i = 0; iterator.hasNext(); ) { int j = i; i++; class_243 pathElm = iterator.next();
/* 101 */       if (((Boolean)this.breakCondition.invoke()).booleanValue()) {
/*     */         break;
/*     */       }
/*     */       
/* 105 */       if (j == 0 || j == pathFinderPath.size() - 1) {
/* 106 */         if (lastLoc != null) {
/* 107 */           path.add(lastLoc.method_1031(0.5D, 0.0D, 0.5D));
/*     */         }
/* 109 */         path.add(pathElm.method_1031(0.5D, 0.0D, 0.5D));
/* 110 */         lastDashLoc = pathElm;
/*     */       } else {
/* 112 */         boolean canContinue = true;
/* 113 */         if (pathElm.method_1025(lastDashLoc) > 25.0D) {
/* 114 */           canContinue = false;
/*     */         } else {
/* 116 */           Intrinsics.checkNotNull(lastDashLoc); double smallX = Math.min(lastDashLoc.method_10216(), pathElm.method_10216());
/* 117 */           double smallY = Math.min(lastDashLoc.method_10214(), pathElm.method_10214());
/* 118 */           double smallZ = Math.min(lastDashLoc.method_10215(), pathElm.method_10215());
/* 119 */           double bigX = Math.max(lastDashLoc.method_10216(), pathElm.method_10216());
/* 120 */           double bigY = Math.max(lastDashLoc.method_10214(), pathElm.method_10214());
/* 121 */           double bigZ = Math.max(lastDashLoc.method_10215(), pathElm.method_10215());
/* 122 */           int x = (int)smallX;
/* 123 */           if (x <= bigX);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 140 */         if (!canContinue) {
/* 141 */           Intrinsics.checkNotNull(lastLoc); path.add(lastLoc.method_1031(0.5D, 0.0D, 0.5D));
/* 142 */           lastDashLoc = lastLoc;
/*     */         } 
/*     */       } 
/* 145 */       lastLoc = pathElm; }
/*     */     
/* 147 */     return path;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\MainPathFinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */