/*     */ package net.integr.utilities.game.pathfind;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3959;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\020 \n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\002\n\002\030\002\n\002\020\002\n\002\b\003\n\002\020\b\n\002\b\r\030\0002\0020\001B\025\022\f\020\004\032\b\022\004\022\0020\0030\002¢\006\004\b\005\020\006J\037\020\n\032\0020\t2\006\020\007\032\0020\0032\006\020\b\032\0020\003H\002¢\006\004\b\n\020\013J'\020\017\032\0020\r2\030\020\016\032\024\022\004\022\0020\003\022\004\022\0020\003\022\004\022\0020\r0\f¢\006\004\b\017\020\020J;\020\024\032\0020\r2\b\b\002\020\022\032\0020\0212\b\b\002\020\023\032\0020\0212\030\020\016\032\024\022\004\022\0020\003\022\004\022\0020\003\022\004\022\0020\r0\f¢\006\004\b\024\020\025J!\020\026\032\0020\r2\b\b\002\020\022\032\0020\0212\b\b\002\020\023\032\0020\021¢\006\004\b\026\020\027J\r\020\030\032\0020\000¢\006\004\b\030\020\031J\r\020\032\032\0020\000¢\006\004\b\032\020\031R\035\020\004\032\b\022\004\022\0020\0030\0028\006¢\006\f\n\004\b\004\020\033\032\004\b\034\020\035¨\006\036"}, d2 = {"Lnet/integr/utilities/game/pathfind/Path;", "", "", "Lnet/minecraft/class_243;", "path", "<init>", "(Ljava/util/List;)V", "from", "to", "", "canTravel", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Z", "Lkotlin/Function2;", "", "execute", "iterate", "(Lkotlin/jvm/functions/Function2;)V", "", "color", "time", "iterateAndRender", "(IILkotlin/jvm/functions/Function2;)V", "render", "(II)V", "reversed", "()Lnet/integr/utilities/game/pathfind/Path;", "smoothened", "Ljava/util/List;", "getPath", "()Ljava/util/List;", "onyx2"})
/*     */ public final class Path
/*     */ {
/*     */   @NotNull
/*     */   private final List<class_243> path;
/*     */   
/*     */   public Path(@NotNull List<class_243> path) {
/*  27 */     this.path = path; } @NotNull public final List<class_243> getPath() { return this.path; }
/*     */    public final void render(int color, int time) {
/*  29 */     if (this.path.isEmpty())
/*     */       return; 
/*  31 */     class_243 pre = this.path.get(0);
/*     */     
/*  33 */     for (class_243 p : this.path.subList(0, this.path.size())) {
/*  34 */       Highlighter.Companion.renderLine(pre, p, color, time);
/*  35 */       class_238 box = new class_238(-0.1D, -0.1D, -0.1D, 0.1D, 0.1D, 0.1D);
/*  36 */       Highlighter.Companion.renderBox(box, p, color, time);
/*  37 */       pre = p;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void iterate(@NotNull Function2 execute) {
/*  42 */     Intrinsics.checkNotNullParameter(execute, "execute"); if (this.path.isEmpty())
/*     */       return; 
/*  44 */     class_243 pre = this.path.get(0);
/*     */     
/*  46 */     for (class_243 p : this.path.subList(0, this.path.size())) {
/*  47 */       execute.invoke(pre, p);
/*  48 */       pre = p;
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void iterateAndRender(int color, int time, @NotNull Function2 execute) {
/*  53 */     Intrinsics.checkNotNullParameter(execute, "execute"); if (this.path.isEmpty())
/*     */       return; 
/*  55 */     class_243 pre = this.path.get(0);
/*     */     
/*  57 */     for (class_243 p : this.path.subList(0, this.path.size())) {
/*  58 */       Highlighter.Companion.renderLine(pre, p, color, time);
/*  59 */       class_238 box = new class_238(-0.1D, -0.1D, -0.1D, 0.1D, 0.1D, 0.1D);
/*  60 */       Highlighter.Companion.renderBox(box, p, color, time);
/*  61 */       execute.invoke(pre, p);
/*  62 */       pre = p;
/*     */     } 
/*     */   }
/*     */   @NotNull
/*     */   public final Path smoothened() {
/*  67 */     if (this.path.size() < 2) return this;
/*     */     
/*  69 */     class_243[] arrayOfClass_243 = new class_243[1]; arrayOfClass_243[0] = this.path.get(0); ArrayList<class_243> smoothedPath = CollectionsKt.arrayListOf((Object[])arrayOfClass_243);
/*  70 */     class_243 lastTravelPos = this.path.get(0);
/*     */     
/*  72 */     int iterCount = 0;
/*     */     
/*  74 */     while (!Intrinsics.areEqual(lastTravelPos, this.path.get(this.path.size() - 1)) && iterCount < 1000) {
/*  75 */       class_243 tempPos = lastTravelPos;
/*  76 */       for (int it = this.path.indexOf(lastTravelPos), i = this.path.size(); it < i; it++) {
/*  77 */         if (canTravel(lastTravelPos, this.path.get(it))) {
/*  78 */           tempPos = this.path.get(it);
/*     */         }
/*     */       } 
/*     */       
/*  82 */       lastTravelPos = tempPos;
/*  83 */       smoothedPath.add(lastTravelPos);
/*     */       
/*  85 */       iterCount++;
/*     */     } 
/*     */     
/*  88 */     if (iterCount == 1000) {
/*  89 */       return this;
/*     */     }
/*     */     
/*  92 */     return new Path(smoothedPath);
/*     */   }
/*     */   @NotNull
/*     */   public final Path reversed() {
/*  96 */     return new Path(CollectionsKt.reversed(this.path));
/*     */   }
/*     */   
/*     */   private final boolean canTravel(class_243 from, class_243 to) {
/* 100 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_17742(new class_3959(from, to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)(Onyx.Companion.getMC()).field_1724)), "raycast(...)"); class_239 h = (class_239)(Onyx.Companion.getMC()).field_1687.method_17742(new class_3959(from, to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)(Onyx.Companion.getMC()).field_1724));
/* 101 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_17742(new class_3959(from.method_1031(0.0D, 1.0D, 0.0D), to.method_1031(0.0D, 1.0D, 0.0D), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)(Onyx.Companion.getMC()).field_1724)), "raycast(...)"); class_239 h2 = (class_239)(Onyx.Companion.getMC()).field_1687.method_17742(new class_3959(from.method_1031(0.0D, 1.0D, 0.0D), to.method_1031(0.0D, 1.0D, 0.0D), class_3959.class_3960.field_17558, class_3959.class_242.field_1348, (class_1297)(Onyx.Companion.getMC()).field_1724));
/*     */     
/* 103 */     return (h.method_17783() != class_239.class_240.field_1332 && h2.method_17783() != class_239.class_240.field_1332);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\Path.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */