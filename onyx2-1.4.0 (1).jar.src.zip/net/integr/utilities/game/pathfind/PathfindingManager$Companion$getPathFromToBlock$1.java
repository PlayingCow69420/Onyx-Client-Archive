/*    */ package net.integr.utilities.game.pathfind;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\013\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()Ljava/lang/Boolean;", "<anonymous>"})
/*    */ final class PathfindingManager$Companion$getPathFromToBlock$1
/*    */   extends Lambda
/*    */   implements Function0<Boolean>
/*    */ {
/*    */   public static final PathfindingManager$Companion$getPathFromToBlock$1 INSTANCE = new PathfindingManager$Companion$getPathFromToBlock$1();
/*    */   
/*    */   PathfindingManager$Companion$getPathFromToBlock$1() {
/*    */     super(0);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final Boolean invoke() {
/* 28 */     return Boolean.valueOf(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\PathfindingManager$Companion$getPathFromToBlock$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */