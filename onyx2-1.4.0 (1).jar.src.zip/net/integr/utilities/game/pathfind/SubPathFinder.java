/*     */ package net.integr.utilities.game.pathfind;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.JvmOverloads;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import net.integr.Onyx;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000@\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\013\n\002\b\003\n\002\020\b\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\006\n\002\b\016\030\000 \"2\0020\001:\002\"#B%\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\f\020\007\032\b\022\004\022\0020\0060\005¢\006\004\b\b\020\tJ3\020\017\032\022\022\004\022\0020\0020\rj\b\022\004\022\0020\002`\0162\b\b\002\020\013\032\0020\n2\b\b\002\020\f\032\0020\nH\007¢\006\004\b\017\020\020J\031\020\023\032\004\030\0010\0222\006\020\021\032\0020\002H\002¢\006\004\b\023\020\024J)\020\030\032\0020\0062\b\020\025\032\004\030\0010\0222\006\020\021\032\0020\0022\006\020\027\032\0020\026H\002¢\006\004\b\030\020\031R\035\020\007\032\b\022\004\022\0020\0060\0058\006¢\006\f\n\004\b\007\020\032\032\004\b\033\020\034R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020\035R&\020\036\032\022\022\004\022\0020\0020\rj\b\022\004\022\0020\002`\0168\002@\002X\016¢\006\006\n\004\b\036\020\037R$\020 \032\022\022\004\022\0020\0220\rj\b\022\004\022\0020\022`\0168\002X\004¢\006\006\n\004\b \020\037R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\035R$\020!\032\022\022\004\022\0020\0220\rj\b\022\004\022\0020\022`\0168\002X\004¢\006\006\n\004\b!\020\037¨\006$"}, d2 = {"Lnet/integr/utilities/game/pathfind/SubPathFinder;", "", "Lnet/minecraft/class_243;", "startVec3Path", "endVec3Path", "Lkotlin/Function0;", "", "breakCondition", "<init>", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lkotlin/jvm/functions/Function0;)V", "", "loops", "depth", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "computePath", "(II)Ljava/util/ArrayList;", "loc", "Lnet/integr/utilities/game/pathfind/Node;", "doesNodeExistAt", "(Lnet/minecraft/class_243;)Lnet/integr/utilities/game/pathfind/Node;", "parent", "", "cost", "putNode", "(Lnet/integr/utilities/game/pathfind/Node;Lnet/minecraft/class_243;D)Z", "Lkotlin/jvm/functions/Function0;", "getBreakCondition", "()Lkotlin/jvm/functions/Function0;", "Lnet/minecraft/class_243;", "path", "Ljava/util/ArrayList;", "pathHubs", "workingPathHubList", "Companion", "CompareNode", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nSubPathFinder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SubPathFinder.kt\nnet/integr/utilities/game/pathfind/SubPathFinder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,208:1\n1#2:209\n*E\n"})
/*     */ public final class SubPathFinder
/*     */ {
/*     */   public SubPathFinder(@NotNull class_243 startVec3Path, @NotNull class_243 endVec3Path, @NotNull Function0<Boolean> breakCondition) {
/*  30 */     this.breakCondition = breakCondition;
/*  31 */     Intrinsics.checkNotNullExpressionValue(startVec3Path.method_1031(0.0D, 0.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051)), "floorAlongAxes(...)"); this.startVec3Path = startVec3Path.method_1031(0.0D, 0.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051));
/*  32 */     Intrinsics.checkNotNullExpressionValue(endVec3Path.method_1031(0.0D, 0.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051)), "floorAlongAxes(...)"); this.endVec3Path = endVec3Path.method_1031(0.0D, 0.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051));
/*  33 */     this.path = new ArrayList<>();
/*  34 */     this.pathHubs = new ArrayList<>();
/*  35 */     this.workingPathHubList = new ArrayList<>();
/*     */   } @JvmOverloads
/*     */   @NotNull
/*     */   public final ArrayList<class_243> computePath(int loops, int depth) {
/*  39 */     this.path.clear();
/*  40 */     this.workingPathHubList.clear();
/*     */     
/*  42 */     ArrayList<class_243> initPath = new ArrayList();
/*  43 */     initPath.add(this.startVec3Path);
/*     */     
/*  45 */     this.workingPathHubList.add(
/*  46 */         new Node(this.startVec3Path, initPath, this.startVec3Path.method_1025(this.endVec3Path), 0.0D, 0.0D));
/*     */     
/*     */     int i;
/*  49 */     label39: for (i = 0; i < loops && 
/*  50 */       !((Boolean)this.breakCondition.invoke()).booleanValue(); i++) {
/*     */ 
/*     */ 
/*     */       
/*  54 */       CollectionsKt.sortWith(this.workingPathHubList, new CompareNode());
/*     */       
/*  56 */       if (this.workingPathHubList.isEmpty())
/*     */         break; 
/*     */       Iterator<?> iterator;
/*     */       int j;
/*  60 */       for (iterator = (new ArrayList(this.workingPathHubList)).iterator(), j = 0; iterator.hasNext(); ) { int k = j; j++; Node pathHub = (Node)iterator.next();
/*  61 */         Object loc2 = null;
/*     */         
/*  63 */         if (k + 1 > depth) {
/*     */           break;
/*     */         }
/*     */         
/*  67 */         this.workingPathHubList.remove(pathHub);
/*  68 */         this.pathHubs.add(pathHub); class_243[] arrayOfClass_243; byte b;
/*     */         int m;
/*  70 */         for (arrayOfClass_243 = directions, b = 0, m = arrayOfClass_243.length; b < m; ) { class_243 direction = arrayOfClass_243[b];
/*     */           
/*  72 */           Intrinsics.checkNotNullExpressionValue(pathHub.getLoc().method_1019(direction).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051)), "floorAlongAxes(...)"); class_243 loc = pathHub.getLoc().method_1019(direction).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051));
/*  73 */           if (Companion.isValid(loc, false) && putNode(pathHub, loc, 0.0D)) {
/*     */             break label39;
/*     */           }
/*     */           b++; }
/*     */         
/*  78 */         Intrinsics.checkNotNullExpressionValue(pathHub.getLoc().method_1031(0.0D, 1.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051)), "floorAlongAxes(...)"); class_243 loc1 = pathHub.getLoc().method_1031(0.0D, 1.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051));
/*  79 */         if (!Companion.isValid(loc1, false) || !putNode(pathHub, loc1, 0.0D)) { class_243 class_2431 = pathHub.getLoc().method_1031(0.0D, -1.0D, 0.0D).method_1032(EnumSet.of((Enum)class_2350.class_2351.field_11048, (Enum)class_2350.class_2351.field_11052, (Enum)class_2350.class_2351.field_11051)), class_2432 = class_2431;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 209 */           Companion companion = Companion; int $i$a$-also-SubPathFinder$computePath$1 = 0;
/*     */           Intrinsics.checkNotNull(class_2432);
/*     */           loc2 = class_2432;
/*     */           Intrinsics.checkNotNullExpressionValue(class_2431, "also(...)");
/*     */           if (companion.isValid(class_2431, false) && putNode(pathHub, (class_243)loc2, 0.0D))
/*     */             break label39; 
/*     */           continue; }
/*     */         
/*     */         break label39; }
/*     */     
/*     */     } 
/*     */     CollectionsKt.sortWith(this.pathHubs, new CompareNode());
/*     */     return ((Node)this.pathHubs.get(0)).getPathway();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final Function0<Boolean> getBreakCondition() {
/*     */     return this.breakCondition;
/*     */   }
/*     */   
/*     */   private final Node doesNodeExistAt(class_243 loc) {
/*     */     for (Node pathHub : this.pathHubs) {
/*     */       if (!((pathHub.getLoc().method_10216() == loc.method_10216()) ? 1 : 0) || !((pathHub.getLoc().method_10214() == loc.method_10214()) ? 1 : 0) || !((pathHub.getLoc().method_10215() == loc.method_10215()) ? 1 : 0))
/*     */         continue; 
/*     */       return pathHub;
/*     */     } 
/*     */     for (Node pathHub : this.workingPathHubList) {
/*     */       if (!((pathHub.getLoc().method_10216() == loc.method_10216()) ? 1 : 0) || !((pathHub.getLoc().method_10214() == loc.method_10214()) ? 1 : 0) || !((pathHub.getLoc().method_10215() == loc.method_10215()) ? 1 : 0))
/*     */         continue; 
/*     */       return pathHub;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   private final boolean putNode(Node parent, class_243 loc, double cost) {
/*     */     Node existingPathHub = doesNodeExistAt(loc);
/*     */     double totalCost = cost;
/*     */     if (parent != null)
/*     */       totalCost += parent.getMaxCost(); 
/*     */     if (existingPathHub == null) {
/*     */       if ((((loc.method_10216() == this.endVec3Path.method_10216())) && ((loc.method_10214() == this.endVec3Path.method_10214())) && ((loc.method_10215() == this.endVec3Path.method_10215()))) || loc.method_1025(this.endVec3Path) <= 1.0D) {
/*     */         this.path.clear();
/*     */         if (parent == null || parent.getPathway() == null)
/*     */           parent.getPathway(); 
/*     */         ((SubPathFinder)parent.getPathway()).path = new ArrayList<>();
/*     */         this.path.add(loc);
/*     */         return true;
/*     */       } 
/*     */       ArrayList<class_243> path = (parent != null) ? new ArrayList<>(parent.getPathway()) : new ArrayList();
/*     */       path.add(loc);
/*     */       this.workingPathHubList.add(new Node(loc, path, loc.method_1025(this.endVec3Path), cost, totalCost));
/*     */     } else if (existingPathHub.getCurrentCost() > cost) {
/*     */       ArrayList<class_243> path = (parent != null) ? new ArrayList<>(parent.getPathway()) : new ArrayList();
/*     */       path.add(loc);
/*     */       existingPathHub.setLoc(loc);
/*     */       existingPathHub.setPathway(path);
/*     */       existingPathHub.setSqDist(loc.method_1025(this.endVec3Path));
/*     */       existingPathHub.setCurrentCost(cost);
/*     */       existingPathHub.setMaxCost(totalCost);
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\007¢\006\004\b\003\020\004J\037\020\b\032\0020\0072\006\020\005\032\0020\0022\006\020\006\032\0020\002H\026¢\006\004\b\b\020\t¨\006\n"}, d2 = {"Lnet/integr/utilities/game/pathfind/SubPathFinder$CompareNode;", "Ljava/util/Comparator;", "Lnet/integr/utilities/game/pathfind/Node;", "<init>", "()V", "o1", "o2", "", "compare", "(Lnet/integr/utilities/game/pathfind/Node;Lnet/integr/utilities/game/pathfind/Node;)I", "onyx2"})
/*     */   public static final class CompareNode implements Comparator<Node> {
/*     */     public int compare(@NotNull Node o1, @NotNull Node o2) {
/*     */       Intrinsics.checkNotNullParameter(o1, "o1");
/*     */       Intrinsics.checkNotNullParameter(o2, "o2");
/*     */       return (int)(o1.getSqDist() + o1.getMaxCost() - o2.getSqDist() + o2.getMaxCost());
/*     */     }
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\020\b\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\021\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\t\020\bJ/\020\017\032\0020\0062\006\020\013\032\0020\n2\006\020\f\032\0020\n2\006\020\r\032\0020\n2\006\020\016\032\0020\006H\002¢\006\004\b\017\020\020J\035\020\017\032\0020\0062\006\020\022\032\0020\0212\006\020\016\032\0020\006¢\006\004\b\017\020\023R\032\020\025\032\b\022\004\022\0020\0210\0248\002X\004¢\006\006\n\004\b\025\020\026¨\006\027"}, d2 = {"Lnet/integr/utilities/game/pathfind/SubPathFinder$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2338;", "block", "", "canWalkOn", "(Lnet/minecraft/class_2338;)Z", "isNotPassable", "", "x", "y", "z", "checkGround", "isValid", "(IIIZ)Z", "Lnet/minecraft/class_243;", "loc", "(Lnet/minecraft/class_243;Z)Z", "", "directions", "[Lnet/minecraft/class_243;", "onyx2"})
/*     */   public static final class Companion {
/*     */     private Companion() {}
/*     */     
/*     */     public final boolean isValid(@NotNull class_243 loc, boolean checkGround) {
/*     */       Intrinsics.checkNotNullParameter(loc, "loc");
/*     */       return isValid((int)loc.method_10216(), (int)loc.method_10214(), (int)loc.method_10215(), checkGround);
/*     */     }
/*     */     
/*     */     private final boolean isValid(int x, int y, int z, boolean checkGround) {
/*     */       class_2338 block1 = new class_2338(x, y, z);
/*     */       class_2338 block2 = new class_2338(x, y + 1, z);
/*     */       class_2338 block3 = new class_2338(x, y - 1, z);
/*     */       return (!isNotPassable(block1) && !isNotPassable(block2) && (isNotPassable(block3) || !checkGround) && canWalkOn(block3));
/*     */     }
/*     */     
/*     */     private final boolean isNotPassable(class_2338 block) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204(), "getBlock(...)");
/*     */       class_2248 b = (Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204();
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */       return (b.method_9564().method_26234((Onyx.Companion.getMC()).field_1687.method_22338(((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181, ((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181), (Onyx.Companion.getMC()).field_1724.method_24515()) || b instanceof net.minecraft.class_2482 || b instanceof net.minecraft.class_2510 || b instanceof net.minecraft.class_2266 || b instanceof net.minecraft.class_2281 || b instanceof net.minecraft.class_2336 || b instanceof net.minecraft.class_2484 || b instanceof net.minecraft.class_2389 || b instanceof net.minecraft.class_2354 || b instanceof net.minecraft.class_2544 || b instanceof net.minecraft.class_2671 || b instanceof net.minecraft.class_2667 || b instanceof net.minecraft.class_2665 || b instanceof net.minecraft.class_2506 || b instanceof net.minecraft.class_2533 || b instanceof net.minecraft.class_2333 || b instanceof net.minecraft.class_2334 || b instanceof net.minecraft.class_2244 || b instanceof net.minecraft.class_2560 || b instanceof net.minecraft.class_2213 || b instanceof net.minecraft.class_2399 || b instanceof net.minecraft.class_2577 || b instanceof net.minecraft.class_2369 || b instanceof net.minecraft.class_2323 || b instanceof net.minecraft.class_2349 || b instanceof net.minecraft.class_2377 || b instanceof net.minecraft.class_2492 || b instanceof net.minecraft.class_3962 || b instanceof net.minecraft.class_2426 || b instanceof net.minecraft.class_5551 || b instanceof net.minecraft.class_3749 || b instanceof net.minecraft.class_5546);
/*     */     }
/*     */     
/*     */     private final boolean canWalkOn(class_2338 block) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       return (!((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204() instanceof net.minecraft.class_2354) && !((Onyx.Companion.getMC()).field_1687.method_8320(new class_2338(block.method_10263(), block.method_10264(), block.method_10260())).method_26204() instanceof net.minecraft.class_2544));
/*     */     }
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   @NotNull
/*     */   private final Function0<Boolean> breakCondition;
/*     */   @NotNull
/*     */   private final class_243 startVec3Path;
/*     */   @NotNull
/*     */   private final class_243 endVec3Path;
/*     */   @NotNull
/*     */   private ArrayList<class_243> path;
/*     */   @NotNull
/*     */   private final ArrayList<Node> pathHubs;
/*     */   @NotNull
/*     */   private final ArrayList<Node> workingPathHubList;
/*     */   @NotNull
/*     */   private static final class_243[] directions;
/*     */   
/*     */   static {
/*     */     class_243[] arrayOfClass_243 = new class_243[4];
/*     */     arrayOfClass_243[0] = new class_243(1.0D, 0.0D, 0.0D);
/*     */     arrayOfClass_243[1] = new class_243(-1.0D, 0.0D, 0.0D);
/*     */     arrayOfClass_243[2] = new class_243(0.0D, 0.0D, 1.0D);
/*     */     arrayOfClass_243[3] = new class_243(0.0D, 0.0D, -1.0D);
/*     */     directions = arrayOfClass_243;
/*     */   }
/*     */   
/*     */   @JvmOverloads
/*     */   @NotNull
/*     */   public final ArrayList<class_243> computePath(int loops) {
/*     */     return computePath$default(this, loops, 0, 2, null);
/*     */   }
/*     */   
/*     */   @JvmOverloads
/*     */   @NotNull
/*     */   public final ArrayList<class_243> computePath() {
/*     */     return computePath$default(this, 0, 0, 3, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\SubPathFinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */