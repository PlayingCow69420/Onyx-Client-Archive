/*    */ package net.integr.utilities.game.pathfind;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.minecraft.class_2338;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J-\020\013\032\0020\n2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\016\b\002\020\t\032\b\022\004\022\0020\b0\007¢\006\004\b\013\020\fJ%\020\016\032\0020\n2\006\020\r\032\0020\0042\016\b\002\020\t\032\b\022\004\022\0020\b0\007¢\006\004\b\016\020\017¨\006\020"}, d2 = {"Lnet/integr/utilities/game/pathfind/PathfindingManager$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_2338;", "from", "to", "Lkotlin/Function0;", "", "breakCondition", "Lnet/integr/utilities/game/pathfind/Path;", "getPathFromToBlock", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2338;Lkotlin/jvm/functions/Function0;)Lnet/integr/utilities/game/pathfind/Path;", "blockPos", "getPathToBlock", "(Lnet/minecraft/class_2338;Lkotlin/jvm/functions/Function0;)Lnet/integr/utilities/game/pathfind/Path;", "onyx2"})
/*    */ public final class Companion {
/*    */   private Companion() {}
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\013\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()Ljava/lang/Boolean;", "<anonymous>"})
/*    */   static final class PathfindingManager$Companion$getPathToBlock$1 extends Lambda implements Function0<Boolean> { public static final PathfindingManager$Companion$getPathToBlock$1 INSTANCE = new PathfindingManager$Companion$getPathToBlock$1();
/*    */     
/*    */     PathfindingManager$Companion$getPathToBlock$1() {
/*    */       super(0);
/*    */     }
/*    */     
/*    */     @NotNull
/* 24 */     public final Boolean invoke() { return Boolean.valueOf(false); } } @NotNull
/* 25 */   public final Path getPathToBlock(@NotNull class_2338 blockPos, @NotNull Function0<Boolean> breakCondition) { Intrinsics.checkNotNullParameter(blockPos, "blockPos"); Intrinsics.checkNotNullParameter(breakCondition, "breakCondition"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_24515().method_46558(), "toCenterPos(...)"); Intrinsics.checkNotNullExpressionValue(blockPos.method_46558(), "toCenterPos(...)"); return new Path((new MainPathFinder(breakCondition)).computePath((Onyx.Companion.getMC()).field_1724.method_24515().method_46558(), blockPos.method_46558())); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\013\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()Ljava/lang/Boolean;", "<anonymous>"})
/*    */   static final class PathfindingManager$Companion$getPathFromToBlock$1 extends Lambda implements Function0<Boolean> {
/*    */     public static final PathfindingManager$Companion$getPathFromToBlock$1 INSTANCE = new PathfindingManager$Companion$getPathFromToBlock$1(); PathfindingManager$Companion$getPathFromToBlock$1() { super(0); } @NotNull
/* 28 */     public final Boolean invoke() { return Boolean.valueOf(false); } } @NotNull
/* 29 */   public final Path getPathFromToBlock(@NotNull class_2338 from, @NotNull class_2338 to, @NotNull Function0<Boolean> breakCondition) { Intrinsics.checkNotNullParameter(from, "from"); Intrinsics.checkNotNullParameter(to, "to"); Intrinsics.checkNotNullParameter(breakCondition, "breakCondition"); Intrinsics.checkNotNullExpressionValue(from.method_46558(), "toCenterPos(...)"); Intrinsics.checkNotNullExpressionValue(to.method_46558(), "toCenterPos(...)"); return new Path((new MainPathFinder(breakCondition)).computePath(from.method_46558(), to.method_46558())); }
/*    */ 
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\pathfind\PathfindingManager$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */