/*    */ package net.integr.utilities.game.rotationfake;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PostTickEvent;
/*    */ import net.integr.event.SendPacketEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.mixin.PlayerInteractItemC2SPacketAccessor;
/*    */ import net.integr.utilities.game.interaction.RotationUtils;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000:\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020\007\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\026\030\000 *2\0020\001:\001*B\007¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\035\020\f\032\0020\0062\006\020\n\032\0020\t2\006\020\013\032\0020\t¢\006\004\b\f\020\rJ\027\020\020\032\0020\0062\006\020\017\032\0020\016H\007¢\006\004\b\020\020\021J\027\020\023\032\0020\0062\006\020\017\032\0020\022H\007¢\006\004\b\023\020\024R\"\020\026\032\0020\0258\006@\006X\016¢\006\022\n\004\b\026\020\027\032\004\b\026\020\030\"\004\b\031\020\032R\"\020\033\032\0020\t8\006@\006X\016¢\006\022\n\004\b\033\020\034\032\004\b\035\020\036\"\004\b\037\020 R\"\020!\032\0020\t8\006@\006X\016¢\006\022\n\004\b!\020\034\032\004\b\"\020\036\"\004\b#\020 R\"\020$\032\0020\t8\006@\006X\016¢\006\022\n\004\b$\020\034\032\004\b%\020\036\"\004\b&\020 R\"\020'\032\0020\t8\006@\006X\016¢\006\022\n\004\b'\020\034\032\004\b(\020\036\"\004\b)\020 ¨\006+"}, d2 = {"Lnet/integr/utilities/game/rotationfake/RotationFaker;", "", "<init>", "()V", "Lnet/minecraft/class_243;", "vec", "", "face", "(Lnet/minecraft/class_243;)V", "", "yaw", "pitch", "look", "(FF)V", "Lnet/integr/event/SendPacketEvent;", "e", "onPacket", "(Lnet/integr/event/SendPacketEvent;)V", "Lnet/integr/event/PostTickEvent;", "onTick", "(Lnet/integr/event/PostTickEvent;)V", "", "isFake", "Z", "()Z", "setFake", "(Z)V", "prePitch", "F", "getPrePitch", "()F", "setPrePitch", "(F)V", "preYaw", "getPreYaw", "setPreYaw", "serverPitch", "getServerPitch", "setServerPitch", "serverYaw", "getServerYaw", "setServerYaw", "Companion", "onyx2"})
/*    */ public final class RotationFaker
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/utilities/game/rotationfake/RotationFaker$Companion;", "", "<init>", "()V", "Lnet/integr/utilities/game/rotationfake/RotationFaker;", "INSTANCE", "Lnet/integr/utilities/game/rotationfake/RotationFaker;", "getINSTANCE", "()Lnet/integr/utilities/game/rotationfake/RotationFaker;", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     @NotNull
/*    */     public final RotationFaker getINSTANCE() {
/* 34 */       return RotationFaker.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); private float serverYaw; private float serverPitch; @NotNull private static final RotationFaker INSTANCE = new RotationFaker(); private float preYaw; private float prePitch; private boolean isFake;
/*    */   
/*    */   public final float getServerYaw() {
/* 37 */     return this.serverYaw; } public final void setServerYaw(float <set-?>) { this.serverYaw = <set-?>; }
/* 38 */   public final float getServerPitch() { return this.serverPitch; } public final void setServerPitch(float <set-?>) { this.serverPitch = <set-?>; }
/*    */   
/* 40 */   public final float getPreYaw() { return this.preYaw; } public final void setPreYaw(float <set-?>) { this.preYaw = <set-?>; }
/* 41 */   public final float getPrePitch() { return this.prePitch; } public final void setPrePitch(float <set-?>) { this.prePitch = <set-?>; }
/*    */   
/* 43 */   public final boolean isFake() { return this.isFake; } public final void setFake(boolean <set-?>) { this.isFake = <set-?>; }
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PostTickEvent e) {
/* 47 */     Intrinsics.checkNotNullParameter(e, "e"); this.isFake = false;
/*    */   }
/*    */   
/*    */   @EventListen(prio = Priority.LAST)
/*    */   public final void onPacket(@NotNull SendPacketEvent e) {
/* 52 */     Intrinsics.checkNotNullParameter(e, "e"); if (!RotationLocker.Companion.isLocked()) {
/*    */       return;
/*    */     }
/*    */     
/* 56 */     if ((Onyx.Companion.getMC()).field_1724 != null && 
/* 57 */       e.packet instanceof net.minecraft.class_2886) {
/* 58 */       Intrinsics.checkNotNull(e.packet, "null cannot be cast to non-null type net.integr.mixin.PlayerInteractItemC2SPacketAccessor"); PlayerInteractItemC2SPacketAccessor p = (PlayerInteractItemC2SPacketAccessor)e.packet;
/*    */       
/* 60 */       p.setYaw(this.serverYaw);
/* 61 */       p.setPitch(this.serverPitch);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public final void face(@NotNull class_243 vec) {
/* 67 */     Intrinsics.checkNotNullParameter(vec, "vec"); this.isFake = true;
/* 68 */     Pair needed = RotationUtils.Companion.getNeededRotations(vec);
/*    */     
/* 70 */     if (((this.serverPitch == ((Number)needed.getSecond()).floatValue())) && ((this.serverYaw == ((Number)needed.getFirst()).floatValue())))
/*    */       return; 
/* 72 */     this.serverYaw = ((Number)needed.getFirst()).floatValue();
/* 73 */     this.serverPitch = ((Number)needed.getSecond()).floatValue();
/*    */   }
/*    */   
/*    */   public final void look(float yaw, float pitch) {
/* 77 */     this.isFake = true;
/* 78 */     if (((this.serverPitch == pitch)) && ((this.serverYaw == yaw)))
/*    */       return; 
/* 80 */     this.serverYaw = yaw;
/* 81 */     this.serverPitch = pitch;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\rotationfake\RotationFaker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */