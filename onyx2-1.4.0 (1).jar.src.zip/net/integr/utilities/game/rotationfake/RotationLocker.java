/*    */ package net.integr.utilities.game.rotationfake;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/utilities/game/rotationfake/RotationLocker;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class RotationLocker
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   private static boolean rotationLocked;
/*    */   private static float fakeYaw;
/*    */   private static float fakePitch;
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\002\n\002\b\002\n\002\020\007\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006J\r\020\b\032\0020\007¢\006\004\b\b\020\003J\r\020\t\032\0020\007¢\006\004\b\t\020\003R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\020\f\032\004\b\r\020\016\"\004\b\017\020\020R\"\020\021\032\0020\n8\006@\006X\016¢\006\022\n\004\b\021\020\f\032\004\b\022\020\016\"\004\b\023\020\020R\026\020\024\032\0020\0048\002@\002X\016¢\006\006\n\004\b\024\020\025¨\006\026"}, d2 = {"Lnet/integr/utilities/game/rotationfake/RotationLocker$Companion;", "", "<init>", "()V", "", "isLocked", "()Z", "", "lock", "unLock", "", "fakePitch", "F", "getFakePitch", "()F", "setFakePitch", "(F)V", "fakeYaw", "getFakeYaw", "setFakeYaw", "rotationLocked", "Z", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final float getFakeYaw() {
/* 25 */       return RotationLocker.fakeYaw; } public final void setFakeYaw(float <set-?>) { RotationLocker.fakeYaw = <set-?>; }
/* 26 */     public final float getFakePitch() { return RotationLocker.fakePitch; } public final void setFakePitch(float <set-?>) { RotationLocker.fakePitch = <set-?>; }
/*    */     
/*    */     public final void lock() {
/* 29 */       RotationLocker.rotationLocked = true;
/*    */     }
/*    */     
/*    */     public final void unLock() {
/* 33 */       RotationLocker.rotationLocked = false;
/*    */     }
/*    */     public final boolean isLocked() {
/* 36 */       return RotationLocker.rotationLocked;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\rotationfake\RotationLocker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */