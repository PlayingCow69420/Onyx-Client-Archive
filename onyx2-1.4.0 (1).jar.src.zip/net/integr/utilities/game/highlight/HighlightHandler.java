/*     */ package net.integr.utilities.game.highlight;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import net.integr.Variables;
/*     */ import net.integr.event.RenderWorldEvent;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\004\030\000 \r2\0020\001:\001\rB\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\t\020\bR\030\020\013\032\004\030\0010\n8\002@\002X\016¢\006\006\n\004\b\013\020\f¨\006\016"}, d2 = {"Lnet/integr/utilities/game/highlight/HighlightHandler;", "", "<init>", "()V", "Lnet/integr/event/RenderWorldEvent;", "event", "", "onRender", "(Lnet/integr/event/RenderWorldEvent;)V", "renderCrystal", "Lnet/minecraft/class_243;", "oldCrystal", "Lnet/minecraft/class_243;", "Companion", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nHighlightHandler.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HighlightHandler.kt\nnet/integr/utilities/game/highlight/HighlightHandler\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,82:1\n1655#2,8:83\n1855#2,2:91\n1655#2,8:93\n1855#2,2:101\n1655#2,8:103\n1855#2,2:111\n1655#2,8:113\n1855#2,2:121\n766#2:123\n857#2,2:124\n766#2:126\n857#2,2:127\n766#2:129\n857#2,2:130\n766#2:132\n857#2,2:133\n*S KotlinDebug\n*F\n+ 1 HighlightHandler.kt\nnet/integr/utilities/game/highlight/HighlightHandler\n*L\n36#1:83,8\n40#1:91,2\n42#1:93,8\n46#1:101,2\n48#1:103,8\n53#1:111,2\n55#1:113,8\n60#1:121,2\n64#1:123\n64#1:124,2\n65#1:126\n65#1:127,2\n66#1:129\n66#1:130,2\n67#1:132\n67#1:133,2\n*E\n"})
/*     */ public final class HighlightHandler {
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/utilities/game/highlight/HighlightHandler$Companion;", "", "<init>", "()V", "Lnet/integr/utilities/game/highlight/HighlightHandler;", "INSTANCE", "Lnet/integr/utilities/game/highlight/HighlightHandler;", "getINSTANCE", "()Lnet/integr/utilities/game/highlight/HighlightHandler;", "onyx2"})
/*     */   public static final class Companion { private Companion() {}
/*     */     
/*     */     @NotNull
/*  29 */     public final HighlightHandler getINSTANCE() { return HighlightHandler.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @Nullable private class_243 oldCrystal; @NotNull private static final HighlightHandler INSTANCE = new HighlightHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onRender(@NotNull RenderWorldEvent event) {
/*  36 */     Intrinsics.checkNotNullParameter(event, "event"); Iterable<Pair<class_243, AtomicInteger>> iterable8 = Highlighter.Companion.getBlocks(); int i1 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     HashSet set$iv = new HashSet();
/*  84 */     ArrayList list$iv = new ArrayList();
/*  85 */     for (Object<class_243, AtomicInteger> e$iv : iterable8) {
/*  86 */       Pair it = (Pair)e$iv; int $i$a$-distinctBy-HighlightHandler$onRender$1 = 0; Object key$iv = it.getFirst();
/*     */     } 
/*     */ 
/*     */     
/*  90 */     for (Pair block : list$iv) { Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.box((class_243)block.getFirst(), event.matrices, Variables.Companion.getGuiColor()); }
/*  91 */      Iterable<Pair<class_243, AtomicInteger>> iterable5 = Highlighter.Companion.getBlocks(); int k = 0; Iterator<Pair<class_243, AtomicInteger>> iterator3 = iterable5.iterator(); if (iterator3.hasNext()) { Object<class_243, AtomicInteger> element$iv = (Object<class_243, AtomicInteger>)iterator3.next(); Pair it = (Pair)element$iv; int $i$a$-forEach-HighlightHandler$onRender$2 = 0; ((AtomicInteger)it.getSecond()).set(((AtomicInteger)it.getSecond()).get() - 1); }
/*     */      Iterable<Pair<class_243, AtomicInteger>> iterable7 = Highlighter.Companion.getBlocksOutlined(); int n = 0;
/*  93 */     set$iv = new HashSet();
/*  94 */     list$iv = new ArrayList();
/*  95 */     for (Object<class_243, AtomicInteger> e$iv : iterable7) {
/*  96 */       Pair it = (Pair)e$iv; int $i$a$-distinctBy-HighlightHandler$onRender$3 = 0; Object key$iv = it.getFirst();
/*     */     } 
/*     */ 
/*     */     
/* 100 */     for (Pair block : list$iv) { Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.outlinedBox((class_243)block.getFirst(), event.matrices, Variables.Companion.getGuiColor()); }
/* 101 */      Iterable<Pair<class_243, AtomicInteger>> iterable4 = Highlighter.Companion.getBlocksOutlined(); int j = 0; Iterator<Pair<class_243, AtomicInteger>> iterator2 = iterable4.iterator(); if (iterator2.hasNext()) { Object<class_243, AtomicInteger> element$iv = (Object<class_243, AtomicInteger>)iterator2.next(); Pair it = (Pair)element$iv; int $i$a$-forEach-HighlightHandler$onRender$4 = 0; ((AtomicInteger)it.getSecond()).set(((AtomicInteger)it.getSecond()).get() - 1); }
/*     */      Iterable<Pair<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterable6 = Highlighter.Companion.getLines(); int m = 0;
/* 103 */     set$iv = new HashSet();
/* 104 */     list$iv = new ArrayList();
/* 105 */     for (Object<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger> e$iv : iterable6) {
/* 106 */       Pair it = (Pair)e$iv; int $i$a$-distinctBy-HighlightHandler$onRender$5 = 0; Object key$iv = it.getFirst();
/*     */     } 
/*     */ 
/*     */     
/* 110 */     for (Pair line : list$iv) { boolean isGuiColor = ((Boolean)((Pair)((Pair)line.getFirst()).getSecond()).getSecond()).booleanValue(); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.line((class_243)((Pair)((Pair)line.getFirst()).getFirst()).getFirst(), (class_243)((Pair)((Pair)line.getFirst()).getFirst()).getSecond(), event.matrices, isGuiColor ? Variables.Companion.getGuiColor() : ((Number)((Pair)((Pair)line.getFirst()).getSecond()).getFirst()).intValue()); }
/* 111 */      Iterable<Pair<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterable3 = Highlighter.Companion.getLines(); int i = 0; Iterator<Pair<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterator1 = iterable3.iterator(); if (iterator1.hasNext()) { Object<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger> element$iv = (Object<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>)iterator1.next(); Pair it = (Pair)element$iv; int $i$a$-forEach-HighlightHandler$onRender$6 = 0; ((AtomicInteger)it.getSecond()).set(((AtomicInteger)it.getSecond()).get() - 1); }
/*     */      Iterable<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> $this$distinctBy$iv = Highlighter.Companion.getBoxes(); int $i$f$distinctBy = 0;
/* 113 */     set$iv = new HashSet();
/* 114 */     list$iv = new ArrayList();
/* 115 */     for (Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger> e$iv : $this$distinctBy$iv) {
/* 116 */       Pair it = (Pair)e$iv; int $i$a$-distinctBy-HighlightHandler$onRender$7 = 0; Object key$iv = ((Pair)it.getFirst()).getFirst();
/*     */     } 
/*     */ 
/*     */     
/* 120 */     for (Pair box : list$iv) { boolean isGuiColor = ((Boolean)((Pair)((Pair)box.getFirst()).getSecond()).getSecond()).booleanValue(); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.box((class_238)((Pair)((Pair)box.getFirst()).getFirst()).getFirst(), (class_243)((Pair)((Pair)box.getFirst()).getFirst()).getSecond(), event.matrices, isGuiColor ? Variables.Companion.getGuiColor() : ((Number)((Pair)((Pair)box.getFirst()).getSecond()).getFirst()).intValue()); }
/* 121 */      Iterable<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> $this$forEach$iv = Highlighter.Companion.getBoxes(); int $i$f$forEach = 0; Iterator<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger> element$iv = (Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>)iterator.next(); Pair it = (Pair)element$iv; int $i$a$-forEach-HighlightHandler$onRender$8 = 0; ((AtomicInteger)it.getSecond()).set(((AtomicInteger)it.getSecond()).get() - 1); }
/*     */      renderCrystal(event); $this$forEach$iv = (Iterable)Highlighter.Companion.getBlocks(); Highlighter.Companion companion = Highlighter.Companion; int $i$f$filter = 0;
/* 123 */     Iterable<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterable11 = $this$forEach$iv; Collection<Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> collection2 = new ArrayList(); int $i$f$filterTo = 0;
/* 124 */     for (Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger> element$iv$iv : iterable11) { Pair it = (Pair)element$iv$iv; int $i$a$-filter-HighlightHandler$onRender$9 = 0; if ((((AtomicInteger)it.getSecond()).get() > 0)) collection2.add(element$iv$iv);  }
/* 125 */      companion.setBlocks((List)collection2); Iterable<Pair<class_243, AtomicInteger>> iterable2 = Highlighter.Companion.getBlocksOutlined(); companion = Highlighter.Companion; $i$f$filter = 0;
/* 126 */     Iterable<Pair<class_243, AtomicInteger>> iterable10 = iterable2; Collection<Object<class_243, AtomicInteger>> collection1 = new ArrayList(); $i$f$filterTo = 0;
/* 127 */     for (Object<class_243, AtomicInteger> element$iv$iv : iterable10) { Pair it = (Pair)element$iv$iv; int $i$a$-filter-HighlightHandler$onRender$10 = 0; if ((((AtomicInteger)it.getSecond()).get() > 0)) collection1.add(element$iv$iv);  }
/* 128 */      companion.setBlocksOutlined((List)collection1); Iterable<Pair<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterable1 = Highlighter.Companion.getLines(); companion = Highlighter.Companion; $i$f$filter = 0;
/* 129 */     Iterable<Pair<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> iterable9 = iterable1; Collection<Object<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> collection = new ArrayList(); $i$f$filterTo = 0;
/* 130 */     for (Object<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger> element$iv$iv : iterable9) { Pair it = (Pair)element$iv$iv; int $i$a$-filter-HighlightHandler$onRender$11 = 0; if ((((AtomicInteger)it.getSecond()).get() > 0)) collection.add(element$iv$iv);  }
/* 131 */      companion.setLines((List)collection); Iterable<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> $this$filter$iv = Highlighter.Companion.getBoxes(); companion = Highlighter.Companion; $i$f$filter = 0;
/* 132 */     Iterable<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> $this$filterTo$iv$iv = $this$filter$iv; Collection<Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> destination$iv$iv = new ArrayList(); $i$f$filterTo = 0;
/* 133 */     for (Object<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger> element$iv$iv : $this$filterTo$iv$iv) { Pair it = (Pair)element$iv$iv; int $i$a$-filter-HighlightHandler$onRender$12 = 0; if ((((AtomicInteger)it.getSecond()).get() > 0)) destination$iv$iv.add(element$iv$iv);  }
/* 134 */      companion.setBoxes((List)destination$iv$iv);
/*     */   }
/*     */   
/*     */   private final void renderCrystal(RenderWorldEvent event) {
/*     */     class_243 crystal = Highlighter.Companion.getCrystal();
/*     */     if (crystal != null)
/*     */       if (this.oldCrystal != null) {
/*     */         Intrinsics.checkNotNull(this.oldCrystal);
/*     */         class_243 newCrystal = CoordinateUtils.Companion.lerpPositionBetween(this.oldCrystal, crystal, 0.5F);
/*     */         this.oldCrystal = newCrystal;
/*     */         Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices");
/*     */         RenderingEngine.ThreeDimensional.Companion.box(newCrystal, event.matrices, Variables.Companion.getGuiColor());
/*     */       } else {
/*     */         this.oldCrystal = crystal;
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\highlight\HighlightHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */