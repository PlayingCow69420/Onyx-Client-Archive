/*    */ package net.integr.utilities.game.highlight;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Pair;
/*    */ import kotlin.TuplesKt;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Variables;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_238;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\n\n\002\020 \n\002\030\002\n\002\030\002\n\002\b\t\n\002\020\013\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003J\037\020\n\032\0020\0042\006\020\007\032\0020\0062\b\b\002\020\t\032\0020\b¢\006\004\b\n\020\013J\037\020\n\032\0020\0042\006\020\007\032\0020\f2\b\b\002\020\t\032\0020\b¢\006\004\b\n\020\rJ\037\020\016\032\0020\0042\006\020\007\032\0020\f2\b\b\002\020\t\032\0020\b¢\006\004\b\016\020\rJ1\020\022\032\0020\0042\006\020\020\032\0020\0172\006\020\007\032\0020\f2\b\b\002\020\021\032\0020\b2\b\b\002\020\t\032\0020\b¢\006\004\b\022\020\023J\025\020\024\032\0020\0042\006\020\007\032\0020\f¢\006\004\b\024\020\025J1\020\030\032\0020\0042\006\020\026\032\0020\f2\006\020\027\032\0020\f2\b\b\002\020\021\032\0020\b2\b\b\002\020\t\032\0020\b¢\006\004\b\030\020\031R4\020\035\032\024\022\020\022\016\022\004\022\0020\f\022\004\022\0020\0340\0330\0328\006@\006X\016¢\006\022\n\004\b\035\020\036\032\004\b\037\020 \"\004\b!\020\"R4\020#\032\024\022\020\022\016\022\004\022\0020\f\022\004\022\0020\0340\0330\0328\006@\006X\016¢\006\022\n\004\b#\020\036\032\004\b$\020 \"\004\b%\020\"RX\020'\0328\0224\0222\022(\022&\022\020\022\016\022\004\022\0020\017\022\004\022\0020\f0\033\022\020\022\016\022\004\022\0020\b\022\004\022\0020&0\0330\033\022\004\022\0020\0340\0330\0328\006@\006X\016¢\006\022\n\004\b'\020\036\032\004\b(\020 \"\004\b)\020\"R$\020*\032\004\030\0010\f8\006@\006X\016¢\006\022\n\004\b*\020+\032\004\b,\020-\"\004\b.\020\025RX\020/\0328\0224\0222\022(\022&\022\020\022\016\022\004\022\0020\f\022\004\022\0020\f0\033\022\020\022\016\022\004\022\0020\b\022\004\022\0020&0\0330\033\022\004\022\0020\0340\0330\0328\006@\006X\016¢\006\022\n\004\b/\020\036\032\004\b0\020 \"\004\b1\020\"¨\0062"}, d2 = {"Lnet/integr/utilities/game/highlight/Highlighter$Companion;", "", "<init>", "()V", "", "clearCrystal", "Lnet/minecraft/class_2338;", "pos", "", "time", "renderBlock", "(Lnet/minecraft/class_2338;I)V", "Lnet/minecraft/class_243;", "(Lnet/minecraft/class_243;I)V", "renderBlockOutlined", "Lnet/minecraft/class_238;", "box", "color", "renderBox", "(Lnet/minecraft/class_238;Lnet/minecraft/class_243;II)V", "renderCrystal", "(Lnet/minecraft/class_243;)V", "pos1", "pos2", "renderLine", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;II)V", "", "Lkotlin/Pair;", "Ljava/util/concurrent/atomic/AtomicInteger;", "blocks", "Ljava/util/List;", "getBlocks", "()Ljava/util/List;", "setBlocks", "(Ljava/util/List;)V", "blocksOutlined", "getBlocksOutlined", "setBlocksOutlined", "", "boxes", "getBoxes", "setBoxes", "crystal", "Lnet/minecraft/class_243;", "getCrystal", "()Lnet/minecraft/class_243;", "setCrystal", "lines", "getLines", "setLines", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final List<Pair<class_243, AtomicInteger>> getBlocks() {
/* 29 */     return Highlighter.access$getBlocks$cp(); } public final void setBlocks(@NotNull List <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); Highlighter.access$setBlocks$cp(<set-?>); } @NotNull
/* 30 */   public final List<Pair<Pair<Pair<class_238, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> getBoxes() { return Highlighter.access$getBoxes$cp(); } public final void setBoxes(@NotNull List <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); Highlighter.access$setBoxes$cp(<set-?>); } @NotNull
/* 31 */   public final List<Pair<class_243, AtomicInteger>> getBlocksOutlined() { return Highlighter.access$getBlocksOutlined$cp(); } public final void setBlocksOutlined(@NotNull List <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); Highlighter.access$setBlocksOutlined$cp(<set-?>); }
/*    */   @Nullable
/* 33 */   public final class_243 getCrystal() { return Highlighter.access$getCrystal$cp(); } public final void setCrystal(@Nullable class_243 <set-?>) { Highlighter.access$setCrystal$cp(<set-?>); }
/*    */   @NotNull
/* 35 */   public final List<Pair<Pair<Pair<class_243, class_243>, Pair<Integer, Boolean>>, AtomicInteger>> getLines() { return Highlighter.access$getLines$cp(); } public final void setLines(@NotNull List <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); Highlighter.access$setLines$cp(<set-?>); }
/*    */   
/*    */   public final void renderLine(@NotNull class_243 pos1, @NotNull class_243 pos2, int color, int time) {
/* 38 */     Intrinsics.checkNotNullParameter(pos1, "pos1"); Intrinsics.checkNotNullParameter(pos2, "pos2"); setLines(CollectionsKt.plus(getLines(), TuplesKt.to(TuplesKt.to(TuplesKt.to(pos1, pos2), TuplesKt.to(Integer.valueOf(color), Boolean.valueOf((color == Variables.Companion.getGuiColor())))), new AtomicInteger(time))));
/*    */   }
/*    */   
/*    */   public final void renderCrystal(@NotNull class_243 pos) {
/* 42 */     Intrinsics.checkNotNullParameter(pos, "pos"); setCrystal(pos);
/*    */   }
/*    */   
/*    */   public final void clearCrystal() {
/* 46 */     setCrystal(null);
/*    */   }
/*    */   
/*    */   public final void renderBlock(@NotNull class_243 pos, int time) {
/* 50 */     Intrinsics.checkNotNullParameter(pos, "pos"); setBlocks(CollectionsKt.plus(getBlocks(), TuplesKt.to(pos, new AtomicInteger(time))));
/*    */   }
/*    */   
/*    */   public final void renderBlockOutlined(@NotNull class_243 pos, int time) {
/* 54 */     Intrinsics.checkNotNullParameter(pos, "pos"); setBlocksOutlined(CollectionsKt.plus(getBlocksOutlined(), TuplesKt.to(pos, new AtomicInteger(time))));
/*    */   }
/*    */   
/*    */   public final void renderBlock(@NotNull class_2338 pos, int time) {
/* 58 */     Intrinsics.checkNotNullParameter(pos, "pos"); setBlocks(CollectionsKt.plus(getBlocks(), TuplesKt.to(pos.method_46558().method_1031(0.0D, -0.5D, 0.0D), new AtomicInteger(time))));
/*    */   }
/*    */   
/*    */   public final void renderBox(@NotNull class_238 box, @NotNull class_243 pos, int color, int time) {
/* 62 */     Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(pos, "pos"); setBoxes(CollectionsKt.plus(getBoxes(), TuplesKt.to(TuplesKt.to(TuplesKt.to(box, pos), TuplesKt.to(Integer.valueOf(color), Boolean.valueOf((color == Variables.Companion.getGuiColor())))), new AtomicInteger(time))));
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\highlight\Highlighter$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */