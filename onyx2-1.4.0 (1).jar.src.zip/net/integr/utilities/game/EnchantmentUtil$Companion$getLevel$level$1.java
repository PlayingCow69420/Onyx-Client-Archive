/*    */ package net.integr.utilities.game;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1887;
/*    */ import net.minecraft.class_1890;
/*    */ import net.minecraft.class_6880;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\020\007\032\n \002*\004\030\0010\0040\0042\032\020\003\032\026\022\004\022\0020\001 \002*\n\022\004\022\0020\001\030\0010\0000\000H\n¢\006\004\b\005\020\006"}, d2 = {"Lnet/minecraft/class_6880$class_6883;", "Lnet/minecraft/class_1887;", "kotlin.jvm.PlatformType", "entry", "", "invoke", "(Lnet/minecraft/class_6880$class_6883;)Ljava/lang/Integer;", "<anonymous>"})
/*    */ final class EnchantmentUtil$Companion$getLevel$level$1
/*    */   extends Lambda
/*    */   implements Function1<class_6880.class_6883<class_1887>, Integer>
/*    */ {
/*    */   EnchantmentUtil$Companion$getLevel$level$1(class_1799 $itemStack) {
/*    */     super(1);
/*    */   }
/*    */   
/*    */   public final Integer invoke(class_6880.class_6883 entry) {
/* 38 */     return Integer.valueOf(class_1890.method_8225((class_6880)entry, this.$itemStack));
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\EnchantmentUtil$Companion$getLevel$level$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */