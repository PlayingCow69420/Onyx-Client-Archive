/*    */ package net.integr.utilities.game.command;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/utilities/game/command/CommandUtils$Companion;", "", "<init>", "()V", "", "str", "", "sendCommand", "(Ljava/lang/String;)V", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   public final void sendCommand(@NotNull String str) {
/* 24 */     Intrinsics.checkNotNullParameter(str, "str"); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Onyx.Companion.getMC().method_1562().method_45731(str);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\game\command\CommandUtils$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */