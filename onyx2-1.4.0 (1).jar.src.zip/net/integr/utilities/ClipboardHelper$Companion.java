/*    */ package net.integr.utilities;
/*    */ 
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.datatransfer.Clipboard;
/*    */ import java.awt.datatransfer.DataFlavor;
/*    */ import java.awt.datatransfer.StringSelection;
/*    */ import java.awt.datatransfer.Transferable;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\017\020\t\032\004\030\0010\004¢\006\004\b\t\020\n¨\006\013"}, d2 = {"Lnet/integr/utilities/ClipboardHelper$Companion;", "", "<init>", "()V", "", "text", "", "copyToClipboard", "(Ljava/lang/String;)V", "getClipboardString", "()Ljava/lang/String;", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   public final void copyToClipboard(@NotNull String text) {
/* 27 */     Intrinsics.checkNotNullParameter(text, "text"); Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 28 */     StringSelection selection = new StringSelection(text);
/* 29 */     clipboard.setContents(selection, selection);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final String getClipboardString() {
/* 34 */     Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 35 */     Transferable content = clipboard.getContents(null);
/*    */ 
/*    */     
/* 38 */     Intrinsics.checkNotNull(content.getTransferData(DataFlavor.stringFlavor), "null cannot be cast to non-null type kotlin.String"); return content.isDataFlavorSupported(DataFlavor.stringFlavor) ? (String)content.getTransferData(DataFlavor.stringFlavor) : 
/* 39 */       null;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\ClipboardHelper$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */