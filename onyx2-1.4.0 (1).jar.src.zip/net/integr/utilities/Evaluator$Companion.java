/*     */ package net.integr.utilities;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import kotlin.ranges.RangesKt;
/*     */ import kotlin.text.StringsKt;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\013\n\002\b\013\n\002\020\b\n\002\b\005\n\002\020\f\n\002\b\016\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ\027\020\t\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\t\020\nJ\027\020\013\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\013\020\nJ\027\020\f\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\f\020\nJ\027\020\r\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\r\020\nJ\027\020\016\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\016\020\nJ\027\020\017\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\017\020\nJ\027\020\020\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\020\020\nJ\025\020\021\032\0020\0042\006\020\005\032\0020\004¢\006\004\b\021\020\nJ\037\020\024\032\0020\0222\006\020\005\032\0020\0042\006\020\023\032\0020\022H\002¢\006\004\b\024\020\025J\037\020\026\032\0020\0042\006\020\023\032\0020\0222\006\020\005\032\0020\004H\002¢\006\004\b\026\020\027J\027\020\032\032\0020\0062\006\020\031\032\0020\030H\002¢\006\004\b\032\020\033J\027\020\034\032\0020\0062\006\020\031\032\0020\030H\002¢\006\004\b\034\020\033J\027\020\035\032\0020\0062\006\020\031\032\0020\030H\002¢\006\004\b\035\020\033J\027\020\036\032\0020\0062\006\020\031\032\0020\030H\002¢\006\004\b\036\020\033J\027\020\037\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\037\020\nJ\027\020 \032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b \020\nJ\027\020!\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b!\020\nJ\027\020\"\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\"\020\nJ\027\020#\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b#\020\nJ\027\020$\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b$\020\nJ\027\020%\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b%\020\n¨\006&"}, d2 = {"Lnet/integr/utilities/Evaluator$Companion;", "", "<init>", "()V", "", "form", "", "containsValidMinus", "(Ljava/lang/String;)Z", "evalBrackets", "(Ljava/lang/String;)Ljava/lang/String;", "evalDiv", "evalInternal", "evalMinus", "evalPlus", "evalPow", "evalTimes", "evaluate", "", "index", "findClosingBracket", "(Ljava/lang/String;I)I", "getOperationAround", "(ILjava/lang/String;)Ljava/lang/String;", "", "c", "isDot", "(C)Z", "isLine", "isOperation", "isPow", "replaceConstants", "replaceDots", "replaceLines", "replaceOneDot", "replaceOneLine", "replaceOnePow", "replacePowers", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nEvaluator.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Evaluator.kt\nnet/integr/utilities/Evaluator$Companion\n+ 2 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,246:1\n1099#2,3:247\n1099#2,3:250\n*S KotlinDebug\n*F\n+ 1 Evaluator.kt\nnet/integr/utilities/Evaluator$Companion\n*L\n39#1:247,3\n40#1:250,3\n*E\n"})
/*     */ public final class Companion
/*     */ {
/*     */   private Companion() {}
/*     */   
/*     */   @NotNull
/*     */   public final String evaluate(@NotNull String form) {
/*  25 */     Intrinsics.checkNotNullParameter(form, "form"); String copy = replaceConstants(form);
/*  26 */     while (StringsKt.contains$default(copy, '(', false, 2, null)) {
/*  27 */       String innerBracketContent = evalBrackets(copy);
/*  28 */       String calculatedBracketContent = evalInternal(innerBracketContent);
/*  29 */       String toReplace = "(" + innerBracketContent + ")";
/*     */       
/*  31 */       copy = StringsKt.replace$default(copy, toReplace, calculatedBracketContent, false, 4, null);
/*     */     } 
/*     */     
/*  34 */     String evaluatedContent = evalInternal(copy);
/*  35 */     return evaluatedContent;
/*     */   }
/*     */   
/*     */   private final String evalBrackets(String form) {
/*  39 */     CharSequence $this$count$iv = form; int $i$f$count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     int count$iv = 0; byte b;
/* 248 */     for (b = 0; b < $this$count$iv.length(); ) { char element$iv = $this$count$iv.charAt(b), c = element$iv; int $i$a$-count-Evaluator$Companion$evalBrackets$count$1 = 0; if ((c == '(')) count$iv++;  b++; }
/* 249 */      int count = count$iv; $this$count$iv = form; int i = count; $i$f$count = 0;
/* 250 */     count$iv = 0;
/* 251 */     for (b = 0; b < $this$count$iv.length(); ) { char element$iv = $this$count$iv.charAt(b), c = element$iv; int $i$a$-count-Evaluator$Companion$evalBrackets$1 = 0; if ((c == ')')) count$iv++;  b++; }
/* 252 */      int j = count$iv; if (i == j) {
/*     */       if (count > 0) {
/*     */         int lIndex = StringsKt.lastIndexOf$default(form, '(', 0, false, 6, null);
/*     */         return StringsKt.substring(form, RangesKt.until(lIndex + 1, findClosingBracket(form, lIndex)));
/*     */       } 
/*     */       return form;
/*     */     } 
/*     */     throw new IllegalArgumentException("Bracket error!");
/*     */   }
/*     */   
/*     */   private final int findClosingBracket(String form, int index) {
/*     */     int i = index, j = StringsKt.getLastIndex(form);
/*     */     if (i <= j)
/*     */       while (true) {
/*     */         if (form.charAt(i) == ')')
/*     */           return i; 
/*     */         if (i != j) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     throw new IllegalArgumentException("Bracket error!");
/*     */   }
/*     */   
/*     */   private final String replaceConstants(String form) {
/*     */     String copy = form;
/*     */     copy = StringsKt.replace$default(copy, "e", "2.718281828459045", false, 4, null);
/*     */     copy = StringsKt.replace$default(copy, "pi", "3.141592653589793", false, 4, null);
/*     */     return copy;
/*     */   }
/*     */   
/*     */   private final String evalTimes(String form) {
/*     */     int index = StringsKt.indexOf$default(form, '*', 0, false, 6, null);
/*     */     String first = StringsKt.substring(form, RangesKt.until(0, index));
/*     */     String last = StringsKt.substring(form, RangesKt.until(index + 1, form.length()));
/*     */     return String.valueOf(Double.parseDouble(first) * Double.parseDouble(last));
/*     */   }
/*     */   
/*     */   private final String evalDiv(String form) {
/*     */     int index = StringsKt.indexOf$default(form, '/', 0, false, 6, null);
/*     */     String first = StringsKt.substring(form, RangesKt.until(0, index));
/*     */     String last = StringsKt.substring(form, RangesKt.until(index + 1, form.length()));
/*     */     return String.valueOf(Double.parseDouble(first) / Double.parseDouble(last));
/*     */   }
/*     */   
/*     */   private final String evalPlus(String form) {
/*     */     int index = StringsKt.indexOf$default(form, '+', 0, false, 6, null);
/*     */     String first = StringsKt.substring(form, RangesKt.until(0, index));
/*     */     String last = StringsKt.substring(form, RangesKt.until(index + 1, form.length()));
/*     */     return String.valueOf(Double.parseDouble(first) + Double.parseDouble(last));
/*     */   }
/*     */   
/*     */   private final String evalMinus(String form) {
/*     */     int index = StringsKt.indexOf$default(form, '-', 0, false, 6, null);
/*     */     String first = StringsKt.substring(form, RangesKt.until(0, index));
/*     */     String last = StringsKt.substring(form, RangesKt.until(index + 1, form.length()));
/*     */     return String.valueOf(Double.parseDouble(first) - Double.parseDouble(last));
/*     */   }
/*     */   
/*     */   private final String evalPow(String form) {
/*     */     int index = StringsKt.indexOf$default(form, '^', 0, false, 6, null);
/*     */     String first = StringsKt.substring(form, RangesKt.until(0, index));
/*     */     String last = StringsKt.substring(form, RangesKt.until(index + 1, form.length()));
/*     */     return String.valueOf(Math.pow(Double.parseDouble(first), Double.parseDouble(last)));
/*     */   }
/*     */   
/*     */   private final boolean isDot(char c) {
/*     */     return (c == '/' || c == '*');
/*     */   }
/*     */   
/*     */   private final boolean isLine(char c) {
/*     */     return (c == '-' || c == '+');
/*     */   }
/*     */   
/*     */   private final boolean isPow(char c) {
/*     */     return (c == '^');
/*     */   }
/*     */   
/*     */   private final boolean isOperation(char c) {
/*     */     return (isDot(c) || isLine(c) || isPow(c));
/*     */   }
/*     */   
/*     */   private final boolean containsValidMinus(String form) {
/*     */     if (!StringsKt.contains$default(form, '-', false, 2, null))
/*     */       return false; 
/*     */     int i = 0, j = StringsKt.getLastIndex(form);
/*     */     if (i <= j)
/*     */       while (true) {
/*     */         if (form.charAt(i) == '-' && i != 0)
/*     */           return true; 
/*     */         if (i != j) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     return false;
/*     */   }
/*     */   
/*     */   private final String evalInternal(String form) {
/*     */     String p1 = replacePowers(form);
/*     */     String p2 = replaceDots(p1);
/*     */     return replaceLines(p2);
/*     */   }
/*     */   
/*     */   private final String replaceDots(String form) {
/*     */     String copy = form;
/*     */     while (StringsKt.contains$default(copy, '*', false, 2, null) || StringsKt.contains$default(copy, '/', false, 2, null))
/*     */       copy = replaceOneDot(copy); 
/*     */     return copy;
/*     */   }
/*     */   
/*     */   private final String replaceLines(String form) {
/*     */     String copy = form;
/*     */     while (StringsKt.contains$default(copy, '+', false, 2, null) || containsValidMinus(copy))
/*     */       copy = replaceOneLine(copy); 
/*     */     return copy;
/*     */   }
/*     */   
/*     */   private final String replacePowers(String form) {
/*     */     String copy = form;
/*     */     while (StringsKt.contains$default(copy, '^', false, 2, null))
/*     */       copy = replaceOnePow(copy); 
/*     */     return copy;
/*     */   }
/*     */   
/*     */   private final String replaceOneDot(String form) {
/*     */     int i = 0, j = StringsKt.getLastIndex(form);
/*     */     if (i <= j)
/*     */       while (true) {
/*     */         if (isDot(form.charAt(i))) {
/*     */           String op = getOperationAround(i, form);
/*     */           if (form.charAt(i) == '*') {
/*     */             String str = evalTimes(op);
/*     */             return StringsKt.replace$default(form, op, str, false, 4, null);
/*     */           } 
/*     */           String res = evalDiv(op);
/*     */           return StringsKt.replace$default(form, op, res, false, 4, null);
/*     */         } 
/*     */         if (i != j) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     return form;
/*     */   }
/*     */   
/*     */   private final String replaceOneLine(String form) {
/*     */     int i = 0, j = StringsKt.getLastIndex(form);
/*     */     if (i <= j)
/*     */       while (true) {
/*     */         if (isLine(form.charAt(i))) {
/*     */           String op = getOperationAround(i, form);
/*     */           if (form.charAt(i) == '+') {
/*     */             String res = evalPlus(op);
/*     */             return StringsKt.replace$default(form, op, res, false, 4, null);
/*     */           } 
/*     */           if (i != 0) {
/*     */             String res = evalMinus(op);
/*     */             return StringsKt.replace$default(form, op, res, false, 4, null);
/*     */           } 
/*     */         } 
/*     */         if (i != j) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     return form;
/*     */   }
/*     */   
/*     */   private final String replaceOnePow(String form) {
/*     */     int i = 0, j = StringsKt.getLastIndex(form);
/*     */     if (i <= j)
/*     */       while (true) {
/*     */         if (isPow(form.charAt(i))) {
/*     */           String op = getOperationAround(i, form);
/*     */           String res = evalPow(op);
/*     */           return StringsKt.replace$default(form, op, res, false, 4, null);
/*     */         } 
/*     */         if (i != j) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     return form;
/*     */   }
/*     */   
/*     */   private final String getOperationAround(int index, String form) {
/*     */     int start = index;
/*     */     int end = index;
/*     */     boolean seenNumberEnd = false;
/*     */     int i;
/*     */     for (i = index - 1; -1 < i; i--) {
/*     */       if (isOperation(form.charAt(i))) {
/*     */         start = i + 1;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     if (start == index)
/*     */       start = 0; 
/*     */     i = index + 1;
/*     */     int j = StringsKt.getLastIndex(form);
/*     */     if (i <= j)
/*     */       while (true) {
/*     */         if (Character.isDigit(form.charAt(i)))
/*     */           seenNumberEnd = true; 
/*     */         if (isOperation(form.charAt(i)) && seenNumberEnd) {
/*     */           end = i;
/*     */           break;
/*     */         } 
/*     */         if (i != j) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     if (end == index)
/*     */       end = form.length(); 
/*     */     return StringsKt.substring(form, RangesKt.until(start, end));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integ\\utilities\Evaluator$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */