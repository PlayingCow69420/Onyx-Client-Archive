/*    */ package net.integr.modules.filters;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.enums.EnumEntries;
/*    */ import kotlin.enums.EnumEntriesKt;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\b\b\002\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006j\002\b\007j\002\b\b¨\006\t"}, d2 = {"Lnet/integr/modules/filters/Filter;", "", "<init>", "(Ljava/lang/String;I)V", "Render", "Combat", "Move", "Util", "Exploit", "onyx2"})
/*    */ public enum Filter
/*    */ {
/* 20 */   Render,
/* 21 */   Combat,
/* 22 */   Move,
/* 23 */   Util,
/* 24 */   Exploit;
/*    */   
/*    */   @NotNull
/*    */   public static EnumEntries<Filter> getEntries() {
/*    */     return $ENTRIES;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\filters\Filter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */