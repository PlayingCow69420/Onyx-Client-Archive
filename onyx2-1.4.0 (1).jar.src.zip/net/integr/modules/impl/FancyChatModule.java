/*     */ package net.integr.modules.impl;
/*     */ import java.util.List;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.text.StringsKt;
/*     */ import net.integr.event.SendChatMessageEvent;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020 \n\002\b\r\n\002\020\021\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\006\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\007¢\006\004\b\013\020\fJ%\020\017\032\0020\0042\006\020\005\032\0020\0042\f\020\016\032\b\022\004\022\0020\0040\rH\002¢\006\004\b\017\020\020J\027\020\021\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\021\020\007J\027\020\022\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\022\020\007J\027\020\023\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\023\020\007R\024\020\024\032\0020\0048\002XD¢\006\006\n\004\b\024\020\025R\024\020\026\032\0020\0048\002XD¢\006\006\n\004\b\026\020\025R\024\020\027\032\0020\0048\002XD¢\006\006\n\004\b\027\020\025R\024\020\030\032\0020\0048\002XD¢\006\006\n\004\b\030\020\025R\024\020\031\032\0020\0048\002XD¢\006\006\n\004\b\031\020\025R\024\020\032\032\0020\0048\002XD¢\006\006\n\004\b\032\020\025R\032\020\034\032\b\022\004\022\0020\0040\0338\002X\004¢\006\006\n\004\b\034\020\035R\032\020\036\032\b\022\004\022\0020\0040\0338\002X\004¢\006\006\n\004\b\036\020\035¨\006\037"}, d2 = {"Lnet/integr/modules/impl/FancyChatModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "str", "annoyIfy", "(Ljava/lang/String;)Ljava/lang/String;", "Lnet/integr/event/SendChatMessageEvent;", "event", "", "onChatMessage", "(Lnet/integr/event/SendChatMessageEvent;)V", "", "font", "replaceChars", "(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;", "stutterIfy", "uwuIfy", "vowelIfy", "alphabet", "Ljava/lang/String;", "script1", "script2", "small", "thick", "thin", "", "uwuVariations", "[Ljava/lang/String;", "vowels", "onyx2"})
/*     */ public final class FancyChatModule extends Module {
/*     */   @NotNull
/*     */   private final String alphabet;
/*     */   @NotNull
/*     */   private final String small;
/*     */   @NotNull
/*     */   private final String thin;
/*     */   @NotNull
/*     */   private final String thick;
/*     */   @NotNull
/*     */   private final String script1;
/*     */   @NotNull
/*     */   private final String script2;
/*     */   @NotNull
/*     */   private final String[] vowels;
/*     */   @NotNull
/*     */   private final String[] uwuVariations;
/*     */   
/*     */   public FancyChatModule() {
/*  29 */     super("Fancy Chat", "Modify your chat font", "fancyChat", Filter.Util, false, 16, null);
/*     */     
/*  31 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */     
/*  35 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  36 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(FancyChatModule.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)FancyChatModule.this.getSettings().getById("mode")).getElement());
/*     */           } }
/*     */       );
/*     */     
/*  40 */     this.alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
/*     */     
/*  42 */     this.small = "ᵃ ᵇ ᶜ ᵈ ᵉ ᶠ ᵍ ʰ ⁱ ʲ ᵏ ˡ ᵐ ⁿ ᵒ ᵖ q ʳ ˢ ᵗ ᵘ ᵛ ʷ ˣ ʸ ᶻ ᴬ ᴮ ᶜ ᴰ ᴱ ᶠ ᴳ ᴴ ᴵ ᴶ ᴷ ᴸ ᴹ ᴺ ᴼ ᴾ Q ᴿ ˢ ᵀ ᵁ ⱽ ᵂ ˣ ʸ ᶻ";
/*  43 */     this.thin = "ａ ｂ ｃ ｄ ｅ ｆ ｇ ｈ ｉ ｊ ｋ ｌ ｍ ｎ ｏ ｐ ｑ ｒ ｓ ｔ ｕ ｖ ｗ ｘ ｙ ｚ Ａ Ｂ Ｃ Ｄ Ｅ Ｆ Ｇ Ｈ Ｉ Ｊ Ｋ Ｌ Ｍ Ｎ Ｏ Ｐ Ｑ Ｒ Ｓ Ｔ Ｕ Ｖ Ｗ Ｘ Ｙ Ｚ";
/*  44 */     this.thick = "𝕒 𝕓 𝕔 𝕕 𝕖 𝕗 𝕘 𝕙 𝕚 𝕛 𝕜 𝕝 𝕞 𝕟 𝕠 𝕡 𝕢 𝕣 𝕤 𝕥 𝕦 𝕧 𝕨 𝕩 𝕪 𝕫 𝔸 𝔹 ℂ 𝔻 𝔼 𝔽 𝔾 ℍ 𝕀 𝕁 𝕂 𝕃 𝕄 ℕ 𝕆 ℙ ℚ ℝ 𝕊 𝕋 𝕌 𝕍 𝕎 𝕏 𝕐 ℤ";
/*  45 */     this.script1 = "𝖆 𝖇 𝖈 𝖉 𝖊 𝖋 𝖌 𝖍 𝖎 𝖏 𝖐 𝖑 𝖒 𝖓 𝖔 𝖕 𝖖 𝖗 𝖘 𝖙 𝖚 𝖛 𝖜 𝖝 𝖞 𝖟 𝕬 𝕭 𝕮 𝕯 𝕰 𝕱 𝕲 𝕳 𝕴 𝕵 𝕶 𝕷 𝕸 𝕹 𝕺 𝕻 𝕼 𝕽 𝕾 𝕿 𝖀 𝖁 𝖂 𝖃 𝖄 𝖅";
/*  46 */     this.script2 = "𝒶 𝒷 𝒸 𝒹 𝑒 𝒻 𝑔 𝒽 𝒾 𝒿 𝓀 𝓁 𝓂 𝓃 𝑜 𝓅 𝓆 𝓇 𝓈 𝓉 𝓊 𝓋 𝓌 𝓍 𝓎 𝓏 𝒜 𝐵 𝒞 𝒟 𝐸 𝐹 𝒢 𝐻 𝐼 𝒥 𝒦 𝐿 𝑀 𝒩 𝒪 𝒫 𝒬 𝑅 𝒮 𝒯 𝒰 𝒱 𝒲 𝒳 𝒴 𝒵";
/*     */     
/*  48 */     String[] arrayOfString = new String[5]; arrayOfString[0] = "a"; arrayOfString[1] = "e"; arrayOfString[2] = "i"; arrayOfString[3] = "o"; arrayOfString[4] = "u"; this.vowels = arrayOfString;
/*     */ 
/*     */     
/*  51 */     arrayOfString = new String[13]; arrayOfString[0] = "UwU"; arrayOfString[1] = "nya~"; arrayOfString[2] = ":3"; arrayOfString[3] = "OwO"; arrayOfString[4] = "*blushes*"; arrayOfString[5] = "*stuttering*"; arrayOfString[6] = "rawrrr"; arrayOfString[7] = "( ˶ˆ꒳ˆ˵ )"; arrayOfString[8] = "*moans*"; arrayOfString[9] = "*gets a boner*"; arrayOfString[10] = "Breed me~"; arrayOfString[11] = "Daddy~"; arrayOfString[12] = "*cums cutely*"; this.uwuVariations = arrayOfString;
/*     */   } @EventListen(prio = Priority.LAST)
/*     */   public final void onChatMessage(@NotNull SendChatMessageEvent event) {
/*     */     char[] arrayOfChar;
/*  55 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("mode")); String mode = ((CyclerSetting)getSettings().getById("mode")).getElement();
/*     */     
/*  57 */     String oldMsg = (event.getCallback() != null) ? String.valueOf(event.getCallback()) : event.message;
/*     */     
/*  59 */     String str1 = mode; switch (str1.hashCode()) { case 85459: if (!str1.equals("UwU")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  65 */         Intrinsics.checkNotNull(oldMsg); event.setCallback(uwuIfy(oldMsg)); break;case 79996135: if (!str1.equals("Small")) break;  Intrinsics.checkNotNull(oldMsg); arrayOfChar = new char[1]; arrayOfChar[0] = ' '; event.setCallback(replaceChars(oldMsg, StringsKt.split$default(this.small, arrayOfChar, false, 0, 6, null))); break;case -703799130: if (!str1.equals("Script1")) break;  Intrinsics.checkNotNull(oldMsg); arrayOfChar = new char[1]; arrayOfChar[0] = ' '; event.setCallback(replaceChars(oldMsg, StringsKt.split$default(this.script1, arrayOfChar, false, 0, 6, null))); break;case -703799129: if (!str1.equals("Script2")) break;  Intrinsics.checkNotNull(oldMsg); arrayOfChar = new char[1]; arrayOfChar[0] = ' '; event.setCallback(replaceChars(oldMsg, StringsKt.split$default(this.script2, arrayOfChar, false, 0, 6, null))); break;case 63415147: if (!str1.equals("Annoy"))
/*  66 */           break;  Intrinsics.checkNotNull(oldMsg); event.setCallback(annoyIfy(oldMsg)); break;case 80778109: if (!str1.equals("Thick")) break;  Intrinsics.checkNotNull(oldMsg); arrayOfChar = new char[1]; arrayOfChar[0] = ' '; event.setCallback(replaceChars(oldMsg, StringsKt.split$default(this.thick, arrayOfChar, false, 0, 6, null))); break;case 2605753: if (!str1.equals("Thin")) break;  Intrinsics.checkNotNull(oldMsg); arrayOfChar = new char[1]; arrayOfChar[0] = ' '; event.setCallback(replaceChars(oldMsg, StringsKt.split$default(this.thin, arrayOfChar, false, 0, 6, null))); break;case 2061025: if (!str1.equals("CAPS"))
/*  67 */           break;  Intrinsics.checkNotNull(oldMsg); Intrinsics.checkNotNullExpressionValue(oldMsg.toUpperCase(Locale.ROOT), "toUpperCase(...)"); event.setCallback(oldMsg.toUpperCase(Locale.ROOT));
/*     */         break; }
/*     */   
/*     */   }
/*     */   private final String annoyIfy(String str) {
/*  72 */     String output = ""; byte b;
/*     */     int i;
/*  74 */     for (b = 0, i = str.length(); b < i; ) { char c = str.charAt(b);
/*  75 */       Intrinsics.checkNotNull(String.valueOf(c), "null cannot be cast to non-null type java.lang.String"); Intrinsics.checkNotNullExpressionValue(String.valueOf(c).toLowerCase(Locale.ROOT), "toLowerCase(...)"); Intrinsics.checkNotNull(String.valueOf(c), "null cannot be cast to non-null type java.lang.String"); Intrinsics.checkNotNullExpressionValue(String.valueOf(c).toUpperCase(Locale.ROOT), "toUpperCase(...)"); output = output + output;
/*     */       b++; }
/*     */     
/*  78 */     return output;
/*     */   }
/*     */   
/*     */   private final String uwuIfy(String str) {
/*  82 */     String output = vowelIfy(str);
/*  83 */     output = stutterIfy(output);
/*  84 */     output = output + "...";
/*     */     
/*  86 */     int i = 0, j = Random.Default.nextInt(0, 3); if (i <= j)
/*  87 */       while (true) { output = output + " " + output; if (i != j) {
/*     */           i++; continue;
/*     */         }  break; }
/*  90 */         return output;
/*     */   }
/*     */   
/*     */   private final String stutterIfy(String str) {
/*  94 */     String output = "";
/*     */     
/*  96 */     for (int i = 0, j = str.length(); i < j; i++) {
/*  97 */       if (Random.Default.nextInt(0, 2) == 0 && i - 1 >= 0 && str.charAt(i - 1) == ' ') {
/*  98 */         output = output + output + "- ";
/*     */       }
/*     */       
/* 101 */       output = output + output;
/*     */     } 
/*     */     
/* 104 */     return output;
/*     */   }
/*     */   
/*     */   private final String vowelIfy(String str) {
/* 108 */     String output = ""; byte b;
/*     */     int i;
/* 110 */     for (b = 0, i = str.length(); b < i; ) { char c = str.charAt(b);
/* 111 */       Intrinsics.checkNotNull(String.valueOf(c), "null cannot be cast to non-null type java.lang.String"); Intrinsics.checkNotNullExpressionValue(String.valueOf(c).toLowerCase(Locale.ROOT), "toLowerCase(...)"); if (Random.Default.nextInt(0, 5) == 0 && Character.isLowerCase(c) && ArraysKt.contains((Object[])this.vowels, String.valueOf(c).toLowerCase(Locale.ROOT))) {
/* 112 */         output = output + "w";
/*     */       }
/*     */       
/* 115 */       output = output + output;
/*     */       b++; }
/*     */     
/* 118 */     return output;
/*     */   }
/*     */   
/*     */   private final String replaceChars(String str, List<String> font) {
/* 122 */     String copy = str;
/* 123 */     for (int c = 0, i = this.alphabet.length(); c < i; c++) {
/* 124 */       copy = StringsKt.replace$default(copy, String.valueOf(this.alphabet.charAt(c)), font.get(c), false, 4, null);
/*     */     }
/*     */     
/* 127 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\FancyChatModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */