/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.utilities.game.interaction.MovementUtil;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"})
/*     */ final class InfAuraModule$runOn$1
/*     */   extends Lambda
/*     */   implements Function2<class_243, class_243, Unit>
/*     */ {
/*     */   public static final InfAuraModule$runOn$1 INSTANCE = new InfAuraModule$runOn$1();
/*     */   
/*     */   public final void invoke(@NotNull class_243 paramclass_2431, @NotNull class_243 current) {
/* 107 */     Intrinsics.checkNotNullParameter(paramclass_2431, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(current, "current"); MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null);
/*     */   }
/*     */   
/*     */   InfAuraModule$runOn$1() {
/*     */     super(2);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\InfAuraModule$runOn$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */