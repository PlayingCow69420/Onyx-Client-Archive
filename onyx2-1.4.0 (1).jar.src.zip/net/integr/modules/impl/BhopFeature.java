/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreMoveEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.polar.PolarSystem;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\006\n\002\b\007\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\003J\017\020\006\032\0020\004H\002¢\006\004\b\006\020\003J\017\020\007\032\0020\004H\026¢\006\004\b\007\020\003J\027\020\n\032\0020\0042\006\020\t\032\0020\bH\007¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\002¢\006\004\b\r\020\016J\027\020\021\032\0020\f2\006\020\020\032\0020\017H\002¢\006\004\b\021\020\022R\"\020\024\032\0020\0238\006@\006X\016¢\006\022\n\004\b\024\020\025\032\004\b\026\020\027\"\004\b\030\020\031¨\006\032"}, d2 = {"Lnet/integr/modules/impl/BhopFeature;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "doLowMovement", "doMovement", "onEnable", "Lnet/integr/event/PreMoveEvent;", "event", "onPreMove", "(Lnet/integr/event/PreMoveEvent;)V", "", "shouldJump", "()Z", "Lnet/minecraft/class_2338;", "pos", "shouldJumpAt", "(Lnet/minecraft/class_2338;)Z", "", "startHeight", "D", "getStartHeight", "()D", "setStartHeight", "(D)V", "onyx2"})
/*     */ public final class BhopFeature
/*     */   extends Module
/*     */ {
/*     */   private double startHeight;
/*     */   
/*     */   public BhopFeature() {
/*  32 */     super("Bhop", "Makes you jump around", "bhop", Filter.Move, false, 16, null);
/*     */     
/*  34 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  41 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(BhopFeature.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)BhopFeature.this.getSettings().getById("mode")).getElement());
/*     */           } }
/*     */       );
/*     */   }
/*  45 */   public final double getStartHeight() { return this.startHeight; } public final void setStartHeight(double <set-?>) { this.startHeight = <set-?>; }
/*     */   
/*     */   public void onEnable() {
/*  48 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.startHeight = (Onyx.Companion.getMC()).field_1724.method_23318();
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onPreMove(@NotNull PreMoveEvent event) {
/*  53 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("mode")); String mode = ((CyclerSetting)getSettings().getById("mode")).getElement();
/*  54 */     String str1 = mode;
/*  55 */     if (Intrinsics.areEqual(str1, "Normal")) { doMovement(); }
/*  56 */     else if (Intrinsics.areEqual(str1, "Low")) { doLowMovement(); }
/*     */   
/*     */   }
/*     */   
/*     */   private final void doLowMovement() {
/*  61 */     Intrinsics.checkNotNull(getSettings().getById("speed")); float speed = (float)((SliderSetting)getSettings().getById("speed")).getSetValue();
/*     */     
/*  63 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.field_28627 = 0.04F * speed;
/*     */     
/*  65 */     double velocityX = 0.0D;
/*  66 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double velocityY = ((Onyx.Companion.getMC()).field_1724.method_18798()).field_1351;
/*  67 */     double velocityZ = 0.0D;
/*     */     
/*  69 */     class_243 side = PolarSystem.Companion.getSide();
/*  70 */     class_243 forward = PolarSystem.Companion.getForward();
/*     */     
/*  72 */     boolean shouldJump = false;
/*     */ 
/*     */     
/*  75 */     velocityX += forward.field_1352 * 0.25D * speed;
/*  76 */     velocityZ += forward.field_1350 * 0.25D * speed;
/*     */     
/*  78 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1894.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */ 
/*     */     
/*  82 */     velocityX -= forward.field_1352 * 0.25D * speed;
/*  83 */     velocityZ -= forward.field_1350 * 0.25D * speed;
/*     */     
/*  85 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1881.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */ 
/*     */     
/*  89 */     velocityZ -= side.field_1350 * 0.25D * speed;
/*  90 */     velocityX -= side.field_1352 * 0.25D * speed;
/*     */     
/*  92 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1913.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */ 
/*     */     
/*  96 */     velocityZ += side.field_1350 * 0.25D * speed;
/*  97 */     velocityX += side.field_1352 * 0.25D * speed;
/*     */     
/*  99 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1849.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */     
/* 102 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(velocityX, velocityY, velocityZ);
/*     */     
/* 104 */     if (shouldJump)
/* 105 */     { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull(getSettings().getById("lowHeight")); (Onyx.Companion.getMC()).field_1724.method_18800(velocityX, ((SliderSetting)getSettings().getById("lowHeight")).getSetValue() / 100, velocityZ);
/* 106 */       if (shouldJump()) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6043(); }  }
/* 107 */     else { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(velocityX, velocityY, velocityZ); }
/*     */   
/*     */   }
/*     */   private final void doMovement() {
/* 111 */     Intrinsics.checkNotNull(getSettings().getById("speed")); float speed = (float)((SliderSetting)getSettings().getById("speed")).getSetValue();
/*     */     
/* 113 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.field_28627 = 0.04F * speed;
/*     */     
/* 115 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); float yaw = (Onyx.Companion.getMC()).field_1724.method_36454();
/*     */     
/* 117 */     double velocityX = 0.0D;
/* 118 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double velocityY = ((Onyx.Companion.getMC()).field_1724.method_18798()).field_1351;
/* 119 */     double velocityZ = 0.0D;
/*     */     
/* 121 */     class_243 forward = class_243.method_1030(0.0F, yaw);
/* 122 */     class_243 side = class_243.method_1030(0.0F, yaw + 90);
/*     */     
/* 124 */     boolean shouldJump = false;
/*     */ 
/*     */     
/* 127 */     velocityX += forward.field_1352 * 0.25D * speed;
/* 128 */     velocityZ += forward.field_1350 * 0.25D * speed;
/*     */     
/* 130 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1894.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */ 
/*     */     
/* 134 */     velocityX -= forward.field_1352 * 0.25D * speed;
/* 135 */     velocityZ -= forward.field_1350 * 0.25D * speed;
/*     */     
/* 137 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1881.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */ 
/*     */     
/* 141 */     velocityZ -= side.field_1350 * 0.25D * speed;
/* 142 */     velocityX -= side.field_1352 * 0.25D * speed;
/*     */     
/* 144 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1913.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */ 
/*     */     
/* 148 */     velocityZ += side.field_1350 * 0.25D * speed;
/* 149 */     velocityX += side.field_1352 * 0.25D * speed;
/*     */     
/* 151 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1849.method_1434() && (Onyx.Companion.getMC()).field_1724.method_24828()) shouldJump = true;
/*     */ 
/*     */     
/* 154 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(velocityX, velocityY, velocityZ);
/*     */     
/* 156 */     if (shouldJump) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_6043(); }
/*     */   
/*     */   }
/*     */   private final boolean shouldJump() {
/* 160 */     for (int i = -1; i < 2; i++) {
/* 161 */       for (int j = -1; j < 2; j++) {
/* 162 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_24515().method_10069(i, 0, j), "add(...)"); if (shouldJumpAt((Onyx.Companion.getMC()).field_1724.method_24515().method_10069(i, 0, j))) return true;
/*     */       
/*     */       } 
/*     */     } 
/* 166 */     return false;
/*     */   }
/*     */   private final boolean shouldJumpAt(class_2338 pos) {
/* 169 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return (Onyx.Companion.getMC()).field_1687.method_8320(pos).method_26212((Onyx.Companion.getMC()).field_1687.method_22338(((Onyx.Companion.getMC()).field_1724.method_31476()).field_9181, ((Onyx.Companion.getMC()).field_1724.method_31476()).field_9180), pos);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\BhopFeature.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */