/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_3532;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\006\n\002\b\005\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\006\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\006\020\007J\027\020\b\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\b\020\007J\027\020\t\032\0020\0042\006\020\005\032\0020\004H\002¢\006\004\b\t\020\007J/\020\022\032\0020\0212\006\020\013\032\0020\n2\006\020\r\032\0020\f2\006\020\016\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\022\020\023R\026\020\025\032\0020\0248\002@\002X\016¢\006\006\n\004\b\025\020\026¨\006\027"}, d2 = {"Lnet/integr/modules/impl/Speedometer;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "", "speed", "bps", "(D)D", "kmh", "mph", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "box", "Lnet/integr/rendering/uisystem/Box;", "onyx2"})
/*    */ public final class Speedometer
/*    */   extends UiModule
/*    */ {
/*    */   @NotNull
/*    */   private Box box;
/*    */   
/*    */   public Speedometer() {
/* 31 */     super("Speedometer", "Measures your speed", "speedometer", 20, 110, Filter.Render);
/*    */     
/* 33 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */     
/* 37 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 38 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(Speedometer.this.getSettings().getById("unit")); $this$initHacklist.add(((CyclerSetting)Speedometer.this.getSettings().getById("unit")).getElement());
/*    */           } }
/*    */       );
/*    */     
/* 42 */     this.box = new Box(0, 0, 110, 20, null, false, false, false, 192, null);
/*    */   }
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/* 45 */     Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538(), "getPos(...)"); class_243 playerPosVec = (Onyx.Companion.getMC()).field_1724.method_19538();
/* 46 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double travelledX = playerPosVec.field_1352 - (Onyx.Companion.getMC()).field_1724.field_6014;
/* 47 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double travelledZ = playerPosVec.field_1350 - (Onyx.Companion.getMC()).field_1724.field_5969;
/*    */     
/* 49 */     double currentSpeed = class_3532.method_15355((float)(travelledX * travelledX + travelledZ * travelledZ));
/*    */     
/* 51 */     Intrinsics.checkNotNull(getSettings().getById("unit")); String str = ((CyclerSetting)getSettings().getById("unit")).getElement(); switch (str.hashCode()) { case 97765: if (str.equals("bps"));case 108325: if (str.equals("mph"));case 3293947: if (str.equals("km/h"));default: break; }  this.box.setText("Speed: " + 
/*    */ 
/*    */ 
/*    */         
/* 55 */         "None");
/*    */ 
/*    */     
/* 58 */     this.box.update(originX, originY).method_25394(context, 10, 10, delta);
/*    */   }
/*    */   
/* 61 */   private final double bps(double speed) { return speed / 0.05F; }
/* 62 */   private final double kmh(double speed) { return bps(speed) * 3.6D; } private final double mph(double speed) {
/* 63 */     return bps(speed) * 2.237D;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\Speedometer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */