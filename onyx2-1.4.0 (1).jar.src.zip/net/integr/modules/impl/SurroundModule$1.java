/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 39 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); $this$initSettings.add((Setting)new IntSliderSetting("Delay: ", "Waits after each placement to prevent ghost blocks", "delay", 0, 5, 0, 32, null));
/* 40 */     $this$initSettings.add((Setting)new BooleanSetting("Floor", "Places on the floor", "floor", false, 8, null));
/* 41 */     $this$initSettings.add((Setting)new BooleanSetting("Security on Exit", "Places an extra layer on exiting the hole", "secure", false, 8, null));
/* 42 */     $this$initSettings.add((Setting)new BooleanSetting("Center Before", "Centers the player before placing", "center", false, 8, null));
/* 43 */     $this$initSettings.add((Setting)new BooleanSetting("Keep Protecting", "Keeps protecting you by not stopping placement while in the same spot", "keep", false, 8, null));
/* 44 */     $this$initSettings.add((Setting)new BooleanSetting("Pause Combat Modules", "Pauses modules such as Killaura and Crystal aura", "pause", false, 8, null));
/* 45 */     $this$initSettings.add((Setting)new IntSliderSetting("Amount: ", "The amount to attempt to place per block", "amount", 1, 10, 0, 32, null));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\SurroundModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */