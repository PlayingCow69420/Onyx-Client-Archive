/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_640;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\006J/\020\016\032\0020\r2\006\020\b\032\0020\0072\006\020\t\032\0020\0042\006\020\n\032\0020\0042\006\020\f\032\0020\013H\026¢\006\004\b\016\020\017R\026\020\021\032\0020\0208\002@\002X\016¢\006\006\n\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/PingModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "", "getPing", "()I", "Lnet/minecraft/class_332;", "context", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "background", "Lnet/integr/rendering/uisystem/Box;", "onyx2"})
/*    */ public final class PingModule
/*    */   extends UiModule
/*    */ {
/*    */   @NotNull
/*    */   private Box background;
/*    */   
/*    */   public PingModule() {
/* 28 */     super("Ping", "Renders your Ping", "ping", 22, 70, Filter.Render);
/* 29 */     this.background = new Box(0, 0, 70, 22, "Ping: ", false, false, false, 192, null);
/*    */   }
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/* 32 */     Intrinsics.checkNotNullParameter(context, "context"); this.background.setText("Ping: " + getPing());
/* 33 */     this.background.update(originX, originY).method_25394(context, 10, 10, delta);
/*    */   }
/*    */   private final int getPing() {
/*    */     class_640 playerListEntry;
/* 37 */     if (Onyx.Companion.getMC().method_1562() == null) return 0;
/*    */     
/* 39 */     Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (Onyx.Companion.getMC().method_1562().method_2871((Onyx.Companion.getMC()).field_1724.method_5667()) == null) { Onyx.Companion.getMC().method_1562().method_2871((Onyx.Companion.getMC()).field_1724.method_5667()); return 0; }
/* 40 */      return playerListEntry.method_2959();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\PingModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */