/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.integr.utilities.game.interaction.AttackUtils;
/*     */ import net.integr.utilities.game.interaction.MovementUtil;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\006\020\t\032\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\020\032\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$MaceKillAuraMode;", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */ public final class MaceKillAuraMode
/*     */   extends KillAuraModule.KillAuraMode
/*     */ {
/*     */   @NotNull
/*     */   private final SettingsBuilder settings;
/*     */   @NotNull
/*     */   private final KillAuraModule.ModeHandler modes;
/*     */   
/*     */   public MaceKillAuraMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) {
/* 208 */     super("Mace"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */    public void run(@NotNull String rotMode, @NotNull class_1309 entity) {
/* 210 */     Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull(this.settings.getById("maceHeight")); double height = ((SliderSetting)this.settings.getById("maceHeight")).getSetValue();
/* 211 */     Intrinsics.checkNotNull(this.settings.getById("critical")); boolean critical = ((BooleanSetting)this.settings.getById("critical")).isEnabled();
/*     */     
/* 213 */     boolean found = false;
/*     */     
/* 215 */     for (KillAuraModule.RotationMode mode : this.modes.getRotationModes()) {
/* 216 */       if (Intrinsics.areEqual(mode.getName(), rotMode)) {
/* 217 */         Variables.Companion.setTarget(entity);
/* 218 */         if (AttackUtils.Companion.canAttack()) {
/* 219 */           Intrinsics.checkNotNull(this.settings.getById("spoofGround")); if (((BooleanSetting)this.settings.getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(height * 2);
/*     */           
/* 221 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 origin = (Onyx.Companion.getMC()).field_1724.method_19538();
/*     */           
/* 223 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), "add(...)"); Highlighter.Companion.renderBlock$default(Highlighter.Companion, (Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), 0, 2, null);
/* 224 */           Intrinsics.checkNotNull(origin); Highlighter.Companion.renderBlock$default(Highlighter.Companion, origin, 0, 2, null);
/*     */           
/* 226 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), "add(...)"); Highlighter.Companion.renderLine$default(Highlighter.Companion, origin, (Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), 0, 0, 12, null);
/*     */           
/* 228 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), true);
/* 229 */           Intrinsics.checkNotNullExpressionValue(origin.method_1031(0.0D, 0.0D, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(origin.method_1031(0.0D, 0.0D, 0.0D), true);
/* 230 */           Intrinsics.checkNotNullExpressionValue(origin.method_1031(0.0D, 0.0D, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(origin.method_1031(0.0D, 0.0D, 0.0D), true);
/*     */           
/* 232 */           AttackUtils.Companion.attack(entity, critical);
/*     */         } 
/*     */         
/* 235 */         mode.run(entity);
/* 236 */         found = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 241 */     if (!found) RotationLocker.Companion.unLock(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillAuraModule$MaceKillAuraMode.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */