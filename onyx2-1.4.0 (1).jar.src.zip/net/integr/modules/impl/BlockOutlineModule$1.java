/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 39 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); String[] arrayOfString = new String[2]; arrayOfString[0] = "Full"; arrayOfString[1] = "Lines"; $this$initSettings.add((Setting)new CyclerSetting("Mode: ", "The Mode to use", "mode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 40 */     $this$initSettings.add((Setting)new BooleanSetting("Entity Box", "Also render a box around the entity you are looking at", "entityBox", false, 8, null));
/* 41 */     $this$initSettings.add((Setting)new BooleanSetting("Lerp Movement", "Smoothly move the box between the blocks", "lerpMovement", false, 8, null));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\BlockOutlineModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */