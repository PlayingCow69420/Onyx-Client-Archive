/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import net.integr.event.SendChatMessageEvent;
/*     */ import net.integr.event.SendCommandEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.eventsystem.Priority;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.utilities.LogUtils;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\000\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\006\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ7\020\017\032\0020\0062\006\020\n\032\0020\t2\006\020\013\032\0020\t2\006\020\f\032\0020\0062\006\020\r\032\0020\0062\006\020\016\032\0020\006H\002¢\006\004\b\017\020\020J\027\020\024\032\0020\0232\006\020\022\032\0020\021H\007¢\006\004\b\024\020\025J\027\020\027\032\0020\0232\006\020\022\032\0020\026H\007¢\006\004\b\027\020\030J\027\020\032\032\0020\0062\006\020\031\032\0020\006H\002¢\006\004\b\032\020\033¨\006\034"}, d2 = {"Lnet/integr/modules/impl/ChatFormatModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "c", "", "componentToHex", "(I)Ljava/lang/String;", "Ljava/awt/Color;", "color1", "color2", "word", "fChar", "modifiers", "grad", "(Ljava/awt/Color;Ljava/awt/Color;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "Lnet/integr/event/SendChatMessageEvent;", "event", "", "onChatMessage", "(Lnet/integr/event/SendChatMessageEvent;)V", "Lnet/integr/event/SendCommandEvent;", "onCommand", "(Lnet/integr/event/SendCommandEvent;)V", "messageIn", "replaceInText", "(Ljava/lang/String;)Ljava/lang/String;", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nChatFormatModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ChatFormatModule.kt\nnet/integr/modules/impl/ChatFormatModule\n+ 2 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 3 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,134:1\n1313#2,2:135\n1313#2:137\n1314#2:140\n1174#3,2:138\n*S KotlinDebug\n*F\n+ 1 ChatFormatModule.kt\nnet/integr/modules/impl/ChatFormatModule\n*L\n57#1:135,2\n74#1:137\n74#1:140\n79#1:138,2\n*E\n"})
/*     */ public final class ChatFormatModule
/*     */   extends Module
/*     */ {
/*     */   public ChatFormatModule() {
/*  33 */     super("Chat Format", "Chat formatter (Details on the Modrinth page)", "chatFormat", Filter.Util, false, 16, null);
/*     */     
/*  35 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen(prio = Priority.FIRST)
/*     */   public final void onChatMessage(@NotNull SendChatMessageEvent event) {
/*  43 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNullExpressionValue(event.message, "message"); String m = replaceInText(event.message);
/*  44 */     if (m.length() < 269 && ((m.length() > 0))) { event.setCallback(m); } else { LogUtils.Companion.sendChatLog("Message to Long/Short!"); }
/*     */   
/*     */   }
/*     */   @EventListen(prio = Priority.FIRST)
/*     */   public final void onCommand(@NotNull SendCommandEvent event) {
/*  49 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNullExpressionValue(event.command, "command"); String m = replaceInText(event.command);
/*  50 */     if (m.length() < 269 && ((m.length() > 0))) { event.setCallback(m); } else { LogUtils.Companion.sendChatLog("Message to Long/Short!"); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String replaceInText(String messageIn) {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: aload_1
/*     */     //   3: astore_2
/*     */     //   4: aload_0
/*     */     //   5: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   8: ldc 'math'
/*     */     //   10: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   13: dup
/*     */     //   14: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   17: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   20: invokevirtual isEnabled : ()Z
/*     */     //   23: ifeq -> 232
/*     */     //   26: new kotlin/text/Regex
/*     */     //   29: dup
/*     */     //   30: ldc '(<solve>)[^<]*(<solve>)'
/*     */     //   32: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   35: aload_1
/*     */     //   36: checkcast java/lang/CharSequence
/*     */     //   39: iconst_0
/*     */     //   40: iconst_2
/*     */     //   41: aconst_null
/*     */     //   42: invokestatic findAll$default : (Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/sequences/Sequence;
/*     */     //   45: astore_3
/*     */     //   46: iconst_0
/*     */     //   47: istore #4
/*     */     //   49: aload_3
/*     */     //   50: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   55: astore #5
/*     */     //   57: aload #5
/*     */     //   59: invokeinterface hasNext : ()Z
/*     */     //   64: ifeq -> 231
/*     */     //   67: aload #5
/*     */     //   69: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   74: astore #6
/*     */     //   76: aload #6
/*     */     //   78: checkcast kotlin/text/MatchResult
/*     */     //   81: astore #7
/*     */     //   83: iconst_0
/*     */     //   84: istore #8
/*     */     //   86: aload #7
/*     */     //   88: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   93: aload #7
/*     */     //   95: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   100: checkcast java/lang/CharSequence
/*     */     //   103: bipush #62
/*     */     //   105: iconst_0
/*     */     //   106: iconst_0
/*     */     //   107: bipush #6
/*     */     //   109: aconst_null
/*     */     //   110: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   113: iconst_1
/*     */     //   114: iadd
/*     */     //   115: aload #7
/*     */     //   117: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   122: checkcast java/lang/CharSequence
/*     */     //   125: bipush #60
/*     */     //   127: iconst_0
/*     */     //   128: iconst_0
/*     */     //   129: bipush #6
/*     */     //   131: aconst_null
/*     */     //   132: invokestatic lastIndexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   135: invokestatic until : (II)Lkotlin/ranges/IntRange;
/*     */     //   138: invokestatic substring : (Ljava/lang/String;Lkotlin/ranges/IntRange;)Ljava/lang/String;
/*     */     //   141: astore #9
/*     */     //   143: ldc ''
/*     */     //   145: astore #10
/*     */     //   147: nop
/*     */     //   148: getstatic net/integr/utilities/Evaluator.Companion : Lnet/integr/utilities/Evaluator$Companion;
/*     */     //   151: aload #9
/*     */     //   153: invokevirtual evaluate : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   156: astore #10
/*     */     //   158: goto -> 176
/*     */     //   161: astore #11
/*     */     //   163: getstatic net/integr/utilities/LogUtils.Companion : Lnet/integr/utilities/LogUtils$Companion;
/*     */     //   166: ldc 'Invalid Operation!'
/*     */     //   168: invokevirtual sendChatLog : (Ljava/lang/String;)V
/*     */     //   171: aload #11
/*     */     //   173: invokevirtual printStackTrace : ()V
/*     */     //   176: aload_2
/*     */     //   177: astore #11
/*     */     //   179: aload #7
/*     */     //   181: invokeinterface getRange : ()Lkotlin/ranges/IntRange;
/*     */     //   186: invokevirtual getFirst : ()I
/*     */     //   189: istore #12
/*     */     //   191: aload #7
/*     */     //   193: invokeinterface getRange : ()Lkotlin/ranges/IntRange;
/*     */     //   198: invokevirtual getLast : ()I
/*     */     //   201: iconst_1
/*     */     //   202: iadd
/*     */     //   203: istore #13
/*     */     //   205: aload #11
/*     */     //   207: checkcast java/lang/CharSequence
/*     */     //   210: iload #12
/*     */     //   212: iload #13
/*     */     //   214: aload #10
/*     */     //   216: checkcast java/lang/CharSequence
/*     */     //   219: invokestatic replaceRange : (Ljava/lang/CharSequence;IILjava/lang/CharSequence;)Ljava/lang/CharSequence;
/*     */     //   222: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   225: astore_2
/*     */     //   226: nop
/*     */     //   227: nop
/*     */     //   228: goto -> 57
/*     */     //   231: nop
/*     */     //   232: aload_0
/*     */     //   233: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   236: ldc 'gradients'
/*     */     //   238: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   241: dup
/*     */     //   242: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   245: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   248: invokevirtual isEnabled : ()Z
/*     */     //   251: ifeq -> 764
/*     */     //   254: new kotlin/text/Regex
/*     */     //   257: dup
/*     */     //   258: ldc '(<.*:([lonm]*)#[0-9a-f]{6}>)[^<]*(<#[0-9a-f]{6}>)'
/*     */     //   260: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   263: aload_1
/*     */     //   264: checkcast java/lang/CharSequence
/*     */     //   267: iconst_0
/*     */     //   268: iconst_2
/*     */     //   269: aconst_null
/*     */     //   270: invokestatic findAll$default : (Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/sequences/Sequence;
/*     */     //   273: astore_3
/*     */     //   274: iconst_0
/*     */     //   275: istore #4
/*     */     //   277: aload_3
/*     */     //   278: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   283: astore #5
/*     */     //   285: aload #5
/*     */     //   287: invokeinterface hasNext : ()Z
/*     */     //   292: ifeq -> 763
/*     */     //   295: aload #5
/*     */     //   297: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   302: astore #6
/*     */     //   304: aload #6
/*     */     //   306: checkcast kotlin/text/MatchResult
/*     */     //   309: astore #7
/*     */     //   311: iconst_0
/*     */     //   312: istore #8
/*     */     //   314: aconst_null
/*     */     //   315: astore #9
/*     */     //   317: ldc ''
/*     */     //   319: astore #9
/*     */     //   321: aload #7
/*     */     //   323: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   328: aload #7
/*     */     //   330: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   335: checkcast java/lang/CharSequence
/*     */     //   338: bipush #58
/*     */     //   340: iconst_0
/*     */     //   341: iconst_0
/*     */     //   342: bipush #6
/*     */     //   344: aconst_null
/*     */     //   345: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   348: iconst_1
/*     */     //   349: iadd
/*     */     //   350: aload #7
/*     */     //   352: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   357: checkcast java/lang/CharSequence
/*     */     //   360: bipush #35
/*     */     //   362: iconst_0
/*     */     //   363: iconst_0
/*     */     //   364: bipush #6
/*     */     //   366: aconst_null
/*     */     //   367: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   370: invokestatic until : (II)Lkotlin/ranges/IntRange;
/*     */     //   373: invokestatic substring : (Ljava/lang/String;Lkotlin/ranges/IntRange;)Ljava/lang/String;
/*     */     //   376: astore #10
/*     */     //   378: aload #7
/*     */     //   380: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   385: iconst_1
/*     */     //   386: aload #7
/*     */     //   388: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   393: checkcast java/lang/CharSequence
/*     */     //   396: bipush #58
/*     */     //   398: iconst_0
/*     */     //   399: iconst_0
/*     */     //   400: bipush #6
/*     */     //   402: aconst_null
/*     */     //   403: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   406: invokestatic until : (II)Lkotlin/ranges/IntRange;
/*     */     //   409: invokestatic substring : (Ljava/lang/String;Lkotlin/ranges/IntRange;)Ljava/lang/String;
/*     */     //   412: astore #11
/*     */     //   414: aload #10
/*     */     //   416: checkcast java/lang/CharSequence
/*     */     //   419: astore #12
/*     */     //   421: iconst_0
/*     */     //   422: istore #13
/*     */     //   424: iconst_0
/*     */     //   425: istore #14
/*     */     //   427: iload #14
/*     */     //   429: aload #12
/*     */     //   431: invokeinterface length : ()I
/*     */     //   436: if_icmpge -> 476
/*     */     //   439: aload #12
/*     */     //   441: iload #14
/*     */     //   443: invokeinterface charAt : (I)C
/*     */     //   448: istore #15
/*     */     //   450: iload #15
/*     */     //   452: istore #16
/*     */     //   454: iconst_0
/*     */     //   455: istore #17
/*     */     //   457: aload #9
/*     */     //   459: iload #16
/*     */     //   461: <illegal opcode> makeConcatWithConstants : (Ljava/lang/Object;C)Ljava/lang/String;
/*     */     //   466: astore #9
/*     */     //   468: nop
/*     */     //   469: nop
/*     */     //   470: iinc #14, 1
/*     */     //   473: goto -> 427
/*     */     //   476: nop
/*     */     //   477: aload #7
/*     */     //   479: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   484: aload #7
/*     */     //   486: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   491: checkcast java/lang/CharSequence
/*     */     //   494: bipush #60
/*     */     //   496: iconst_0
/*     */     //   497: iconst_0
/*     */     //   498: bipush #6
/*     */     //   500: aconst_null
/*     */     //   501: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   504: iconst_1
/*     */     //   505: iadd
/*     */     //   506: aload #10
/*     */     //   508: checkcast java/lang/CharSequence
/*     */     //   511: invokeinterface length : ()I
/*     */     //   516: iadd
/*     */     //   517: aload #11
/*     */     //   519: checkcast java/lang/CharSequence
/*     */     //   522: invokeinterface length : ()I
/*     */     //   527: iadd
/*     */     //   528: iconst_1
/*     */     //   529: iadd
/*     */     //   530: aload #7
/*     */     //   532: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   537: checkcast java/lang/CharSequence
/*     */     //   540: bipush #62
/*     */     //   542: iconst_0
/*     */     //   543: iconst_0
/*     */     //   544: bipush #6
/*     */     //   546: aconst_null
/*     */     //   547: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   550: invokestatic until : (II)Lkotlin/ranges/IntRange;
/*     */     //   553: invokestatic substring : (Ljava/lang/String;Lkotlin/ranges/IntRange;)Ljava/lang/String;
/*     */     //   556: astore #12
/*     */     //   558: aload #7
/*     */     //   560: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   565: aload #7
/*     */     //   567: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   572: checkcast java/lang/CharSequence
/*     */     //   575: bipush #60
/*     */     //   577: iconst_0
/*     */     //   578: iconst_0
/*     */     //   579: bipush #6
/*     */     //   581: aconst_null
/*     */     //   582: invokestatic lastIndexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   585: iconst_1
/*     */     //   586: iadd
/*     */     //   587: aload #7
/*     */     //   589: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   594: checkcast java/lang/CharSequence
/*     */     //   597: bipush #62
/*     */     //   599: iconst_0
/*     */     //   600: iconst_0
/*     */     //   601: bipush #6
/*     */     //   603: aconst_null
/*     */     //   604: invokestatic lastIndexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   607: invokestatic until : (II)Lkotlin/ranges/IntRange;
/*     */     //   610: invokestatic substring : (Ljava/lang/String;Lkotlin/ranges/IntRange;)Ljava/lang/String;
/*     */     //   613: astore #13
/*     */     //   615: aload #7
/*     */     //   617: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   622: aload #7
/*     */     //   624: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   629: checkcast java/lang/CharSequence
/*     */     //   632: bipush #62
/*     */     //   634: iconst_0
/*     */     //   635: iconst_0
/*     */     //   636: bipush #6
/*     */     //   638: aconst_null
/*     */     //   639: invokestatic indexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   642: iconst_1
/*     */     //   643: iadd
/*     */     //   644: aload #7
/*     */     //   646: invokeinterface getValue : ()Ljava/lang/String;
/*     */     //   651: checkcast java/lang/CharSequence
/*     */     //   654: bipush #60
/*     */     //   656: iconst_0
/*     */     //   657: iconst_0
/*     */     //   658: bipush #6
/*     */     //   660: aconst_null
/*     */     //   661: invokestatic lastIndexOf$default : (Ljava/lang/CharSequence;CIZILjava/lang/Object;)I
/*     */     //   664: invokestatic until : (II)Lkotlin/ranges/IntRange;
/*     */     //   667: invokestatic substring : (Ljava/lang/String;Lkotlin/ranges/IntRange;)Ljava/lang/String;
/*     */     //   670: astore #14
/*     */     //   672: aload_0
/*     */     //   673: aload #12
/*     */     //   675: invokestatic decode : (Ljava/lang/String;)Ljava/awt/Color;
/*     */     //   678: dup
/*     */     //   679: ldc_w 'decode(...)'
/*     */     //   682: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   685: aload #13
/*     */     //   687: invokestatic decode : (Ljava/lang/String;)Ljava/awt/Color;
/*     */     //   690: dup
/*     */     //   691: ldc_w 'decode(...)'
/*     */     //   694: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   697: aload #14
/*     */     //   699: aload #11
/*     */     //   701: aload #9
/*     */     //   703: invokespecial grad : (Ljava/awt/Color;Ljava/awt/Color;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   706: astore #15
/*     */     //   708: aload_2
/*     */     //   709: astore #16
/*     */     //   711: aload #7
/*     */     //   713: invokeinterface getRange : ()Lkotlin/ranges/IntRange;
/*     */     //   718: invokevirtual getFirst : ()I
/*     */     //   721: istore #17
/*     */     //   723: aload #7
/*     */     //   725: invokeinterface getRange : ()Lkotlin/ranges/IntRange;
/*     */     //   730: invokevirtual getLast : ()I
/*     */     //   733: iconst_1
/*     */     //   734: iadd
/*     */     //   735: istore #18
/*     */     //   737: aload #16
/*     */     //   739: checkcast java/lang/CharSequence
/*     */     //   742: iload #17
/*     */     //   744: iload #18
/*     */     //   746: aload #15
/*     */     //   748: checkcast java/lang/CharSequence
/*     */     //   751: invokestatic replaceRange : (Ljava/lang/CharSequence;IILjava/lang/CharSequence;)Ljava/lang/CharSequence;
/*     */     //   754: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   757: astore_2
/*     */     //   758: nop
/*     */     //   759: nop
/*     */     //   760: goto -> 285
/*     */     //   763: nop
/*     */     //   764: aload_2
/*     */     //   765: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #54	-> 0
/*     */     //   #56	-> 4
/*     */     //   #57	-> 26
/*     */     //   #135	-> 49
/*     */     //   #58	-> 86
/*     */     //   #60	-> 143
/*     */     //   #62	-> 147
/*     */     //   #63	-> 148
/*     */     //   #64	-> 161
/*     */     //   #65	-> 163
/*     */     //   #66	-> 171
/*     */     //   #69	-> 176
/*     */     //   #69	-> 225
/*     */     //   #70	-> 226
/*     */     //   #135	-> 227
/*     */     //   #136	-> 231
/*     */     //   #73	-> 232
/*     */     //   #74	-> 254
/*     */     //   #137	-> 277
/*     */     //   #75	-> 314
/*     */     //   #76	-> 321
/*     */     //   #77	-> 378
/*     */     //   #79	-> 414
/*     */     //   #138	-> 424
/*     */     //   #80	-> 457
/*     */     //   #81	-> 468
/*     */     //   #138	-> 469
/*     */     //   #139	-> 476
/*     */     //   #83	-> 477
/*     */     //   #83	-> 516
/*     */     //   #83	-> 527
/*     */     //   #84	-> 558
/*     */     //   #86	-> 615
/*     */     //   #88	-> 672
/*     */     //   #89	-> 708
/*     */     //   #89	-> 757
/*     */     //   #90	-> 758
/*     */     //   #137	-> 759
/*     */     //   #140	-> 763
/*     */     //   #93	-> 764
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   163	13	11	e	Ljava/lang/Exception;
/*     */     //   86	141	8	$i$a$-forEach-ChatFormatModule$replaceInText$1	I
/*     */     //   143	84	9	text	Ljava/lang/String;
/*     */     //   147	80	10	result	Ljava/lang/String;
/*     */     //   83	144	7	exp	Lkotlin/text/MatchResult;
/*     */     //   76	152	6	element$iv	Ljava/lang/Object;
/*     */     //   49	183	4	$i$f$forEach	I
/*     */     //   46	186	3	$this$forEach$iv	Lkotlin/sequences/Sequence;
/*     */     //   457	12	17	$i$a$-forEach-ChatFormatModule$replaceInText$2$1	I
/*     */     //   454	15	16	it	C
/*     */     //   450	20	15	element$iv	C
/*     */     //   424	53	13	$i$f$forEach	I
/*     */     //   421	56	12	$this$forEach$iv	Ljava/lang/CharSequence;
/*     */     //   314	445	8	$i$a$-forEach-ChatFormatModule$replaceInText$2	I
/*     */     //   317	442	9	modText	Ljava/lang/Object;
/*     */     //   378	381	10	mods	Ljava/lang/String;
/*     */     //   414	345	11	fChar	Ljava/lang/String;
/*     */     //   558	201	12	c1	Ljava/lang/String;
/*     */     //   615	144	13	c2	Ljava/lang/String;
/*     */     //   672	87	14	text	Ljava/lang/String;
/*     */     //   708	51	15	hText	Ljava/lang/String;
/*     */     //   311	448	7	exp	Lkotlin/text/MatchResult;
/*     */     //   304	456	6	element$iv	Ljava/lang/Object;
/*     */     //   277	487	4	$i$f$forEach	I
/*     */     //   274	490	3	$this$forEach$iv	Lkotlin/sequences/Sequence;
/*     */     //   2	764	2	message	Ljava/lang/Object;
/*     */     //   0	766	0	this	Lnet/integr/modules/impl/ChatFormatModule;
/*     */     //   0	766	1	messageIn	Ljava/lang/String;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   147	158	161	java/lang/Exception
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String grad(Color color1, Color color2, String word, String fChar, String modifiers) {
/*  97 */     int r1 = color1.getRed();
/*  98 */     int g1 = color1.getGreen();
/*  99 */     int b1 = color1.getBlue();
/* 100 */     int r2 = color2.getRed();
/* 101 */     int g2 = color2.getGreen();
/* 102 */     int b2 = color2.getBlue();
/*     */     
/* 104 */     int[] arrayOfInt1 = new int[3]; arrayOfInt1[0] = r2 - r1; arrayOfInt1[1] = g2 - g1; arrayOfInt1[2] = b2 - b1; int[] unitVector = arrayOfInt1;
/* 105 */     double r = unitVector[0] / word.length();
/* 106 */     double g = unitVector[1] / word.length();
/* 107 */     double b = unitVector[2] / word.length();
/*     */     
/* 109 */     int[] arrayOfInt2 = new int[3]; arrayOfInt2[0] = r1; arrayOfInt2[1] = g1; arrayOfInt2[2] = b1; int[] values = arrayOfInt2;
/* 110 */     List<String> output = new ArrayList();
/* 111 */     for (int i = 0, j = word.length(); i < j; i++) {
/* 112 */       if (word.charAt(i) == ' ') {
/* 113 */         output.add(" ");
/*     */         
/* 115 */         values[0] = (int)(values[0] + r);
/* 116 */         values[1] = (int)(values[1] + g);
/* 117 */         values[2] = (int)(values[2] + b);
/*     */       } else {
/* 119 */         output.add(fChar + "#" + fChar + componentToHex(values[0]) + componentToHex(values[1]) + componentToHex(values[2]) + modifiers);
/*     */         
/* 121 */         values[0] = (int)(values[0] + r);
/* 122 */         values[1] = (int)(values[1] + g);
/* 123 */         values[2] = (int)(values[2] + b);
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     return CollectionsKt.joinToString$default(output, "", null, null, 0, null, null, 62, null);
/*     */   }
/*     */   
/*     */   private final String componentToHex(int c) {
/* 131 */     String hex = Integer.toHexString(c);
/* 132 */     Intrinsics.checkNotNull(hex); return (hex.length() == 1) ? ("0" + hex) : hex;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\ChatFormatModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */