/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 62 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); $this$initSettings.add((Setting)new IntSliderSetting("Amount: ", "Crystal Amount", "amount", 1, 4, 0, 32, null));
/* 63 */     $this$initSettings.add((Setting)new IntSliderSetting("Max Active: ", "Maximum amount of crystals active at once", "maxActive", 1, 10, 0, 32, null));
/* 64 */     $this$initSettings.add((Setting)new SliderSetting("Min Damage: ", "Minimum damage amount", "minDamage", 0.0D, 120.0D, 0.0D, 32, null));
/* 65 */     $this$initSettings.add((Setting)new SliderSetting("Self Max Damage: ", "Maximum self damage amount", "selfMaxDamage", 0.0D, 120.0D, 0.0D, 32, null));
/* 66 */     $this$initSettings.add((Setting)new IntSliderSetting("Entity Radius: ", "The Radius around the targeted entity", "entityRadius", 1, 7, 0, 32, null));
/* 67 */     $this$initSettings.add((Setting)new BooleanSetting("Support", "Allow placing support", "support", false, 8, null));
/* 68 */     $this$initSettings.add((Setting)new BooleanSetting("Mine", "Attempt to mine blocks if needed", "mine", false, 8, null));
/* 69 */     $this$initSettings.add((Setting)new IntSliderSetting("Mining Tool Dura Min: ", "The minimum allowed durability to be left", "minDura", 0, 100, 0, 32, null));
/* 70 */     $this$initSettings.add((Setting)new IntSliderSetting("Max Mine Ticks: ", "The maximum allowed ticks to mine", "mineTicks", 10, 200, 0, 32, null));
/* 71 */     $this$initSettings.add((Setting)new BooleanSetting("Sight", "Check if the player can see the entity", "see", false, 8, null));
/* 72 */     $this$initSettings.add((Setting)new SliderSetting("Range: ", "The maximum allowed range for entities", "range", 1.0D, 16.0D, 0.0D, 32, null));
/* 73 */     $this$initSettings.add((Setting)new SliderSetting("Place Range: ", "The maximum allowed range for placing", "placeRange", 1.0D, 7.0D, 0.0D, 32, null));
/* 74 */     $this$initSettings.add((Setting)new BooleanSetting("Rotate", "Enable rotations if wanted", "rotate", false, 8, null));
/* 75 */     String[] arrayOfString = new String[3]; arrayOfString[0] = "All"; arrayOfString[1] = "Players"; arrayOfString[2] = "Mobs"; $this$initSettings.add((Setting)new CyclerSetting("Target: ", "The entities to target", "target", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 76 */     $this$initSettings.add((Setting)new IntSliderSetting("Delay: ", "The ticks to wait after each cycle", "delay", 0, 5, 0, 32, null));
/* 77 */     $this$initSettings.add((Setting)new IntSliderSetting("Break Delay: ", "The ticks to wait before breaking each crystal", "breakDelay", 0, 25, 0, 32, null));
/* 78 */     $this$initSettings.add((Setting)new BooleanSetting("Swing", "Swing the hand when placing", "swing", false, 8, null));
/* 79 */     $this$initSettings.add((Setting)new BooleanSetting("ReDupe", "Automatically Dupes resources on DupeAnarchy", "redupe", false, 8, null));
/* 80 */     $this$initSettings.add((Setting)new BooleanSetting("Pause On Use", "Automatically Pauses on Item use", "pauseOnUse", false, 8, null));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CrystalAuraModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */