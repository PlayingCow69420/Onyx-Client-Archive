/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.integr.utilities.game.inventory.InvUtils;
/*     */ import net.integr.utilities.game.inventory.ToolUtils;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2682;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000l\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\006\n\000\n\002\020\013\n\002\b\004\n\002\020\b\n\002\b\004\n\002\020 \n\002\b\002\n\002\030\002\n\002\b\007\n\002\020%\n\002\b\022\n\002\030\002\n\002\b\024\n\002\030\002\n\002\030\002\n\002\b\016\n\002\030\002\n\002\b\002\030\0002\0020\001B\007¢\006\004\b\002\020\003J\031\020\007\032\0020\0062\b\020\005\032\004\030\0010\004H\002¢\006\004\b\007\020\bJ\027\020\013\032\0020\0062\006\020\n\032\0020\tH\002¢\006\004\b\013\020\fJ\037\020\020\032\0020\0172\006\020\n\032\0020\t2\006\020\016\032\0020\rH\002¢\006\004\b\020\020\021J\027\020\022\032\0020\0172\006\020\n\032\0020\tH\002¢\006\004\b\022\020\023J\017\020\025\032\0020\024H\002¢\006\004\b\025\020\026J\017\020\027\032\0020\024H\002¢\006\004\b\027\020\026J\035\020\032\032\b\022\004\022\0020\t0\0312\006\020\030\032\0020\024H\002¢\006\004\b\032\020\033JS\020%\032\016\022\004\022\0020\t\022\004\022\0020\r0$2\006\020\035\032\0020\0342\006\020\036\032\0020\0242\006\020\037\032\0020\0172\006\020 \032\0020\r2\006\020!\032\0020\r2\006\020\"\032\0020\r2\006\020#\032\0020\017H\002¢\006\004\b%\020&J\037\020)\032\0020\t2\006\020'\032\0020\t2\006\020(\032\0020\tH\002¢\006\004\b)\020*J\027\020+\032\0020\0172\006\020\005\032\0020\004H\002¢\006\004\b+\020,J\037\020.\032\0020\0172\006\020\n\032\0020\t2\006\020-\032\0020\024H\002¢\006\004\b.\020/J\027\0200\032\0020\0172\006\020\n\032\0020\tH\002¢\006\004\b0\020\023J\027\0201\032\0020\0172\006\020\005\032\0020\004H\002¢\006\004\b1\020,JG\0202\032\0020\0062\006\020\035\032\0020\0342\006\020\036\032\0020\0242\006\020\037\032\0020\0172\006\020 \032\0020\r2\006\020!\032\0020\r2\006\020\"\032\0020\r2\006\020#\032\0020\017H\002¢\006\004\b2\0203J\027\0204\032\0020\0062\006\020\n\032\0020\tH\002¢\006\004\b4\020\fJ\027\0205\032\0020\0062\006\020\n\032\0020\tH\002¢\006\004\b5\020\fJ\017\0206\032\0020\006H\026¢\006\004\b6\020\003J\027\0209\032\0020\0062\006\0208\032\00207H\007¢\006\004\b9\020:J_\020C\032\0020\0062\006\020\n\032\0020\t2\006\020;\032\0020\0342\006\020<\032\0020\0172\006\020=\032\0020\0242\006\020>\032\0020\0242\006\020?\032\0020\0242\006\020@\032\0020\0172\006\020\016\032\0020\r2\006\020A\032\0020\0172\006\020B\032\0020\017H\002¢\006\004\bC\020DJ'\020E\032\0020\0062\006\020\n\032\0020\t2\006\020=\032\0020\0242\006\020A\032\0020\017H\002¢\006\004\bE\020FJ_\020G\032\0020\0062\006\020\n\032\0020\t2\006\020;\032\0020\0342\006\020<\032\0020\0172\006\020=\032\0020\0242\006\020>\032\0020\0242\006\020?\032\0020\0242\006\020@\032\0020\0172\006\020\016\032\0020\r2\006\020A\032\0020\0172\006\020B\032\0020\017H\002¢\006\004\bG\020DJ\037\020H\032\0020\0062\006\020\005\032\0020\0042\006\020\016\032\0020\rH\002¢\006\004\bH\020IJ\037\020J\032\0020\0172\006\020\005\032\0020\0042\006\020\016\032\0020\rH\002¢\006\004\bJ\020KR(\020N\032\024\022\020\022\016\022\004\022\0020\t\022\004\022\0020M0L0\0318\002@\002X\016¢\006\006\n\004\bN\020OR\026\020P\032\0020\0248\002@\002X\016¢\006\006\n\004\bP\020QR\026\020R\032\0020\0178\002@\002X\016¢\006\006\n\004\bR\020SR\"\020T\032\016\022\004\022\0020\t\022\004\022\0020\r0$8\002@\002X\016¢\006\006\n\004\bT\020UR\030\020V\032\004\030\0010\t8\002@\002X\016¢\006\006\n\004\bV\020WR\026\020X\032\0020\0248\002@\002X\016¢\006\006\n\004\bX\020QR\026\020Y\032\0020\0248\002@\002X\016¢\006\006\n\004\bY\020QR\026\020Z\032\0020\0248\002@\002X\016¢\006\006\n\004\bZ\020QR\026\020[\032\0020\0248\002@\002X\016¢\006\006\n\004\b[\020QR\032\020]\032\b\022\004\022\0020\\0\0318\002X\004¢\006\006\n\004\b]\020O¨\006^"}, d2 = {"Lnet/integr/modules/impl/CrystalAuraModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/minecraft/class_1297;", "entity", "", "breakCrystal", "(Lnet/minecraft/class_1297;)V", "Lnet/minecraft/class_2338;", "bp", "breakOnly", "(Lnet/minecraft/class_2338;)V", "", "maxReach", "", "canMine", "(Lnet/minecraft/class_2338;D)Z", "canPlaceOn", "(Lnet/minecraft/class_2338;)Z", "", "findCrystal", "()I", "findSupport", "amt", "", "getBest", "(I)Ljava/util/List;", "Lnet/minecraft/class_1309;", "e", "radius", "checkPlayerAccessible", "accessRange", "minDamage", "selfMaxDamage", "support", "", "getDamageGrid", "(Lnet/minecraft/class_1309;IZDDDZ)Ljava/util/Map;", "placementPos", "entityPos", "getOptimalFacePlacePosition", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2338;)Lnet/minecraft/class_2338;", "hasOpenSpots", "(Lnet/minecraft/class_1297;)Z", "minDura", "isMined", "(Lnet/minecraft/class_2338;I)Z", "isMinedAir", "isPhased", "loadNextGrid", "(Lnet/minecraft/class_1309;IZDDDZ)V", "mineBlock", "mineBlockStart", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "pe", "rotate", "obsSlot", "crystalSlot", "delay", "mine", "redupe", "swing", "placeCrystal", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_1309;ZIIIZDZZ)V", "placeObsidian", "(Lnet/minecraft/class_2338;IZ)V", "placeOnly", "runFacePlaceMining", "(Lnet/minecraft/class_1297;D)V", "shouldFacePlaceMine", "(Lnet/minecraft/class_1297;D)Z", "Lkotlin/Pair;", "Ljava/util/concurrent/atomic/AtomicInteger;", "crystals", "Ljava/util/List;", "facePlaceCrystalCounter", "I", "facePlaceMining", "Z", "lastGrid", "Ljava/util/Map;", "minePosition", "Lnet/minecraft/class_2338;", "minePre", "mineTicks", "reDupeTimer", "timer", "Lnet/minecraft/class_2248;", "unbreakable", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nCrystalAuraModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CrystalAuraModule.kt\nnet/integr/modules/impl/CrystalAuraModule\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,466:1\n766#2:467\n857#2,2:468\n1054#2:470\n*S KotlinDebug\n*F\n+ 1 CrystalAuraModule.kt\nnet/integr/modules/impl/CrystalAuraModule\n*L\n202#1:467\n202#1:468,2\n403#1:470\n*E\n"})
/*     */ public final class CrystalAuraModule extends Module {
/*     */   @NotNull
/*     */   private Map<class_2338, Double> lastGrid;
/*     */   private int timer;
/*     */   private int reDupeTimer;
/*     */   @NotNull
/*     */   private List<? extends Pair<? extends class_2338, ? extends AtomicInteger>> crystals;
/*     */   @Nullable
/*     */   private class_2338 minePosition;
/*     */   private int mineTicks;
/*     */   private boolean facePlaceMining;
/*     */   private int facePlaceCrystalCounter;
/*     */   private int minePre;
/*     */   @NotNull
/*     */   private final List<class_2248> unbreakable;
/*     */   
/*     */   public void onDisable() {
/*     */     Variables.Companion.setTarget(null);
/*     */     Highlighter.Companion.clearCrystal();
/*     */     RotationLocker.Companion.unLock();
/*     */     this.minePosition = null;
/*     */     this.mineTicks = 0;
/*     */     this.facePlaceMining = false;
/*     */     this.facePlaceCrystalCounter = 0;
/*     */   }
/*     */   
/*  59 */   public CrystalAuraModule() { super("Crystal Aura", "Automatically places crystals", "crystalAura", Filter.Combat, false, 16, null);
/*     */     
/*  61 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  84 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(CrystalAuraModule.this.getSettings().getById("target")); $this$initHacklist.add(((CyclerSetting)CrystalAuraModule.this.getSettings().getById("target")).getElement());
/*  85 */             Intrinsics.checkNotNull(CrystalAuraModule.this.getSettings().getById("range")); $this$initHacklist.add("" + ((SliderSetting)CrystalAuraModule.this.getSettings().getById("range")).getSetValue() + "m");
/*  86 */             Intrinsics.checkNotNull(CrystalAuraModule.this.getSettings().getById("placeRange")); $this$initHacklist.add("" + ((SliderSetting)CrystalAuraModule.this.getSettings().getById("placeRange")).getSetValue() + "m(p)");
/*  87 */             Intrinsics.checkNotNull(CrystalAuraModule.this.getSettings().getById("entityRadius")); $this$initHacklist.add("" + ((IntSliderSetting)CrystalAuraModule.this.getSettings().getById("entityRadius")).getSetValue() + "m(r)");
/*  88 */             Intrinsics.checkNotNull(CrystalAuraModule.this.getSettings().getById("breakDelay")); $this$initHacklist.add("" + ((IntSliderSetting)CrystalAuraModule.this.getSettings().getById("breakDelay")).getSetValue() + "t");
/*     */           } }
/*     */       );
/*     */     
/*  92 */     this.lastGrid = new LinkedHashMap<>();
/*     */ 
/*     */     
/*  95 */     this.crystals = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.minePre = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 447 */     class_2248[] arrayOfClass_2248 = new class_2248[2]; arrayOfClass_2248[0] = class_2246.field_9987; arrayOfClass_2248[1] = 
/* 448 */       class_2246.field_38420; this.unbreakable = CollectionsKt.listOf((Object[])arrayOfClass_2248); } @EventListen public final void onTick(@NotNull PreTickEvent event) { Intrinsics.checkNotNullParameter(event, "event"); if (this.timer > 0) { int i = this.timer; this.timer = i + -1; return; }
/*     */      Intrinsics.checkNotNull(getSettings().getById("pauseOnUse")); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (((BooleanSetting)getSettings().getById("pauseOnUse")).isEnabled() && (Onyx.Companion.getMC()).field_1724.method_6115())
/*     */       return;  if (CombatPauser.Companion.isPaused())
/*     */       return;  int obsSlot = findSupport(); int crystalSlot = findCrystal(); Intrinsics.checkNotNull(getSettings().getById("amount")); int amount = ((IntSliderSetting)getSettings().getById("amount")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("maxActive")); int maxActive = ((IntSliderSetting)getSettings().getById("maxActive")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("delay")); int delay = ((IntSliderSetting)getSettings().getById("delay")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("breakDelay")); int breakDelay = ((IntSliderSetting)getSettings().getById("breakDelay")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("entityRadius")); int entityRadius = ((IntSliderSetting)getSettings().getById("entityRadius")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("support")); boolean support = ((BooleanSetting)getSettings().getById("support")).isEnabled(); Intrinsics.checkNotNull(getSettings().getById("minDamage")); double minDmg = ((SliderSetting)getSettings().getById("minDamage")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("selfMaxDamage")); double selfMaxDamage = ((SliderSetting)getSettings().getById("selfMaxDamage")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("see")); boolean see = ((BooleanSetting)getSettings().getById("see")).isEnabled(); Intrinsics.checkNotNull(getSettings().getById("rotate")); boolean rotate = ((BooleanSetting)getSettings().getById("rotate")).isEnabled(); Intrinsics.checkNotNull(getSettings().getById("range")); double range = ((SliderSetting)getSettings().getById("range")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("placeRange")); double placeRange = ((SliderSetting)getSettings().getById("placeRange")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("target")); String target = ((CyclerSetting)getSettings().getById("target")).getElement(); Intrinsics.checkNotNull(getSettings().getById("mine")); boolean mine = ((BooleanSetting)getSettings().getById("mine")).isEnabled(); Intrinsics.checkNotNull(getSettings().getById("minDura")); int minDura = ((IntSliderSetting)getSettings().getById("minDura")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("mineTicks")); int mineTicksMax = ((IntSliderSetting)getSettings().getById("mineTicks")).getSetValue(); Intrinsics.checkNotNull(getSettings().getById("redupe")); boolean redupe = ((BooleanSetting)getSettings().getById("redupe")).isEnabled(); Intrinsics.checkNotNull(getSettings().getById("swing")); boolean swing = ((BooleanSetting)getSettings().getById("swing")).isEnabled(); class_1309 entity = EntityFinder.Companion.getClosestAuraEntity(range, target, see); if (entity != null) { if (this.reDupeTimer > 0) { int i = this.reDupeTimer; this.reDupeTimer = i + -1; }
/*     */        Intrinsics.checkNotNullExpressionValue(class_1802.field_8301, "END_CRYSTAL"); Intrinsics.checkNotNullExpressionValue(class_1802.field_8281, "OBSIDIAN"); boolean shouldRedupe = ((redupe && InvUtils.Companion.countInHotbar(class_1802.field_8301) <= 32) || (redupe && InvUtils.Companion.countInHotbar(class_1802.field_8281) <= 32)); if (this.minePosition != null) { if (this.minePre != -1) { InvUtils.Companion.selectSlotPacket(this.minePre); this.minePre = -1; }
/*     */          if (this.facePlaceMining) { Intrinsics.checkNotNull(this.minePosition); int bestTool = ToolUtils.Companion.getBestSlotForBlock$default(ToolUtils.Companion, this.minePosition, false, false, false, minDura, 14, null); this.minePre = InvUtils.Companion.getSelectedSlot(); InvUtils.Companion.selectSlotPacket(bestTool); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562()); Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, this.minePosition, class_2350.field_11036)); Intrinsics.checkNotNull(this.minePosition); Intrinsics.checkNotNullExpressionValue(this.minePosition.method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); Highlighter.Companion.renderBlock(this.minePosition.method_46558().method_1031(0.0D, -0.5D, 0.0D), 30); Intrinsics.checkNotNull(this.minePosition); Intrinsics.checkNotNullExpressionValue(entity.method_24515(), "getBlockPos(...)"); placeCrystal(getOptimalFacePlacePosition(this.minePosition, entity.method_24515()), entity, rotate, obsSlot, crystalSlot, delay, mine, placeRange, shouldRedupe, swing); Intrinsics.checkNotNull(this.minePosition); Intrinsics.checkNotNullExpressionValue(this.minePosition.method_46558(), "toCenterPos(...)"); boolean hasCrystal = (EntityFinder.Companion.getClosestCrystalAround(this.minePosition.method_46558()) != null); if (hasCrystal) {
/*     */             int i = this.facePlaceCrystalCounter; this.facePlaceCrystalCounter = i + 1;
/*     */           }  Intrinsics.checkNotNullExpressionValue(entity.method_19538(), "getPos(...)"); Intrinsics.checkNotNull(this.minePosition); Intrinsics.checkNotNullExpressionValue(this.minePosition.method_46558(), "toCenterPos(...)"); if ((!shouldFacePlaceMine((class_1297)entity, placeRange) && CoordinateUtils.Companion.distanceBetween(entity.method_19538(), this.minePosition.method_46558()) > 2.0D) || this.facePlaceCrystalCounter > 15) {
/*     */             this.minePosition = null; this.mineTicks = 0; this.facePlaceMining = false; this.facePlaceCrystalCounter = 0;
/*     */           }  }
/*     */         else
/*     */         { Intrinsics.checkNotNull(this.minePosition); if (this.mineTicks < mineTicksMax && !isMinedAir(this.minePosition)) {
/*     */             int i = this.mineTicks; this.mineTicks = i + 1; Intrinsics.checkNotNull(this.minePosition); int bestTool = ToolUtils.Companion.getBestSlotForBlock$default(ToolUtils.Companion, this.minePosition, false, false, false, minDura, 14, null); this.minePre = InvUtils.Companion.getSelectedSlot(); InvUtils.Companion.selectSlotPacket(bestTool); Intrinsics.checkNotNull(this.minePosition); mineBlock(this.minePosition);
/*     */           } else {
/*     */             this.mineTicks = 0;
/*     */           }  Intrinsics.checkNotNull(this.minePosition); if (isMinedAir(this.minePosition) || this.mineTicks >= mineTicksMax) {
/*     */             this.minePosition = null; this.mineTicks = 0;
/*     */           }  return; }
/*     */          }
/* 467 */        List<? extends Pair<? extends class_2338, ? extends AtomicInteger>> list1 = this.crystals; CrystalAuraModule crystalAuraModule = this; int $i$f$filter = 0; List<? extends Pair<? extends class_2338, ? extends AtomicInteger>> list2 = list1; Collection<Object<? extends class_2338, ? extends AtomicInteger>> destination$iv$iv = new ArrayList(); int $i$f$filterTo = 0;
/* 468 */       for (Object<? extends class_2338, ? extends AtomicInteger> element$iv$iv : list2) { Pair it = (Pair)element$iv$iv; int $i$a$-filter-CrystalAuraModule$onTick$1 = 0; if ((((AtomicInteger)it.getSecond()).get() > -1)) destination$iv$iv.add(element$iv$iv);  }
/* 469 */        crystalAuraModule.crystals = (List)destination$iv$iv; for (Pair<? extends class_2338, ? extends AtomicInteger> position : this.crystals) { if (((AtomicInteger)position.getSecond()).get() > 0) { ((AtomicInteger)position.getSecond()).set(((AtomicInteger)position.getSecond()).get() - 1); continue; }  breakOnly((class_2338)position.getFirst()); ((AtomicInteger)position.getSecond()).set(-1); }  Intrinsics.checkNotNullExpressionValue(entity.method_24515(), "getBlockPos(...)"); if (isPhased((class_1297)entity) && canMine(entity.method_24515(), placeRange)) { Intrinsics.checkNotNullExpressionValue(entity.method_24515(), "getBlockPos(...)"); mineBlock(entity.method_24515()); return; }  if (this.crystals.size() < maxActive && !this.facePlaceMining && crystalSlot != -1) { loadNextGrid(entity, entityRadius, true, placeRange, minDmg, selfMaxDamage, (support && obsSlot != -1)); List<class_2338> positions = getBest(amount); if (!positions.isEmpty()) { for (class_2338 position : CollectionsKt.distinct(positions)) { placeOnly(position, entity, rotate, obsSlot, crystalSlot, breakDelay, mine, placeRange, shouldRedupe, swing); this.timer = delay; }  } else if (mine) { runFacePlaceMining((class_1297)entity, placeRange); }  Variables.Companion.setTarget(entity); }  } else { RotationLocker.Companion.unLock(); }  Intrinsics.checkNotNull(Variables.Companion.getTarget()); if (Variables.Companion.getTarget() != null && !Variables.Companion.getTarget().method_5805()) { Variables.Companion.setTarget(null); Highlighter.Companion.clearCrystal(); }  } private final class_2338 getOptimalFacePlacePosition(class_2338 placementPos, class_2338 entityPos) { class_2338 dir = CoordinateUtils.Companion.getDirectionOfBlockToBlockAsVector(entityPos, placementPos); class_2338 extended = placementPos.method_10081((class_2382)dir); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull(extended); return (Onyx.Companion.getMC()).field_1687.method_8320(extended).method_26215() ? extended : placementPos; } private final boolean isPhased(class_1297 entity) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); return (Onyx.Companion.getMC()).field_1687.method_8320(entity.method_24515()).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980); } private final int findSupport() { for (int i = 0; i < 9; i++) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i); Intrinsics.checkNotNull(stack); if (Intrinsics.areEqual(stack.method_7909(), class_1802.field_8281) || Intrinsics.areEqual(stack.method_7909(), class_1802.field_8542)) return i;  }  return -1; }
/* 470 */   private final List<class_2338> getBest(int amt) { Iterable<class_2338> $this$sortedByDescending$iv = this.lastGrid.keySet(); int $i$f$sortedByDescending = 0; return CollectionsKt.take(CollectionsKt.sortedWith($this$sortedByDescending$iv, new CrystalAuraModule$getBest$$inlined$sortedByDescending$1(this)), amt); }
/*     */ 
/*     */   
/*     */   private final int findCrystal() {
/*     */     for (int i = 0; i < 9; i++) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */       class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*     */       Intrinsics.checkNotNull(stack);
/*     */       if (Intrinsics.areEqual(stack.method_7909(), class_1802.field_8301))
/*     */         return i; 
/*     */     } 
/*     */     return -1;
/*     */   }
/*     */   
/*     */   private final void runFacePlaceMining(class_1297 entity, double maxReach) {
/*     */     class_2338 pos = entity.method_24515();
/*     */     Pair[] arrayOfPair = new Pair[4];
/*     */     arrayOfPair[0] = new Pair(Integer.valueOf(1), Integer.valueOf(0));
/*     */     arrayOfPair[1] = new Pair(Integer.valueOf(-1), Integer.valueOf(0));
/*     */     arrayOfPair[2] = new Pair(Integer.valueOf(0), Integer.valueOf(1));
/*     */     arrayOfPair[3] = new Pair(Integer.valueOf(0), Integer.valueOf(-1));
/*     */     List pairs = CollectionsKt.listOf((Object[])arrayOfPair);
/*     */     for (Pair pair : pairs) {
/*     */       int i = ((Number)pair.component1()).intValue(), j = ((Number)pair.component2()).intValue();
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, -1, j), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, 0, j), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, -1, j), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, 0, j), "add(...)");
/*     */       if ((canPlaceOn(pos.method_10069(i, -1, j)) && canMine(pos.method_10069(i, 0, j), maxReach)) || (isMinedAir(pos.method_10069(i, -1, j)) && canMine(pos.method_10069(i, 0, j), maxReach))) {
/*     */         Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, 0, j), "add(...)");
/*     */         mineBlockStart(pos.method_10069(i, 0, j));
/*     */         this.facePlaceMining = true;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final boolean shouldFacePlaceMine(class_1297 entity, double maxReach) {
/*     */     if (hasOpenSpots(entity))
/*     */       return false; 
/*     */     class_2338 pos = entity.method_24515();
/*     */     Pair[] arrayOfPair = new Pair[4];
/*     */     arrayOfPair[0] = new Pair(Integer.valueOf(1), Integer.valueOf(0));
/*     */     arrayOfPair[1] = new Pair(Integer.valueOf(-1), Integer.valueOf(0));
/*     */     arrayOfPair[2] = new Pair(Integer.valueOf(0), Integer.valueOf(1));
/*     */     arrayOfPair[3] = new Pair(Integer.valueOf(0), Integer.valueOf(-1));
/*     */     List pairs = CollectionsKt.listOf((Object[])arrayOfPair);
/*     */     for (Pair pair : pairs) {
/*     */       int i = ((Number)pair.component1()).intValue(), j = ((Number)pair.component2()).intValue();
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, -1, j), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, 0, j), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, -1, j), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pos.method_10069(i, 0, j), "add(...)");
/*     */       if ((canPlaceOn(pos.method_10069(i, -1, j)) && canMine(pos.method_10069(i, 0, j), maxReach)) || (isMinedAir(pos.method_10069(i, -1, j)) && canMine(pos.method_10069(i, 0, j), maxReach)))
/*     */         return true; 
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private final boolean hasOpenSpots(class_1297 entity) {
/*     */     class_2338 pos = entity.method_24515();
/*     */     Pair[] arrayOfPair = new Pair[4];
/*     */     arrayOfPair[0] = new Pair(Integer.valueOf(1), Integer.valueOf(0));
/*     */     arrayOfPair[1] = new Pair(Integer.valueOf(-1), Integer.valueOf(0));
/*     */     arrayOfPair[2] = new Pair(Integer.valueOf(0), Integer.valueOf(1));
/*     */     arrayOfPair[3] = new Pair(Integer.valueOf(0), Integer.valueOf(-1));
/*     */     List pairs = CollectionsKt.listOf((Object[])arrayOfPair);
/*     */     for (Pair pair : pairs) {
/*     */       int i = ((Number)pair.component1()).intValue(), j = ((Number)pair.component2()).intValue();
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       if ((Onyx.Companion.getMC()).field_1687.method_8320(pos.method_10069(i, 0, j)).method_26215())
/*     */         return true; 
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private final void placeObsidian(class_2338 bp, int obsSlot, boolean redupe) {
/*     */     int pre = InvUtils.Companion.getSelectedSlot();
/*     */     InvUtils.Companion.selectSlot(obsSlot);
/*     */     if (redupe) {
/*     */       InvUtils.Companion.selectSlotPacket(obsSlot);
/*     */       CommandUtils.Companion.sendCommand("dupe 2");
/*     */       this.reDupeTimer = 10;
/*     */     } 
/*     */     BlockUtil.Companion.placeBlock(bp, false, true, false);
/*     */     InvUtils.Companion.selectSlot(pre);
/*     */   }
/*     */   
/*     */   private final void mineBlock(class_2338 bp) {
/*     */     BlockUtil.Companion.minePosition(bp, false, true);
/*     */     this.minePosition = bp;
/*     */   }
/*     */   
/*     */   private final void mineBlockStart(class_2338 bp) {
/*     */     BlockUtil.Companion.minePositionStart(bp, false, true);
/*     */     this.minePosition = bp;
/*     */   }
/*     */   
/*     */   private final void placeOnly(class_2338 bp, class_1309 pe, boolean rotate, int obsSlot, int crystalSlot, int delay, boolean mine, double maxReach, boolean redupe, boolean swing) {
/*     */     placeCrystal(bp, pe, rotate, obsSlot, crystalSlot, delay, mine, maxReach, redupe, swing);
/*     */   }
/*     */   
/*     */   private final void breakOnly(class_2338 bp) {
/*     */     Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)");
/*     */     breakCrystal((class_1297)EntityFinder.Companion.getClosestCrystalAround(bp.method_46558()));
/*     */   }
/*     */   
/*     */   private final void placeCrystal(class_2338 bp, class_1309 pe, boolean rotate, int obsSlot, int crystalSlot, int delay, boolean mine, double maxReach, boolean redupe, boolean swing) {
/*     */     boolean trueRedupe = (redupe && this.reDupeTimer == 0);
/*     */     Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */     if (!canPlaceOn(bp.method_10069(0, -1, 0))) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       if ((Onyx.Companion.getMC()).field_1687.method_8320(bp.method_10069(0, -1, 0)).method_26215()) {
/*     */         Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */         placeObsidian(bp.method_10069(0, -1, 0), obsSlot, trueRedupe);
/*     */       } else {
/*     */         Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */         if (mine && canMine(bp.method_10069(0, -1, 0), maxReach)) {
/*     */           Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */           mineBlock(bp.method_10069(0, -1, 0));
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       this.crystals = CollectionsKt.plus(this.crystals, TuplesKt.to(bp, new AtomicInteger(delay)));
/*     */       int pre = InvUtils.Companion.getSelectedSlot();
/*     */       class_3965 hitResult = new class_3965(bp.method_10059(new class_2382(0, 1, 0)).method_46558(), class_2350.field_11036, bp.method_10059(new class_2382(0, 1, 0)), false);
/*     */       if (rotate) {
/*     */         RotationLocker.Companion.lock();
/*     */         Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)");
/*     */         RotationUtils.Companion.lookAt$default(RotationUtils.Companion, bp.method_46558(), false, 2, null);
/*     */       } else {
/*     */         RotationLocker.Companion.unLock();
/*     */       } 
/*     */       InvUtils.Companion.selectSlot(crystalSlot);
/*     */       if (trueRedupe) {
/*     */         InvUtils.Companion.selectSlotPacket(crystalSlot);
/*     */         CommandUtils.Companion.sendCommand("dupe 2");
/*     */         this.reDupeTimer = 10;
/*     */       } 
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761);
/*     */       (Onyx.Companion.getMC()).field_1761.method_2896((Onyx.Companion.getMC()).field_1724, class_1268.field_5808, hitResult);
/*     */       if (swing) {
/*     */         ClickUtils.Companion.rightClick();
/*     */         ClickUtils.Companion.leftClick();
/*     */       } 
/*     */       InvUtils.Companion.selectSlot(pre);
/*     */       Intrinsics.checkNotNullExpressionValue(bp.method_46558().method_1031(0.0D, -1.5D, 0.0D), "add(...)");
/*     */       Highlighter.Companion.renderCrystal(bp.method_46558().method_1031(0.0D, -1.5D, 0.0D));
/*     */       Intrinsics.checkNotNullExpressionValue(bp.method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(pe.method_19538(), "getPos(...)");
/*     */       Highlighter.Companion.renderLine$default(Highlighter.Companion, bp.method_46558().method_1031(0.0D, -0.5D, 0.0D), pe.method_19538(), 0, 6, 4, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void breakCrystal(class_1297 entity) {
/*     */     if (entity != null && entity.method_5805()) {
/*     */       AttackUtils.Companion.attackViaManager(entity);
/*     */       entity.method_5768();
/*     */       entity.method_5650(class_1297.class_5529.field_26998);
/*     */       entity.method_36209();
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void loadNextGrid(class_1309 e, int radius, boolean checkPlayerAccessible, double accessRange, double minDamage, double selfMaxDamage, boolean support) {
/*     */     this.lastGrid = getDamageGrid(e, radius, checkPlayerAccessible, accessRange, minDamage, selfMaxDamage, support);
/*     */   }
/*     */   
/*     */   private final Map<class_2338, Double> getDamageGrid(class_1309 e, int radius, boolean checkPlayerAccessible, double accessRange, double minDamage, double selfMaxDamage, boolean support) {
/*     */     Map<Object, Object> returnList = new LinkedHashMap<>();
/*     */     int fpPenalty = shouldFacePlaceMine((class_1297)e, accessRange) ? 80 : 0;
/*     */     int i = -radius;
/*     */     if (i <= radius)
/*     */       while (true) {
/*     */         int j = -radius;
/*     */         if (j <= radius)
/*     */           while (true) {
/*     */             int k = -radius;
/*     */             if (k <= radius)
/*     */               while (true) {
/*     */                 class_2338 bp = e.method_24515().method_10069(i, j, k);
/*     */                 int supportPenalty = 0;
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */                 if (!(Onyx.Companion.getMC()).field_1687.method_8320(bp.method_10069(0, -1, 0)).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980))
/*     */                   if (support) {
/*     */                     supportPenalty = 30;
/*     */                   } else {
/*     */                     continue;
/*     */                   }  
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */                 Intrinsics.checkNotNull(bp);
/*     */                 if (!(Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980) && !Intrinsics.areEqual((Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26204(), class_2246.field_10382) && !CoordinateUtils.Companion.crystalIsBlockedByEntity(bp)) {
/*     */                   Intrinsics.checkNotNullExpressionValue(bp.method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)");
/*     */                   Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */                   double entityDamage = DamageUtil.Companion.crystalDamage(e, bp.method_46558().method_1031(0.0D, -0.5D, 0.0D), false, bp.method_10069(0, -1, 0));
/*     */                   Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */                   Intrinsics.checkNotNullExpressionValue(bp.method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)");
/*     */                   Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */                   double selfDamage = DamageUtil.Companion.crystalDamage((class_1309)(Onyx.Companion.getMC()).field_1724, bp.method_46558().method_1031(0.0D, -0.5D, 0.0D), false, bp.method_10069(0, -1, 0));
/*     */                   Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)");
/*     */                   if ((checkPlayerAccessible && CoordinateUtils.Companion.distanceTo(bp.method_46558()) <= accessRange) || !checkPlayerAccessible) {
/*     */                     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */                     Intrinsics.checkNotNullExpressionValue(bp.method_10069(0, -1, 0), "add(...)");
/*     */                     int miningPenalty = ((Onyx.Companion.getMC()).field_1687.method_8320(bp.method_10069(0, -1, 0)).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980) && !canPlaceOn(bp.method_10069(0, -1, 0))) ? 50 : 0;
/*     */                     if (entityDamage >= minDamage && selfDamage < selfMaxDamage) {
/*     */                       double dmg = entityDamage - miningPenalty - fpPenalty - supportPenalty;
/*     */                       if (dmg > 0.0D) {
/*     */                         Double double_ = Double.valueOf(dmg);
/*     */                         returnList.put(bp, double_);
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */                 continue;
/*     */                 if (k != radius) {
/*     */                   k++;
/*     */                   continue;
/*     */                 } 
/*     */                 break;
/*     */               }  
/*     */             if (j != radius) {
/*     */               j++;
/*     */               continue;
/*     */             } 
/*     */             break;
/*     */           }  
/*     */         if (i != radius) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */     return (Map)returnList;
/*     */   }
/*     */   
/*     */   private final boolean canPlaceOn(class_2338 bp) {
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     return ((Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26204().equals(class_2246.field_10540) || (Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26204().equals(class_2246.field_9987));
/*     */   }
/*     */   
/*     */   private final boolean isMined(class_2338 bp, int minDura) {
/*     */     return (this.mineTicks >= BlockUtil.Companion.getMineTicks(bp, ToolUtils.Companion.getBestSlotForBlock$default(ToolUtils.Companion, bp, false, false, false, minDura, 14, null), true));
/*     */   }
/*     */   
/*     */   private final boolean isMinedAir(class_2338 bp) {
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     return !(Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980);
/*     */   }
/*     */   
/*     */   private final boolean canMine(class_2338 bp, double maxReach) {
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     Intrinsics.checkNotNullExpressionValue(bp.method_46558(), "toCenterPos(...)");
/*     */     return ((Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980) && !this.unbreakable.contains((Onyx.Companion.getMC()).field_1687.method_8320(bp).method_26204()) && CoordinateUtils.Companion.distanceTo(bp.method_46558()) < maxReach);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CrystalAuraModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */