/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 36 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); $this$initSettings.add((Setting)new BooleanSetting("Background", "Renders a background to the hacklist", "background", false, 8, null));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HacklistModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */