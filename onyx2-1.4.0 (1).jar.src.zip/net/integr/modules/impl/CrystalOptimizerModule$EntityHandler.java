/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1293;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1831;
/*     */ import net.minecraft.class_1832;
/*     */ import net.minecraft.class_1834;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2824;
/*     */ import net.minecraft.class_3966;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\026¢\006\004\b\b\020\tJ\037\020\f\032\0020\0042\006\020\007\032\0020\0062\006\020\013\032\0020\nH\026¢\006\004\b\f\020\rJ\027\020\021\032\0020\0202\006\020\017\032\0020\016H\002¢\006\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/CrystalOptimizerModule$EntityHandler;", "Lnet/minecraft/class_2824$class_5908;", "<init>", "()V", "", "attack", "Lnet/minecraft/class_1268;", "hand", "interact", "(Lnet/minecraft/class_1268;)V", "Lnet/minecraft/class_243;", "pos", "interactAt", "(Lnet/minecraft/class_1268;Lnet/minecraft/class_243;)V", "Lnet/minecraft/class_1799;", "itemStack", "", "isTool", "(Lnet/minecraft/class_1799;)Z", "onyx2"})
/*     */ public final class EntityHandler
/*     */   implements class_2824.class_5908
/*     */ {
/*     */   public void method_34219(@NotNull class_1268 hand) {
/*  84 */     Intrinsics.checkNotNullParameter(hand, "hand"); } public void method_34220(@NotNull class_1268 hand, @NotNull class_243 pos) {
/*  85 */     Intrinsics.checkNotNullParameter(hand, "hand"); Intrinsics.checkNotNullParameter(pos, "pos");
/*     */   }
/*     */   public void method_34218() {
/*  88 */     class_239 hitResult = (Onyx.Companion.getMC()).field_1765;
/*  89 */     if (hitResult != null && 
/*  90 */       hitResult.method_17783() == class_239.class_240.field_1331) {
/*  91 */       class_3966 entityHitResult = (class_3966)hitResult;
/*  92 */       class_1297 entity = entityHitResult.method_17782();
/*     */       
/*  94 */       if (entity instanceof net.minecraft.class_1511) {
/*  95 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1293 weakness = (Onyx.Companion.getMC()).field_1724.method_6112(class_1294.field_5911);
/*  96 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1293 strength = (Onyx.Companion.getMC()).field_1724.method_6112(class_1294.field_5910);
/*     */         
/*  98 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_6047(), "getMainHandStack(...)"); if (weakness != null && (strength == null || strength.method_5578() <= weakness.method_5578()) && !isTool((Onyx.Companion.getMC()).field_1724.method_6047())) {
/*     */           return;
/*     */         }
/*     */         
/* 102 */         entity.method_5768();
/* 103 */         entity.method_31745(class_1297.class_5529.field_26998);
/* 104 */         entity.method_36209();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean isTool(class_1799 itemStack) {
/* 112 */     if (itemStack.method_7909() instanceof class_1831 && !(itemStack.method_7909() instanceof net.minecraft.class_1794)) {
/* 113 */       Intrinsics.checkNotNull(itemStack.method_7909(), "null cannot be cast to non-null type net.minecraft.item.ToolItem"); class_1832 material = ((class_1831)itemStack.method_7909()).method_8022();
/* 114 */       return (material == class_1834.field_8930 || material == class_1834.field_22033);
/*     */     } 
/* 116 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CrystalOptimizerModule$EntityHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */