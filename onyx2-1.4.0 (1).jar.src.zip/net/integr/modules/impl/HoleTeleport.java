/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.enums.EnumEntries;
/*     */ import kotlin.enums.EnumEntriesKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.integr.utilities.game.interaction.MovementUtil;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\000\n\002\030\002\n\002\b\004\n\002\020\013\n\002\b\002\n\002\020\002\n\002\b\002\030\0002\0020\001B\007¢\006\004\b\002\020\003J!\020\b\032\004\030\0010\0062\006\020\005\032\0020\0042\006\020\007\032\0020\006H\002¢\006\004\b\b\020\tJ\027\020\f\032\0020\0132\006\020\n\032\0020\006H\002¢\006\004\b\f\020\rJ\017\020\017\032\0020\016H\026¢\006\004\b\017\020\003¨\006\020"}, d2 = {"Lnet/integr/modules/impl/HoleTeleport;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "range", "Lnet/minecraft/class_2338;", "pos", "getNextHole", "(ILnet/minecraft/class_2338;)Lnet/minecraft/class_2338;", "blockPos", "", "isValidHole", "(Lnet/minecraft/class_2338;)Z", "", "onEnable", "onyx2"})
/*     */ public final class HoleTeleport
/*     */   extends Module
/*     */ {
/*     */   public HoleTeleport() {
/*  33 */     super("Hole Teleport", "Teleports you to the next hole in the direction you are facing", "holeTp", Filter.Move, true);
/*     */     
/*  35 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  41 */     Intrinsics.checkNotNull(getSettings().getById("range")); int range = ((IntSliderSetting)getSettings().getById("range")).getSetValue();
/*  42 */     int stepRange = 1;
/*     */     
/*  44 */     boolean found = false;
/*  45 */     double distance = 4.0D;
/*     */     
/*  47 */     while (!found && distance < range) {
/*  48 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 target = (Onyx.Companion.getMC()).field_1724.method_19538().method_1019((Onyx.Companion.getMC()).field_1724.method_5720().method_1021(distance));
/*     */       
/*  50 */       class_2338 next = getNextHole(stepRange, new class_2338((int)target.field_1352, (int)target.field_1351, (int)target.field_1350));
/*  51 */       if (next != null) {
/*  52 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538(), "getPos(...)"); Intrinsics.checkNotNullExpressionValue(next.method_46558(), "toCenterPos(...)"); Highlighter.Companion.renderLine$default(Highlighter.Companion, (Onyx.Companion.getMC()).field_1724.method_19538(), next.method_46558(), 0, 80, 4, null);
/*  53 */         Intrinsics.checkNotNullExpressionValue(next.method_10084(), "up(...)"); MovementUtil.Companion.moveViaPath(next.method_10084());
/*  54 */         Intrinsics.checkNotNullExpressionValue(next.method_10084(), "up(...)"); MovementUtil.Companion.move(next.method_10084());
/*  55 */         MovementUtil.Companion.move(next);
/*     */         
/*  57 */         found = true;
/*     */       } 
/*     */       
/*  60 */       double d = distance; distance = d + 1.0D;
/*     */     } 
/*     */   }
/*     */   private final class_2338 getNextHole(int range, class_2338 pos) {
/*  64 */     int i = -range; if (i <= range)
/*  65 */       while (true) { int j = -range; if (j <= range)
/*  66 */           while (true) { int k = -range; if (k <= range)
/*  67 */               while (true) { class_2338 nPos = new class_2338(pos.method_10263() + i, pos.method_10264() + j, pos.method_10260() + k);
/*     */                 
/*  69 */                 if (isValidHole(nPos)) return nPos;  if (k != range) { k++; continue; }  break; }
/*     */                 if (j != range) { j++; continue; }
/*     */              break; }
/*     */             if (i != range) { i++; continue; }
/*     */          break; }
/*  74 */         return null;
/*     */   }
/*     */   
/*     */   private final boolean isValidHole(class_2338 blockPos) {
/*  78 */     Intrinsics.checkNotNullExpressionValue(blockPos.method_46558(), "toCenterPos(...)"); double distance = CoordinateUtils.Companion.distanceTo(blockPos.method_46558());
/*  79 */     if (distance < 1.0D) return false;
/*     */     
/*  81 */     int verySafe = 0;
/*  82 */     int safe = 0;
/*     */     
/*  84 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(blockPos), "getBlockState(...)"); class_2680 checkStateCenter = (Onyx.Companion.getMC()).field_1687.method_8320(blockPos);
/*  85 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(blockPos.method_10069(0, 1, 0)), "getBlockState(...)"); class_2680 checkStateCenterOffset = (Onyx.Companion.getMC()).field_1687.method_8320(blockPos.method_10069(0, 1, 0));
/*     */     
/*  87 */     if (!checkStateCenter.method_26215() || !checkStateCenterOffset.method_26215()) return false;
/*     */     
/*  89 */     for (class_2350 direction : EntriesMappings.entries$0) {
/*  90 */       if (direction != class_2350.field_11036) {
/*  91 */         Intrinsics.checkNotNullExpressionValue(blockPos.method_10093(direction), "offset(...)"); class_2338 offsetPos = blockPos.method_10093(direction);
/*  92 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(offsetPos), "getBlockState(...)"); class_2680 state = (Onyx.Companion.getMC()).field_1687.method_8320(offsetPos);
/*     */         
/*  94 */         if (Intrinsics.areEqual(state.method_26204(), class_2246.field_9987)) { verySafe++; continue; }
/*  95 */          if (Intrinsics.areEqual(state.method_26204(), class_2246.field_38420)) { verySafe++; continue; }
/*  96 */          if (Intrinsics.areEqual(state.method_26204(), class_2246.field_10540)) { safe++; continue; }
/*  97 */          if (direction == class_2350.field_11033) return false; 
/*     */       } 
/*     */     } 
/* 100 */     return (safe + verySafe == 5);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HoleTeleport.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */