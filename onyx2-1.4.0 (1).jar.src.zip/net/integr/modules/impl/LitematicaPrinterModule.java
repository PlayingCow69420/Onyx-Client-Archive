/*     */ package net.integr.modules.impl;
/*     */ import fi.dy.masa.litematica.data.DataManager;
/*     */ import fi.dy.masa.litematica.world.WorldSchematic;
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.integr.utilities.game.interaction.RotationUtils;
/*     */ import net.integr.utilities.game.inventory.InvUtils;
/*     */ import net.integr.utilities.game.pathfind.auto.AutoPathTraverser;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1269;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_265;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2741;
/*     */ import net.minecraft.class_2760;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2771;
/*     */ import net.minecraft.class_2873;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_3959;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_4538;
/*     */ import net.minecraft.class_746;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\021\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\b\n\002\b\007\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\020\007\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\r\n\002\020\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\n\n\002\030\002\n\000\n\002\020\006\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\b\030\0002\0020\001B\007¢\006\004\b\002\020\003J\035\020\b\032\b\022\004\022\0020\0070\0062\006\020\005\032\0020\004H\002¢\006\004\b\b\020\tJ#\020\r\032\0020\0072\022\020\f\032\016\022\004\022\0020\013\022\004\022\0020\0130\nH\002¢\006\004\b\r\020\016J+\020\021\032\016\022\004\022\0020\013\022\004\022\0020\0130\n2\006\020\017\032\0020\0072\006\020\020\032\0020\007H\002¢\006\004\b\021\020\022J\031\020\026\032\0020\0252\b\020\024\032\004\030\0010\023H\002¢\006\004\b\026\020\027J\027\020\032\032\0020\0042\006\020\031\032\0020\030H\002¢\006\004\b\032\020\033JI\020%\032\004\030\0010\0042\006\020\024\032\0020\0232\006\020\035\032\0020\0342\b\020\037\032\004\030\0010\0362\b\020!\032\004\030\0010 2\b\020\"\032\004\030\0010\0042\b\020$\032\004\030\0010#H\002¢\006\004\b%\020&J\031\020)\032\0020\0252\b\020(\032\004\030\0010'H\002¢\006\004\b)\020*J\027\020+\032\0020\0252\006\020(\032\0020'H\002¢\006\004\b+\020*J\031\020,\032\0020\0252\b\020(\032\004\030\0010'H\002¢\006\004\b,\020*J)\020.\032\0020\0252\006\020(\032\0020'2\b\020\"\032\004\030\0010\0042\006\020-\032\0020\004H\002¢\006\004\b.\020/J)\0201\032\0020\0252\006\020(\032\0020'2\b\020\"\032\004\030\0010\0042\006\0200\032\0020\004H\002¢\006\004\b1\020/J\027\0203\032\0020\0302\006\0202\032\0020\030H\002¢\006\004\b3\0204J\017\0206\032\00205H\026¢\006\004\b6\020\003J\027\0209\032\002052\006\0208\032\00207H\007¢\006\004\b9\020:J\037\020=\032\0020\0252\006\020;\032\0020\0342\006\020<\032\0020\023H\002¢\006\004\b=\020>J\037\020=\032\002052\006\020@\032\0020?2\006\020A\032\0020\025H\002¢\006\004\b=\020BJi\020H\032\0020\0252\006\020\024\032\0020\0232\b\020C\032\004\030\0010\0042\b\020\037\032\004\030\0010\0362\b\020!\032\004\030\0010 2\b\020\"\032\004\030\0010\0042\b\020$\032\004\030\0010#2\006\020D\032\0020\0252\006\020E\032\0020\0252\006\020F\032\0020\0252\006\020G\032\0020\013H\002¢\006\004\bH\020IJ3\020O\032\0020N2\006\020K\032\0020J2\022\020\f\032\016\022\004\022\0020\013\022\004\022\0020\0130\n2\006\020M\032\0020LH\002¢\006\004\bO\020PJ%\020U\032\0020\0252\006\020R\032\0020Q2\f\020T\032\b\022\004\022\0020\0250SH\002¢\006\004\bU\020VR\026\020W\032\0020\0138\002@\002X\016¢\006\006\n\004\bW\020XR\026\020Y\032\0020\0138\002@\002X\016¢\006\006\n\004\bY\020XR\026\020Z\032\0020\0138\002@\002X\016¢\006\006\n\004\bZ\020X¨\006["}, d2 = {"Lnet/integr/modules/impl/LitematicaPrinterModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/minecraft/class_2350;", "side", "", "Lnet/minecraft/class_243;", "aabbSideMultipliers", "(Lnet/minecraft/class_2350;)[Lnet/minecraft/class_243;", "Lkotlin/Pair;", "", "rotation", "calcLookDirectionFromRotation", "(Lkotlin/Pair;)Lnet/minecraft/class_243;", "orig", "dest", "calcRotationFromVec3d", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Lkotlin/Pair;", "Lnet/minecraft/class_2338;", "blockPos", "", "canPlace", "(Lnet/minecraft/class_2338;)Z", "", "yawI", "getHorizontalDirectionFromYaw", "(F)Lnet/minecraft/class_2350;", "Lnet/minecraft/class_2680;", "placeAtState", "Lnet/minecraft/class_2771;", "slabType", "Lnet/minecraft/class_2760;", "blockHalf", "blockHorizontalOrientation", "Lnet/minecraft/class_2350$class_2351;", "wantedAxies", "getPlaceSide", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2680;Lnet/minecraft/class_2771;Lnet/minecraft/class_2760;Lnet/minecraft/class_2350;Lnet/minecraft/class_2350$class_2351;)Lnet/minecraft/class_2350;", "Lnet/minecraft/class_2248;", "block", "isBlockLikeButton", "(Lnet/minecraft/class_2248;)Z", "isBlockPlacementOppositeToPlacePos", "isBlockSameAsPlaceDir", "against", "isFaceDesired", "(Lnet/minecraft/class_2248;Lnet/minecraft/class_2350;Lnet/minecraft/class_2350;)Z", "playerOrientation", "isPlayerOrientationDesired", "yaw", "normalizeYaw", "(F)F", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "required", "pos", "place", "(Lnet/minecraft/class_2680;Lnet/minecraft/class_2338;)Z", "Lnet/minecraft/class_3965;", "blockHitResult", "swing", "(Lnet/minecraft/class_3965;Z)V", "directionI", "airPlace", "swingHand", "rotate", "range", "placeInternal", "(Lnet/minecraft/class_2338;Lnet/minecraft/class_2350;Lnet/minecraft/class_2771;Lnet/minecraft/class_2760;Lnet/minecraft/class_2350;Lnet/minecraft/class_2350$class_2351;ZZZI)Z", "Lnet/minecraft/class_746;", "entity", "", "blockReachDistance", "Lnet/minecraft/class_239;", "rayTraceTowards", "(Lnet/minecraft/class_746;Lkotlin/Pair;D)Lnet/minecraft/class_239;", "Lnet/minecraft/class_1792;", "item", "Lkotlin/Function0;", "action", "switchItem", "(Lnet/minecraft/class_1792;Lkotlin/jvm/functions/Function0;)Z", "delay", "I", "getDelay", "usedSlot", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nLitematicaPrinterModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LitematicaPrinterModule.kt\nnet/integr/modules/impl/LitematicaPrinterModule\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,614:1\n1045#2:615\n*S KotlinDebug\n*F\n+ 1 LitematicaPrinterModule.kt\nnet/integr/modules/impl/LitematicaPrinterModule\n*L\n105#1:615\n*E\n"})
/*     */ public final class LitematicaPrinterModule extends Module {
/*     */   public LitematicaPrinterModule() {
/*  58 */     super("Litematica Printer", "Automatically prints schematics", "litematicaPrinter", Filter.Util, false, 16, null);
/*     */     
/*  60 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  70 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(LitematicaPrinterModule.this.getSettings().getById("delay")); $this$initHacklist.add("" + ((IntSliderSetting)LitematicaPrinterModule.this.getSettings().getById("delay")).getSetValue() + "t");
/*  71 */             Intrinsics.checkNotNull(LitematicaPrinterModule.this.getSettings().getById("range")); $this$initHacklist.add("" + ((SliderSetting)LitematicaPrinterModule.this.getSettings().getById("range")).getSetValue() + "m");
/*  72 */             Intrinsics.checkNotNull(LitematicaPrinterModule.this.getSettings().getById("amount")); $this$initHacklist.add("" + ((IntSliderSetting)LitematicaPrinterModule.this.getSettings().getById("amount")).getSetValue() + "b");
/*  73 */             Intrinsics.checkNotNull(LitematicaPrinterModule.this.getSettings().getById("autoMove")); $this$initHacklist.add(((BooleanSetting)LitematicaPrinterModule.this.getSettings().getById("autoMove")).isEnabled() ? "Auto" : "Manual");
/*     */           } }
/*     */       );
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     this.usedSlot = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int delay;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getDelay;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int usedSlot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*     */     AutoPathTraverser.Companion.getINSTANCE().cancel();
/*     */     RotationLocker.Companion.unLock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*     */     Intrinsics.checkNotNullParameter(event, "event");
/*     */     LitematicaPrinterModule $this$onTick_u24lambda_u240 = this;
/*     */     int $i$a$-run-LitematicaPrinterModule$onTick$1 = 0;
/*     */     if ($this$onTick_u24lambda_u240.delay > 0) {
/*     */       int i = $this$onTick_u24lambda_u240.delay;
/*     */       $this$onTick_u24lambda_u240.delay = i + -1;
/*     */       return;
/*     */     } 
/*     */     Unit unit1 = Unit.INSTANCE;
/*     */     Unit it = unit1;
/*     */     int $i$a$-also-LitematicaPrinterModule$onTick$2 = 0;
/*     */     if (this.getDelay > 0) {
/*     */       int i = this.getDelay;
/*     */       this.getDelay = i + -1;
/*     */       return;
/*     */     } 
/*     */     WorldSchematic schematic = SchematicWorldHandler.getSchematicWorld();
/*     */     Intrinsics.checkNotNull(getSettings().getById("range"));
/*     */     double range = ((SliderSetting)getSettings().getById("range")).getSetValue();
/*     */     Intrinsics.checkNotNull(getSettings().getById("amount"));
/*     */     int amount = ((IntSliderSetting)getSettings().getById("amount")).getSetValue();
/*     */     if (schematic != null) {
/*     */       List list1 = CoordinateUtils.Companion.getGridAroundPlayer((int)range, true, range);
/*     */       int $i$f$sortedBy = 0;
/* 615 */       List blocks = CollectionsKt.sortedWith(list1, new LitematicaPrinterModule$onTick$$inlined$sortedBy$1());
/*     */       List<class_2338> chosenBlocks = new ArrayList();
/*     */       Intrinsics.checkNotNull(getSettings().getById("moveRadius"));
/*     */       class_2338 nextSchematicBlock = CoordinateUtils.Companion.getNextSchematicPos(((IntSliderSetting)getSettings().getById("moveRadius")).getSetValue(), schematic);
/*     */       Intrinsics.checkNotNull(getSettings().getById("autoMove"));
/*     */       if (((BooleanSetting)getSettings().getById("autoMove")).isEnabled() && nextSchematicBlock != null) {
/*     */         AutoPathTraverser.Companion.getINSTANCE().traverse(nextSchematicBlock);
/*     */         for (class_2338 block : blocks) {
/*     */           if (block.method_10264() == nextSchematicBlock.method_10264()) {
/*     */             if (chosenBlocks.size() < amount) {
/*     */               Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */               class_2680 actualBlock = (Onyx.Companion.getMC()).field_1687.method_8320(block);
/*     */               class_2680 requiredBlock = schematic.method_8320(block);
/*     */               Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */               if (actualBlock.method_45474() && !requiredBlock.method_51176() && !requiredBlock.method_26215() && !Intrinsics.areEqual(actualBlock.method_26204(), requiredBlock.method_26204()) && DataManager.getRenderLayerRange().isPositionWithinRange(block) && !(Onyx.Companion.getMC()).field_1724.method_5829().method_993(class_243.method_24954((class_2382)block), class_243.method_24954((class_2382)block).method_1031(1.0D, 1.0D, 1.0D)) && requiredBlock.method_26184((class_4538)(Onyx.Companion.getMC()).field_1687, block))
/*     */                 chosenBlocks.add(block); 
/*     */               continue;
/*     */             } 
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         for (class_2338 block : blocks) {
/*     */           if (chosenBlocks.size() < amount) {
/*     */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */             class_2680 actualBlock = (Onyx.Companion.getMC()).field_1687.method_8320(block);
/*     */             class_2680 requiredBlock = schematic.method_8320(block);
/*     */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */             if (actualBlock.method_45474() && !requiredBlock.method_51176() && !requiredBlock.method_26215() && !Intrinsics.areEqual(actualBlock.method_26204(), requiredBlock.method_26204()) && DataManager.getRenderLayerRange().isPositionWithinRange(block) && !(Onyx.Companion.getMC()).field_1724.method_5829().method_993(class_243.method_24954((class_2382)block), class_243.method_24954((class_2382)block).method_1031(1.0D, 1.0D, 1.0D)) && requiredBlock.method_26184((class_4538)(Onyx.Companion.getMC()).field_1687, block))
/*     */               chosenBlocks.add(block); 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       RotationLocker.Companion.lock();
/*     */       class_1792 pickedType = null;
/*     */       for (class_2338 block : chosenBlocks) {
/*     */         class_2680 requiredBlock = schematic.method_8320(block);
/*     */         class_1792 item = requiredBlock.method_26204().method_8389();
/*     */         if (pickedType != null && !Intrinsics.areEqual(item, pickedType))
/*     */           continue; 
/*     */         Intrinsics.checkNotNull(item);
/*     */         if (switchItem(item, new LitematicaPrinterModule$onTick$3(this, requiredBlock))) {
/*     */           pickedType = item;
/*     */           Intrinsics.checkNotNull(getSettings().getById("getDelay"));
/*     */           this.getDelay = ((IntSliderSetting)getSettings().getById("getDelay")).getSetValue();
/*     */         } 
/*     */       } 
/*     */       if (chosenBlocks.isEmpty())
/*     */         RotationLocker.Companion.unLock(); 
/*     */       Intrinsics.checkNotNull(getSettings().getById("delay"));
/*     */       this.delay = ((IntSliderSetting)getSettings().getById("delay")).getSetValue();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\013\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()Ljava/lang/Boolean;", "<anonymous>"})
/*     */   static final class LitematicaPrinterModule$onTick$3 extends Lambda implements Function0<Boolean> {
/*     */     @NotNull
/*     */     public final Boolean invoke() {
/*     */       Highlighter.Companion.renderBlock$default(Highlighter.Companion, this.$block, 0, 2, null);
/*     */       Intrinsics.checkNotNullExpressionValue(this.$requiredBlock, "$requiredBlock");
/*     */       return Boolean.valueOf(LitematicaPrinterModule.this.place(this.$requiredBlock, this.$block));
/*     */     }
/*     */     
/*     */     LitematicaPrinterModule$onTick$3(LitematicaPrinterModule $receiver, class_2680 $requiredBlock) {
/*     */       super(0);
/*     */     }
/*     */   }
/*     */   
/*     */   private final boolean switchItem(class_1792 item, Function0 action) {
/*     */     if ((Onyx.Companion.getMC()).field_1724 == null)
/*     */       return false; 
/*     */     int selectedSlot = InvUtils.Companion.getSelectedSlot();
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */     boolean isCreative = ((Onyx.Companion.getMC()).field_1724.method_31549()).field_7477;
/*     */     int foundSlot = InvUtils.Companion.find(item);
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */     if (Intrinsics.areEqual((Onyx.Companion.getMC()).field_1724.method_6047().method_7909(), item)) {
/*     */       if (((Boolean)action.invoke()).booleanValue()) {
/*     */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */         this.usedSlot = ((Onyx.Companion.getMC()).field_1724.method_31548()).field_7545;
/*     */         return false;
/*     */       } 
/*     */       return false;
/*     */     } 
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */     if (this.usedSlot != -1 && Intrinsics.areEqual((Onyx.Companion.getMC()).field_1724.method_31548().method_5438(this.usedSlot).method_7909(), item)) {
/*     */       InvUtils.Companion.selectSlot(this.usedSlot);
/*     */       if (((Boolean)action.invoke()).booleanValue())
/*     */         return false; 
/*     */       return false;
/*     */     } 
/*     */     if (foundSlot != -1) {
/*     */       if (InvUtils.Companion.isHotbarSlot(foundSlot)) {
/*     */         InvUtils.Companion.selectSlot(foundSlot);
/*     */         if (((Boolean)action.invoke()).booleanValue()) {
/*     */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */           this.usedSlot = ((Onyx.Companion.getMC()).field_1724.method_31548()).field_7545;
/*     */           return false;
/*     */         } 
/*     */         return false;
/*     */       } 
/*     */       if (!InvUtils.Companion.isHotbarSlot(foundSlot)) {
/*     */         Intrinsics.checkNotNullExpressionValue(class_1802.field_8162, "AIR");
/*     */         int empty = InvUtils.Companion.find(class_1802.field_8162);
/*     */         if (empty != -1 && InvUtils.Companion.isHotbarSlot(empty)) {
/*     */           InvUtils.Companion.moveItem(foundSlot, empty);
/*     */           InvUtils.Companion.selectSlot(empty);
/*     */           if (((Boolean)action.invoke()).booleanValue()) {
/*     */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */             this.usedSlot = ((Onyx.Companion.getMC()).field_1724.method_31548()).field_7545;
/*     */             return false;
/*     */           } 
/*     */           return false;
/*     */         } 
/*     */         if (this.usedSlot != -1) {
/*     */           InvUtils.Companion.moveItem(foundSlot, this.usedSlot);
/*     */           InvUtils.Companion.selectSlot(this.usedSlot);
/*     */           if (((Boolean)action.invoke()).booleanValue())
/*     */             return false; 
/*     */           return false;
/*     */         } 
/*     */         return false;
/*     */       } 
/*     */       return false;
/*     */     } 
/*     */     if (isCreative) {
/*     */       int slot = 0;
/*     */       Intrinsics.checkNotNullExpressionValue(class_1802.field_8162, "AIR");
/*     */       int fir = InvUtils.Companion.findInHotbar(class_1802.field_8162);
/*     */       if (fir != -1)
/*     */         slot = fir; 
/*     */       if ((0 <= slot) ? ((slot < 9)) : false) {
/*     */         Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562());
/*     */         Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2873(36 + slot, item.method_7854()));
/*     */       } 
/*     */       InvUtils.Companion.selectSlot(slot);
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private final boolean place(class_2680 required, class_2338 pos) {
/*     */     if ((Onyx.Companion.getMC()).field_1724 == null || (Onyx.Companion.getMC()).field_1687 == null)
/*     */       return false; 
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     if (!(Onyx.Companion.getMC()).field_1687.method_8320(pos).method_45474())
/*     */       return false; 
/*     */     class_2771 wantedSlabType = required.method_28498((class_2769)class_2741.field_12485) ? (class_2771)required.method_11654((class_2769)class_2741.field_12485) : null;
/*     */     class_2760 wantedBlockHalf = required.method_28498((class_2769)class_2741.field_12518) ? (class_2760)required.method_11654((class_2769)class_2741.field_12518) : null;
/*     */     class_2350 wantedHorizontalOrientation = required.method_28498((class_2769)class_2741.field_12481) ? (class_2350)required.method_11654((class_2769)class_2741.field_12481) : null;
/*     */     class_2350.class_2351 wantedAxies = required.method_28498((class_2769)class_2741.field_12496) ? (class_2350.class_2351)required.method_11654((class_2769)class_2741.field_12496) : null;
/*     */     class_2350 wantedHopperOrientation = required.method_28498((class_2769)class_2741.field_12545) ? (class_2350)required.method_11654((class_2769)class_2741.field_12545) : null;
/*     */     if (wantedHorizontalOrientation == null);
/*     */     class_2350 placeSide = pos.getPlaceSide((class_2338)required, (class_2680)wantedSlabType, (class_2771)wantedBlockHalf, (class_2760)wantedHorizontalOrientation, wantedHopperOrientation, wantedAxies);
/*     */     if (wantedHorizontalOrientation == null);
/*     */     Intrinsics.checkNotNull(getSettings().getById("range"));
/*     */     return pos.placeInternal((class_2338)placeSide, (class_2350)wantedSlabType, (class_2771)wantedBlockHalf, (class_2760)wantedHorizontalOrientation, wantedHopperOrientation, wantedAxies, true, true, true, (int)((SliderSetting)getSettings().getById("range")).getSetValue());
/*     */   }
/*     */   
/*     */   private final boolean placeInternal(class_2338 blockPos, class_2350 directionI, class_2771 slabType, class_2760 blockHalf, class_2350 blockHorizontalOrientation, class_2350.class_2351 wantedAxies, boolean airPlace, boolean swingHand, boolean rotate, int range) {
/*     */     class_2350 direction = directionI;
/*     */     if ((Onyx.Companion.getMC()).field_1724 == null)
/*     */       return false; 
/*     */     if (!canPlace(blockPos))
/*     */       return false; 
/*     */     class_243 hitPos = new class_243(blockPos.method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D);
/*     */     class_2338 neighbour = null;
/*     */     if (direction == null) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */       if (((slabType != null && slabType != class_2771.field_12682) || blockHalf != null || blockHorizontalOrientation != null || wantedAxies != null) && !(Onyx.Companion.getMC()).field_1724.method_7337())
/*     */         return false; 
/*     */       direction = class_2350.field_11036;
/*     */       neighbour = blockPos;
/*     */     } else if (airPlace) {
/*     */       neighbour = blockPos;
/*     */     } else {
/*     */       Intrinsics.checkNotNullExpressionValue(blockPos.method_10093(direction.method_10153()), "offset(...)");
/*     */       neighbour = blockPos.method_10093(direction.method_10153());
/*     */       hitPos.method_1031(direction.method_10148() * 0.5D, direction.method_10164() * 0.5D, direction.method_10165() * 0.5D);
/*     */     } 
/*     */     class_2350 s = direction;
/*     */     if (rotate) {
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(neighbour).method_26220((class_1922)(Onyx.Companion.getMC()).field_1687, neighbour), "getCollisionShape(...)");
/*     */       class_265 collisionShape = (Onyx.Companion.getMC()).field_1687.method_8320(neighbour).method_26220((class_1922)(Onyx.Companion.getMC()).field_1687, neighbour);
/*     */       if (collisionShape.method_1110()) {
/*     */         RotationUtils.Companion.lookAt$default(RotationUtils.Companion, hitPos, false, 2, null);
/*     */         place(new class_3965(hitPos, s, neighbour, false), swingHand);
/*     */         return true;
/*     */       } 
/*     */       Intrinsics.checkNotNullExpressionValue(collisionShape.method_1107(), "getBoundingBox(...)");
/*     */       class_238 aabb = collisionShape.method_1107();
/*     */       double z = 0.1D;
/*     */       while (z < 0.9D) {
/*     */         double x = 0.1D;
/*     */         while (x < 0.9D) {
/*     */           Intrinsics.checkNotNullExpressionValue(direction.method_10153(), "getOpposite(...)");
/*     */           class_243[] arrayOfClass_243;
/*     */           byte b;
/*     */           int i;
/*     */           for (arrayOfClass_243 = aabbSideMultipliers(direction.method_10153()), b = 0, i = arrayOfClass_243.length; b < i; ) {
/*     */             class_243 placementMultiplier = arrayOfClass_243[b];
/*     */             double placeX = neighbour.method_10263() + aabb.field_1323 * x + aabb.field_1320 * (true - x);
/*     */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */             if (((slabType == null || slabType == class_2771.field_12682) && (blockHalf == null || direction == class_2350.field_11036 || direction == class_2350.field_11033)) || (Onyx.Companion.getMC()).field_1724.method_7337() || ((blockHalf == class_2760.field_12617) ? (placementMultiplier.field_1351 <= 0.5D) : (placementMultiplier.field_1351 > 0.5D))) {
/*     */               double placeY = neighbour.method_10264() + aabb.field_1322 * placementMultiplier.field_1351 + aabb.field_1325 * (true - placementMultiplier.field_1351);
/*     */               double placeZ = neighbour.method_10260() + aabb.field_1321 * z + aabb.field_1324 * (true - z);
/*     */               class_243 testHitPos = new class_243(placeX, placeY, placeZ);
/*     */               Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */               Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */               Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */               class_243 playerHead = new class_243((Onyx.Companion.getMC()).field_1724.method_23317(), (Onyx.Companion.getMC()).field_1724.method_23320(), (Onyx.Companion.getMC()).field_1724.method_23321());
/*     */               Pair<Integer, Integer> rot = calcRotationFromVec3d(playerHead, testHitPos);
/*     */               class_2350 testHorizontalDirection = getHorizontalDirectionFromYaw(normalizeYaw(((Number)rot.getFirst()).intValue()));
/*     */               if (blockHorizontalOrientation == null || testHorizontalDirection.method_10166() == blockHorizontalOrientation.method_10166()) {
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */                 class_239 res = rayTraceTowards((Onyx.Companion.getMC()).field_1724, rot, range);
/*     */                 Intrinsics.checkNotNull(res, "null cannot be cast to non-null type net.minecraft.util.hit.BlockHitResult");
/*     */                 class_3965 blockHitRes = (class_3965)res;
/*     */                 if (res.method_17783() == class_239.class_240.field_1332 && Intrinsics.areEqual(blockHitRes.method_17777(), neighbour) && blockHitRes.method_17780() == direction) {
/*     */                   RotationUtils.Companion.lookAt$default(RotationUtils.Companion, testHitPos, false, 2, null);
/*     */                   place(new class_3965(testHitPos, s, neighbour, false), swingHand);
/*     */                   return true;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             b++;
/*     */           } 
/*     */           x += 0.2D;
/*     */         } 
/*     */         z += 0.2D;
/*     */       } 
/*     */     } else {
/*     */       place(new class_3965(hitPos, s, neighbour, false), swingHand);
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   private final void place(class_3965 blockHitResult, boolean swing) {
/*     */     if ((Onyx.Companion.getMC()).field_1724 == null || (Onyx.Companion.getMC()).field_1761 == null || Onyx.Companion.getMC().method_1562() == null)
/*     */       return; 
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */     boolean wasSneaking = (Onyx.Companion.getMC()).field_1724.field_3913.field_3903;
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */     (Onyx.Companion.getMC()).field_1724.field_3913.field_3903 = false;
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1761);
/*     */     Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1761.method_2896((Onyx.Companion.getMC()).field_1724, class_1268.field_5808, blockHitResult), "interactBlock(...)");
/*     */     class_1269 result = (Onyx.Companion.getMC()).field_1761.method_2896((Onyx.Companion.getMC()).field_1724, class_1268.field_5808, blockHitResult);
/*     */     if (result.method_23666())
/*     */       if (swing) {
/*     */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */         (Onyx.Companion.getMC()).field_1724.method_6104(class_1268.field_5808);
/*     */       } else {
/*     */         Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562());
/*     */         Onyx.Companion.getMC().method_1562().method_52787((class_2596)new class_2879(class_1268.field_5808));
/*     */       }  
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */     (Onyx.Companion.getMC()).field_1724.field_3913.field_3903 = wasSneaking;
/*     */   }
/*     */   
/*     */   private final boolean canPlace(class_2338 blockPos) {
/*     */     if (blockPos == null)
/*     */       return false; 
/*     */     if (!class_1937.method_25953(blockPos))
/*     */       return false; 
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     if (!(Onyx.Companion.getMC()).field_1687.method_8320(blockPos).method_45474())
/*     */       return false; 
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     return (Onyx.Companion.getMC()).field_1687.method_8628(class_2246.field_10540.method_9564(), blockPos, class_3726.method_16194());
/*     */   }
/*     */   
/*     */   private final class_239 rayTraceTowards(class_746 entity, Pair<Integer, Integer> rotation, double blockReachDistance) {
/*     */     class_243 start = entity.method_5836(1.0F);
/*     */     class_243 direction = calcLookDirectionFromRotation(rotation);
/*     */     class_243 end = start.method_1031(direction.field_1352 * blockReachDistance, direction.field_1351 * blockReachDistance, direction.field_1350 * blockReachDistance);
/*     */     Intrinsics.checkNotNullExpressionValue(entity.method_37908().method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)entity)), "raycast(...)");
/*     */     return (class_239)entity.method_37908().method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)entity));
/*     */   }
/*     */   
/*     */   private final class_243 calcLookDirectionFromRotation(Pair rotation) {
/*     */     float radToDeg = 57.295776F;
/*     */     float flatZ = class_3532.method_15362(-((Number)rotation.getFirst()).intValue() * radToDeg - 3.1415927F);
/*     */     float flatX = class_3532.method_15374(-((Number)rotation.getFirst()).intValue() * radToDeg - 3.1415927F);
/*     */     float pitchBase = -class_3532.method_15362(-((Number)rotation.getSecond()).intValue() * radToDeg);
/*     */     float pitchHeight = class_3532.method_15374(-((Number)rotation.getSecond()).intValue() * radToDeg);
/*     */     return new class_243((flatX * pitchBase), pitchHeight, (flatZ * pitchBase));
/*     */   }
/*     */   
/*     */   private final class_2350 getPlaceSide(class_2338 blockPos, class_2680 placeAtState, class_2771 slabType, class_2760 blockHalf, class_2350 blockHorizontalOrientation, class_2350.class_2351 wantedAxies) {
/*     */     // Byte code:
/*     */     //   0: getstatic net/integr/modules/impl/LitematicaPrinterModule$EntriesMappings.entries$0 : Lkotlin/enums/EnumEntries;
/*     */     //   3: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   8: astore #7
/*     */     //   10: aload #7
/*     */     //   12: invokeinterface hasNext : ()Z
/*     */     //   17: ifeq -> 569
/*     */     //   20: aload #7
/*     */     //   22: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   27: checkcast net/minecraft/class_2350
/*     */     //   30: astore #8
/*     */     //   32: aload_1
/*     */     //   33: aload #8
/*     */     //   35: invokevirtual method_10093 : (Lnet/minecraft/class_2350;)Lnet/minecraft/class_2338;
/*     */     //   38: astore #9
/*     */     //   40: aload #8
/*     */     //   42: invokevirtual method_10153 : ()Lnet/minecraft/class_2350;
/*     */     //   45: astore #10
/*     */     //   47: aload #6
/*     */     //   49: ifnull -> 62
/*     */     //   52: aload #8
/*     */     //   54: invokevirtual method_10166 : ()Lnet/minecraft/class_2350$class_2351;
/*     */     //   57: aload #6
/*     */     //   59: if_acmpne -> 10
/*     */     //   62: aload #4
/*     */     //   64: ifnull -> 102
/*     */     //   67: aload #8
/*     */     //   69: getstatic net/minecraft/class_2350.field_11036 : Lnet/minecraft/class_2350;
/*     */     //   72: if_acmpne -> 83
/*     */     //   75: aload #4
/*     */     //   77: getstatic net/minecraft/class_2760.field_12617 : Lnet/minecraft/class_2760;
/*     */     //   80: if_acmpeq -> 10
/*     */     //   83: aload #8
/*     */     //   85: getstatic net/minecraft/class_2350.field_11033 : Lnet/minecraft/class_2350;
/*     */     //   88: if_acmpne -> 102
/*     */     //   91: aload #4
/*     */     //   93: getstatic net/minecraft/class_2760.field_12619 : Lnet/minecraft/class_2760;
/*     */     //   96: if_acmpne -> 102
/*     */     //   99: goto -> 10
/*     */     //   102: aload_3
/*     */     //   103: ifnull -> 113
/*     */     //   106: aload_3
/*     */     //   107: getstatic net/minecraft/class_2771.field_12682 : Lnet/minecraft/class_2771;
/*     */     //   110: if_acmpne -> 118
/*     */     //   113: aload #4
/*     */     //   115: ifnull -> 171
/*     */     //   118: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   121: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   124: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   127: dup
/*     */     //   128: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   131: invokevirtual method_7337 : ()Z
/*     */     //   134: ifne -> 171
/*     */     //   137: aload_3
/*     */     //   138: getstatic net/minecraft/class_2771.field_12681 : Lnet/minecraft/class_2771;
/*     */     //   141: if_acmpeq -> 152
/*     */     //   144: aload #4
/*     */     //   146: getstatic net/minecraft/class_2760.field_12617 : Lnet/minecraft/class_2760;
/*     */     //   149: if_acmpne -> 163
/*     */     //   152: aload #10
/*     */     //   154: getstatic net/minecraft/class_2350.field_11033 : Lnet/minecraft/class_2350;
/*     */     //   157: if_acmpne -> 171
/*     */     //   160: goto -> 10
/*     */     //   163: aload #10
/*     */     //   165: getstatic net/minecraft/class_2350.field_11036 : Lnet/minecraft/class_2350;
/*     */     //   168: if_acmpeq -> 10
/*     */     //   171: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   174: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   177: getfield field_1687 : Lnet/minecraft/class_638;
/*     */     //   180: dup
/*     */     //   181: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   184: aload #9
/*     */     //   186: invokevirtual method_8320 : (Lnet/minecraft/class_2338;)Lnet/minecraft/class_2680;
/*     */     //   189: dup
/*     */     //   190: ldc_w 'getBlockState(...)'
/*     */     //   193: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   196: astore #11
/*     */     //   198: aload #6
/*     */     //   200: ifnonnull -> 225
/*     */     //   203: aload_0
/*     */     //   204: aload_2
/*     */     //   205: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   208: dup
/*     */     //   209: ldc_w 'getBlock(...)'
/*     */     //   212: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   215: aload #5
/*     */     //   217: aload #8
/*     */     //   219: invokespecial isFaceDesired : (Lnet/minecraft/class_2248;Lnet/minecraft/class_2350;Lnet/minecraft/class_2350;)Z
/*     */     //   222: ifeq -> 10
/*     */     //   225: aload #6
/*     */     //   227: ifnull -> 243
/*     */     //   230: aload #6
/*     */     //   232: aload #8
/*     */     //   234: invokevirtual method_10166 : ()Lnet/minecraft/class_2350$class_2351;
/*     */     //   237: if_acmpeq -> 243
/*     */     //   240: goto -> 10
/*     */     //   243: aload #11
/*     */     //   245: invokevirtual method_26215 : ()Z
/*     */     //   248: ifne -> 353
/*     */     //   251: getstatic net/integr/utilities/game/interaction/BlockUtil.Companion : Lnet/integr/utilities/game/interaction/BlockUtil$Companion;
/*     */     //   254: aload #11
/*     */     //   256: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   259: dup
/*     */     //   260: ldc_w 'getBlock(...)'
/*     */     //   263: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   266: invokevirtual canBeClicked : (Lnet/minecraft/class_2248;)Z
/*     */     //   269: ifne -> 353
/*     */     //   272: aload #11
/*     */     //   274: getstatic net/minecraft/class_2741.field_12485 : Lnet/minecraft/class_2754;
/*     */     //   277: checkcast net/minecraft/class_2769
/*     */     //   280: invokevirtual method_28498 : (Lnet/minecraft/class_2769;)Z
/*     */     //   283: ifeq -> 356
/*     */     //   286: aload #11
/*     */     //   288: getstatic net/minecraft/class_2741.field_12485 : Lnet/minecraft/class_2754;
/*     */     //   291: checkcast net/minecraft/class_2769
/*     */     //   294: invokevirtual method_11654 : (Lnet/minecraft/class_2769;)Ljava/lang/Comparable;
/*     */     //   297: getstatic net/minecraft/class_2771.field_12682 : Lnet/minecraft/class_2771;
/*     */     //   300: if_acmpeq -> 353
/*     */     //   303: aload #8
/*     */     //   305: getstatic net/minecraft/class_2350.field_11036 : Lnet/minecraft/class_2350;
/*     */     //   308: if_acmpne -> 328
/*     */     //   311: aload #11
/*     */     //   313: getstatic net/minecraft/class_2741.field_12485 : Lnet/minecraft/class_2754;
/*     */     //   316: checkcast net/minecraft/class_2769
/*     */     //   319: invokevirtual method_11654 : (Lnet/minecraft/class_2769;)Ljava/lang/Comparable;
/*     */     //   322: getstatic net/minecraft/class_2771.field_12679 : Lnet/minecraft/class_2771;
/*     */     //   325: if_acmpeq -> 353
/*     */     //   328: aload #8
/*     */     //   330: getstatic net/minecraft/class_2350.field_11033 : Lnet/minecraft/class_2350;
/*     */     //   333: if_acmpne -> 356
/*     */     //   336: aload #11
/*     */     //   338: getstatic net/minecraft/class_2741.field_12485 : Lnet/minecraft/class_2754;
/*     */     //   341: checkcast net/minecraft/class_2769
/*     */     //   344: invokevirtual method_11654 : (Lnet/minecraft/class_2769;)Ljava/lang/Comparable;
/*     */     //   347: getstatic net/minecraft/class_2771.field_12681 : Lnet/minecraft/class_2771;
/*     */     //   350: if_acmpne -> 356
/*     */     //   353: goto -> 10
/*     */     //   356: aload #11
/*     */     //   358: invokevirtual method_26227 : ()Lnet/minecraft/class_3610;
/*     */     //   361: invokevirtual method_15769 : ()Z
/*     */     //   364: ifeq -> 10
/*     */     //   367: new net/minecraft/class_243
/*     */     //   370: dup
/*     */     //   371: aload #9
/*     */     //   373: invokevirtual method_10263 : ()I
/*     */     //   376: i2d
/*     */     //   377: aload #9
/*     */     //   379: invokevirtual method_10264 : ()I
/*     */     //   382: i2d
/*     */     //   383: aload #9
/*     */     //   385: invokevirtual method_10260 : ()I
/*     */     //   388: i2d
/*     */     //   389: invokespecial <init> : (DDD)V
/*     */     //   392: astore #12
/*     */     //   394: new net/minecraft/class_243
/*     */     //   397: dup
/*     */     //   398: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   401: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   404: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   407: dup
/*     */     //   408: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   411: invokevirtual method_23317 : ()D
/*     */     //   414: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   417: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   420: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   423: dup
/*     */     //   424: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   427: invokevirtual method_23320 : ()D
/*     */     //   430: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   433: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   436: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   439: dup
/*     */     //   440: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   443: invokevirtual method_23321 : ()D
/*     */     //   446: invokespecial <init> : (DDD)V
/*     */     //   449: astore #13
/*     */     //   451: aload_0
/*     */     //   452: aload #13
/*     */     //   454: aload #12
/*     */     //   456: invokespecial calcRotationFromVec3d : (Lnet/minecraft/class_243;Lnet/minecraft/class_243;)Lkotlin/Pair;
/*     */     //   459: astore #14
/*     */     //   461: aload_0
/*     */     //   462: aload_0
/*     */     //   463: aload #14
/*     */     //   465: invokevirtual getFirst : ()Ljava/lang/Object;
/*     */     //   468: checkcast java/lang/Number
/*     */     //   471: invokevirtual intValue : ()I
/*     */     //   474: i2f
/*     */     //   475: invokespecial normalizeYaw : (F)F
/*     */     //   478: invokespecial getHorizontalDirectionFromYaw : (F)Lnet/minecraft/class_2350;
/*     */     //   481: astore #15
/*     */     //   483: aload_2
/*     */     //   484: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   487: instanceof net/minecraft/class_2533
/*     */     //   490: ifeq -> 531
/*     */     //   493: aload #8
/*     */     //   495: getstatic net/minecraft/class_2350.field_11033 : Lnet/minecraft/class_2350;
/*     */     //   498: if_acmpeq -> 509
/*     */     //   501: aload #8
/*     */     //   503: getstatic net/minecraft/class_2350.field_11036 : Lnet/minecraft/class_2350;
/*     */     //   506: if_acmpne -> 531
/*     */     //   509: aload_0
/*     */     //   510: aload_2
/*     */     //   511: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   514: dup
/*     */     //   515: ldc_w 'getBlock(...)'
/*     */     //   518: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   521: aload #5
/*     */     //   523: aload #15
/*     */     //   525: invokespecial isPlayerOrientationDesired : (Lnet/minecraft/class_2248;Lnet/minecraft/class_2350;Lnet/minecraft/class_2350;)Z
/*     */     //   528: ifeq -> 563
/*     */     //   531: aload_2
/*     */     //   532: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   535: instanceof net/minecraft/class_2533
/*     */     //   538: ifne -> 566
/*     */     //   541: aload_0
/*     */     //   542: aload_2
/*     */     //   543: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   546: dup
/*     */     //   547: ldc_w 'getBlock(...)'
/*     */     //   550: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   553: aload #5
/*     */     //   555: aload #15
/*     */     //   557: invokespecial isPlayerOrientationDesired : (Lnet/minecraft/class_2248;Lnet/minecraft/class_2350;Lnet/minecraft/class_2350;)Z
/*     */     //   560: ifne -> 566
/*     */     //   563: goto -> 10
/*     */     //   566: aload #10
/*     */     //   568: areturn
/*     */     //   569: aconst_null
/*     */     //   570: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #445	-> 0
/*     */     //   #446	-> 32
/*     */     //   #447	-> 40
/*     */     //   #449	-> 47
/*     */     //   #451	-> 102
/*     */     //   #452	-> 137
/*     */     //   #453	-> 152
/*     */     //   #455	-> 163
/*     */     //   #458	-> 171
/*     */     //   #459	-> 198
/*     */     //   #461	-> 243
/*     */     //   #462	-> 251
/*     */     //   #463	-> 272
/*     */     //   #464	-> 303
/*     */     //   #465	-> 328
/*     */     //   #466	-> 353
/*     */     //   #468	-> 356
/*     */     //   #470	-> 367
/*     */     //   #471	-> 394
/*     */     //   #472	-> 451
/*     */     //   #473	-> 452
/*     */     //   #474	-> 454
/*     */     //   #472	-> 456
/*     */     //   #477	-> 461
/*     */     //   #479	-> 483
/*     */     //   #480	-> 510
/*     */     //   #481	-> 521
/*     */     //   #482	-> 523
/*     */     //   #479	-> 525
/*     */     //   #484	-> 531
/*     */     //   #485	-> 542
/*     */     //   #486	-> 553
/*     */     //   #487	-> 555
/*     */     //   #484	-> 557
/*     */     //   #489	-> 563
/*     */     //   #491	-> 566
/*     */     //   #494	-> 569
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   40	529	9	neighbor	Lnet/minecraft/class_2338;
/*     */     //   47	522	10	side2	Lnet/minecraft/class_2350;
/*     */     //   198	371	11	state	Lnet/minecraft/class_2680;
/*     */     //   394	175	12	hitPos	Lnet/minecraft/class_243;
/*     */     //   451	118	13	playerHead	Lnet/minecraft/class_243;
/*     */     //   461	108	14	rot	Lkotlin/Pair;
/*     */     //   483	86	15	testHorizontalDirection	Lnet/minecraft/class_2350;
/*     */     //   32	537	8	side	Lnet/minecraft/class_2350;
/*     */     //   0	571	0	this	Lnet/integr/modules/impl/LitematicaPrinterModule;
/*     */     //   0	571	1	blockPos	Lnet/minecraft/class_2338;
/*     */     //   0	571	2	placeAtState	Lnet/minecraft/class_2680;
/*     */     //   0	571	3	slabType	Lnet/minecraft/class_2771;
/*     */     //   0	571	4	blockHalf	Lnet/minecraft/class_2760;
/*     */     //   0	571	5	blockHorizontalOrientation	Lnet/minecraft/class_2350;
/*     */     //   0	571	6	wantedAxies	Lnet/minecraft/class_2350$class_2351;
/*     */   }
/*     */   
/*     */   private final class_243[] aabbSideMultipliers(class_2350 side) {
/*     */     class_243[] arrayOfClass_2431;
/*     */     double x;
/*     */     double z;
/*     */     class_243[] arrayOfClass_2432;
/*     */     switch (WhenMappings.$EnumSwitchMapping$0[side.ordinal()]) {
/*     */       case 1:
/*     */         arrayOfClass_2431 = new class_243[5];
/*     */         arrayOfClass_2431[0] = new class_243(0.5D, 1.0D, 0.5D);
/*     */         arrayOfClass_2431[1] = new class_243(0.1D, 1.0D, 0.5D);
/*     */         arrayOfClass_2431[2] = new class_243(0.9D, 1.0D, 0.5D);
/*     */         arrayOfClass_2431[3] = new class_243(0.5D, 1.0D, 0.1D);
/*     */         arrayOfClass_2431[4] = new class_243(0.5D, 1.0D, 0.9D);
/*     */         return arrayOfClass_2431;
/*     */       case 2:
/*     */         arrayOfClass_2431 = new class_243[5];
/*     */         arrayOfClass_2431[0] = new class_243(0.5D, 0.0D, 0.5D);
/*     */         arrayOfClass_2431[1] = new class_243(0.1D, 0.0D, 0.5D);
/*     */         arrayOfClass_2431[2] = new class_243(0.9D, 0.0D, 0.5D);
/*     */         arrayOfClass_2431[3] = new class_243(0.5D, 0.0D, 0.1D);
/*     */         arrayOfClass_2431[4] = new class_243(0.5D, 0.0D, 0.9D);
/*     */         return arrayOfClass_2431;
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */         x = (side.method_10148() == 0) ? 0.5D : ((1 + side.method_10148()) / 2.0D);
/*     */         z = (side.method_10165() == 0) ? 0.5D : ((1 + side.method_10165()) / 2.0D);
/*     */         arrayOfClass_2432 = new class_243[2];
/*     */         arrayOfClass_2432[0] = new class_243(x, 0.25D, z);
/*     */         arrayOfClass_2432[1] = new class_243(x, 0.75D, z);
/*     */         return arrayOfClass_2432;
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   }
/*     */   
/*     */   private final float normalizeYaw(float yaw) {
/*     */     float newYaw = yaw % 360.0F;
/*     */     if (newYaw < -180.0F)
/*     */       newYaw += 360.0F; 
/*     */     if (newYaw > 180.0F)
/*     */       newYaw -= 360.0F; 
/*     */     return newYaw;
/*     */   }
/*     */   
/*     */   private final class_2350 getHorizontalDirectionFromYaw(float yawI) {
/*     */     float yaw = yawI;
/*     */     yaw %= 360.0F;
/*     */     if (yaw < 0.0F)
/*     */       yaw += 360.0F; 
/*     */     return ((yaw >= 45.0F && yaw < 135.0F) || (yaw >= -315.0F && yaw < -225.0F)) ? class_2350.field_11039 : (((yaw >= 135.0F && yaw < 225.0F) || (yaw >= -225.0F && yaw < -135.0F)) ? class_2350.field_11043 : (((yaw >= 225.0F && yaw < 315.0F) || (yaw >= -135.0F && yaw < -45.0F)) ? class_2350.field_11034 : class_2350.field_11035));
/*     */   }
/*     */   
/*     */   private final Pair<Integer, Integer> calcRotationFromVec3d(class_243 orig, class_243 dest) {
/*     */     double radToDeg = 57.29577951308232D;
/*     */     double[] arrayOfDouble1 = new double[3];
/*     */     arrayOfDouble1[0] = orig.field_1352 - dest.field_1352;
/*     */     arrayOfDouble1[1] = orig.field_1351 - dest.field_1351;
/*     */     arrayOfDouble1[2] = orig.field_1350 - dest.field_1350;
/*     */     double[] delta = arrayOfDouble1;
/*     */     double yaw = class_3532.method_15349(delta[0], -delta[2]);
/*     */     double dist = Math.sqrt(delta[0] * delta[0] + delta[2] * delta[2]);
/*     */     double pitch = class_3532.method_15349(delta[1], dist);
/*     */     return new Pair(Integer.valueOf((int)(float)(yaw * radToDeg)), Integer.valueOf((int)(float)(pitch * radToDeg)));
/*     */   }
/*     */   
/*     */   private final boolean isFaceDesired(class_2248 block, class_2350 blockHorizontalOrientation, class_2350 against) {
/*     */     return (blockHorizontalOrientation == null || (!isBlockSameAsPlaceDir(block) && !isBlockPlacementOppositeToPlacePos(block)) || (isBlockSameAsPlaceDir(block) && blockHorizontalOrientation == against) || (block instanceof net.minecraft.class_2533 && against.method_10153() == blockHorizontalOrientation) || (!(block instanceof net.minecraft.class_2533) && ((isBlockPlacementOppositeToPlacePos(block) && blockHorizontalOrientation == against.method_10153()) || (isBlockLikeButton(block) && against != class_2350.field_11036 && against != class_2350.field_11033 && blockHorizontalOrientation == against))));
/*     */   }
/*     */   
/*     */   private final boolean isPlayerOrientationDesired(class_2248 block, class_2350 blockHorizontalOrientation, class_2350 playerOrientation) {
/*     */     return (blockHorizontalOrientation == null || (block instanceof net.minecraft.class_2510 && playerOrientation == blockHorizontalOrientation) || (!(block instanceof net.minecraft.class_2510) && !isBlockPlacementOppositeToPlacePos(block) && !isBlockSameAsPlaceDir(block) && playerOrientation == blockHorizontalOrientation.method_10153()));
/*     */   }
/*     */   
/*     */   private final boolean isBlockPlacementOppositeToPlacePos(class_2248 block) {
/*     */     return (block instanceof net.minecraft.class_5542 || block instanceof net.minecraft.class_5551 || block instanceof net.minecraft.class_5554 || block instanceof net.minecraft.class_2533 || block instanceof net.minecraft.class_5172 || Intrinsics.areEqual(block, class_2246.field_10431) || Intrinsics.areEqual(block, class_2246.field_10037) || Intrinsics.areEqual(block, class_2246.field_10511) || Intrinsics.areEqual(block, class_2246.field_10306) || Intrinsics.areEqual(block, class_2246.field_10533) || Intrinsics.areEqual(block, class_2246.field_10010) || Intrinsics.areEqual(block, class_2246.field_10436) || Intrinsics.areEqual(block, class_2246.field_10366) || Intrinsics.areEqual(block, class_2246.field_10254) || Intrinsics.areEqual(block, class_2246.field_10622) || Intrinsics.areEqual(block, class_2246.field_10244));
/*     */   }
/*     */   
/*     */   private final boolean isBlockSameAsPlaceDir(class_2248 block) {
/*     */     return block instanceof net.minecraft.class_2377;
/*     */   }
/*     */   
/*     */   private final boolean isBlockLikeButton(class_2248 block) {
/*     */     return (block instanceof net.minecraft.class_2269 || block instanceof net.minecraft.class_3709 || block instanceof net.minecraft.class_3713 || block instanceof net.minecraft.class_2533);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\LitematicaPrinterModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */