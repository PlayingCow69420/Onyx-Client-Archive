/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.event.RenderArmEvent;
/*    */ import net.integr.event.RenderHeldItemEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_7833;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/modules/impl/BetterArmModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/RenderArmEvent;", "event", "", "onRenderArm", "(Lnet/integr/event/RenderArmEvent;)V", "Lnet/integr/event/RenderHeldItemEvent;", "onRenderItem", "(Lnet/integr/event/RenderHeldItemEvent;)V", "onyx2"})
/*    */ public final class BetterArmModule
/*    */   extends Module
/*    */ {
/*    */   public BetterArmModule() {
/* 31 */     super("Better Arm", "Changes rendering of your hand", "betterArm", Filter.Render, false, 16, null);
/*    */     
/* 33 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onRenderItem(@NotNull RenderHeldItemEvent event) {
/* 46 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("xOffset")); double xO = ((SliderSetting)getSettings().getById("xOffset")).getSetValue();
/* 47 */     Intrinsics.checkNotNull(getSettings().getById("yOffset")); double yO = ((SliderSetting)getSettings().getById("yOffset")).getSetValue();
/* 48 */     Intrinsics.checkNotNull(getSettings().getById("zOffset")); double zO = ((SliderSetting)getSettings().getById("zOffset")).getSetValue();
/*    */     
/* 50 */     Intrinsics.checkNotNull(getSettings().getById("xRotation")); double xR = ((SliderSetting)getSettings().getById("xRotation")).getSetValue();
/* 51 */     Intrinsics.checkNotNull(getSettings().getById("yRotation")); double yR = ((SliderSetting)getSettings().getById("yRotation")).getSetValue();
/* 52 */     Intrinsics.checkNotNull(getSettings().getById("zRotation")); double zR = ((SliderSetting)getSettings().getById("zRotation")).getSetValue();
/*    */     
/* 54 */     if (event.hand == class_1268.field_5808)
/* 55 */     { event.matrices.method_22907(class_7833.field_40714.rotationDegrees((float)xR));
/* 56 */       event.matrices.method_22907(class_7833.field_40716.rotationDegrees((float)yR));
/* 57 */       event.matrices.method_22907(class_7833.field_40718.rotationDegrees((float)zR));
/* 58 */       event.matrices.method_22905(1.0F, 1.0F, 1.0F);
/* 59 */       event.matrices.method_22904(xO, yO, zO); }
/* 60 */     else { Intrinsics.checkNotNull(getSettings().getById("offhand")); if (((BooleanSetting)getSettings().getById("offhand")).isEnabled()) {
/* 61 */         event.matrices.method_22907(class_7833.field_40714.rotationDegrees((float)xR));
/* 62 */         event.matrices.method_22907(class_7833.field_40715.rotationDegrees((float)yR));
/* 63 */         event.matrices.method_22907(class_7833.field_40717.rotationDegrees((float)zR));
/* 64 */         event.matrices.method_22905(1.0F, 1.0F, 1.0F);
/* 65 */         event.matrices.method_22904(-xO, yO, zO);
/*    */       }  }
/*    */   
/*    */   }
/*    */   @EventListen
/*    */   public final void onRenderArm(@NotNull RenderArmEvent event) {
/* 71 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("xOffset")); double xO = ((SliderSetting)getSettings().getById("xOffset")).getSetValue();
/* 72 */     Intrinsics.checkNotNull(getSettings().getById("yOffset")); double yO = ((SliderSetting)getSettings().getById("yOffset")).getSetValue();
/* 73 */     Intrinsics.checkNotNull(getSettings().getById("zOffset")); double zO = ((SliderSetting)getSettings().getById("zOffset")).getSetValue();
/*    */     
/* 75 */     Intrinsics.checkNotNull(getSettings().getById("xRotation")); double xR = ((SliderSetting)getSettings().getById("xRotation")).getSetValue();
/* 76 */     Intrinsics.checkNotNull(getSettings().getById("yRotation")); double yR = ((SliderSetting)getSettings().getById("yRotation")).getSetValue();
/* 77 */     Intrinsics.checkNotNull(getSettings().getById("zRotation")); double zR = ((SliderSetting)getSettings().getById("zRotation")).getSetValue();
/*    */     
/* 79 */     event.matrices.method_22907(class_7833.field_40714.rotationDegrees((float)xR));
/* 80 */     event.matrices.method_22907(class_7833.field_40716.rotationDegrees((float)yR));
/* 81 */     event.matrices.method_22907(class_7833.field_40718.rotationDegrees((float)zR));
/* 82 */     event.matrices.method_22905(1.0F, 1.0F, 1.0F);
/* 83 */     event.matrices.method_22904(xO, yO, zO);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\BetterArmModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */