/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreMoveEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.integr.utilities.game.polar.PolarSystem;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\t¨\006\n"}, d2 = {"Lnet/integr/modules/impl/AutosprintModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "doSnapMove", "Lnet/integr/event/PreMoveEvent;", "event", "onPreMove", "(Lnet/integr/event/PreMoveEvent;)V", "onyx2"})
/*    */ public final class AutosprintModule
/*    */   extends Module
/*    */ {
/*    */   public AutosprintModule() {
/* 32 */     super("Autosprint", "Sprints for you", "autoSprint", Filter.Move, false, 16, null);
/*    */     
/* 34 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onPreMove(@NotNull PreMoveEvent event) {
/* 43 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("snap")); if (((BooleanSetting)getSettings().getById("snap")).isEnabled()) {
/* 44 */       doSnapMove();
/*    */     } else {
/* 46 */       Intrinsics.checkNotNull(getSettings().getById("allDirs")); if (((BooleanSetting)getSettings().getById("allDirs")).isEnabled())
/* 47 */       { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!(Onyx.Companion.getMC()).field_1724.method_5624()) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5728(true); }  }
/* 48 */       else if (!(Onyx.Companion.getMC()).field_1690.field_1867.method_1434()) { (Onyx.Companion.getMC()).field_1690.field_1867.method_23481(true); }
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   private final void doSnapMove() {
/* 54 */     Intrinsics.checkNotNull(getSettings().getById("snapSpeed")); float speed = (float)((SliderSetting)getSettings().getById("snapSpeed")).getSetValue();
/*    */     
/* 56 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.field_28627 = 0.04F * speed;
/*    */     
/* 58 */     double velocityX = 0.0D;
/* 59 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double velocityY = ((Onyx.Companion.getMC()).field_1724.method_18798()).field_1351;
/* 60 */     double velocityZ = 0.0D;
/*    */     
/* 62 */     class_243 side = PolarSystem.Companion.getSide();
/* 63 */     class_243 forward = PolarSystem.Companion.getForward();
/*    */ 
/*    */     
/* 66 */     velocityX += forward.field_1352 * 0.25D * speed;
/* 67 */     velocityZ += forward.field_1350 * 0.25D * speed;
/*    */     
/* 69 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1894.method_1434() && !(Onyx.Companion.getMC()).field_1724.method_5624()) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5728(true); }
/*    */ 
/*    */ 
/*    */     
/* 73 */     velocityX -= forward.field_1352 * 0.25D * speed;
/* 74 */     velocityZ -= forward.field_1350 * 0.25D * speed;
/*    */     
/* 76 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1881.method_1434() && !(Onyx.Companion.getMC()).field_1724.method_5624()) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5728(true); }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 81 */     velocityZ -= side.field_1350 * 0.25D * speed;
/* 82 */     velocityX -= side.field_1352 * 0.25D * speed;
/*    */     
/* 84 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1913.method_1434() && !(Onyx.Companion.getMC()).field_1724.method_5624()) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5728(true); }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 89 */     velocityZ += side.field_1350 * 0.25D * speed;
/* 90 */     velocityX += side.field_1352 * 0.25D * speed;
/*    */     
/* 92 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1849.method_1434() && !(Onyx.Companion.getMC()).field_1724.method_5624()) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5728(true); }
/*    */ 
/*    */ 
/*    */     
/* 96 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(velocityX, velocityY, velocityZ);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AutosprintModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */