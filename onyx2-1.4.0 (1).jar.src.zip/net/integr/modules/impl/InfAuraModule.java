/*     */ package net.integr.modules.impl;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.Ref;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.integr.utilities.game.interaction.AttackUtils;
/*     */ import net.integr.utilities.game.interaction.MovementUtil;
/*     */ import net.integr.utilities.game.pathfind.Path;
/*     */ import net.integr.utilities.game.pathfind.PathfindingManager;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\002\b\005\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\tJ\037\020\016\032\0020\0042\006\020\013\032\0020\n2\006\020\r\032\0020\fH\002¢\006\004\b\016\020\017J\027\020\020\032\0020\0042\006\020\013\032\0020\nH\002¢\006\004\b\020\020\021R\034\020\024\032\n \023*\004\030\0010\0220\0228\002X\004¢\006\006\n\004\b\024\020\025¨\006\026"}, d2 = {"Lnet/integr/modules/impl/InfAuraModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "Lnet/minecraft/class_1309;", "entity", "", "reset", "runOn", "(Lnet/minecraft/class_1309;Z)V", "runOnMace", "(Lnet/minecraft/class_1309;)V", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "service", "Ljava/util/concurrent/ExecutorService;", "onyx2"})
/*     */ public final class InfAuraModule extends Module {
/*     */   private final ExecutorService service;
/*     */   
/*     */   public InfAuraModule() {
/*  38 */     super("Infinite Aura", "Hit entities around you from very far", "infAura", Filter.Combat, false, 16, null);
/*     */     
/*  40 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  50 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(InfAuraModule.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)InfAuraModule.this.getSettings().getById("mode")).getElement());
/*  51 */             Intrinsics.checkNotNull(InfAuraModule.this.getSettings().getById("target")); $this$initHacklist.add(((CyclerSetting)InfAuraModule.this.getSettings().getById("target")).getElement());
/*  52 */             Intrinsics.checkNotNull(InfAuraModule.this.getSettings().getById("range")); $this$initHacklist.add("" + ((SliderSetting)InfAuraModule.this.getSettings().getById("range")).getSetValue() + "m");
/*     */           } }
/*     */       );
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     this.service = Executors.newSingleThreadExecutor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*     */     Variables.Companion.setTarget(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'event'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_0
/*     */     //   7: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   10: ldc 'mode'
/*     */     //   12: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   15: dup
/*     */     //   16: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   19: checkcast net/integr/modules/management/settings/impl/CyclerSetting
/*     */     //   22: invokevirtual getElement : ()Ljava/lang/String;
/*     */     //   25: astore_2
/*     */     //   26: aload_0
/*     */     //   27: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   30: ldc 'range'
/*     */     //   32: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   35: dup
/*     */     //   36: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   39: checkcast net/integr/modules/management/settings/impl/SliderSetting
/*     */     //   42: invokevirtual getSetValue : ()D
/*     */     //   45: dstore_3
/*     */     //   46: aload_0
/*     */     //   47: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   50: ldc 'target'
/*     */     //   52: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   55: dup
/*     */     //   56: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   59: checkcast net/integr/modules/management/settings/impl/CyclerSetting
/*     */     //   62: invokevirtual getElement : ()Ljava/lang/String;
/*     */     //   65: astore #5
/*     */     //   67: getstatic net/integr/utilities/game/entity/EntityFinder.Companion : Lnet/integr/utilities/game/entity/EntityFinder$Companion;
/*     */     //   70: dload_3
/*     */     //   71: aload #5
/*     */     //   73: iconst_0
/*     */     //   74: invokevirtual getClosestAuraEntity : (DLjava/lang/String;Z)Lnet/minecraft/class_1309;
/*     */     //   77: astore #6
/*     */     //   79: aload #6
/*     */     //   81: ifnull -> 285
/*     */     //   84: getstatic net/integr/utilities/game/interaction/AttackUtils.Companion : Lnet/integr/utilities/game/interaction/AttackUtils$Companion;
/*     */     //   87: invokevirtual canAttack : ()Z
/*     */     //   90: ifeq -> 285
/*     */     //   93: aload_0
/*     */     //   94: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   97: ldc 'sight'
/*     */     //   99: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   102: dup
/*     */     //   103: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   106: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   109: invokevirtual isEnabled : ()Z
/*     */     //   112: ifeq -> 140
/*     */     //   115: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   118: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   121: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   124: dup
/*     */     //   125: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   128: aload #6
/*     */     //   130: checkcast net/minecraft/class_1297
/*     */     //   133: invokevirtual method_6057 : (Lnet/minecraft/class_1297;)Z
/*     */     //   136: ifne -> 140
/*     */     //   139: return
/*     */     //   140: getstatic net/integr/Variables.Companion : Lnet/integr/Variables$Companion;
/*     */     //   143: aload #6
/*     */     //   145: invokevirtual setTarget : (Lnet/minecraft/class_1309;)V
/*     */     //   148: aload_2
/*     */     //   149: astore #7
/*     */     //   151: aload #7
/*     */     //   153: invokevirtual hashCode : ()I
/*     */     //   156: lookupswitch default -> 285, -1955878649 -> 218, 48571 -> 205, 2390294 -> 192
/*     */     //   192: aload #7
/*     */     //   194: ldc 'Mace'
/*     */     //   196: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   199: ifne -> 268
/*     */     //   202: goto -> 285
/*     */     //   205: aload #7
/*     */     //   207: ldc '1.8'
/*     */     //   209: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   212: ifne -> 248
/*     */     //   215: goto -> 285
/*     */     //   218: aload #7
/*     */     //   220: ldc 'Normal'
/*     */     //   222: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   225: ifeq -> 285
/*     */     //   228: aload_0
/*     */     //   229: getfield service : Ljava/util/concurrent/ExecutorService;
/*     */     //   232: aload_0
/*     */     //   233: aload #6
/*     */     //   235: <illegal opcode> run : (Lnet/integr/modules/impl/InfAuraModule;Lnet/minecraft/class_1309;)Ljava/lang/Runnable;
/*     */     //   240: invokeinterface execute : (Ljava/lang/Runnable;)V
/*     */     //   245: goto -> 285
/*     */     //   248: aload_0
/*     */     //   249: getfield service : Ljava/util/concurrent/ExecutorService;
/*     */     //   252: aload_0
/*     */     //   253: aload #6
/*     */     //   255: <illegal opcode> run : (Lnet/integr/modules/impl/InfAuraModule;Lnet/minecraft/class_1309;)Ljava/lang/Runnable;
/*     */     //   260: invokeinterface execute : (Ljava/lang/Runnable;)V
/*     */     //   265: goto -> 285
/*     */     //   268: aload_0
/*     */     //   269: getfield service : Ljava/util/concurrent/ExecutorService;
/*     */     //   272: aload_0
/*     */     //   273: aload #6
/*     */     //   275: <illegal opcode> run : (Lnet/integr/modules/impl/InfAuraModule;Lnet/minecraft/class_1309;)Ljava/lang/Runnable;
/*     */     //   280: invokeinterface execute : (Ljava/lang/Runnable;)V
/*     */     //   285: getstatic net/integr/Variables.Companion : Lnet/integr/Variables$Companion;
/*     */     //   288: invokevirtual getTarget : ()Lnet/minecraft/class_1309;
/*     */     //   291: ifnull -> 317
/*     */     //   294: getstatic net/integr/Variables.Companion : Lnet/integr/Variables$Companion;
/*     */     //   297: invokevirtual getTarget : ()Lnet/minecraft/class_1309;
/*     */     //   300: dup
/*     */     //   301: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   304: invokevirtual method_5805 : ()Z
/*     */     //   307: ifne -> 317
/*     */     //   310: getstatic net/integr/Variables.Companion : Lnet/integr/Variables$Companion;
/*     */     //   313: aconst_null
/*     */     //   314: invokevirtual setTarget : (Lnet/minecraft/class_1309;)V
/*     */     //   317: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #64	-> 6
/*     */     //   #65	-> 26
/*     */     //   #66	-> 46
/*     */     //   #68	-> 67
/*     */     //   #70	-> 79
/*     */     //   #71	-> 93
/*     */     //   #73	-> 140
/*     */     //   #75	-> 148
/*     */     //   #77	-> 228
/*     */     //   #83	-> 248
/*     */     //   #89	-> 268
/*     */     //   #98	-> 285
/*     */     //   #99	-> 317
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   26	292	2	mode	Ljava/lang/String;
/*     */     //   46	272	3	range	D
/*     */     //   67	251	5	target	Ljava/lang/String;
/*     */     //   79	239	6	entity	Lnet/minecraft/class_1309;
/*     */     //   0	318	0	this	Lnet/integr/modules/impl/InfAuraModule;
/*     */     //   0	318	1	event	Lnet/integr/event/PreTickEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void onTick$lambda$0(InfAuraModule this$0, class_1309 $entity) {
/*  78 */     Intrinsics.checkNotNullParameter(this$0, "this$0"); this$0.runOn($entity, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void onTick$lambda$1(InfAuraModule this$0, class_1309 $entity) {
/*  84 */     Intrinsics.checkNotNullParameter(this$0, "this$0"); this$0.runOn($entity, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void onTick$lambda$2(InfAuraModule this$0, class_1309 $entity) {
/*  90 */     Intrinsics.checkNotNullParameter(this$0, "this$0"); Intrinsics.checkNotNull(this$0.getSettings().getById("spoofGround")); if (((BooleanSetting)this$0.getSettings().getById("spoofGround")).isEnabled()) { Intrinsics.checkNotNull(this$0.getSettings().getById("maceHeight")); MovementUtil.Companion.spoofGroundOnlyFromDistance(((SliderSetting)this$0.getSettings().getById("maceHeight")).getSetValue()); }
/*     */     
/*  92 */     this$0.runOnMace($entity);
/*     */   } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"})
/*     */   static final class InfAuraModule$runOn$1 extends Lambda implements Function2<class_243, class_243, Unit> {
/*     */     public static final InfAuraModule$runOn$1 INSTANCE = new InfAuraModule$runOn$1(); public final void invoke(@NotNull class_243 param1class_2431, @NotNull class_243 current) {
/*     */       Intrinsics.checkNotNullParameter(param1class_2431, "<anonymous parameter 0>");
/*     */       Intrinsics.checkNotNullParameter(current, "current");
/*     */       MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null);
/*     */     } InfAuraModule$runOn$1() {
/*     */       super(2);
/*     */     } }
/* 102 */   private final void runOn(class_1309 entity, boolean reset) { Intrinsics.checkNotNullExpressionValue(entity.method_24515(), "getBlockPos(...)"); Path path = PathfindingManager.Companion.getPathToBlock$default(PathfindingManager.Companion, entity.method_24515(), null, 2, null);
/*     */     
/* 104 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(path.getPath().size() * 5.0D);
/*     */     
/* 106 */     Path.iterateAndRender$default(path, 0, 20, InfAuraModule$runOn$1.INSTANCE, 1, null);
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (reset) { AttackUtils.Companion.attack(entity, false); } else { AttackUtils.Companion.attackWithoutReset$default(AttackUtils.Companion, (class_1297)entity, false, false, 4, null); }
/*     */     
/* 112 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(path.getPath().size() * 5.0D);
/*     */     
/* 114 */     path.reversed().iterate(InfAuraModule$runOn$2.INSTANCE); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"})
/* 115 */   static final class InfAuraModule$runOn$2 extends Lambda implements Function2<class_243, class_243, Unit> { public static final InfAuraModule$runOn$2 INSTANCE = new InfAuraModule$runOn$2(); public final void invoke(@NotNull class_243 param1class_2431, @NotNull class_243 current) { Intrinsics.checkNotNullParameter(param1class_2431, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(current, "current"); MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null); }
/*     */     InfAuraModule$runOn$2() { super(2); } }
/*     */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"}) static final class InfAuraModule$runOnMace$1 extends Lambda implements Function2<class_243, class_243, Unit> {
/*     */     public final void invoke(@NotNull class_243 param1class_2431, @NotNull class_243 current) { Intrinsics.checkNotNullParameter(param1class_2431, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(current, "current"); this.$last.element = current;
/*     */       MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null); } InfAuraModule$runOnMace$1(Ref.ObjectRef<class_243> $last) { super(2); }
/* 120 */   } private final void runOnMace(class_1309 entity) { Intrinsics.checkNotNullExpressionValue(entity.method_24515(), "getBlockPos(...)"); Path path = PathfindingManager.Companion.getPathToBlock$default(PathfindingManager.Companion, entity.method_24515(), null, 2, null);
/*     */     
/* 122 */     Ref.ObjectRef<class_243> last = new Ref.ObjectRef(); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); last.element = (Onyx.Companion.getMC()).field_1724.method_19538();
/*     */     
/* 124 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(path.getPath().size() * 5.0D);
/*     */     
/* 126 */     Path.iterateAndRender$default(path, 0, 20, new InfAuraModule$runOnMace$1(last), 1, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     Intrinsics.checkNotNull(getSettings().getById("maceHeight")); double height = ((SliderSetting)getSettings().getById("maceHeight")).getSetValue();
/*     */     
/* 133 */     Intrinsics.checkNotNullExpressionValue(((class_243)last.element).method_1031(0.0D, height, 0.0D), "add(...)"); Highlighter.Companion.renderBlock$default(Highlighter.Companion, ((class_243)last.element).method_1031(0.0D, height, 0.0D), 0, 2, null);
/* 134 */     Intrinsics.checkNotNullExpressionValue(last.element, "element"); Highlighter.Companion.renderBlock$default(Highlighter.Companion, (class_243)last.element, 0, 2, null);
/*     */     
/* 136 */     Intrinsics.checkNotNullExpressionValue(last.element, "element"); Intrinsics.checkNotNullExpressionValue(((class_243)last.element).method_1031(0.0D, height, 0.0D), "add(...)"); Highlighter.Companion.renderLine$default(Highlighter.Companion, (class_243)last.element, ((class_243)last.element).method_1031(0.0D, height, 0.0D), 0, 0, 12, null);
/*     */     
/* 138 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(height * 2);
/*     */     
/* 140 */     Intrinsics.checkNotNullExpressionValue(((class_243)last.element).method_1031(0.0D, height, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(((class_243)last.element).method_1031(0.0D, height, 0.0D), true);
/* 141 */     Intrinsics.checkNotNullExpressionValue(((class_243)last.element).method_1031(0.0D, 0.0D, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(((class_243)last.element).method_1031(0.0D, 0.0D, 0.0D), true);
/* 142 */     Intrinsics.checkNotNullExpressionValue(((class_243)last.element).method_1031(0.0D, 0.0D, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(((class_243)last.element).method_1031(0.0D, 0.0D, 0.0D), true);
/*     */     
/* 144 */     AttackUtils.Companion.attack(entity, false);
/*     */     
/* 146 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(path.getPath().size() * 5.0D);
/*     */     
/* 148 */     path.reversed().iterate(InfAuraModule$runOnMace$2.INSTANCE); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"})
/* 149 */   static final class InfAuraModule$runOnMace$2 extends Lambda implements Function2<class_243, class_243, Unit> { public final void invoke(@NotNull class_243 param1class_2431, @NotNull class_243 current) { Intrinsics.checkNotNullParameter(param1class_2431, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(current, "current"); MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null); }
/*     */ 
/*     */     
/*     */     public static final InfAuraModule$runOnMace$2 INSTANCE = new InfAuraModule$runOnMace$2();
/*     */     
/*     */     InfAuraModule$runOnMace$2() {
/*     */       super(2);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\InfAuraModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */