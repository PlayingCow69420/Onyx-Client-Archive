/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Locale;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.impl.KeyBindSetting;
/*     */ import net.minecraft.class_124;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\003\030\0002\022\022\004\022\0020\0020\001j\b\022\004\022\0020\002`\003B\007¢\006\004\b\004\020\005J\037\020\t\032\0020\b2\006\020\006\032\0020\0022\006\020\007\032\0020\002H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\f2\006\020\013\032\0020\002H\002¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/modules/impl/HacklistModule$ModuleComparer;", "Ljava/util/Comparator;", "Lnet/integr/modules/management/Module;", "Lkotlin/Comparator;", "<init>", "()V", "o1", "o2", "", "compare", "(Lnet/integr/modules/management/Module;Lnet/integr/modules/management/Module;)I", "module", "", "getMnText", "(Lnet/integr/modules/management/Module;)Ljava/lang/String;", "onyx2"})
/*     */ public final class ModuleComparer
/*     */   implements Comparator<Module>
/*     */ {
/*     */   public int compare(@NotNull Module o1, @NotNull Module o2) {
/* 132 */     Intrinsics.checkNotNullParameter(o1, "o1"); Intrinsics.checkNotNullParameter(o2, "o2"); int l1 = (Onyx.Companion.getMC()).field_1772.method_1727(getMnText(o1));
/* 133 */     int l2 = (Onyx.Companion.getMC()).field_1772.method_1727(getMnText(o2));
/*     */     
/* 135 */     if (l1 < l2) return 1; 
/* 136 */     if (l1 > l2) return -1;
/*     */     
/* 138 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getMnText(Module module) {
/* 144 */     Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar()); Intrinsics.checkNotNullExpressionValue(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar().toUpperCase(Locale.ROOT), "toUpperCase(...)"); return module.getDisplayName() + module.getDisplayName() + class_124.field_1080 + Module.getHacklistData$default(module, false, 1, null) + class_124.field_1063;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HacklistModule$ModuleComparer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */