/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.integr.utilities.game.pausers.CombatPauser;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\tR\026\020\013\032\0020\n8\002@\002X\016¢\006\006\n\004\b\013\020\f¨\006\r"}, d2 = {"Lnet/integr/modules/impl/AutoGapModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "", "pre", "I", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nAutoGapModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AutoGapModule.kt\nnet/integr/modules/impl/AutoGapModule\n+ 2 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n*L\n1#1,90:1\n71#2,7:91\n*S KotlinDebug\n*F\n+ 1 AutoGapModule.kt\nnet/integr/modules/impl/AutoGapModule\n*L\n55#1:91,7\n*E\n"})
/*    */ public final class AutoGapModule
/*    */   extends Module
/*    */ {
/*    */   private int pre;
/*    */   
/*    */   public AutoGapModule() {
/* 33 */     super("Auto Gap", "Automatically eats an golden apple when you're low on health", "autoGap", Filter.Util, false, 16, null);
/*    */     
/* 35 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 42 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(AutoGapModule.this.getSettings().getById("health")); $this$initHacklist.add("" + ((SliderSetting)AutoGapModule.this.getSettings().getById("health")).getSetValue() + "hp");
/*    */           } }
/*    */       );
/*    */     
/* 46 */     this.pre = -1;
/*    */   }
/*    */   public void onDisable() {
/* 49 */     CombatPauser.Companion.resume();
/* 50 */     (Onyx.Companion.getMC()).field_1690.field_1904.method_23481(false);
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PreTickEvent event) {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: ldc 'event'
/*    */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   6: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*    */     //   9: astore_2
/*    */     //   10: iconst_0
/*    */     //   11: istore_3
/*    */     //   12: aload_2
/*    */     //   13: invokevirtual getModules : ()Ljava/util/List;
/*    */     //   16: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   21: astore #4
/*    */     //   23: aload #4
/*    */     //   25: invokeinterface hasNext : ()Z
/*    */     //   30: ifeq -> 83
/*    */     //   33: aload #4
/*    */     //   35: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   40: checkcast net/integr/modules/management/Module
/*    */     //   43: astore #5
/*    */     //   45: aload #5
/*    */     //   47: invokevirtual getClass : ()Ljava/lang/Class;
/*    */     //   50: ldc net/integr/modules/impl/AutoMendModule
/*    */     //   52: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   55: ifeq -> 23
/*    */     //   58: aload #5
/*    */     //   60: dup
/*    */     //   61: ifnonnull -> 74
/*    */     //   64: new java/lang/NullPointerException
/*    */     //   67: dup
/*    */     //   68: ldc 'null cannot be cast to non-null type net.integr.modules.impl.AutoMendModule'
/*    */     //   70: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   73: athrow
/*    */     //   74: checkcast net/integr/modules/impl/AutoMendModule
/*    */     //   77: checkcast net/integr/modules/management/Module
/*    */     //   80: goto -> 84
/*    */     //   83: aconst_null
/*    */     //   84: dup
/*    */     //   85: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   88: checkcast net/integr/modules/impl/AutoMendModule
/*    */     //   91: invokevirtual isEnabled : ()Z
/*    */     //   94: ifeq -> 98
/*    */     //   97: return
/*    */     //   98: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   101: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   104: getfield field_1724 : Lnet/minecraft/class_746;
/*    */     //   107: dup
/*    */     //   108: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   111: invokevirtual method_6032 : ()F
/*    */     //   114: f2d
/*    */     //   115: aload_0
/*    */     //   116: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*    */     //   119: ldc 'health'
/*    */     //   121: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*    */     //   124: dup
/*    */     //   125: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   128: checkcast net/integr/modules/management/settings/impl/SliderSetting
/*    */     //   131: invokevirtual getSetValue : ()D
/*    */     //   134: dcmpg
/*    */     //   135: ifge -> 304
/*    */     //   138: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   141: getstatic net/minecraft/class_1802.field_8367 : Lnet/minecraft/class_1792;
/*    */     //   144: dup
/*    */     //   145: ldc 'ENCHANTED_GOLDEN_APPLE'
/*    */     //   147: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   150: invokevirtual findInHotbar : (Lnet/minecraft/class_1792;)I
/*    */     //   153: istore_2
/*    */     //   154: iload_2
/*    */     //   155: iconst_m1
/*    */     //   156: if_icmpne -> 175
/*    */     //   159: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   162: getstatic net/minecraft/class_1802.field_8463 : Lnet/minecraft/class_1792;
/*    */     //   165: dup
/*    */     //   166: ldc 'GOLDEN_APPLE'
/*    */     //   168: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   171: invokevirtual findInHotbar : (Lnet/minecraft/class_1792;)I
/*    */     //   174: istore_2
/*    */     //   175: iload_2
/*    */     //   176: iconst_m1
/*    */     //   177: if_icmpeq -> 259
/*    */     //   180: aload_0
/*    */     //   181: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*    */     //   184: ldc 'pauseCombat'
/*    */     //   186: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*    */     //   189: dup
/*    */     //   190: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   193: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*    */     //   196: invokevirtual isEnabled : ()Z
/*    */     //   199: ifeq -> 208
/*    */     //   202: getstatic net/integr/utilities/game/pausers/CombatPauser.Companion : Lnet/integr/utilities/game/pausers/CombatPauser$Companion;
/*    */     //   205: invokevirtual pause : ()V
/*    */     //   208: aload_0
/*    */     //   209: getfield pre : I
/*    */     //   212: iconst_m1
/*    */     //   213: if_icmpne -> 226
/*    */     //   216: aload_0
/*    */     //   217: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   220: invokevirtual getSelectedSlot : ()I
/*    */     //   223: putfield pre : I
/*    */     //   226: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   229: iload_2
/*    */     //   230: invokevirtual selectSlotPacket : (I)V
/*    */     //   233: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   236: iload_2
/*    */     //   237: invokevirtual selectSlot : (I)V
/*    */     //   240: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   243: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   246: getfield field_1690 : Lnet/minecraft/class_315;
/*    */     //   249: getfield field_1904 : Lnet/minecraft/class_304;
/*    */     //   252: iconst_1
/*    */     //   253: invokevirtual method_23481 : (Z)V
/*    */     //   256: goto -> 359
/*    */     //   259: getstatic net/integr/utilities/game/pausers/CombatPauser.Companion : Lnet/integr/utilities/game/pausers/CombatPauser$Companion;
/*    */     //   262: invokevirtual resume : ()V
/*    */     //   265: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   268: aload_0
/*    */     //   269: getfield pre : I
/*    */     //   272: invokevirtual selectSlotPacket : (I)V
/*    */     //   275: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   278: aload_0
/*    */     //   279: getfield pre : I
/*    */     //   282: invokevirtual selectSlot : (I)V
/*    */     //   285: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   288: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   291: getfield field_1690 : Lnet/minecraft/class_315;
/*    */     //   294: getfield field_1904 : Lnet/minecraft/class_304;
/*    */     //   297: iconst_0
/*    */     //   298: invokevirtual method_23481 : (Z)V
/*    */     //   301: goto -> 359
/*    */     //   304: aload_0
/*    */     //   305: getfield pre : I
/*    */     //   308: iconst_m1
/*    */     //   309: if_icmpeq -> 359
/*    */     //   312: getstatic net/integr/utilities/game/pausers/CombatPauser.Companion : Lnet/integr/utilities/game/pausers/CombatPauser$Companion;
/*    */     //   315: invokevirtual resume : ()V
/*    */     //   318: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   321: aload_0
/*    */     //   322: getfield pre : I
/*    */     //   325: invokevirtual selectSlotPacket : (I)V
/*    */     //   328: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*    */     //   331: aload_0
/*    */     //   332: getfield pre : I
/*    */     //   335: invokevirtual selectSlot : (I)V
/*    */     //   338: aload_0
/*    */     //   339: iconst_m1
/*    */     //   340: putfield pre : I
/*    */     //   343: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   346: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   349: getfield field_1690 : Lnet/minecraft/class_315;
/*    */     //   352: getfield field_1904 : Lnet/minecraft/class_304;
/*    */     //   355: iconst_0
/*    */     //   356: invokevirtual method_23481 : (Z)V
/*    */     //   359: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #55	-> 6
/*    */     //   #91	-> 12
/*    */     //   #92	-> 45
/*    */     //   #93	-> 58
/*    */     //   #97	-> 83
/*    */     //   #55	-> 84
/*    */     //   #57	-> 98
/*    */     //   #58	-> 138
/*    */     //   #60	-> 154
/*    */     //   #62	-> 175
/*    */     //   #63	-> 180
/*    */     //   #64	-> 202
/*    */     //   #67	-> 208
/*    */     //   #69	-> 226
/*    */     //   #70	-> 233
/*    */     //   #72	-> 240
/*    */     //   #74	-> 259
/*    */     //   #75	-> 265
/*    */     //   #76	-> 275
/*    */     //   #78	-> 285
/*    */     //   #80	-> 304
/*    */     //   #81	-> 312
/*    */     //   #82	-> 318
/*    */     //   #83	-> 328
/*    */     //   #85	-> 338
/*    */     //   #87	-> 343
/*    */     //   #89	-> 359
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   45	38	5	m$iv	Lnet/integr/modules/management/Module;
/*    */     //   12	72	3	$i$f$getByClass	I
/*    */     //   10	74	2	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*    */     //   154	147	2	slot	I
/*    */     //   0	360	0	this	Lnet/integr/modules/impl/AutoGapModule;
/*    */     //   0	360	1	event	Lnet/integr/event/PreTickEvent;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AutoGapModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */