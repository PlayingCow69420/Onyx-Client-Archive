/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.ApplySwingOffsetEvent;
/*    */ import net.integr.event.GetHandSwingDurationEvent;
/*    */ import net.integr.event.RenderHeldItemEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_7833;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\007\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013J\027\020\r\032\0020\0062\006\020\005\032\0020\fH\007¢\006\004\b\r\020\016J\037\020\023\032\0020\0062\006\020\020\032\0020\0172\006\020\022\032\0020\021H\002¢\006\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/AnimationsModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/ApplySwingOffsetEvent;", "event", "", "onApplySwingOffset", "(Lnet/integr/event/ApplySwingOffsetEvent;)V", "Lnet/integr/event/GetHandSwingDurationEvent;", "onGetHandSwingDuration", "(Lnet/integr/event/GetHandSwingDurationEvent;)V", "Lnet/integr/event/RenderHeldItemEvent;", "onRenderArmOrItem", "(Lnet/integr/event/RenderHeldItemEvent;)V", "Lnet/minecraft/class_4587;", "stack", "", "delta", "transformStack", "(Lnet/minecraft/class_4587;F)V", "onyx2"})
/*    */ public final class AnimationsModule
/*    */   extends Module
/*    */ {
/*    */   public AnimationsModule() {
/* 38 */     super("Animations", "Changes your swing animation", "animations", Filter.Render, false, 16, null);
/*    */     
/* 40 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 45 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 46 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(AnimationsModule.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)AnimationsModule.this.getSettings().getById("mode")).getElement());
/*    */           } }
/*    */       );
/*    */   }
/*    */   @EventListen(prio = Priority.LAST)
/*    */   public final void onGetHandSwingDuration(@NotNull GetHandSwingDurationEvent event) {
/* 52 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("slow")); if (((BooleanSetting)getSettings().getById("slow")).isEnabled()) {
/* 53 */       event.setCallback(Integer.valueOf(20));
/*    */     }
/*    */   }
/*    */   
/*    */   @EventListen(prio = Priority.LAST)
/*    */   public final void onRenderArmOrItem(@NotNull RenderHeldItemEvent event) {
/* 59 */     Intrinsics.checkNotNullParameter(event, "event"); if (event.hand == class_1268.field_5808) { Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); transformStack(event.matrices, event.tickDelta); }
/*    */   
/*    */   }
/*    */   @EventListen
/*    */   public final void onApplySwingOffset(@NotNull ApplySwingOffsetEvent event) {
/* 64 */     Intrinsics.checkNotNullParameter(event, "event"); event.cancel();
/*    */   }
/*    */   
/*    */   private final void transformStack(class_4587 stack, float delta) {
/* 68 */     Intrinsics.checkNotNull(getSettings().getById("mode")); String mode = ((CyclerSetting)getSettings().getById("mode")).getElement();
/*    */     
/* 70 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double swingProg = Math.sin((float)Math.sqrt((Onyx.Companion.getMC()).field_1724.method_6055(delta)) * Math.PI) * 10;
/*    */     
/* 72 */     String str1 = mode; switch (str1.hashCode()) { case 1750431735: if (!str1.equals("Helicopter")) {
/*    */           break;
/*    */         }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 83 */         stack.method_22907(class_7833.field_40718.rotationDegrees(30.0F * (float)swingProg)); break;case 63408307: if (!str1.equals("Angle"))
/*    */           break;  stack.method_22907(class_7833.field_40713.rotationDegrees((float)swingProg * 8)); break;case 2404337: if (!str1.equals("Move"))
/*    */           break;  stack.method_22907(class_7833.field_40713.rotationDegrees((float)swingProg * 8)); stack.method_22904(0.0D, swingProg / 14, 0.0D); break;
/*    */       case 64279661: if (!str1.equals("Block"))
/* 87 */           break;  if (swingProg > 1.0D) stack.method_22907(class_7833.field_40716.rotationDegrees(40.0F)); 
/* 88 */         stack.method_22907(class_7833.field_40713.rotationDegrees((float)swingProg * 14));
/* 89 */         stack.method_22904(swingProg / 10, 0.0D, 0.0D);
/*    */         break; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AnimationsModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */