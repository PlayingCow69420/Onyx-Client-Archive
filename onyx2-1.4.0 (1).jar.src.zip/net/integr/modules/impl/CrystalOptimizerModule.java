/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.AttackEvent;
/*     */ import net.integr.event.SendPacketEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1293;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1831;
/*     */ import net.minecraft.class_1832;
/*     */ import net.minecraft.class_1834;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2824;
/*     */ import net.minecraft.class_3966;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\004\030\0002\0020\001:\001\fB\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013¨\006\r"}, d2 = {"Lnet/integr/modules/impl/CrystalOptimizerModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/AttackEvent;", "event", "", "onAttack", "(Lnet/integr/event/AttackEvent;)V", "Lnet/integr/event/SendPacketEvent;", "onPacket", "(Lnet/integr/event/SendPacketEvent;)V", "EntityHandler", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nCrystalOptimizerModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CrystalOptimizerModule.kt\nnet/integr/modules/impl/CrystalOptimizerModule\n+ 2 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n*L\n1#1,120:1\n71#2,7:121\n71#2,7:128\n*S KotlinDebug\n*F\n+ 1 CrystalOptimizerModule.kt\nnet/integr/modules/impl/CrystalOptimizerModule\n*L\n51#1:121,7\n69#1:128,7\n*E\n"})
/*     */ public final class CrystalOptimizerModule
/*     */   extends Module
/*     */ {
/*     */   public CrystalOptimizerModule() {
/*  42 */     super("Optimizer", "Increases crystal speed by removing crystals clientside after they were hit", "optimizer", Filter.Combat, false, 16, null);
/*     */     
/*  44 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onPacket(@NotNull SendPacketEvent event) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'event'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   9: astore_2
/*     */     //   10: iconst_0
/*     */     //   11: istore_3
/*     */     //   12: aload_2
/*     */     //   13: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   16: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   21: astore #4
/*     */     //   23: aload #4
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 83
/*     */     //   33: aload #4
/*     */     //   35: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   40: checkcast net/integr/modules/management/Module
/*     */     //   43: astore #5
/*     */     //   45: aload #5
/*     */     //   47: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   50: ldc net/integr/modules/impl/CrystalAuraModule
/*     */     //   52: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   55: ifeq -> 23
/*     */     //   58: aload #5
/*     */     //   60: dup
/*     */     //   61: ifnonnull -> 74
/*     */     //   64: new java/lang/NullPointerException
/*     */     //   67: dup
/*     */     //   68: ldc 'null cannot be cast to non-null type net.integr.modules.impl.CrystalAuraModule'
/*     */     //   70: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   73: athrow
/*     */     //   74: checkcast net/integr/modules/impl/CrystalAuraModule
/*     */     //   77: checkcast net/integr/modules/management/Module
/*     */     //   80: goto -> 84
/*     */     //   83: aconst_null
/*     */     //   84: dup
/*     */     //   85: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   88: checkcast net/integr/modules/impl/CrystalAuraModule
/*     */     //   91: invokevirtual isEnabled : ()Z
/*     */     //   94: ifeq -> 98
/*     */     //   97: return
/*     */     //   98: aload_1
/*     */     //   99: getfield packet : Lnet/minecraft/class_2596;
/*     */     //   102: astore_2
/*     */     //   103: aload_2
/*     */     //   104: instanceof net/minecraft/class_2824
/*     */     //   107: ifeq -> 164
/*     */     //   110: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   113: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   116: getfield field_1765 : Lnet/minecraft/class_239;
/*     */     //   119: astore_3
/*     */     //   120: aload_3
/*     */     //   121: ifnull -> 164
/*     */     //   124: aload_3
/*     */     //   125: invokevirtual method_17783 : ()Lnet/minecraft/class_239$class_240;
/*     */     //   128: getstatic net/minecraft/class_239$class_240.field_1331 : Lnet/minecraft/class_239$class_240;
/*     */     //   131: if_acmpne -> 164
/*     */     //   134: aload_3
/*     */     //   135: checkcast net/minecraft/class_3966
/*     */     //   138: invokevirtual method_17782 : ()Lnet/minecraft/class_1297;
/*     */     //   141: instanceof net/minecraft/class_1511
/*     */     //   144: ifeq -> 164
/*     */     //   147: aload_2
/*     */     //   148: checkcast net/minecraft/class_2824
/*     */     //   151: new net/integr/modules/impl/CrystalOptimizerModule$EntityHandler
/*     */     //   154: dup
/*     */     //   155: invokespecial <init> : ()V
/*     */     //   158: checkcast net/minecraft/class_2824$class_5908
/*     */     //   161: invokevirtual method_34209 : (Lnet/minecraft/class_2824$class_5908;)V
/*     */     //   164: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #51	-> 6
/*     */     //   #121	-> 12
/*     */     //   #122	-> 45
/*     */     //   #123	-> 58
/*     */     //   #127	-> 83
/*     */     //   #51	-> 84
/*     */     //   #53	-> 98
/*     */     //   #55	-> 103
/*     */     //   #56	-> 110
/*     */     //   #57	-> 120
/*     */     //   #58	-> 124
/*     */     //   #59	-> 134
/*     */     //   #60	-> 147
/*     */     //   #65	-> 164
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   45	38	5	m$iv	Lnet/integr/modules/management/Module;
/*     */     //   12	72	3	$i$f$getByClass	I
/*     */     //   10	74	2	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   120	44	3	hitResult	Lnet/minecraft/class_239;
/*     */     //   103	62	2	packet	Lnet/minecraft/class_2596;
/*     */     //   0	165	0	this	Lnet/integr/modules/impl/CrystalOptimizerModule;
/*     */     //   0	165	1	event	Lnet/integr/event/SendPacketEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onAttack(@NotNull AttackEvent event) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'event'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   9: astore_2
/*     */     //   10: iconst_0
/*     */     //   11: istore_3
/*     */     //   12: aload_2
/*     */     //   13: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   16: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   21: astore #4
/*     */     //   23: aload #4
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 83
/*     */     //   33: aload #4
/*     */     //   35: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   40: checkcast net/integr/modules/management/Module
/*     */     //   43: astore #5
/*     */     //   45: aload #5
/*     */     //   47: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   50: ldc net/integr/modules/impl/CrystalAuraModule
/*     */     //   52: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   55: ifeq -> 23
/*     */     //   58: aload #5
/*     */     //   60: dup
/*     */     //   61: ifnonnull -> 74
/*     */     //   64: new java/lang/NullPointerException
/*     */     //   67: dup
/*     */     //   68: ldc 'null cannot be cast to non-null type net.integr.modules.impl.CrystalAuraModule'
/*     */     //   70: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   73: athrow
/*     */     //   74: checkcast net/integr/modules/impl/CrystalAuraModule
/*     */     //   77: checkcast net/integr/modules/management/Module
/*     */     //   80: goto -> 84
/*     */     //   83: aconst_null
/*     */     //   84: dup
/*     */     //   85: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   88: checkcast net/integr/modules/impl/CrystalAuraModule
/*     */     //   91: invokevirtual isEnabled : ()Z
/*     */     //   94: ifeq -> 98
/*     */     //   97: return
/*     */     //   98: aload_0
/*     */     //   99: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   102: ldc 'mineBlock'
/*     */     //   104: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   107: dup
/*     */     //   108: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   111: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   114: invokevirtual isEnabled : ()Z
/*     */     //   117: ifeq -> 238
/*     */     //   120: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   123: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   126: getfield field_1765 : Lnet/minecraft/class_239;
/*     */     //   129: astore_2
/*     */     //   130: aload_2
/*     */     //   131: dup
/*     */     //   132: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   135: invokevirtual method_17783 : ()Lnet/minecraft/class_239$class_240;
/*     */     //   138: getstatic net/minecraft/class_239$class_240.field_1332 : Lnet/minecraft/class_239$class_240;
/*     */     //   141: if_acmpne -> 238
/*     */     //   144: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   147: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   150: getfield field_1687 : Lnet/minecraft/class_638;
/*     */     //   153: dup
/*     */     //   154: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   157: aload_2
/*     */     //   158: checkcast net/minecraft/class_3965
/*     */     //   161: invokevirtual method_17777 : ()Lnet/minecraft/class_2338;
/*     */     //   164: invokevirtual method_8320 : (Lnet/minecraft/class_2338;)Lnet/minecraft/class_2680;
/*     */     //   167: invokevirtual method_26204 : ()Lnet/minecraft/class_2248;
/*     */     //   170: astore_3
/*     */     //   171: aload_3
/*     */     //   172: getstatic net/minecraft/class_2246.field_10540 : Lnet/minecraft/class_2248;
/*     */     //   175: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   178: ifne -> 191
/*     */     //   181: aload_3
/*     */     //   182: getstatic net/minecraft/class_2246.field_9987 : Lnet/minecraft/class_2248;
/*     */     //   185: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   188: ifeq -> 238
/*     */     //   191: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   194: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   197: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   200: dup
/*     */     //   201: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   204: invokevirtual method_31548 : ()Lnet/minecraft/class_1661;
/*     */     //   207: invokevirtual method_7391 : ()Lnet/minecraft/class_1799;
/*     */     //   210: invokevirtual method_7909 : ()Lnet/minecraft/class_1792;
/*     */     //   213: getstatic net/minecraft/class_1802.field_8301 : Lnet/minecraft/class_1792;
/*     */     //   216: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   219: ifeq -> 238
/*     */     //   222: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   225: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   228: getfield field_1690 : Lnet/minecraft/class_315;
/*     */     //   231: getfield field_1886 : Lnet/minecraft/class_304;
/*     */     //   234: iconst_0
/*     */     //   235: invokevirtual method_23481 : (Z)V
/*     */     //   238: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #69	-> 6
/*     */     //   #128	-> 12
/*     */     //   #129	-> 45
/*     */     //   #130	-> 58
/*     */     //   #134	-> 83
/*     */     //   #69	-> 84
/*     */     //   #71	-> 98
/*     */     //   #72	-> 120
/*     */     //   #73	-> 130
/*     */     //   #74	-> 144
/*     */     //   #76	-> 171
/*     */     //   #77	-> 191
/*     */     //   #81	-> 238
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   45	38	5	m$iv	Lnet/integr/modules/management/Module;
/*     */     //   12	72	3	$i$f$getByClass	I
/*     */     //   10	74	2	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   171	67	3	block	Lnet/minecraft/class_2248;
/*     */     //   130	108	2	hitResult	Lnet/minecraft/class_239;
/*     */     //   0	239	0	this	Lnet/integr/modules/impl/CrystalOptimizerModule;
/*     */     //   0	239	1	event	Lnet/integr/event/AttackEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\026¢\006\004\b\b\020\tJ\037\020\f\032\0020\0042\006\020\007\032\0020\0062\006\020\013\032\0020\nH\026¢\006\004\b\f\020\rJ\027\020\021\032\0020\0202\006\020\017\032\0020\016H\002¢\006\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/CrystalOptimizerModule$EntityHandler;", "Lnet/minecraft/class_2824$class_5908;", "<init>", "()V", "", "attack", "Lnet/minecraft/class_1268;", "hand", "interact", "(Lnet/minecraft/class_1268;)V", "Lnet/minecraft/class_243;", "pos", "interactAt", "(Lnet/minecraft/class_1268;Lnet/minecraft/class_243;)V", "Lnet/minecraft/class_1799;", "itemStack", "", "isTool", "(Lnet/minecraft/class_1799;)Z", "onyx2"})
/*     */   public static final class EntityHandler
/*     */     implements class_2824.class_5908
/*     */   {
/*     */     public void method_34219(@NotNull class_1268 hand) {
/*  84 */       Intrinsics.checkNotNullParameter(hand, "hand"); } public void method_34220(@NotNull class_1268 hand, @NotNull class_243 pos) {
/*  85 */       Intrinsics.checkNotNullParameter(hand, "hand"); Intrinsics.checkNotNullParameter(pos, "pos");
/*     */     }
/*     */     public void method_34218() {
/*  88 */       class_239 hitResult = (Onyx.Companion.getMC()).field_1765;
/*  89 */       if (hitResult != null && 
/*  90 */         hitResult.method_17783() == class_239.class_240.field_1331) {
/*  91 */         class_3966 entityHitResult = (class_3966)hitResult;
/*  92 */         class_1297 entity = entityHitResult.method_17782();
/*     */         
/*  94 */         if (entity instanceof net.minecraft.class_1511) {
/*  95 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1293 weakness = (Onyx.Companion.getMC()).field_1724.method_6112(class_1294.field_5911);
/*  96 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1293 strength = (Onyx.Companion.getMC()).field_1724.method_6112(class_1294.field_5910);
/*     */           
/*  98 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_6047(), "getMainHandStack(...)"); if (weakness != null && (strength == null || strength.method_5578() <= weakness.method_5578()) && !isTool((Onyx.Companion.getMC()).field_1724.method_6047())) {
/*     */             return;
/*     */           }
/*     */           
/* 102 */           entity.method_5768();
/* 103 */           entity.method_31745(class_1297.class_5529.field_26998);
/* 104 */           entity.method_36209();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean isTool(class_1799 itemStack) {
/* 112 */       if (itemStack.method_7909() instanceof class_1831 && !(itemStack.method_7909() instanceof net.minecraft.class_1794)) {
/* 113 */         Intrinsics.checkNotNull(itemStack.method_7909(), "null cannot be cast to non-null type net.minecraft.item.ToolItem"); class_1832 material = ((class_1831)itemStack.method_7909()).method_8022();
/* 114 */         return (material == class_1834.field_8930 || material == class_1834.field_22033);
/*     */       } 
/* 116 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CrystalOptimizerModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */