/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.KeyEvent;
/*     */ import net.integr.event.PreMoveEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.KeyBindSetting;
/*     */ import net.integr.utilities.game.notification.NotificationHandler;
/*     */ import net.integr.utilities.game.polar.PolarSystem;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\006\n\002\b\002\n\002\020\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\037\020\b\032\0020\0072\006\020\005\032\0020\0042\006\020\006\032\0020\004H\002¢\006\004\b\b\020\tJ\017\020\n\032\0020\007H\026¢\006\004\b\n\020\003J\017\020\013\032\0020\007H\026¢\006\004\b\013\020\003J\027\020\016\032\0020\0072\006\020\r\032\0020\fH\026¢\006\004\b\016\020\017J\027\020\021\032\0020\0072\006\020\r\032\0020\020H\007¢\006\004\b\021\020\022R\026\020\024\032\0020\0238\002@\002X\016¢\006\006\n\004\b\024\020\025R\026\020\026\032\0020\0238\002@\002X\016¢\006\006\n\004\b\026\020\025¨\006\027"}, d2 = {"Lnet/integr/modules/impl/FlightModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "speed", "hSpeed", "", "doFly", "(DD)V", "onDisable", "onEnable", "Lnet/integr/event/KeyEvent;", "event", "onKeyEvent", "(Lnet/integr/event/KeyEvent;)V", "Lnet/integr/event/PreMoveEvent;", "onPreMove", "(Lnet/integr/event/PreMoveEvent;)V", "", "flightSpeedMode", "I", "floatingTime", "onyx2"})
/*     */ public final class FlightModule
/*     */   extends Module
/*     */ {
/*     */   private int flightSpeedMode;
/*     */   private int floatingTime;
/*     */   
/*     */   public FlightModule() {
/*  33 */     super("Flight", "Makes you fly", "flight", Filter.Move, false, 16, null);
/*     */     
/*  35 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.flightSpeedMode = 1;
/*     */   }
/*     */   
/*     */   public void onKeyEvent(@NotNull KeyEvent event) {
/*  44 */     Intrinsics.checkNotNullParameter(event, "event"); if (event.action == 1) { Intrinsics.checkNotNull(getSettings().getById("speedBind")); if (((KeyBindSetting)getSettings().getById("speedBind")).getBind() == null) { ((KeyBindSetting)getSettings().getById("speedBind")).getBind(); ((KeyBindSetting)getSettings().getById("speedBind")).getBind(); } else if (((KeyBindSetting)getSettings().getById("speedBind")).getBind() == ((KeyBindSetting)getSettings().getById("speedBind")).getBind().intValue())
/*  45 */       { if (this.flightSpeedMode == 10) { this.flightSpeedMode = 1; }
/*  46 */         else { int i = this.flightSpeedMode; this.flightSpeedMode = i + 1; }
/*     */         
/*  48 */         NotificationHandler.Companion.notify("Flight speed " + this.flightSpeedMode); }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {}
/*     */ 
/*     */   
/*     */   public void onDisable() {}
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onPreMove(@NotNull PreMoveEvent event) {
/*  62 */     Intrinsics.checkNotNullParameter(event, "event"); doFly(0.4D * this.flightSpeedMode, 0.4D * this.flightSpeedMode);
/*     */     
/*  64 */     switch (this.floatingTime) {
/*     */       case 20:
/*  66 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5762(0.0D, -0.04D, 0.0D);
/*  67 */         this.floatingTime = 0;
/*     */         return;
/*     */       case 2:
/*  70 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5762(0.0D, 0.04D, 0.0D);
/*  71 */         i = this.floatingTime; this.floatingTime = i + 1; return;
/*     */     } 
/*  73 */     int i = this.floatingTime; this.floatingTime = i + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private final void doFly(double speed, double hSpeed) {
/*  78 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.field_28627 = 0.06F;
/*  79 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(0.0D, (Onyx.Companion.getMC()).field_1724.method_18798().method_10214(), 0.0D);
/*     */     
/*  81 */     double velocityX = 0.0D;
/*  82 */     double velocityY = 0.0D;
/*  83 */     double velocityZ = 0.0D;
/*     */     
/*  85 */     class_243 side = PolarSystem.Companion.getSide();
/*  86 */     class_243 forward = PolarSystem.Companion.getForward();
/*     */     
/*  88 */     if ((Onyx.Companion.getMC()).field_1690.field_1894.method_1434()) {
/*  89 */       velocityX += forward.field_1352 * speed;
/*  90 */       velocityZ += forward.field_1350 * speed;
/*     */     } 
/*     */     
/*  93 */     if ((Onyx.Companion.getMC()).field_1690.field_1881.method_1434()) {
/*  94 */       velocityX -= forward.field_1352 * speed;
/*  95 */       velocityZ -= forward.field_1350 * speed;
/*     */     } 
/*     */     
/*  98 */     if ((Onyx.Companion.getMC()).field_1690.field_1913.method_1434()) {
/*  99 */       velocityZ -= side.field_1350 * speed;
/* 100 */       velocityX -= side.field_1352 * speed;
/*     */     } 
/*     */     
/* 103 */     if ((Onyx.Companion.getMC()).field_1690.field_1849.method_1434()) {
/* 104 */       velocityZ += side.field_1350 * speed;
/* 105 */       velocityX += side.field_1352 * speed;
/*     */     } 
/*     */     
/* 108 */     if ((Onyx.Companion.getMC()).field_1690.field_1903.method_1434()) {
/* 109 */       velocityY += hSpeed;
/*     */     }
/*     */     
/* 112 */     if ((Onyx.Companion.getMC()).field_1690.field_1832.method_1434()) {
/* 113 */       velocityY -= hSpeed;
/*     */     }
/*     */     
/* 116 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_18800(velocityX, velocityY, velocityZ);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\FlightModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */