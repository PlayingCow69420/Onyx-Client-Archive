/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.ExplosionVelocityEvent;
/*    */ import net.integr.event.PushOutOfBlocksEvent;
/*    */ import net.integr.event.ReceivePacketEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.minecraft.class_1927;
/*    */ import net.minecraft.class_1937;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013J\027\020\r\032\0020\0062\006\020\005\032\0020\fH\007¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/modules/impl/VelocityModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/ExplosionVelocityEvent;", "event", "", "onExplosionVelocity", "(Lnet/integr/event/ExplosionVelocityEvent;)V", "Lnet/integr/event/ReceivePacketEvent;", "onPacket", "(Lnet/integr/event/ReceivePacketEvent;)V", "Lnet/integr/event/PushOutOfBlocksEvent;", "onPushOutOfBlock", "(Lnet/integr/event/PushOutOfBlocksEvent;)V", "onyx2"})
/*    */ public final class VelocityModule
/*    */   extends Module
/*    */ {
/*    */   public VelocityModule() {
/* 33 */     super("Velocity", "Take no knockback", "velocity", Filter.Move, false, 16, null);
/*    */     
/* 35 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onPacket(@NotNull ReceivePacketEvent event) {
/* 42 */     Intrinsics.checkNotNullParameter(event, "event"); if (event.packet instanceof net.minecraft.class_2743) {
/* 43 */       event.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onExplosionVelocity(@NotNull ExplosionVelocityEvent event) {
/* 49 */     Intrinsics.checkNotNullParameter(event, "event"); event.cancel();
/*    */     
/* 51 */     class_1927 explosion = new class_1927(
/* 52 */         (class_1937)(Onyx.Companion.getMC()).field_1687, 
/* 53 */         null, 
/* 54 */         event.packet.method_11475(), 
/* 55 */         event.packet.method_11477(), 
/* 56 */         event.packet.method_11478(), 
/* 57 */         event.packet.method_11476(), 
/* 58 */         event.packet.method_11479(), 
/* 59 */         event.packet.method_55328(), 
/* 60 */         event.packet.method_55329(), 
/* 61 */         event.packet.method_55330(), 
/* 62 */         event.packet.method_55331());
/*    */ 
/*    */     
/* 65 */     explosion.method_8350(true);
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onPushOutOfBlock(@NotNull PushOutOfBlocksEvent event) {
/* 70 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("blocks")); if (((BooleanSetting)getSettings().getById("blocks")).isEnabled())
/* 71 */       event.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\VelocityModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */