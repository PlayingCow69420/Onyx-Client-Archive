/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Settings;
/*    */ import net.integr.Variables;
/*    */ import net.integr.event.RenderWorldEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.rendering.RenderingEngine;
/*    */ import net.integr.utilities.game.CoordinateUtils;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_5498;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/modules/impl/CosmeticsModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/RenderWorldEvent;", "event", "", "onRender", "(Lnet/integr/event/RenderWorldEvent;)V", "onyx2"})
/*    */ public final class CosmeticsModule
/*    */   extends Module
/*    */ {
/*    */   public CosmeticsModule() {
/* 34 */     super("Cosmetics", "Gives you cosmetics", "cosmetics", Filter.Render, false, 16, null);
/*    */     
/* 36 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onRender(@NotNull RenderWorldEvent event) {
/* 43 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("chinaHat")); if (((BooleanSetting)getSettings().getById("chinaHat")).isEnabled() && (Onyx.Companion.getMC()).field_1690.method_31044() != class_5498.field_26664) {
/* 44 */       Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("smol")); boolean smol = ((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("smol")).isEnabled();
/*    */       
/* 46 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (Intrinsics.areEqual((Onyx.Companion.getMC()).field_1724.method_7334().getName(), "Integr") && smol) {
/* 47 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 pos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)(Onyx.Companion.getMC()).field_1724, event.tickDelta);
/* 48 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(pos.method_1031(0.0D, (Onyx.Companion.getMC()).field_1724.method_5829().method_17940() - 0.15D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(pos.method_1031(0.0D, (Onyx.Companion.getMC()).field_1724.method_5829().method_17940() - 0.15D, 0.0D), 0.1D, 0.7D, 0.2F, true, event.matrices, Variables.Companion.getGuiColor());
/*    */       } else {
/* 50 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 pos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)(Onyx.Companion.getMC()).field_1724, event.tickDelta);
/* 51 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(pos.method_1031(0.0D, (Onyx.Companion.getMC()).field_1724.method_5829().method_17940() + 0.2D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(pos.method_1031(0.0D, (Onyx.Companion.getMC()).field_1724.method_5829().method_17940() + 0.2D, 0.0D), 0.1D, 1.0D, 0.2F, true, event.matrices, Variables.Companion.getGuiColor());
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CosmeticsModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */