/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.text.StringsKt;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.EntityHasLabelEvent;
/*    */ import net.integr.event.EntityRenderLabelEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.friendsystem.FriendStorage;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.minecraft.class_124;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_310;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/modules/impl/NametagsModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/EntityHasLabelEvent;", "event", "", "onEntityHasLabel", "(Lnet/integr/event/EntityHasLabelEvent;)V", "Lnet/integr/event/EntityRenderLabelEvent;", "onEntityRenderLabel", "(Lnet/integr/event/EntityRenderLabelEvent;)V", "onyx2"})
/*    */ public final class NametagsModule
/*    */   extends Module
/*    */ {
/*    */   public NametagsModule() {
/* 36 */     super("Nametags", "Changes the nametags", "nametags", Filter.Render, false, 16, null);
/*    */     
/* 38 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onEntityHasLabel(@NotNull EntityHasLabelEvent event) {
/* 48 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("own")); if (Intrinsics.areEqual(event.entity, (Onyx.Companion.getMC()).field_1724) && ((BooleanSetting)getSettings().getById("own")).isEnabled()) {
/* 49 */       event.setCallback(Boolean.valueOf(class_310.method_1498()));
/*    */     }
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onEntityRenderLabel(@NotNull EntityRenderLabelEvent event) {
/* 55 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("healthTags")); boolean hpInfo = ((BooleanSetting)getSettings().getById("healthTags")).isEnabled();
/* 56 */     Intrinsics.checkNotNull(getSettings().getById("friendTags")); boolean friendInfo = ((BooleanSetting)getSettings().getById("friendTags")).isEnabled();
/* 57 */     Intrinsics.checkNotNull(getSettings().getById("distanceTags")); boolean distanceTags = ((BooleanSetting)getSettings().getById("distanceTags")).isEnabled();
/*    */     
/* 59 */     String str = "";
/* 60 */     Intrinsics.checkNotNullExpressionValue(event.text.getString(), "getString(...)"); Intrinsics.checkNotNull(event.entity, "null cannot be cast to non-null type net.minecraft.entity.player.PlayerEntity"); Intrinsics.checkNotNullExpressionValue(((class_1657)event.entity).method_7334().getName(), "getName(...)"); if (event.entity instanceof class_1657 && StringsKt.contains$default(event.text.getString(), ((class_1657)event.entity).method_7334().getName(), false, 2, null)) {
/* 61 */       if (hpInfo) {
/* 62 */         Intrinsics.checkNotNull(event.entity, "null cannot be cast to non-null type net.minecraft.entity.LivingEntity"); Intrinsics.checkNotNull(event.entity, "null cannot be cast to non-null type net.minecraft.entity.LivingEntity"); str = str + " " + str + class_124.field_1061 + "❤";
/*    */       } 
/*    */       
/* 65 */       if (distanceTags) {
/* 66 */         Intrinsics.checkNotNull(event.entity, "null cannot be cast to non-null type net.minecraft.entity.LivingEntity"); str = str + " " + str + class_124.field_1080 + "m";
/*    */       } 
/*    */       
/* 69 */       if (friendInfo) {
/* 70 */         Intrinsics.checkNotNull(event.entity, "null cannot be cast to non-null type net.minecraft.entity.player.PlayerEntity"); boolean contains = FriendStorage.Companion.contains((class_1657)event.entity);
/*    */         
/* 72 */         str = str + str;
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 82 */       event.setCallback(event.text.method_27661().method_10852((class_2561)class_2561.method_43470(str)));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\NametagsModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */