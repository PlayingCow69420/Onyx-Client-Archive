/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.event.DamageTiltEvent;
/*    */ import net.integr.event.PlaySoundEvent;
/*    */ import net.integr.event.RenderEntityEvent;
/*    */ import net.integr.event.SpawnBreakingParticlesEvent;
/*    */ import net.integr.event.SpawnParticleEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_2398;
/*    */ import net.minecraft.class_3417;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013J\027\020\r\032\0020\0062\006\020\005\032\0020\fH\007¢\006\004\b\r\020\016J\027\020\020\032\0020\0062\006\020\005\032\0020\017H\007¢\006\004\b\020\020\021J\027\020\023\032\0020\0062\006\020\005\032\0020\022H\007¢\006\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/NoRenderModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/DamageTiltEvent;", "event", "", "onDamageTilt", "(Lnet/integr/event/DamageTiltEvent;)V", "Lnet/integr/event/PlaySoundEvent;", "onPlaySound", "(Lnet/integr/event/PlaySoundEvent;)V", "Lnet/integr/event/RenderEntityEvent;", "onRenderEntity", "(Lnet/integr/event/RenderEntityEvent;)V", "Lnet/integr/event/SpawnBreakingParticlesEvent;", "onSpawnBreakingParticles", "(Lnet/integr/event/SpawnBreakingParticlesEvent;)V", "Lnet/integr/event/SpawnParticleEvent;", "onSpawnParticle", "(Lnet/integr/event/SpawnParticleEvent;)V", "onyx2"})
/*    */ public final class NoRenderModule
/*    */   extends Module
/*    */ {
/*    */   public NoRenderModule() {
/* 34 */     super("No Render", "Disables rendering of some things", "noRender", Filter.Render, false, 16, null);
/*    */     
/* 36 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onRenderEntity(@NotNull RenderEntityEvent event) {
/* 47 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("entities")); if (((BooleanSetting)getSettings().getById("entities")).isEnabled()) {
/* 48 */       event.cancel();
/*    */     } else {
/* 50 */       Intrinsics.checkNotNull(getSettings().getById("items")); if (((BooleanSetting)getSettings().getById("items")).isEnabled() && 
/* 51 */         Intrinsics.areEqual(event.entity.method_5864(), class_1299.field_6052)) {
/* 52 */         event.cancel();
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onSpawnParticle(@NotNull SpawnParticleEvent event) {
/* 60 */     Intrinsics.checkNotNullParameter(event, "event");
/* 61 */     Intrinsics.checkNotNull(getSettings().getById("explosions")); if ((Intrinsics.areEqual(event.parameters.method_10295(), class_2398.field_11236) || Intrinsics.areEqual(event.parameters.method_10295(), class_2398.field_11221)) && ((BooleanSetting)getSettings().getById("explosions")).isEnabled()) {
/* 62 */       event.cancel();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onPlaySound(@NotNull PlaySoundEvent event) {
/* 69 */     Intrinsics.checkNotNullParameter(event, "event");
/* 70 */     Intrinsics.checkNotNull(getSettings().getById("explosions")); if (Intrinsics.areEqual(event.event, class_3417.field_15152.comp_349()) && ((BooleanSetting)getSettings().getById("explosions")).isEnabled()) {
/* 71 */       event.cancel();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onSpawnBreakingParticles(@NotNull SpawnBreakingParticlesEvent event) {
/* 78 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("breakParticles")); if (((BooleanSetting)getSettings().getById("breakParticles")).isEnabled()) {
/* 79 */       event.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onDamageTilt(@NotNull DamageTiltEvent event) {
/* 85 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("damageTilt")); if (((BooleanSetting)getSettings().getById("damageTilt")).isEnabled())
/* 86 */       event.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\NoRenderModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */