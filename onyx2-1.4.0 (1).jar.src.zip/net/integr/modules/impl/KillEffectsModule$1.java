/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 40 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); $this$initSettings.add((Setting)new BooleanSetting("Sound", "Plays a sound when you hit an entity", "sound", false, 8, null));
/* 41 */     $this$initSettings.add((Setting)new BooleanSetting("Particles", "Displays some particles when you hit an entity", "particles", false, 8, null));
/* 42 */     $this$initSettings.add((Setting)new SliderSetting("Particle Frequency: ", "The frequency of particles to display", "particleFrequency", 0.1D, 2.0D, 0.2D));
/* 43 */     $this$initSettings.add((Setting)new SliderSetting("Particle Range: ", "The amount of particles to display", "particleRange", 0.1D, 1.0D, 0.5D));
/* 44 */     String[] arrayOfString = new String[2]; arrayOfString[0] = "Sphere"; arrayOfString[1] = "Wave"; $this$initSettings.add((Setting)new CyclerSetting("Mode: ", "The mode of the kill effect", "mode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillEffectsModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */