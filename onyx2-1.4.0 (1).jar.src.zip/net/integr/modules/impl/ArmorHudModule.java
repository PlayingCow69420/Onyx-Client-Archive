/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Variables;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.rendering.RenderingEngine;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J/\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rR\024\020\017\032\0020\0168\002X\004¢\006\006\n\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/ArmorHudModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "background", "Lnet/integr/rendering/uisystem/Box;", "onyx2"})
/*    */ public final class ArmorHudModule
/*    */   extends UiModule
/*    */ {
/*    */   @NotNull
/*    */   private final Box background;
/*    */   
/*    */   public ArmorHudModule() {
/* 31 */     super("Armor Hud", "Render your armor durability on screen", "armorHud", 85, 60, Filter.Render);
/*    */     
/* 33 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 38 */     this.background = new Box(0, 0, 60, 85, null, false, true, false, 128, null);
/*    */   }
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/* 41 */     Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(3), "get(...)"); class_1799 helmetItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(3);
/* 42 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(2), "get(...)"); class_1799 chestPlateItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(2);
/* 43 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(1), "get(...)"); class_1799 leggingsItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(1);
/* 44 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(0), "get(...)"); class_1799 bootsItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(0);
/*    */     
/* 46 */     Intrinsics.checkNotNull(getSettings().getById("percent")); if (((BooleanSetting)getSettings().getById("percent")).isEnabled()) {
/* 47 */       this.background.setXSize(60);
/* 48 */       setWidth(60);
/* 49 */       this.background.update(originX, originY).method_25394(context, 0, 0, delta);
/*    */       
/* 51 */       context.method_51427(helmetItem, originX + 5, originY + 5);
/* 52 */       context.method_51427(chestPlateItem, originX + 5, originY + 25);
/* 53 */       context.method_51427(leggingsItem, originX + 5, originY + 45);
/* 54 */       context.method_51427(bootsItem, originX + 5, originY + 65);
/*    */       
/* 56 */       Object helmetPercent = (helmetItem.method_7936() != 0) ? Double.valueOf((helmetItem.method_7936() - helmetItem.method_7919()) / helmetItem.method_7936() * 100.0D) : Integer.valueOf(0);
/* 57 */       Object chestPlatePercent = (chestPlateItem.method_7936() != 0) ? Double.valueOf((chestPlateItem.method_7936() - chestPlateItem.method_7919()) / chestPlateItem.method_7936() * 100.0D) : Integer.valueOf(0);
/* 58 */       Object leggingsPercent = (leggingsItem.method_7936() != 0) ? Double.valueOf((leggingsItem.method_7936() - leggingsItem.method_7919()) / leggingsItem.method_7936() * 100.0D) : Integer.valueOf(0);
/* 59 */       Object bootsPercent = (bootsItem.method_7936() != 0) ? Double.valueOf((bootsItem.method_7936() - bootsItem.method_7919()) / bootsItem.method_7936() * 100.0D) : Integer.valueOf(0);
/*    */       
/* 61 */       RenderingEngine.Text.Companion.draw(context, "" + ((((Number)helmetPercent).intValue() > 0) ? (String)Integer.valueOf(((Number)helmetPercent).intValue()) : "- ") + "%", originX + 25, originY + 5 + 4, Variables.Companion.getGuiColor());
/* 62 */       RenderingEngine.Text.Companion.draw(context, "" + ((((Number)chestPlatePercent).intValue() > 0) ? (String)Integer.valueOf(((Number)chestPlatePercent).intValue()) : "- ") + "%", originX + 25, originY + 25 + 4, Variables.Companion.getGuiColor());
/* 63 */       RenderingEngine.Text.Companion.draw(context, "" + ((((Number)leggingsPercent).intValue() > 0) ? (String)Integer.valueOf(((Number)leggingsPercent).intValue()) : "- ") + "%", originX + 25, originY + 45 + 4, Variables.Companion.getGuiColor());
/* 64 */       RenderingEngine.Text.Companion.draw(context, "" + ((((Number)bootsPercent).intValue() > 0) ? (String)Integer.valueOf(((Number)bootsPercent).intValue()) : "- ") + "%", originX + 25, originY + 65 + 4, Variables.Companion.getGuiColor());
/*    */     } else {
/* 66 */       this.background.setXSize(75);
/* 67 */       setWidth(75);
/* 68 */       this.background.update(originX, originY).method_25394(context, 0, 0, delta);
/*    */       
/* 70 */       context.method_51427(helmetItem, originX + 5, originY + 5);
/* 71 */       context.method_51427(chestPlateItem, originX + 5, originY + 25);
/* 72 */       context.method_51427(leggingsItem, originX + 5, originY + 45);
/* 73 */       context.method_51427(bootsItem, originX + 5, originY + 65);
/*    */ 
/*    */       
/* 76 */       RenderingEngine.Text.Companion.draw(context, (helmetItem.method_7936() > 0) ? ("" + helmetItem.method_7936() - helmetItem.method_7919() + "/" + helmetItem.method_7936() - helmetItem.method_7919()) : "-", originX + 25, originY + 5 + 4, Variables.Companion.getGuiColor());
/* 77 */       RenderingEngine.Text.Companion.draw(context, (chestPlateItem.method_7936() > 0) ? ("" + chestPlateItem.method_7936() - chestPlateItem.method_7919() + "/" + chestPlateItem.method_7936() - chestPlateItem.method_7919()) : "-", originX + 25, originY + 25 + 4, Variables.Companion.getGuiColor());
/* 78 */       RenderingEngine.Text.Companion.draw(context, (leggingsItem.method_7936() > 0) ? ("" + leggingsItem.method_7936() - leggingsItem.method_7919() + "/" + leggingsItem.method_7936() - leggingsItem.method_7919()) : "-", originX + 25, originY + 45 + 4, Variables.Companion.getGuiColor());
/* 79 */       RenderingEngine.Text.Companion.draw(context, (bootsItem.method_7936() > 0) ? ("" + bootsItem.method_7936() - bootsItem.method_7919() + "/" + bootsItem.method_7936() - bootsItem.method_7919()) : "-", originX + 25, originY + 65 + 4, Variables.Companion.getGuiColor());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\ArmorHudModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */