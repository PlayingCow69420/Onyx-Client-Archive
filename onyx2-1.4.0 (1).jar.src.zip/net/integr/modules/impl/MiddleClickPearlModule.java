/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.event.DoItemPickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.utilities.game.command.CommandUtils;
/*    */ import net.integr.utilities.game.interaction.ClickUtils;
/*    */ import net.integr.utilities.game.inventory.InvUtils;
/*    */ import net.minecraft.class_1802;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/modules/impl/MiddleClickPearlModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/DoItemPickEvent;", "event", "", "onPickBlockEvent", "(Lnet/integr/event/DoItemPickEvent;)V", "onyx2"})
/*    */ public final class MiddleClickPearlModule
/*    */   extends Module
/*    */ {
/*    */   public MiddleClickPearlModule() {
/* 32 */     super("Middle click pearl", "Middle click to throw an ender pearl", "middleClickPearl", Filter.Util, false, 16, null);
/*    */     
/* 34 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen(prio = Priority.LAST)
/*    */   public final void onPickBlockEvent(@NotNull DoItemPickEvent event) {
/* 41 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNullExpressionValue(class_1802.field_8634, "ENDER_PEARL"); int epSlot = InvUtils.Companion.findInHotbar(class_1802.field_8634);
/*    */     
/* 43 */     if (epSlot == -1)
/*    */       return; 
/* 45 */     int pre = InvUtils.Companion.getSelectedSlot();
/* 46 */     InvUtils.Companion.selectSlot(epSlot);
/* 47 */     Intrinsics.checkNotNull(getSettings().getById("redupe")); if (((BooleanSetting)getSettings().getById("redupe")).isEnabled()) CommandUtils.Companion.sendCommand("dupe 2"); 
/* 48 */     ClickUtils.Companion.rightClick();
/* 49 */     InvUtils.Companion.selectSlot(pre);
/*    */     
/* 51 */     event.cancel();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\MiddleClickPearlModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */