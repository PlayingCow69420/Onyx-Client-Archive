/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 41 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); String[] arrayOfString = new String[3]; arrayOfString[0] = "Normal"; arrayOfString[1] = "1.8"; arrayOfString[2] = "Mace"; $this$initSettings.add((Setting)new CyclerSetting("Mode: ", "The base mode to use", "mode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 42 */     $this$initSettings.add((Setting)new SliderSetting("Range: ", "How far you can hit entities", "range", 1.0D, 100.0D, 0.0D, 32, null));
/* 43 */     $this$initSettings.add((Setting)new SliderSetting("Mace Height: ", "The height to hit entities with mace", "maceHeight", 1.0D, 100.0D, 0.0D, 32, null));
/* 44 */     $this$initSettings.add((Setting)new BooleanSetting("Sight", "Only hit entities in your sight", "sight", false, 8, null));
/* 45 */     $this$initSettings.add((Setting)new BooleanSetting("Spoof Ground", "Spoof ground for bypass on paper servers", "spoofGround", false, 8, null));
/* 46 */     arrayOfString = new String[3]; arrayOfString[0] = "All"; arrayOfString[1] = "Players"; arrayOfString[2] = "Mobs"; $this$initSettings.add((Setting)new CyclerSetting("Target: ", "The entities to target", "target", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\InfAuraModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */