/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.ModuleManager;
/*     */ import net.integr.modules.management.UiModule;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.KeyBindSetting;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_332;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0006\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\004\030\0002\0020\001:\001\024B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\t\020\bJ/\020\022\032\0020\0212\006\020\013\032\0020\n2\006\020\r\032\0020\f2\006\020\016\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\022\020\023¨\006\025"}, d2 = {"Lnet/integr/modules/impl/HacklistModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/integr/modules/management/Module;", "module", "", "getMnLText", "(Lnet/integr/modules/management/Module;)Ljava/lang/String;", "getMnRText", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "ModuleComparer", "onyx2"})
/*     */ public final class HacklistModule
/*     */   extends UiModule
/*     */ {
/*     */   public HacklistModule() {
/*  33 */     super("Hacklist", "Shows your active modules", "hackList", 20, 100, Filter.Render);
/*     */     
/*  35 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/*  41 */     Intrinsics.checkNotNullParameter(context, "context"); List modules = CollectionsKt.sortedWith(ModuleManager.Companion.getEnabledModules(), new ModuleComparer());
/*     */     
/*  43 */     Intrinsics.checkNotNull(getSettings().getById("background")); boolean background = ((BooleanSetting)getSettings().getById("background")).isEnabled();
/*  44 */     int counter = 0;
/*     */     
/*  46 */     if (originX - 10 >= context.method_51421() / 2) {
/*     */       
/*  48 */       if (originY - 50 >= context.method_51443() / 2)
/*     */       {
/*  50 */         for (Module module : modules) {
/*  51 */           String mn = getMnRText(module);
/*  52 */           if (background) {
/*  53 */             RenderingEngine.TwoDimensional.Companion.fill((originX + 5) + 100.0F - (Onyx.Companion.getMC()).field_1772.method_1727(mn) - 3, (originY + 5 + 5) - counter - true, (originX + 6) + 100.0F, (originY + 5 + 5 - counter) + 15.0F, Variables.Companion.getGuiColor(), context.method_51448().method_23760().method_23761());
/*  54 */             RenderingEngine.TwoDimensional.Companion.fill((originX + 5) + 100.0F - (Onyx.Companion.getMC()).field_1772.method_1727(mn) - 2, (originY + 5 + 5) - counter, (originX + 6) + 100.0F, (originY + 5 + 5 - counter) + 15.0F, Variables.Companion.getGuiBack(), context.method_51448().method_23760().method_23761());
/*  55 */             RenderingEngine.Text.Companion.draw(context, mn, originX + 5 + 100 - (Onyx.Companion.getMC()).field_1772.method_1727(mn), originY + 5 + 5 - counter + 4, Variables.Companion.getGuiColor()); counter += 15;
/*     */             
/*     */             continue;
/*     */           } 
/*  59 */           RenderingEngine.Text.Companion.draw(context, mn, originX + 5 + 100 - (Onyx.Companion.getMC()).field_1772.method_1727(mn), originY + 5 + 5 - counter + 5, Variables.Companion.getGuiColor()); counter += 10;
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*  65 */         for (Module module : modules) {
/*  66 */           String mn = getMnRText(module);
/*  67 */           if (background) {
/*  68 */             RenderingEngine.TwoDimensional.Companion.fill((originX + 5) + 100.0F - (Onyx.Companion.getMC()).field_1772.method_1727(mn) - 3, (originY - 5) + counter, (originX + 6) + 100.0F, (originY - 5 + counter) + 16.0F, Variables.Companion.getGuiColor(), context.method_51448().method_23760().method_23761());
/*  69 */             RenderingEngine.TwoDimensional.Companion.fill((originX + 5) + 100.0F - (Onyx.Companion.getMC()).field_1772.method_1727(mn) - 2, (originY - 5) + counter, (originX + 6) + 100.0F, (originY - 5 + counter) + 15.0F, Variables.Companion.getGuiBack(), context.method_51448().method_23760().method_23761());
/*  70 */             RenderingEngine.Text.Companion.draw(context, mn, originX + 5 + 100 - (Onyx.Companion.getMC()).field_1772.method_1727(mn), originY - 5 + counter + 4, Variables.Companion.getGuiColor()); counter += 15;
/*     */             
/*     */             continue;
/*     */           } 
/*  74 */           RenderingEngine.Text.Companion.draw(context, mn, originX + 5 + 100 - (Onyx.Companion.getMC()).field_1772.method_1727(mn), originY - 5 + counter, Variables.Companion.getGuiColor()); counter += 10;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  81 */     else if (originY - 50 >= context.method_51443() / 2) {
/*     */       
/*  83 */       for (Module module : modules) {
/*  84 */         String mn = getMnLText(module);
/*  85 */         if (background) {
/*  86 */           RenderingEngine.TwoDimensional.Companion.fill(originX - 5.0F - 2, (originY + 5 + 5) - counter - true, originX - 5.0F + (Onyx.Companion.getMC()).field_1772.method_1727(mn) + 2 + true, (originY + 5 + 5 - counter) + 15.0F, Variables.Companion.getGuiColor(), context.method_51448().method_23760().method_23761());
/*  87 */           RenderingEngine.TwoDimensional.Companion.fill(originX - 5.0F - 2, (originY + 5 + 5) - counter, originX - 5.0F + (Onyx.Companion.getMC()).field_1772.method_1727(mn) + 2, (originY + 5 + 5 - counter) + 15.0F, Variables.Companion.getGuiBack(), context.method_51448().method_23760().method_23761());
/*  88 */           RenderingEngine.Text.Companion.draw(context, mn, originX - 5, originY + 5 + 5 - counter + 4, Variables.Companion.getGuiColor()); counter += 15;
/*     */           
/*     */           continue;
/*     */         } 
/*  92 */         RenderingEngine.Text.Companion.draw(context, mn, originX - 5, originY + 5 + 5 - counter + 5, Variables.Companion.getGuiColor()); counter += 10;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  98 */       for (Module module : modules) {
/*  99 */         String mn = getMnLText(module);
/* 100 */         if (background) {
/* 101 */           RenderingEngine.TwoDimensional.Companion.fill(originX - 5.0F - 2, (originY - 5) + counter, originX - 5.0F + (Onyx.Companion.getMC()).field_1772.method_1727(mn) + 2 + true, (originY - 5 + counter) + 16.0F, Variables.Companion.getGuiColor(), context.method_51448().method_23760().method_23761());
/* 102 */           RenderingEngine.TwoDimensional.Companion.fill(originX - 5.0F - 2, (originY - 5) + counter, originX - 5.0F + (Onyx.Companion.getMC()).field_1772.method_1727(mn) + 2, (originY - 5 + counter) + 15.0F, Variables.Companion.getGuiBack(), context.method_51448().method_23760().method_23761());
/* 103 */           RenderingEngine.Text.Companion.draw(context, mn, originX - 5, originY - 5 + counter + 4, Variables.Companion.getGuiColor()); counter += 15;
/*     */           
/*     */           continue;
/*     */         } 
/* 107 */         RenderingEngine.Text.Companion.draw(context, mn, originX - 5, originY - 5 + counter, Variables.Companion.getGuiColor()); counter += 10;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getMnRText(Module module) {
/* 120 */     Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar()); Intrinsics.checkNotNullExpressionValue(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar().toUpperCase(Locale.ROOT), "toUpperCase(...)"); return module.getDisplayName() + module.getDisplayName() + class_124.field_1080 + Module.getHacklistData$default(module, false, 1, null) + class_124.field_1063;
/*     */   }
/*     */   
/*     */   private final String getMnLText(Module module) {
/* 124 */     Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar()); Intrinsics.checkNotNullExpressionValue(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar().toUpperCase(Locale.ROOT), "toUpperCase(...)"); return "" + class_124.field_1063 + class_124.field_1063 + (((KeyBindSetting)module.getSettings().getById("bind")).isBound() ? ("[" + ((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar().toUpperCase(Locale.ROOT) + "] ") : "") + 
/* 125 */       class_124.field_1080 + module.getHacklistData(true) + 
/* 126 */       class_124.field_1070;
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\003\030\0002\022\022\004\022\0020\0020\001j\b\022\004\022\0020\002`\003B\007¢\006\004\b\004\020\005J\037\020\t\032\0020\b2\006\020\006\032\0020\0022\006\020\007\032\0020\002H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\f2\006\020\013\032\0020\002H\002¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/modules/impl/HacklistModule$ModuleComparer;", "Ljava/util/Comparator;", "Lnet/integr/modules/management/Module;", "Lkotlin/Comparator;", "<init>", "()V", "o1", "o2", "", "compare", "(Lnet/integr/modules/management/Module;Lnet/integr/modules/management/Module;)I", "module", "", "getMnText", "(Lnet/integr/modules/management/Module;)Ljava/lang/String;", "onyx2"})
/*     */   public static final class ModuleComparer implements Comparator<Module> {
/*     */     public int compare(@NotNull Module o1, @NotNull Module o2) {
/* 132 */       Intrinsics.checkNotNullParameter(o1, "o1"); Intrinsics.checkNotNullParameter(o2, "o2"); int l1 = (Onyx.Companion.getMC()).field_1772.method_1727(getMnText(o1));
/* 133 */       int l2 = (Onyx.Companion.getMC()).field_1772.method_1727(getMnText(o2));
/*     */       
/* 135 */       if (l1 < l2) return 1; 
/* 136 */       if (l1 > l2) return -1;
/*     */       
/* 138 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final String getMnText(Module module) {
/* 144 */       Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(module.getSettings().getById("bind")); Intrinsics.checkNotNull(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar()); Intrinsics.checkNotNullExpressionValue(((KeyBindSetting)module.getSettings().getById("bind")).getKeyChar().toUpperCase(Locale.ROOT), "toUpperCase(...)"); return module.getDisplayName() + module.getDisplayName() + class_124.field_1080 + Module.getHacklistData$default(module, false, 1, null) + class_124.field_1063;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HacklistModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */