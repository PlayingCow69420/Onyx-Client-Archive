/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.EntityPopTotemEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.SettingsActionButton;
/*    */ import net.integr.utilities.LogUtils;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1937;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\020%\n\002\030\002\n\002\020\b\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\002¢\006\004\b\t\020\003R\"\020\r\032\016\022\004\022\0020\013\022\004\022\0020\f0\n8\002@\002X\016¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/modules/impl/CombatAssistant;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/EntityPopTotemEvent;", "event", "", "onEntityPopTotem", "(Lnet/integr/event/EntityPopTotemEvent;)V", "printStats", "", "Lnet/minecraft/class_1657;", "", "pops", "Ljava/util/Map;", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nCombatAssistant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CombatAssistant.kt\nnet/integr/modules/impl/CombatAssistant\n+ 2 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,69:1\n215#2,2:70\n*S KotlinDebug\n*F\n+ 1 CombatAssistant.kt\nnet/integr/modules/impl/CombatAssistant\n*L\n65#1:70,2\n*E\n"})
/*    */ public final class CombatAssistant
/*    */   extends Module {
/*    */   public CombatAssistant() {
/* 32 */     super("Combat Assistant", "Tracks stats of players in a fight", "combatAssistant", Filter.Util, false, 16, null);
/*    */     
/* 34 */     initSettings(new Function1<SettingsBuilder, Unit>() { public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 35 */             Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); $this$initSettings.add((Setting)new SettingsActionButton("Reset Session", "Resets the currently tracked data", "resetSession", new Function0<Unit>() { public final void invoke() {
/* 36 */                       LogUtils.Companion.assistantMessage("Session Reset");
/* 37 */                       CombatAssistant.this.pops.clear();
/*    */                     } }
/*    */                 ));
/* 40 */             $this$initSettings.add((Setting)new SettingsActionButton("Show Stats", "Shows the current stats", "showStats", new Function0<Unit>() { public final void invoke() {
/* 41 */                       CombatAssistant.this.printStats();
/*    */                     } }
/*    */                 ));
/*    */           } }
/*    */       );
/* 46 */     this.pops = new LinkedHashMap<>();
/*    */   } @NotNull
/*    */   private Map<class_1657, Integer> pops; @EventListen
/*    */   public final void onEntityPopTotem(@NotNull EntityPopTotemEvent event) {
/* 50 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull(event.packet.method_11469((class_1937)(Onyx.Companion.getMC()).field_1687)); class_1297 entity = event.packet.method_11469((class_1937)(Onyx.Companion.getMC()).field_1687);
/* 51 */     if (entity instanceof class_1657) {
/* 52 */       (Integer)this.pops.get(entity); LogUtils.Companion.assistantMessage((Intrinsics.areEqual(entity, (Onyx.Companion.getMC()).field_1724) ? "You" : (((class_1657)entity).method_7334().getName() + " has")) + " popped a Totem (" + (Intrinsics.areEqual(entity, (Onyx.Companion.getMC()).field_1724) ? "You" : (((class_1657)entity).method_7334().getName() + " has")) + " total)");
/*    */       
/* 54 */       if (this.pops.containsKey(entity)) {
/* 55 */         Intrinsics.checkNotNull(this.pops.get(entity)); this.pops.put(entity, Integer.valueOf(this.pops.get(entity).intValue() + 1));
/*    */       } else {
/* 57 */         this.pops.put(entity, Integer.valueOf(1));
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private final void printStats() {
/* 63 */     LogUtils.Companion.assistantMessage("Stats:");
/* 64 */     LogUtils.Companion.assistantMessage("Pops:");
/* 65 */     Map<class_1657, Integer> $this$forEach$iv = this.pops; int $i$f$forEach = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     Iterator<Map.Entry> iterator = $this$forEach$iv.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-CombatAssistant$printStats$1 = 0;
/*    */       class_1657 entity = (class_1657)entry1.getKey();
/*    */       int pops = ((Number)entry1.getValue()).intValue(); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CombatAssistant.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */