/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PlaySoundEvent;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.minecraft.class_1109;
/*    */ import net.minecraft.class_1113;
/*    */ import net.minecraft.class_3417;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013R\026\020\r\032\0020\f8\002@\002X\016¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/modules/impl/CrystalTweaksModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/PlaySoundEvent;", "event", "", "onPlaySound", "(Lnet/integr/event/PlaySoundEvent;)V", "Lnet/integr/event/PreTickEvent;", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "", "timeout", "I", "onyx2"})
/*    */ public final class CrystalTweaksModule
/*    */   extends Module
/*    */ {
/*    */   private int timeout;
/*    */   
/*    */   public CrystalTweaksModule() {
/* 31 */     super("Crystal Tweaks", "Tweak various aspects of end crystals", "crystalTweaks", Filter.Render, false, 16, null);
/*    */     
/* 33 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen(prio = Priority.FIRST)
/*    */   public final void onPlaySound(@NotNull PlaySoundEvent event) {
/* 49 */     Intrinsics.checkNotNullParameter(event, "event");
/* 50 */     Intrinsics.checkNotNull(getSettings().getById("sound")); if (Intrinsics.areEqual(event.event, class_3417.field_15152.comp_349()) && ((BooleanSetting)getSettings().getById("sound")).isEnabled()) {
/* 51 */       Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_4757(class_3417.field_14742, 1.3F, 0.1F));
/* 52 */       Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_4757(class_3417.field_15145, 1.0F, 0.5F));
/*    */       
/* 54 */       this.timeout = 9;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PreTickEvent event) {
/* 61 */     Intrinsics.checkNotNullParameter(event, "event"); if (this.timeout > 0) {
/* 62 */       int i = this.timeout; this.timeout = i + -1;
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CrystalTweaksModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */