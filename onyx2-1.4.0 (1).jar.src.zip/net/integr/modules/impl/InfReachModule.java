/*    */ package net.integr.modules.impl;
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.functions.Function2;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Variables;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.integr.utilities.game.entity.EntityFinder;
/*    */ import net.integr.utilities.game.interaction.AttackUtils;
/*    */ import net.integr.utilities.game.interaction.MovementUtil;
/*    */ import net.integr.utilities.game.pathfind.Path;
/*    */ import net.integr.utilities.game.pathfind.PathfindingManager;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\tJ\027\020\f\032\0020\0042\006\020\013\032\0020\nH\002¢\006\004\b\f\020\rR\030\020\016\032\004\030\0010\n8\002@\002X\016¢\006\006\n\004\b\016\020\017¨\006\020"}, d2 = {"Lnet/integr/modules/impl/InfReachModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "Lnet/minecraft/class_1309;", "entity", "runOn", "(Lnet/minecraft/class_1309;)V", "lastTarget", "Lnet/minecraft/class_1309;", "onyx2"})
/*    */ public final class InfReachModule extends Module {
/*    */   @Nullable
/*    */   private class_1309 lastTarget;
/*    */   
/*    */   public InfReachModule() {
/* 35 */     super("Infinite Reach", "Reach further than normal", "infReach", Filter.Combat, false, 16, null);
/*    */     
/* 37 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 42 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 43 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(InfReachModule.this.getSettings().getById("range")); $this$initHacklist.add("" + ((SliderSetting)InfReachModule.this.getSettings().getById("range")).getSetValue() + "m");
/*    */           } }
/*    */       );
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 50 */     this.lastTarget = null;
/* 51 */     Variables.Companion.setTarget(null); }
/*    */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"}) static final class InfReachModule$runOn$1 extends Lambda implements Function2<class_243, class_243, Unit> {
/*    */     public static final InfReachModule$runOn$1 INSTANCE = new InfReachModule$runOn$1();
/*    */     public final void invoke(@NotNull class_243 param1class_2431, @NotNull class_243 current) { Intrinsics.checkNotNullParameter(param1class_2431, "<anonymous parameter 0>");
/*    */       Intrinsics.checkNotNullParameter(current, "current");
/* 56 */       MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null); } InfReachModule$runOn$1() { super(2); } } @EventListen public final void onTick(@NotNull PreTickEvent event) { Intrinsics.checkNotNullParameter(event, "event"); if ((Onyx.Companion.getMC()).field_1690.field_1886.method_1434()) {
/* 57 */       Intrinsics.checkNotNull(getSettings().getById("range")); double range = ((SliderSetting)getSettings().getById("range")).getSetValue();
/*    */       
/* 59 */       (Onyx.Companion.getMC()).field_1690.field_1886.method_23481(false);
/*    */       
/* 61 */       class_1309 entity = EntityFinder.Companion.getStaredAtEntity(range);
/*    */       
/* 63 */       if (entity != null) {
/* 64 */         this.lastTarget = entity;
/* 65 */         Variables.Companion.setTarget(entity);
/*    */         
/* 67 */         runOn(entity);
/* 68 */       } else if (this.lastTarget != null) {
/*    */         
/* 70 */         Intrinsics.checkNotNull(this.lastTarget); runOn(this.lastTarget);
/*    */       } 
/*    */     } 
/*    */     
/* 74 */     Intrinsics.checkNotNull(this.lastTarget); if (this.lastTarget != null && !this.lastTarget.method_5805()) {
/* 75 */       this.lastTarget = null;
/*    */     }
/*    */     
/* 78 */     Intrinsics.checkNotNull(Variables.Companion.getTarget()); if (Variables.Companion.getTarget() != null && !Variables.Companion.getTarget().method_5805()) {
/* 79 */       Variables.Companion.setTarget(null);
/*    */     } }
/*    */ 
/*    */   
/*    */   private final void runOn(class_1309 entity) {
/* 84 */     Intrinsics.checkNotNullExpressionValue(entity.method_24515(), "getBlockPos(...)"); Path path = PathfindingManager.Companion.getPathToBlock$default(PathfindingManager.Companion, entity.method_24515(), null, 2, null);
/*    */     
/* 86 */     this.lastTarget = entity;
/*    */     
/* 88 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(path.getPath().size() * 5.0D);
/*    */     
/* 90 */     Path.iterateAndRender$default(path, 0, 20, InfReachModule$runOn$1.INSTANCE, 1, null);
/*    */ 
/*    */ 
/*    */     
/* 94 */     AttackUtils.Companion.attack(entity, false);
/*    */     
/* 96 */     Intrinsics.checkNotNull(getSettings().getById("spoofGround")); if (((BooleanSetting)getSettings().getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(path.getPath().size() * 5.0D);
/*    */     
/* 98 */     path.reversed().iterate(InfReachModule$runOn$2.INSTANCE); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\003\020\006\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_243;", "<anonymous parameter 0>", "current", "", "invoke", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;)V", "<anonymous>"})
/* 99 */   static final class InfReachModule$runOn$2 extends Lambda implements Function2<class_243, class_243, Unit> { public final void invoke(@NotNull class_243 param1class_2431, @NotNull class_243 current) { Intrinsics.checkNotNullParameter(param1class_2431, "<anonymous parameter 0>"); Intrinsics.checkNotNullParameter(current, "current"); MovementUtil.Companion.moveViaPacket$default(MovementUtil.Companion, current, false, 2, null); }
/*    */ 
/*    */     
/*    */     public static final InfReachModule$runOn$2 INSTANCE = new InfReachModule$runOn$2();
/*    */     
/*    */     InfReachModule$runOn$2() {
/*    */       super(2);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\InfReachModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */