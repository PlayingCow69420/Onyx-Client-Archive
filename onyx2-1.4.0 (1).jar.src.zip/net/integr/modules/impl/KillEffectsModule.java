/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.EntityDeathEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.minecraft.class_1109;
/*    */ import net.minecraft.class_1113;
/*    */ import net.minecraft.class_2394;
/*    */ import net.minecraft.class_2398;
/*    */ import net.minecraft.class_2400;
/*    */ import net.minecraft.class_3417;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\034\020\013\032\n \n*\004\030\0010\t0\t8\002X\004¢\006\006\n\004\b\013\020\f¨\006\r"}, d2 = {"Lnet/integr/modules/impl/KillEffectsModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/EntityDeathEvent;", "event", "", "onEntityDamage", "(Lnet/integr/event/EntityDeathEvent;)V", "Lnet/minecraft/class_1109;", "kotlin.jvm.PlatformType", "sound", "Lnet/minecraft/class_1109;", "onyx2"})
/*    */ public final class KillEffectsModule
/*    */   extends Module
/*    */ {
/*    */   private final class_1109 sound;
/*    */   
/*    */   public KillEffectsModule() {
/* 37 */     super("Kill Effects", "Does an effect when you kill an entity", "killEffects", Filter.Render, false, 16, null);
/*    */     
/* 39 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 47 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 48 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(KillEffectsModule.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)KillEffectsModule.this.getSettings().getById("mode")).getElement());
/*    */           } }
/*    */       );
/*    */ 
/*    */     
/* 53 */     this.sound = class_1109.method_4757(class_3417.field_15224, 1.7F, 1.0F);
/*    */   }
/*    */   @EventListen(prio = Priority.FIRST)
/*    */   public final void onEntityDamage(@NotNull EntityDeathEvent event) {
/* 57 */     Intrinsics.checkNotNullParameter(event, "event"); if (Intrinsics.areEqual(event.entity, (Onyx.Companion.getMC()).field_1724))
/* 58 */       return;  if (!(event.entity instanceof net.minecraft.class_1309))
/*    */       return; 
/* 60 */     Intrinsics.checkNotNull(getSettings().getById("sound")); if (((BooleanSetting)getSettings().getById("sound")).isEnabled()) {
/* 61 */       Onyx.Companion.getMC().method_1483().method_4873((class_1113)this.sound);
/*    */     }
/*    */     
/* 64 */     Intrinsics.checkNotNull(getSettings().getById("particles")); if (((BooleanSetting)getSettings().getById("particles")).isEnabled()) {
/* 65 */       double angle = 0.0D;
/* 66 */       while (angle <= 6.283185307179586D) {
/* 67 */         double x = Math.cos(angle);
/* 68 */         double z = Math.sin(angle);
/*    */         
/* 70 */         double angle2 = 0.0D;
/* 71 */         while (angle2 <= 2.0D) {
/* 72 */           double y = Math.sin(angle2 * Math.PI) / 2;
/* 73 */           Intrinsics.checkNotNull(getSettings().getById("mode")); String mode = ((CyclerSetting)getSettings().getById("mode")).getElement();
/*    */ 
/*    */           
/* 76 */           double radMul = Intrinsics.areEqual(mode, "Sphere") ? 
/* 77 */             Math.cos(angle2 * Math.PI) : 
/* 78 */             angle2;
/*    */           
/* 80 */           class_2400 effect = class_2398.field_11240;
/*    */           
/* 82 */           Intrinsics.checkNotNull(getSettings().getById("particleRange")); double range = ((SliderSetting)getSettings().getById("particleRange")).getSetValue() * radMul;
/*    */           
/* 84 */           (Onyx.Companion.getMC()).field_1769.method_8568((class_2394)effect, true, event.entity.method_23317(), event.entity.method_23318(), event.entity.method_23321(), x * range, y, z * range);
/*    */           
/* 86 */           Intrinsics.checkNotNull(getSettings().getById("particleFrequency")); angle2 += ((SliderSetting)getSettings().getById("particleFrequency")).getSetValue() / Math.PI;
/*    */         } 
/*    */         
/* 89 */         Intrinsics.checkNotNull(getSettings().getById("particleFrequency")); angle += ((SliderSetting)getSettings().getById("particleFrequency")).getSetValue();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillEffectsModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */