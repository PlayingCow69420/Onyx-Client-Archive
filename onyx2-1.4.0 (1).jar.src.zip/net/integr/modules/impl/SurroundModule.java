/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2682;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\b\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\006J\021\020\b\032\004\030\0010\007H\002¢\006\004\b\b\020\tJ\017\020\013\032\0020\nH\026¢\006\004\b\013\020\003J\027\020\016\032\0020\n2\006\020\r\032\0020\fH\007¢\006\004\b\016\020\017R\030\020\020\032\004\030\0010\0078\002@\002X\016¢\006\006\n\004\b\020\020\021R\026\020\022\032\0020\0048\002@\002X\016¢\006\006\n\004\b\022\020\023¨\006\024"}, d2 = {"Lnet/integr/modules/impl/SurroundModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "findBlock", "()I", "Lnet/minecraft/class_2338;", "getNext", "()Lnet/minecraft/class_2338;", "", "onEnable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "saveSpot", "Lnet/minecraft/class_2338;", "timer", "I", "onyx2"})
/*     */ public final class SurroundModule
/*     */   extends Module {
/*     */   @Nullable
/*     */   private class_2338 saveSpot;
/*     */   private int timer;
/*     */   
/*     */   public SurroundModule() {
/*  36 */     super("Surround", "Protects you by placing blocks on all sides", "surround", Filter.Util, false, 16, null);
/*     */     
/*  38 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  53 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.saveSpot = (Onyx.Companion.getMC()).field_1724.method_24515();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'event'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_0
/*     */     //   7: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   10: ldc 'pause'
/*     */     //   12: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   15: dup
/*     */     //   16: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   19: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   22: invokevirtual isEnabled : ()Z
/*     */     //   25: istore_2
/*     */     //   26: aload_0
/*     */     //   27: getfield timer : I
/*     */     //   30: ifle -> 46
/*     */     //   33: aload_0
/*     */     //   34: getfield timer : I
/*     */     //   37: istore_3
/*     */     //   38: aload_0
/*     */     //   39: iload_3
/*     */     //   40: iconst_m1
/*     */     //   41: iadd
/*     */     //   42: putfield timer : I
/*     */     //   45: return
/*     */     //   46: aload_0
/*     */     //   47: invokespecial getNext : ()Lnet/minecraft/class_2338;
/*     */     //   50: astore_3
/*     */     //   51: aload_3
/*     */     //   52: ifnull -> 226
/*     */     //   55: iload_2
/*     */     //   56: ifeq -> 65
/*     */     //   59: getstatic net/integr/utilities/game/pausers/CombatPauser.Companion : Lnet/integr/utilities/game/pausers/CombatPauser$Companion;
/*     */     //   62: invokevirtual pause : ()V
/*     */     //   65: aload_0
/*     */     //   66: invokespecial findBlock : ()I
/*     */     //   69: istore #4
/*     */     //   71: iload #4
/*     */     //   73: iconst_m1
/*     */     //   74: if_icmpeq -> 362
/*     */     //   77: aload_0
/*     */     //   78: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   81: ldc 'center'
/*     */     //   83: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   86: dup
/*     */     //   87: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   90: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   93: invokevirtual isEnabled : ()Z
/*     */     //   96: ifeq -> 142
/*     */     //   99: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   102: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   105: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   108: dup
/*     */     //   109: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   112: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   115: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   118: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   121: dup
/*     */     //   122: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   125: invokevirtual method_24515 : ()Lnet/minecraft/class_2338;
/*     */     //   128: invokevirtual method_46558 : ()Lnet/minecraft/class_243;
/*     */     //   131: dconst_0
/*     */     //   132: ldc2_w -0.5
/*     */     //   135: dconst_0
/*     */     //   136: invokevirtual method_1031 : (DDD)Lnet/minecraft/class_243;
/*     */     //   139: invokevirtual method_33574 : (Lnet/minecraft/class_243;)V
/*     */     //   142: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*     */     //   145: invokevirtual getSelectedSlot : ()I
/*     */     //   148: istore #5
/*     */     //   150: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*     */     //   153: iload #4
/*     */     //   155: invokevirtual selectSlot : (I)V
/*     */     //   158: iconst_1
/*     */     //   159: istore #6
/*     */     //   161: aload_0
/*     */     //   162: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   165: ldc 'amount'
/*     */     //   167: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   170: dup
/*     */     //   171: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   174: checkcast net/integr/modules/management/settings/impl/IntSliderSetting
/*     */     //   177: invokevirtual getSetValue : ()I
/*     */     //   180: istore #7
/*     */     //   182: iload #6
/*     */     //   184: iload #7
/*     */     //   186: if_icmpgt -> 215
/*     */     //   189: getstatic net/integr/utilities/game/interaction/BlockUtil.Companion : Lnet/integr/utilities/game/interaction/BlockUtil$Companion;
/*     */     //   192: aload_3
/*     */     //   193: iconst_0
/*     */     //   194: iconst_1
/*     */     //   195: iconst_0
/*     */     //   196: bipush #8
/*     */     //   198: aconst_null
/*     */     //   199: invokestatic placeBlock$default : (Lnet/integr/utilities/game/interaction/BlockUtil$Companion;Lnet/minecraft/class_2338;ZZZILjava/lang/Object;)V
/*     */     //   202: iload #6
/*     */     //   204: iload #7
/*     */     //   206: if_icmpeq -> 215
/*     */     //   209: iinc #6, 1
/*     */     //   212: goto -> 189
/*     */     //   215: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*     */     //   218: iload #5
/*     */     //   220: invokevirtual selectSlot : (I)V
/*     */     //   223: goto -> 362
/*     */     //   226: iload_2
/*     */     //   227: ifeq -> 236
/*     */     //   230: getstatic net/integr/utilities/game/pausers/CombatPauser.Companion : Lnet/integr/utilities/game/pausers/CombatPauser$Companion;
/*     */     //   233: invokevirtual resume : ()V
/*     */     //   236: aload_0
/*     */     //   237: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   240: ldc 'keep'
/*     */     //   242: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   245: dup
/*     */     //   246: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   249: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   252: invokevirtual isEnabled : ()Z
/*     */     //   255: ifeq -> 358
/*     */     //   258: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   261: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   264: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   267: dup
/*     */     //   268: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   271: invokevirtual method_24515 : ()Lnet/minecraft/class_2338;
/*     */     //   274: aload_0
/*     */     //   275: getfield saveSpot : Lnet/minecraft/class_2338;
/*     */     //   278: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   281: ifeq -> 358
/*     */     //   284: aload_0
/*     */     //   285: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   288: ldc 'secure'
/*     */     //   290: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   293: dup
/*     */     //   294: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   297: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   300: invokevirtual isEnabled : ()Z
/*     */     //   303: ifne -> 354
/*     */     //   306: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   309: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   312: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   315: dup
/*     */     //   316: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   319: invokevirtual method_23318 : ()D
/*     */     //   322: aload_0
/*     */     //   323: getfield saveSpot : Lnet/minecraft/class_2338;
/*     */     //   326: dup
/*     */     //   327: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   330: invokevirtual method_10264 : ()I
/*     */     //   333: i2d
/*     */     //   334: dcmpg
/*     */     //   335: ifne -> 342
/*     */     //   338: iconst_1
/*     */     //   339: goto -> 343
/*     */     //   342: iconst_0
/*     */     //   343: ifne -> 350
/*     */     //   346: iconst_1
/*     */     //   347: goto -> 355
/*     */     //   350: iconst_0
/*     */     //   351: goto -> 355
/*     */     //   354: iconst_0
/*     */     //   355: ifeq -> 362
/*     */     //   358: aload_0
/*     */     //   359: invokevirtual disable : ()V
/*     */     //   362: aload_0
/*     */     //   363: aload_0
/*     */     //   364: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   367: ldc 'delay'
/*     */     //   369: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   372: dup
/*     */     //   373: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   376: checkcast net/integr/modules/management/settings/impl/IntSliderSetting
/*     */     //   379: invokevirtual getSetValue : ()I
/*     */     //   382: putfield timer : I
/*     */     //   385: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #59	-> 6
/*     */     //   #61	-> 26
/*     */     //   #62	-> 33
/*     */     //   #63	-> 45
/*     */     //   #66	-> 46
/*     */     //   #68	-> 51
/*     */     //   #69	-> 55
/*     */     //   #71	-> 65
/*     */     //   #72	-> 71
/*     */     //   #73	-> 77
/*     */     //   #74	-> 142
/*     */     //   #75	-> 150
/*     */     //   #76	-> 158
/*     */     //   #77	-> 215
/*     */     //   #81	-> 226
/*     */     //   #82	-> 236
/*     */     //   #85	-> 362
/*     */     //   #86	-> 385
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   161	54	6	i	I
/*     */     //   150	73	5	pre	I
/*     */     //   71	152	4	block	I
/*     */     //   26	360	2	pause	Z
/*     */     //   51	335	3	next	Lnet/minecraft/class_2338;
/*     */     //   0	386	0	this	Lnet/integr/modules/impl/SurroundModule;
/*     */     //   0	386	1	event	Lnet/integr/event/PreTickEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int findBlock() {
/*  89 */     for (int i = 0; i < 9; i++) {
/*  90 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*     */       
/*  92 */       if (Intrinsics.areEqual(stack.method_7909(), class_1802.field_8281) || Intrinsics.areEqual(stack.method_7909(), class_1802.field_22421) || Intrinsics.areEqual(stack.method_7909(), class_1802.field_8542)) return i;
/*     */     
/*     */     } 
/*  95 */     return -1;
/*     */   }
/*     */   
/*     */   private final class_2338 getNext() {
/*  99 */     Pair[] arrayOfPair = new Pair[4]; arrayOfPair[0] = new Pair(Integer.valueOf(1), Integer.valueOf(0)); arrayOfPair[1] = new Pair(Integer.valueOf(-1), Integer.valueOf(0)); arrayOfPair[2] = new Pair(Integer.valueOf(0), Integer.valueOf(1)); arrayOfPair[3] = new Pair(Integer.valueOf(0), Integer.valueOf(-1)); List pairs = CollectionsKt.listOf((Object[])arrayOfPair);
/*     */     
/* 101 */     Intrinsics.checkNotNull(getSettings().getById("floor"));
/* 102 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (((BooleanSetting)getSettings().getById("floor")).isEnabled() && !(Onyx.Companion.getMC()).field_1687.method_8320((Onyx.Companion.getMC()).field_1724.method_24515().method_10069(0, -1, 0)).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980)) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return (Onyx.Companion.getMC()).field_1724.method_24515().method_10069(0, -1, 0); }
/*     */ 
/*     */     
/* 105 */     for (Pair pair : pairs) { int i = ((Number)pair.component1()).intValue(), j = ((Number)pair.component2()).intValue();
/* 106 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!(Onyx.Companion.getMC()).field_1687.method_8320((Onyx.Companion.getMC()).field_1724.method_24515().method_10069(i, 0, j)).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980)) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); return (Onyx.Companion.getMC()).field_1724.method_24515().method_10069(i, 0, j); }
/*     */        }
/*     */     
/* 109 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\SurroundModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */