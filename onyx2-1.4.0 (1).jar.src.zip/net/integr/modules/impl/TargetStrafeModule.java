/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.event.RenderWorldEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.utilities.TickDelta;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.integr.utilities.game.polar.PolarSystem;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3532;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\tJ\027\020\013\032\0020\0042\006\020\007\032\0020\nH\007¢\006\004\b\013\020\f¨\006\r"}, d2 = {"Lnet/integr/modules/impl/TargetStrafeModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/RenderWorldEvent;", "event", "onRender", "(Lnet/integr/event/RenderWorldEvent;)V", "Lnet/integr/event/PreTickEvent;", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "onyx2"})
/*     */ public final class TargetStrafeModule
/*     */   extends Module
/*     */ {
/*     */   public TargetStrafeModule() {
/*  40 */     super("Target Strafe", "Automatically rotates around the target", "targetStrafe", Filter.Move, false, 16, null);
/*     */     
/*  42 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  48 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(TargetStrafeModule.this.getSettings().getById("radius")); $this$initHacklist.add("" + ((SliderSetting)TargetStrafeModule.this.getSettings().getById("radius")).getSetValue() + "m");
/*     */           } }
/*     */       );
/*     */   }
/*     */   public void onDisable() {
/*  53 */     PolarSystem.Companion.resetCenter();
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onRender(@NotNull RenderWorldEvent event) {
/*  58 */     Intrinsics.checkNotNullParameter(event, "event"); class_1309 e = Variables.Companion.getTarget();
/*     */     
/*  60 */     if (e != null) {
/*  61 */       class_243 pos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)e, TickDelta.Companion.get());
/*  62 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 pPos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)(Onyx.Companion.getMC()).field_1724, TickDelta.Companion.get());
/*  63 */       Intrinsics.checkNotNull(getSettings().getById("radius")); double r = ((SliderSetting)getSettings().getById("radius")).getSetValue();
/*     */ 
/*     */       
/*  66 */       double aX = pos.field_1352;
/*  67 */       double aZ = pos.field_1350;
/*     */       
/*  69 */       double bX = pPos.field_1352;
/*  70 */       double bZ = pPos.field_1350;
/*     */       
/*  72 */       double cX = aX + r * (bX - aX) / Math.sqrt(Math.pow(bX - aX, 2) + Math.pow(bZ - aZ, 2));
/*  73 */       double cZ = aZ + r * (bZ - aZ) / Math.sqrt(Math.pow(bX - aX, 2) + Math.pow(bZ - aZ, 2));
/*     */       
/*  75 */       class_243 tPoint = new class_243(cX, pPos.field_1351, cZ);
/*  76 */       class_243 fPoint = new class_243(cX, pos.field_1351, cZ);
/*     */       
/*  78 */       if (CoordinateUtils.Companion.distanceTo(tPoint) <= 4.0D && CoordinateUtils.Companion.distanceBetween(tPoint, fPoint) <= 4.0D) {
/*  79 */         Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(pos, 0.1D, r, 0.0F, false, event.matrices, Variables.Companion.getGuiColor());
/*     */         
/*  81 */         class_238 box = new class_238(-0.1D, -0.1D, -0.1D, 0.1D, 0.1D, 0.1D);
/*  82 */         Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.box(box, fPoint, event.matrices, Variables.Companion.getGuiColor());
/*  83 */         Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.box(box, tPoint, event.matrices, Variables.Companion.getGuiColor());
/*     */         
/*  85 */         Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.line(fPoint, tPoint, event.matrices, Variables.Companion.getGuiColor());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*  92 */     Intrinsics.checkNotNullParameter(event, "event"); class_1309 e = Variables.Companion.getTarget();
/*     */     
/*  94 */     if (e != null)
/*  95 */     { class_243 pos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)e, TickDelta.Companion.get());
/*  96 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 pPos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)(Onyx.Companion.getMC()).field_1724, TickDelta.Companion.get());
/*  97 */       Intrinsics.checkNotNull(getSettings().getById("radius")); double r = ((SliderSetting)getSettings().getById("radius")).getSetValue();
/*     */       
/*  99 */       double aX = pos.field_1352;
/* 100 */       double aZ = pos.field_1350;
/*     */       
/* 102 */       double bX = pPos.field_1352;
/* 103 */       double bZ = pPos.field_1350;
/*     */       
/* 105 */       double cX = aX + r * (bX - aX) / Math.sqrt(Math.pow(bX - aX, 2) + Math.pow(bZ - aZ, 2));
/* 106 */       double cZ = aZ + r * (bZ - aZ) / Math.sqrt(Math.pow(bX - aX, 2) + Math.pow(bZ - aZ, 2));
/*     */       
/* 108 */       class_243 tPoint = new class_243(cX, pPos.field_1351, cZ);
/* 109 */       class_243 fPoint = new class_243(cX, pos.field_1351, cZ);
/*     */       
/* 111 */       if (CoordinateUtils.Companion.distanceTo(tPoint) <= 4.0D && CoordinateUtils.Companion.distanceBetween(tPoint, fPoint) <= 4.0D)
/* 112 */       { double velocityX = 0.0D;
/* 113 */         double velocityZ = 0.0D;
/*     */         
/* 115 */         class_243 entityPoint = new class_243(pos.field_1352, pPos.field_1351, pos.field_1350);
/*     */         
/* 117 */         PolarSystem.Companion.setCenter(entityPoint);
/*     */         
/* 119 */         class_243 side = PolarSystem.Companion.getSide();
/* 120 */         class_243 forward = PolarSystem.Companion.getForward();
/*     */         
/* 122 */         double dE = CoordinateUtils.Companion.distanceTo(entityPoint);
/* 123 */         double dT = CoordinateUtils.Companion.distanceTo(tPoint);
/* 124 */         double dTE = CoordinateUtils.Companion.distanceBetween(tPoint, entityPoint);
/*     */         
/* 126 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538(), "getPos(...)"); class_243 playerPosVec = (Onyx.Companion.getMC()).field_1724.method_19538();
/* 127 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double travelledX = playerPosVec.field_1352 - (Onyx.Companion.getMC()).field_1724.field_6014;
/* 128 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); double travelledZ = playerPosVec.field_1350 - (Onyx.Companion.getMC()).field_1724.field_5969;
/* 129 */         float deltaMovement = class_3532.method_15355((float)(travelledX * travelledX + travelledZ * travelledZ));
/*     */         
/* 131 */         Intrinsics.checkNotNull(getSettings().getById("pushbackSpeed")); double pbs = ((SliderSetting)getSettings().getById("pushbackSpeed")).getSetValue();
/*     */         
/* 133 */         if (dE < dTE) {
/* 134 */           velocityX -= forward.field_1352 * 0.25D * Math.max(1.0D, deltaMovement) * dT * pbs;
/* 135 */           velocityZ -= forward.field_1350 * 0.25D * Math.max(1.0D, deltaMovement) * dT * pbs;
/* 136 */         } else if (dE > dTE) {
/* 137 */           velocityX += forward.field_1352 * 0.25D * Math.max(1.0D, deltaMovement) * dT * pbs;
/* 138 */           velocityZ += forward.field_1350 * 0.25D * Math.max(1.0D, deltaMovement) * dT * pbs;
/*     */         } 
/*     */         
/* 141 */         if ((Onyx.Companion.getMC()).field_1690.field_1913.method_1434()) {
/* 142 */           velocityZ -= side.field_1350 * 0.25D * 0.8D;
/* 143 */           velocityX -= side.field_1352 * 0.25D * 0.8D;
/*     */         } 
/*     */         
/* 146 */         if ((Onyx.Companion.getMC()).field_1690.field_1849.method_1434()) {
/* 147 */           velocityZ += side.field_1350 * 0.25D * 0.8D;
/* 148 */           velocityX += side.field_1352 * 0.25D * 0.8D;
/*     */         } 
/*     */         
/* 151 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); (Onyx.Companion.getMC()).field_1724.method_5762(velocityX, 0.0D, velocityZ); }
/* 152 */       else { PolarSystem.Companion.resetCenter(); }  }
/* 153 */     else { PolarSystem.Companion.resetCenter(); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\TargetStrafeModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */