/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*    */ import net.integr.utilities.game.interaction.RotationUtils;
/*    */ import net.integr.utilities.game.rotationfake.RotationFaker;
/*    */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\t¨\006\n"}, d2 = {"Lnet/integr/modules/impl/SpinbotModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "onyx2"})
/*    */ public final class SpinbotModule
/*    */   extends Module
/*    */ {
/*    */   public SpinbotModule() {
/* 34 */     super("Spinbot", "You spin me right round", "spinBot", Filter.Render, false, 16, null);
/*    */     
/* 36 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 45 */     RotationLocker.Companion.unLock();
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen(prio = Priority.LAST)
/*    */   public final void onTick(@NotNull PreTickEvent event) {
/* 51 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("speed")); int speed = ((IntSliderSetting)getSettings().getById("speed")).getSetValue();
/* 52 */     Intrinsics.checkNotNull(getSettings().getById("yaw")); boolean yaw = ((BooleanSetting)getSettings().getById("yaw")).isEnabled();
/* 53 */     Intrinsics.checkNotNull(getSettings().getById("pitch")); boolean pitch = ((BooleanSetting)getSettings().getById("pitch")).isEnabled();
/* 54 */     Intrinsics.checkNotNull(getSettings().getById("syncServer")); boolean syncServer = ((BooleanSetting)getSettings().getById("syncServer")).isEnabled();
/*    */     
/* 56 */     boolean isFake = RotationFaker.Companion.getINSTANCE().isFake();
/*    */     
/* 58 */     RotationLocker.Companion.lock();
/*    */     
/* 60 */     if (!isFake) {
/*    */       
/* 62 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/* 63 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); RotationUtils.Companion.rotate(yaw ? ((RotationLocker.Companion.getFakeYaw() + speed) % 'Ũ') : (Onyx.Companion.getMC()).field_1724.method_36454(), pitch ? ((RotationLocker.Companion.getFakePitch() + speed) % 'Ũ') : (Onyx.Companion.getMC()).field_1724.method_36455(), 
/* 64 */           syncServer);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\SpinbotModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */