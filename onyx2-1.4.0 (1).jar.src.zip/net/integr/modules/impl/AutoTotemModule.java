/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.inventory.InvUtils;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\b\n\002\b\005\n\002\020\013\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\003J\017\020\006\032\0020\004H\002¢\006\004\b\006\020\003J\027\020\t\032\0020\0042\006\020\b\032\0020\007H\007¢\006\004\b\t\020\nJ\027\020\016\032\0020\r2\006\020\f\032\0020\013H\002¢\006\004\b\016\020\017R\026\020\020\032\0020\r8\002@\002X\016¢\006\006\n\004\b\020\020\021R\026\020\022\032\0020\r8\002@\002X\016¢\006\006\n\004\b\022\020\021R\026\020\024\032\0020\0238\002@\002X\016¢\006\006\n\004\b\024\020\025¨\006\026"}, d2 = {"Lnet/integr/modules/impl/AutoTotemModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "doAutoTotem", "finishMovingTotem", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "Lnet/minecraft/class_1661;", "inventory", "", "searchForTotems", "(Lnet/minecraft/class_1661;)I", "nextTickSlot", "I", "timer", "", "wasTotemInOffhand", "Z", "onyx2"})
/*     */ public final class AutoTotemModule
/*     */   extends Module
/*     */ {
/*     */   private boolean wasTotemInOffhand;
/*     */   private int timer;
/*     */   private int nextTickSlot;
/*     */   
/*     */   public AutoTotemModule() {
/*  34 */     super("Autototem", "Automatically equips a totem", "autoTotem", Filter.Util, false, 16, null);
/*     */     
/*  36 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  42 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(AutoTotemModule.this.getSettings().getById("health")); $this$initHacklist.add("" + ((SliderSetting)AutoTotemModule.this.getSettings().getById("health")).getSetValue() + "hp");
/*     */           } }
/*     */       );
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*  53 */     Intrinsics.checkNotNullParameter(event, "event"); if (this.timer > 0) { int i = this.timer; this.timer = i + -1; }
/*  54 */      doAutoTotem();
/*     */   }
/*     */   
/*     */   private final void doAutoTotem() {
/*  58 */     finishMovingTotem();
/*     */     
/*  60 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_31548(), "getInventory(...)"); class_1661 inventory = (Onyx.Companion.getMC()).field_1724.method_31548();
/*  61 */     int nextTotemSlot = searchForTotems(inventory);
/*     */     
/*  63 */     class_1799 offhandStack = inventory.method_5438(40);
/*  64 */     if (Intrinsics.areEqual(offhandStack.method_7909(), class_1802.field_8288)) {
/*  65 */       this.wasTotemInOffhand = true;
/*     */       
/*     */       return;
/*     */     } 
/*  69 */     if (this.wasTotemInOffhand) {
/*  70 */       Intrinsics.checkNotNull(getSettings().getById("delay")); this.timer = ((IntSliderSetting)getSettings().getById("delay")).getSetValue();
/*  71 */       this.wasTotemInOffhand = false;
/*     */     } 
/*     */     
/*  74 */     Intrinsics.checkNotNull(getSettings().getById("health")); double healthF = ((SliderSetting)getSettings().getById("health")).getSetValue();
/*  75 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_6032() > healthF)
/*     */       return; 
/*  77 */     if ((Onyx.Companion.getMC()).field_1755 instanceof net.minecraft.class_465 && !((Onyx.Companion.getMC()).field_1755 instanceof net.minecraft.class_485))
/*     */       return; 
/*  79 */     if (nextTotemSlot == -1)
/*     */       return; 
/*  81 */     if (this.timer > 0) {
/*  82 */       int i = this.timer; this.timer = i + -1;
/*     */       
/*     */       return;
/*     */     } 
/*  86 */     boolean offhandEmpty = offhandStack.method_7960();
/*     */     
/*  88 */     InvUtils.Companion.moveItem(nextTotemSlot, 45);
/*     */     
/*  90 */     if (!offhandEmpty) this.nextTickSlot = nextTotemSlot; 
/*     */   }
/*     */   
/*     */   private final void finishMovingTotem() {
/*  94 */     if (this.nextTickSlot == -1)
/*     */       return; 
/*  96 */     InvUtils.Companion.clickSlot(this.nextTickSlot);
/*  97 */     this.nextTickSlot = -1;
/*     */   }
/*     */   
/*     */   private final int searchForTotems(class_1661 inventory) {
/* 101 */     int nextTotemSlot = -1;
/*     */     
/* 103 */     for (int slot = 0; slot < 37; slot++) {
/* 104 */       if (Intrinsics.areEqual(inventory.method_5438(slot).method_7909(), class_1802.field_8288) && 
/* 105 */         nextTotemSlot == -1) nextTotemSlot = (slot < 9) ? (slot + 36) : slot;
/*     */     
/*     */     } 
/* 108 */     return nextTotemSlot;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AutoTotemModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */