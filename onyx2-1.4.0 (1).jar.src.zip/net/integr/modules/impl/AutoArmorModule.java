/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.utilities.game.EnchantmentUtil;
/*     */ import net.integr.utilities.game.inventory.InvUtils;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1738;
/*     */ import net.minecraft.class_1741;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1893;
/*     */ import net.minecraft.class_746;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\003J\037\020\013\032\0020\n2\006\020\007\032\0020\0062\006\020\t\032\0020\bH\002¢\006\004\b\013\020\fJ\027\020\017\032\0020\0042\006\020\016\032\0020\rH\007¢\006\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/AutoArmorModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "doAutoArmor", "Lnet/minecraft/class_1738;", "item", "Lnet/minecraft/class_1799;", "stack", "", "getArmorValue", "(Lnet/minecraft/class_1738;Lnet/minecraft/class_1799;)I", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "onyx2"})
/*     */ public final class AutoArmorModule
/*     */   extends Module
/*     */ {
/*     */   public AutoArmorModule() {
/*  37 */     super("Auto Armor", "Automatically equips armor for you", "autoArmor", Filter.Util, false, 16, null);
/*     */   }
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*  41 */     Intrinsics.checkNotNullParameter(event, "event"); doAutoArmor();
/*     */   }
/*     */   
/*     */   private final void doAutoArmor() {
/*  45 */     if ((Onyx.Companion.getMC()).field_1755 instanceof net.minecraft.class_465 && !((Onyx.Companion.getMC()).field_1755 instanceof net.minecraft.class_490))
/*     */       return; 
/*  47 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_746 player = (Onyx.Companion.getMC()).field_1724;
/*  48 */     class_1661 inventory = player.method_31548();
/*     */     
/*  50 */     int[] bestArmorSlots = new int[4];
/*  51 */     int[] bestArmorValues = new int[4];
/*     */     
/*  53 */     for (int type = 0; type < 4; type++) {
/*  54 */       bestArmorSlots[type] = -1;
/*     */       
/*  56 */       class_1799 stack = inventory.method_7372(type);
/*  57 */       if (!stack.method_7960() && stack.method_7909() instanceof class_1738) {
/*     */         
/*  59 */         Intrinsics.checkNotNull(stack.method_7909(), "null cannot be cast to non-null type net.minecraft.item.ArmorItem"); class_1738 item = (class_1738)stack.method_7909();
/*  60 */         Intrinsics.checkNotNull(stack); bestArmorValues[type] = getArmorValue(item, stack);
/*     */       } 
/*     */     } 
/*     */     
/*  64 */     for (int slot = 0; slot < 36; slot++) {
/*  65 */       class_1799 stack = inventory.method_5438(slot);
/*     */       
/*  67 */       if (!stack.method_7960() && stack.method_7909() instanceof class_1738) {
/*     */         
/*  69 */         Intrinsics.checkNotNull(stack.method_7909(), "null cannot be cast to non-null type net.minecraft.item.ArmorItem"); class_1738 item = (class_1738)stack.method_7909();
/*  70 */         int armorType = item.method_7685().method_5927();
/*  71 */         Intrinsics.checkNotNull(stack); int armorValue = getArmorValue(item, stack);
/*     */         
/*  73 */         if (armorValue > bestArmorValues[armorType]) {
/*  74 */           bestArmorSlots[armorType] = slot;
/*  75 */           bestArmorValues[armorType] = armorValue;
/*     */         } 
/*     */       } 
/*     */     } 
/*  79 */     Integer[] arrayOfInteger = new Integer[4]; arrayOfInteger[0] = Integer.valueOf(0); arrayOfInteger[1] = Integer.valueOf(1); arrayOfInteger[2] = Integer.valueOf(2); arrayOfInteger[3] = Integer.valueOf(3); ArrayList<?> types = new ArrayList(CollectionsKt.mutableListOf((Object[])arrayOfInteger));
/*  80 */     Collections.shuffle(types);
/*     */     
/*  82 */     for (Integer integer : types) {
/*  83 */       Intrinsics.checkNotNull(integer); int i = bestArmorSlots[integer.intValue()];
/*  84 */       if (i != -1) {
/*     */         
/*  86 */         class_1799 oldArmor = inventory.method_7372(integer.intValue());
/*  87 */         if (oldArmor.method_7960() || inventory.method_7376() != -1) {
/*     */           
/*  89 */           if (i < 9) i += 36;
/*     */           
/*  91 */           if (!oldArmor.method_7960()) InvUtils.Companion.quickMove(9 - integer.intValue()); 
/*  92 */           InvUtils.Companion.quickMove(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private final int getArmorValue(class_1738 item, class_1799 stack) {
/*  99 */     int armorPoints = item.method_7687();
/* 100 */     int prtPoints = 0;
/* 101 */     int armorToughness = (int)item.method_26353();
/* 102 */     int armorType = ((class_1741)item.method_7686().comp_349()).method_48403(class_1738.class_8051.field_41936);
/*     */ 
/*     */     
/* 105 */     Intrinsics.checkNotNullExpressionValue(class_1893.field_9111, "PROTECTION"); prtPoints = EnchantmentUtil.Companion.getLevel(class_1893.field_9111, stack);
/*     */     
/* 107 */     return armorPoints * 5 + prtPoints * 3 + armorToughness + armorType;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AutoArmorModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */