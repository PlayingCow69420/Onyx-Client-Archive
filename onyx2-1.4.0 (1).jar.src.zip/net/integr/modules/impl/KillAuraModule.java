/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.random.Random;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.integr.utilities.game.entity.EntityFinder;
/*     */ import net.integr.utilities.game.highlight.Highlighter;
/*     */ import net.integr.utilities.game.interaction.AttackUtils;
/*     */ import net.integr.utilities.game.interaction.ClickUtils;
/*     */ import net.integr.utilities.game.interaction.MovementUtil;
/*     */ import net.integr.utilities.game.interaction.RotationUtils;
/*     */ import net.integr.utilities.game.pausers.CombatPauser;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\023\030\000 \r2\0020\001:\020\r\016\017\020\021\022\023\024\025\026\027\030\031\032\033\034B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\tR\024\020\013\032\0020\n8\002X\004¢\006\006\n\004\b\013\020\f¨\006\035"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onPreTick", "(Lnet/integr/event/PreTickEvent;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modeHandler", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Companion", "FakeRotationMode", "InstantRotationMode", "KillAuraMode", "LerpRotationMode", "MaceKillAuraMode", "ModeHandler", "MultiSelectionMode", "NormalKillAuraMode", "OffRotationMode", "OneDotEightKillAuraMode", "RotationMode", "SelectionMode", "SingleSelectionMode", "SwitchSelectionMode", "WandKillAuraMode", "onyx2"})
/*     */ public final class KillAuraModule extends Module {
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   @NotNull
/*     */   private final ModeHandler modeHandler;
/*     */   private static boolean isBlocking;
/*     */   
/*  43 */   public KillAuraModule() { super("Killaura", "Automatically attacks entities around you", "killaura", Filter.Combat, false, 16, null);
/*     */     
/*  45 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  59 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(KillAuraModule.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)KillAuraModule.this.getSettings().getById("mode")).getElement());
/*  60 */             Intrinsics.checkNotNull(KillAuraModule.this.getSettings().getById("attackMode")); $this$initHacklist.add(((CyclerSetting)KillAuraModule.this.getSettings().getById("attackMode")).getElement());
/*  61 */             Intrinsics.checkNotNull(KillAuraModule.this.getSettings().getById("target")); $this$initHacklist.add(((CyclerSetting)KillAuraModule.this.getSettings().getById("target")).getElement());
/*  62 */             Intrinsics.checkNotNull(KillAuraModule.this.getSettings().getById("range")); $this$initHacklist.add("" + ((SliderSetting)KillAuraModule.this.getSettings().getById("range")).getSetValue() + "m");
/*     */           } }
/*     */       );
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     this.modeHandler = new ModeHandler(getSettings()); } public void onDisable() { RotationLocker.Companion.unLock();
/*     */     Variables.Companion.setTarget(null); }
/*     */   @EventListen
/*     */   public final void onPreTick(@NotNull PreTickEvent event) {
/*  75 */     Intrinsics.checkNotNullParameter(event, "event"); if (CombatPauser.Companion.isPaused())
/*     */       return; 
/*  77 */     Intrinsics.checkNotNull(getSettings().getById("mode")); String killauraMode = ((CyclerSetting)getSettings().getById("mode")).getElement();
/*  78 */     Intrinsics.checkNotNull(getSettings().getById("attackMode")); String selectionMode = ((CyclerSetting)getSettings().getById("attackMode")).getElement();
/*  79 */     Intrinsics.checkNotNull(getSettings().getById("rotations")); String rotationMode = ((CyclerSetting)getSettings().getById("rotations")).getElement();
/*     */     
/*  81 */     Intrinsics.checkNotNull(getSettings().getById("range")); double range = ((SliderSetting)getSettings().getById("range")).getSetValue();
/*  82 */     Intrinsics.checkNotNull(getSettings().getById("target")); String target = ((CyclerSetting)getSettings().getById("target")).getElement();
/*     */     
/*  84 */     List<? extends class_1309> entities = EntityFinder.Companion.getAuraEntities(Intrinsics.areEqual(killauraMode, "Wand") ? 90.0D : range, target, Intrinsics.areEqual(killauraMode, "Wand"));
/*     */     
/*  86 */     for (SelectionMode mode : this.modeHandler.getSelectionModes()) {
/*  87 */       if (Intrinsics.areEqual(mode.getName(), selectionMode)) {
/*  88 */         mode.run(killauraMode, rotationMode, entities);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     Intrinsics.checkNotNull(Variables.Companion.getTarget()); if (Variables.Companion.getTarget() != null && !Variables.Companion.getTarget().method_5805()) Variables.Companion.setTarget(null); 
/*     */   }
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020\006\032\004\b\005\020\007\"\004\b\b\020\t¨\006\n"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$Companion;", "", "<init>", "()V", "", "isBlocking", "Z", "()Z", "setBlocking", "(Z)V", "onyx2"})
/*     */   public static final class Companion { private Companion() {}
/*  98 */     public final boolean isBlocking() { return KillAuraModule.isBlocking; } public final void setBlocking(boolean <set-?>) { KillAuraModule.isBlocking = <set-?>; }
/*     */      }
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020 \n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J-\020\017\032\0020\0162\006\020\t\032\0020\b2\006\020\n\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\017\020\020R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\021R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\022\032\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$SingleSelectionMode;", "Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "killauraMode", "rotMode", "", "Lnet/minecraft/class_1309;", "entities", "", "run", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class SingleSelectionMode extends SelectionMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 104 */     public SingleSelectionMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Single"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 106 */     public void run(@NotNull String killauraMode, @NotNull String rotMode, @NotNull List entities) { Intrinsics.checkNotNullParameter(killauraMode, "killauraMode"); Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entities, "entities"); for (KillAuraModule.KillAuraMode mode : this.modes.getKillAuraModes()) {
/* 107 */         if (Intrinsics.areEqual(mode.getName(), killauraMode)) {
/* 108 */           if (!entities.isEmpty()) { mode.run(rotMode, (class_1309)CollectionsKt.first(entities)); break; }
/* 109 */            RotationLocker.Companion.unLock();
/*     */           break;
/*     */         } 
/*     */       }  } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020 \n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J-\020\017\032\0020\0162\006\020\t\032\0020\b2\006\020\n\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\017\020\020R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\021R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\022\032\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$SwitchSelectionMode;", "Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "killauraMode", "rotMode", "", "Lnet/minecraft/class_1309;", "entities", "", "run", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class SwitchSelectionMode extends SelectionMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 116 */     public SwitchSelectionMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Switch"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 118 */     public void run(@NotNull String killauraMode, @NotNull String rotMode, @NotNull List entities) { Intrinsics.checkNotNullParameter(killauraMode, "killauraMode"); Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entities, "entities"); for (KillAuraModule.KillAuraMode mode : this.modes.getKillAuraModes()) {
/* 119 */         if (Intrinsics.areEqual(mode.getName(), killauraMode)) {
/* 120 */           if (!entities.isEmpty()) { mode.run(rotMode, (class_1309)CollectionsKt.random(entities, (Random)Random.Default)); break; }
/* 121 */            RotationLocker.Companion.unLock();
/*     */           break;
/*     */         } 
/*     */       }  } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020 \n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J-\020\017\032\0020\0162\006\020\t\032\0020\b2\006\020\n\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\017\020\020R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\021R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\022\032\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$MultiSelectionMode;", "Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "killauraMode", "rotMode", "", "Lnet/minecraft/class_1309;", "entities", "", "run", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class MultiSelectionMode extends SelectionMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 128 */     public MultiSelectionMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Multi"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */      public void run(@NotNull String killauraMode, @NotNull String rotMode, @NotNull List entities) {
/* 130 */       Intrinsics.checkNotNullParameter(killauraMode, "killauraMode"); Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entities, "entities"); for (KillAuraModule.KillAuraMode mode : this.modes.getKillAuraModes()) {
/* 131 */         if (Intrinsics.areEqual(mode.getName(), killauraMode)) {
/* 132 */           if (!entities.isEmpty()) {
/* 133 */             for (class_1309 entity : entities) mode.run(rotMode, entity);  break;
/* 134 */           }  RotationLocker.Companion.unLock();
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\006\020\t\032\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\020\032\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$NormalKillAuraMode;", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class NormalKillAuraMode extends KillAuraMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 142 */     public NormalKillAuraMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Normal"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 144 */     public void run(@NotNull String rotMode, @NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull(this.settings.getById("critical")); boolean critical = ((BooleanSetting)this.settings.getById("critical")).isEnabled();
/*     */       
/* 146 */       boolean found = false;
/*     */       
/* 148 */       for (KillAuraModule.RotationMode mode : this.modes.getRotationModes()) {
/* 149 */         if (Intrinsics.areEqual(mode.getName(), rotMode)) {
/* 150 */           Variables.Companion.setTarget(entity);
/* 151 */           if (AttackUtils.Companion.canAttack()) AttackUtils.Companion.attack(entity, critical); 
/* 152 */           mode.run(entity);
/* 153 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 158 */       if (!found) RotationLocker.Companion.unLock();  } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\006\020\t\032\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\020\032\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$OneDotEightKillAuraMode;", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class OneDotEightKillAuraMode extends KillAuraMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 162 */     public OneDotEightKillAuraMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("1.8"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 164 */     public void run(@NotNull String rotMode, @NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull(this.settings.getById("critical")); boolean critical = ((BooleanSetting)this.settings.getById("critical")).isEnabled();
/* 165 */       Intrinsics.checkNotNull(this.settings.getById("autoBlock")); boolean autoBlock = ((BooleanSetting)this.settings.getById("autoBlock")).isEnabled();
/*     */       
/* 167 */       boolean found = false;
/*     */       
/* 169 */       for (KillAuraModule.RotationMode mode : this.modes.getRotationModes()) {
/* 170 */         if (Intrinsics.areEqual(mode.getName(), rotMode)) {
/* 171 */           Variables.Companion.setTarget(entity);
/* 172 */           if (AttackUtils.Companion.canAttack()) {
/* 173 */             AttackUtils.Companion.attackWithoutReset$default(AttackUtils.Companion, (class_1297)entity, critical, false, 4, null);
/*     */           }
/*     */           
/* 176 */           if (autoBlock) ClickUtils.Companion.rightClick();
/*     */           
/* 178 */           mode.run(entity);
/* 179 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 184 */       if (!found) RotationLocker.Companion.unLock();  } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\006\020\t\032\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\020\032\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$WandKillAuraMode;", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class WandKillAuraMode extends KillAuraMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 188 */     public WandKillAuraMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Wand"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 190 */     public void run(@NotNull String rotMode, @NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull(this.settings.getById("wandMode")); String wandMode = ((CyclerSetting)this.settings.getById("wandMode")).getElement();
/*     */       
/* 192 */       boolean found = false;
/*     */       
/* 194 */       for (KillAuraModule.RotationMode mode : this.modes.getRotationModes()) {
/* 195 */         if (Intrinsics.areEqual(mode.getName(), rotMode)) {
/* 196 */           Variables.Companion.setTarget(entity);
/* 197 */           mode.run(entity);
/* 198 */           if (Intrinsics.areEqual(wandMode, "Rightclick")) { ClickUtils.Companion.rightClick(); } else { ClickUtils.Companion.leftClick(); }
/* 199 */            found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 204 */       if (!found) RotationLocker.Companion.unLock();  } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\006\020\t\032\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\020\032\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$MaceKillAuraMode;", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class MaceKillAuraMode extends KillAuraMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 208 */     public MaceKillAuraMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Mace"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 210 */     public void run(@NotNull String rotMode, @NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull(this.settings.getById("maceHeight")); double height = ((SliderSetting)this.settings.getById("maceHeight")).getSetValue();
/* 211 */       Intrinsics.checkNotNull(this.settings.getById("critical")); boolean critical = ((BooleanSetting)this.settings.getById("critical")).isEnabled();
/*     */       
/* 213 */       boolean found = false;
/*     */       
/* 215 */       for (KillAuraModule.RotationMode mode : this.modes.getRotationModes()) {
/* 216 */         if (Intrinsics.areEqual(mode.getName(), rotMode)) {
/* 217 */           Variables.Companion.setTarget(entity);
/* 218 */           if (AttackUtils.Companion.canAttack()) {
/* 219 */             Intrinsics.checkNotNull(this.settings.getById("spoofGround")); if (((BooleanSetting)this.settings.getById("spoofGround")).isEnabled()) MovementUtil.Companion.spoofGroundOnlyFromDistance(height * 2);
/*     */             
/* 221 */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 origin = (Onyx.Companion.getMC()).field_1724.method_19538();
/*     */             
/* 223 */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), "add(...)"); Highlighter.Companion.renderBlock$default(Highlighter.Companion, (Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), 0, 2, null);
/* 224 */             Intrinsics.checkNotNull(origin); Highlighter.Companion.renderBlock$default(Highlighter.Companion, origin, 0, 2, null);
/*     */             
/* 226 */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), "add(...)"); Highlighter.Companion.renderLine$default(Highlighter.Companion, origin, (Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), 0, 0, 12, null);
/*     */             
/* 228 */             Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, height, 0.0D), true);
/* 229 */             Intrinsics.checkNotNullExpressionValue(origin.method_1031(0.0D, 0.0D, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(origin.method_1031(0.0D, 0.0D, 0.0D), true);
/* 230 */             Intrinsics.checkNotNullExpressionValue(origin.method_1031(0.0D, 0.0D, 0.0D), "add(...)"); MovementUtil.Companion.moveViaPacket(origin.method_1031(0.0D, 0.0D, 0.0D), true);
/*     */             
/* 232 */             AttackUtils.Companion.attack(entity, critical);
/*     */           } 
/*     */           
/* 235 */           mode.run(entity);
/* 236 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 241 */       if (!found) RotationLocker.Companion.unLock();  } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fR\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\rR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\016\032\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$InstantRotationMode;", "Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class InstantRotationMode extends RotationMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 245 */     public InstantRotationMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Instant"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 247 */     public void run(@NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(entity, "entity"); RotationLocker.Companion.lock();
/* 248 */       Intrinsics.checkNotNullExpressionValue(entity.method_33571(), "getEyePos(...)"); RotationUtils.Companion.lookAt$default(RotationUtils.Companion, entity.method_33571(), false, 2, null); } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fR\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\rR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\016\032\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$LerpRotationMode;", "Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class LerpRotationMode extends RotationMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 252 */     public LerpRotationMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Lerp"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 254 */     public void run(@NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(entity, "entity"); RotationLocker.Companion.lock();
/* 255 */       RotationUtils.Companion.lookAt$default(RotationUtils.Companion, CoordinateUtils.Companion.getLerpedEntityPos((class_1297)entity, TickDelta.Companion.get()), false, 2, null); } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fR\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\rR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\016\032\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$FakeRotationMode;", "Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class FakeRotationMode extends RotationMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 259 */     public FakeRotationMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Fake"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */     
/* 261 */     public void run(@NotNull class_1309 entity) { Intrinsics.checkNotNullParameter(entity, "entity"); RotationLocker.Companion.lock();
/* 262 */       Intrinsics.checkNotNullExpressionValue(entity.method_33571(), "getEyePos(...)"); RotationUtils.Companion.lookAt(entity.method_33571(), false); } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fR\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\rR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\016\032\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$OffRotationMode;", "Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class OffRotationMode extends RotationMode { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final KillAuraModule.ModeHandler modes;
/* 266 */     public OffRotationMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) { super("Off"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */      public void run(@NotNull class_1309 entity) {
/* 268 */       Intrinsics.checkNotNullParameter(entity, "entity"); RotationLocker.Companion.unLock();
/*     */     } }
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\005\n\002\020 \n\002\030\002\n\000\n\002\020\002\n\002\b\006\b&\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J-\020\f\032\0020\0132\006\020\006\032\0020\0022\006\020\007\032\0020\0022\f\020\n\032\b\022\004\022\0020\t0\bH&¢\006\004\b\f\020\rR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\016\032\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "", "", "name", "<init>", "(Ljava/lang/String;)V", "killauraMode", "rotMode", "", "Lnet/minecraft/class_1309;", "entities", "", "run", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "Ljava/lang/String;", "getName", "()Ljava/lang/String;", "onyx2"})
/*     */   public static abstract class SelectionMode { @NotNull
/*     */     private final String name;
/*     */     
/* 274 */     public SelectionMode(@NotNull String name) { this.name = name; } @NotNull public final String getName() { return this.name; }
/*     */      public abstract void run(@NotNull String param1String1, @NotNull String param1String2, @NotNull List<? extends class_1309> param1List); } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\004\n\002\030\002\n\000\n\002\020\002\n\002\b\006\b&\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\037\020\n\032\0020\t2\006\020\006\032\0020\0022\006\020\b\032\0020\007H&¢\006\004\b\n\020\013R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\f\032\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "", "", "name", "<init>", "(Ljava/lang/String;)V", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Ljava/lang/String;", "getName", "()Ljava/lang/String;", "onyx2"})
/*     */   public static abstract class KillAuraMode { @NotNull
/*     */     private final String name;
/* 278 */     public KillAuraMode(@NotNull String name) { this.name = name; } @NotNull public final String getName() { return this.name; }
/*     */      public abstract void run(@NotNull String param1String, @NotNull class_1309 param1class_1309); }
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\002\b\006\b&\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\027\020\t\032\0020\b2\006\020\007\032\0020\006H&¢\006\004\b\t\020\nR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\013\032\004\b\f\020\r¨\006\016"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "", "", "name", "<init>", "(Ljava/lang/String;)V", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Lnet/minecraft/class_1309;)V", "Ljava/lang/String;", "getName", "()Ljava/lang/String;", "onyx2"})
/*     */   public static abstract class RotationMode { @NotNull
/*     */     private final String name;
/* 283 */     public RotationMode(@NotNull String name) { this.name = name; } @NotNull public final String getName() { return this.name; } public abstract void run(@NotNull class_1309 param1class_1309); } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005R\035\020\b\032\b\022\004\022\0020\0070\0068\006¢\006\f\n\004\b\b\020\t\032\004\b\n\020\013R\035\020\r\032\b\022\004\022\0020\f0\0068\006¢\006\f\n\004\b\r\020\t\032\004\b\016\020\013R\035\020\020\032\b\022\004\022\0020\0170\0068\006¢\006\f\n\004\b\020\020\t\032\004\b\021\020\013R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\022\032\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "killAuraModes", "Ljava/util/List;", "getKillAuraModes", "()Ljava/util/List;", "Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "rotationModes", "getRotationModes", "Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "selectionModes", "getSelectionModes", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */   public static final class ModeHandler { @NotNull
/*     */     private final SettingsBuilder settings; @NotNull
/*     */     private final List<KillAuraModule.KillAuraMode> killAuraModes; public ModeHandler(@NotNull SettingsBuilder settings) {
/* 287 */       this.settings = settings;
/*     */       
/* 289 */       KillAuraModule.KillAuraMode[] arrayOfKillAuraMode = new KillAuraModule.KillAuraMode[4]; arrayOfKillAuraMode[0] = new KillAuraModule.NormalKillAuraMode(this.settings, this); arrayOfKillAuraMode[1] = 
/* 290 */         new KillAuraModule.OneDotEightKillAuraMode(this.settings, this);
/* 291 */       arrayOfKillAuraMode[2] = new KillAuraModule.WandKillAuraMode(this.settings, this);
/* 292 */       arrayOfKillAuraMode[3] = new KillAuraModule.MaceKillAuraMode(this.settings, this);
/*     */       
/*     */       this.killAuraModes = CollectionsKt.listOf((Object[])arrayOfKillAuraMode);
/*     */       
/* 296 */       KillAuraModule.SelectionMode[] arrayOfSelectionMode = new KillAuraModule.SelectionMode[3]; arrayOfSelectionMode[0] = new KillAuraModule.SingleSelectionMode(this.settings, this); arrayOfSelectionMode[1] = 
/* 297 */         new KillAuraModule.SwitchSelectionMode(this.settings, this);
/* 298 */       arrayOfSelectionMode[2] = new KillAuraModule.MultiSelectionMode(this.settings, this);
/*     */       
/*     */       this.selectionModes = CollectionsKt.listOf((Object[])arrayOfSelectionMode);
/*     */       
/* 302 */       KillAuraModule.RotationMode[] arrayOfRotationMode = new KillAuraModule.RotationMode[4]; arrayOfRotationMode[0] = new KillAuraModule.InstantRotationMode(this.settings, this); arrayOfRotationMode[1] = 
/* 303 */         new KillAuraModule.LerpRotationMode(this.settings, this);
/* 304 */       arrayOfRotationMode[2] = new KillAuraModule.FakeRotationMode(this.settings, this);
/* 305 */       arrayOfRotationMode[3] = new KillAuraModule.OffRotationMode(this.settings, this);
/*     */       this.rotationModes = CollectionsKt.listOf((Object[])arrayOfRotationMode);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     private final List<KillAuraModule.SelectionMode> selectionModes;
/*     */     @NotNull
/*     */     private final List<KillAuraModule.RotationMode> rotationModes;
/*     */     
/*     */     @NotNull
/*     */     public final SettingsBuilder getSettings() {
/*     */       return this.settings;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final List<KillAuraModule.KillAuraMode> getKillAuraModes() {
/*     */       return this.killAuraModes;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final List<KillAuraModule.SelectionMode> getSelectionModes() {
/*     */       return this.selectionModes;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final List<KillAuraModule.RotationMode> getRotationModes() {
/*     */       return this.rotationModes;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillAuraModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */