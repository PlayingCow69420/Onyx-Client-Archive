/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.UiModule;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.Slider;
/*     */ import net.minecraft.class_332;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\030\0002\0020\001B\007¢\006\004\b\002\020\003J/\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rR\024\020\017\032\0020\0168\002X\004¢\006\006\n\004\b\017\020\020R\024\020\021\032\0020\0168\002X\004¢\006\006\n\004\b\021\020\020R\024\020\023\032\0020\0228\002X\004¢\006\006\n\004\b\023\020\024R\024\020\025\032\0020\0168\002X\004¢\006\006\n\004\b\025\020\020R\024\020\026\032\0020\0228\002X\004¢\006\006\n\004\b\026\020\024R\024\020\027\032\0020\0168\002X\004¢\006\006\n\004\b\027\020\020¨\006\030"}, d2 = {"Lnet/integr/modules/impl/HotbarModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Slider;", "airSlider", "Lnet/integr/rendering/uisystem/Slider;", "armorSlider", "Lnet/integr/rendering/uisystem/Box;", "foodBox", "Lnet/integr/rendering/uisystem/Box;", "foodSlider", "healthBox", "healthSlider", "onyx2"})
/*     */ public final class HotbarModule extends UiModule {
/*     */   @NotNull
/*     */   private final Box healthBox;
/*     */   @NotNull
/*     */   private final Slider healthSlider;
/*     */   @NotNull
/*     */   private final Slider armorSlider;
/*     */   
/*     */   public HotbarModule() {
/*  29 */     super("Hotbar", "Revamps the hotbar", "hotbar", 55, 195, Filter.Render);
/*     */     
/*  31 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  36 */     this.healthBox = new Box(0, 0, 95, 30, null, false, false, false, 192, null);
/*     */     
/*  38 */     this.healthSlider = new Slider(0, 0, 89, 20, " Health: ", false, "", 0.0D, 20.0D);
/*  39 */     this.armorSlider = new Slider(0, 0, 89, 20, " Armor: ", false, "", 0.0D, 20.0D);
/*     */     
/*  41 */     this.foodBox = new Box(0, 0, 95, 30, null, false, false, false, 192, null);
/*  42 */     this.foodSlider = new Slider(0, 0, 89, 20, " Food: ", false, "", 0.0D, 20.0D);
/*     */     
/*  44 */     this.airSlider = new Slider(0, 0, 89, 20, " Air: ", false, "", 0.0D, 300.0D); } @NotNull
/*     */   private final Box foodBox; @NotNull
/*     */   private final Slider foodSlider; @NotNull
/*  47 */   private final Slider airSlider; public void render(@NotNull class_332 context, int originX, int originY, float delta) { Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNull(getSettings().getById("locked")); if (((BooleanSetting)getSettings().getById("locked")).isEnabled()) {
/*  48 */       int width = context.method_51421();
/*  49 */       int height = context.method_51443();
/*     */       
/*  51 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!((Onyx.Companion.getMC()).field_1724.method_31549()).field_7477 && !(Onyx.Companion.getMC()).field_1724.method_7325()) {
/*  52 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_6096() > 0) {
/*  53 */           this.healthBox.setYSize(55);
/*  54 */           this.healthBox.update(width / 2 - 105, height - 95).method_25394(context, 0, 0, delta);
/*     */           
/*  56 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.armorSlider.setValue((Onyx.Companion.getMC()).field_1724.method_6096());
/*  57 */           this.armorSlider.update(width / 2 - 102, height - 90).method_25394(context, 0, 0, delta);
/*     */           
/*  59 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setMax((Onyx.Companion.getMC()).field_1724.method_6063() + (Onyx.Companion.getMC()).field_1724.method_6067());
/*  60 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setValue((Onyx.Companion.getMC()).field_1724.method_6032() + (Onyx.Companion.getMC()).field_1724.method_6067());
/*  61 */           this.healthSlider.update(width / 2 - 102, height - 65).method_25394(context, 0, 0, delta);
/*     */         } else {
/*  63 */           this.healthBox.setYSize(30);
/*  64 */           this.healthBox.update(width / 2 - 105, height - 70).method_25394(context, 0, 0, delta);
/*     */           
/*  66 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setMax((Onyx.Companion.getMC()).field_1724.method_6063() + (Onyx.Companion.getMC()).field_1724.method_6067());
/*  67 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setValue((Onyx.Companion.getMC()).field_1724.method_6032() + (Onyx.Companion.getMC()).field_1724.method_6067());
/*  68 */           this.healthSlider.update(width / 2 - 102, height - 65).method_25394(context, 0, 0, delta);
/*     */         } 
/*     */         
/*  71 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_5669() < 300) {
/*  72 */           this.foodBox.setYSize(55);
/*  73 */           this.foodBox.update(width / 2 + 11, height - 95).method_25394(context, 0, 0, delta);
/*     */           
/*  75 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.airSlider.setValue((Onyx.Companion.getMC()).field_1724.method_5669());
/*  76 */           this.airSlider.update(width / 2 + 14, height - 90).method_25394(context, 0, 0, delta);
/*     */           
/*  78 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.foodSlider.setValue((Onyx.Companion.getMC()).field_1724.method_7344().method_7586());
/*  79 */           this.foodSlider.update(width / 2 + 14, height - 65).method_25394(context, 0, 0, delta);
/*     */         } else {
/*  81 */           this.foodBox.setYSize(30);
/*  82 */           this.foodBox.update(width / 2 + 11, height - 70).method_25394(context, 0, 0, delta);
/*     */           
/*  84 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.foodSlider.setValue((Onyx.Companion.getMC()).field_1724.method_7344().method_7586());
/*  85 */           this.foodSlider.update(width / 2 + 14, height - 65).method_25394(context, 0, 0, delta);
/*     */         } 
/*     */       } 
/*     */     } else {
/*  89 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!((Onyx.Companion.getMC()).field_1724.method_31549()).field_7477 && !(Onyx.Companion.getMC()).field_1724.method_7325()) {
/*  90 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_6096() > 0) {
/*  91 */           this.healthBox.setYSize(55);
/*  92 */           this.healthBox.update(originX, originY).method_25394(context, 0, 0, delta);
/*     */           
/*  94 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.armorSlider.setValue((Onyx.Companion.getMC()).field_1724.method_6096());
/*  95 */           this.armorSlider.update(originX + 3, originY + 5).method_25394(context, 0, 0, delta);
/*     */           
/*  97 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setMax((Onyx.Companion.getMC()).field_1724.method_6063() + (Onyx.Companion.getMC()).field_1724.method_6067());
/*  98 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setValue((Onyx.Companion.getMC()).field_1724.method_6032() + (Onyx.Companion.getMC()).field_1724.method_6067());
/*  99 */           this.healthSlider.update(originX + 3, originY + 30).method_25394(context, 0, 0, delta);
/*     */         } else {
/* 101 */           this.healthBox.setYSize(30);
/* 102 */           this.healthBox.update(originX, originY + 25).method_25394(context, 0, 0, delta);
/*     */           
/* 104 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setMax((Onyx.Companion.getMC()).field_1724.method_6063() + (Onyx.Companion.getMC()).field_1724.method_6067());
/* 105 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.healthSlider.setValue((Onyx.Companion.getMC()).field_1724.method_6032() + (Onyx.Companion.getMC()).field_1724.method_6067());
/* 106 */           this.healthSlider.update(originX + 3, originY + 30).method_25394(context, 0, 0, delta);
/*     */         } 
/*     */         
/* 109 */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_5669() < 300) {
/* 110 */           this.foodBox.setYSize(55);
/* 111 */           this.foodBox.update(originX + 100, originY).method_25394(context, 0, 0, delta);
/*     */           
/* 113 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.airSlider.setValue((Onyx.Companion.getMC()).field_1724.method_5669());
/* 114 */           this.airSlider.update(originX + 100 + 3, originY + 5).method_25394(context, 0, 0, delta);
/*     */           
/* 116 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.foodSlider.setValue((Onyx.Companion.getMC()).field_1724.method_7344().method_7586());
/* 117 */           this.foodSlider.update(originX + 100 + 3, originY + 30).method_25394(context, 0, 0, delta);
/*     */         } else {
/* 119 */           this.foodBox.setYSize(30);
/* 120 */           this.foodBox.update(originX + 100, originY + 25).method_25394(context, 0, 0, delta);
/*     */           
/* 122 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.foodSlider.setValue((Onyx.Companion.getMC()).field_1724.method_7344().method_7586());
/* 123 */           this.foodSlider.update(originX + 100 + 3, originY + 30).method_25394(context, 0, 0, delta);
/*     */         } 
/*     */       } 
/*     */     }  }
/*     */ 
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HotbarModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */