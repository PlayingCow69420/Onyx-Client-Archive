/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import net.integr.event.SendPacketEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/modules/impl/NofallModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/SendPacketEvent;", "event", "", "onSendPacket", "(Lnet/integr/event/SendPacketEvent;)V", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nNofallModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NofallModule.kt\nnet/integr/modules/impl/NofallModule\n+ 2 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n*L\n1#1,47:1\n71#2,7:48\n*S KotlinDebug\n*F\n+ 1 NofallModule.kt\nnet/integr/modules/impl/NofallModule\n*L\n38#1:48,7\n*E\n"})
/*    */ public final class NofallModule
/*    */   extends Module
/*    */ {
/*    */   public NofallModule() {
/* 32 */     super("Nofall", "Never take fall damage again", "nofall", Filter.Move, false, 16, null);
/*    */   }
/*    */   
/*    */   @EventListen(prio = Priority.LAST)
/*    */   public final void onSendPacket(@NotNull SendPacketEvent event) {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: ldc 'event'
/*    */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   6: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   9: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   12: getfield field_1724 : Lnet/minecraft/class_746;
/*    */     //   15: ifnonnull -> 19
/*    */     //   18: return
/*    */     //   19: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   22: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   25: getfield field_1724 : Lnet/minecraft/class_746;
/*    */     //   28: dup
/*    */     //   29: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   32: invokevirtual method_31549 : ()Lnet/minecraft/class_1656;
/*    */     //   35: getfield field_7477 : Z
/*    */     //   38: ifne -> 51
/*    */     //   41: aload_1
/*    */     //   42: getfield packet : Lnet/minecraft/class_2596;
/*    */     //   45: instanceof net/minecraft/class_2828
/*    */     //   48: ifne -> 52
/*    */     //   51: return
/*    */     //   52: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*    */     //   55: astore_2
/*    */     //   56: iconst_0
/*    */     //   57: istore_3
/*    */     //   58: aload_2
/*    */     //   59: invokevirtual getModules : ()Ljava/util/List;
/*    */     //   62: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   67: astore #4
/*    */     //   69: aload #4
/*    */     //   71: invokeinterface hasNext : ()Z
/*    */     //   76: ifeq -> 129
/*    */     //   79: aload #4
/*    */     //   81: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   86: checkcast net/integr/modules/management/Module
/*    */     //   89: astore #5
/*    */     //   91: aload #5
/*    */     //   93: invokevirtual getClass : ()Ljava/lang/Class;
/*    */     //   96: ldc net/integr/modules/impl/FlightModule
/*    */     //   98: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   101: ifeq -> 69
/*    */     //   104: aload #5
/*    */     //   106: dup
/*    */     //   107: ifnonnull -> 120
/*    */     //   110: new java/lang/NullPointerException
/*    */     //   113: dup
/*    */     //   114: ldc 'null cannot be cast to non-null type net.integr.modules.impl.FlightModule'
/*    */     //   116: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   119: athrow
/*    */     //   120: checkcast net/integr/modules/impl/FlightModule
/*    */     //   123: checkcast net/integr/modules/management/Module
/*    */     //   126: goto -> 130
/*    */     //   129: aconst_null
/*    */     //   130: dup
/*    */     //   131: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   134: checkcast net/integr/modules/impl/FlightModule
/*    */     //   137: invokevirtual isEnabled : ()Z
/*    */     //   140: ifne -> 212
/*    */     //   143: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   146: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   149: getfield field_1724 : Lnet/minecraft/class_746;
/*    */     //   152: dup
/*    */     //   153: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   156: invokevirtual method_6128 : ()Z
/*    */     //   159: ifeq -> 163
/*    */     //   162: return
/*    */     //   163: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   166: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   169: getfield field_1724 : Lnet/minecraft/class_746;
/*    */     //   172: dup
/*    */     //   173: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*    */     //   176: invokevirtual method_18798 : ()Lnet/minecraft/class_243;
/*    */     //   179: getfield field_1351 : D
/*    */     //   182: ldc2_w -0.5
/*    */     //   185: dcmpl
/*    */     //   186: ifle -> 190
/*    */     //   189: return
/*    */     //   190: aload_1
/*    */     //   191: getfield packet : Lnet/minecraft/class_2596;
/*    */     //   194: dup
/*    */     //   195: ldc 'null cannot be cast to non-null type net.integr.mixin.PlayerMoveC2SPacketAccessor'
/*    */     //   197: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   200: checkcast net/integr/mixin/PlayerMoveC2SPacketAccessor
/*    */     //   203: iconst_1
/*    */     //   204: invokeinterface setOnGround : (Z)V
/*    */     //   209: goto -> 231
/*    */     //   212: aload_1
/*    */     //   213: getfield packet : Lnet/minecraft/class_2596;
/*    */     //   216: dup
/*    */     //   217: ldc 'null cannot be cast to non-null type net.integr.mixin.PlayerMoveC2SPacketAccessor'
/*    */     //   219: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   222: checkcast net/integr/mixin/PlayerMoveC2SPacketAccessor
/*    */     //   225: iconst_1
/*    */     //   226: invokeinterface setOnGround : (Z)V
/*    */     //   231: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #35	-> 6
/*    */     //   #36	-> 19
/*    */     //   #38	-> 52
/*    */     //   #48	-> 58
/*    */     //   #49	-> 91
/*    */     //   #50	-> 104
/*    */     //   #54	-> 129
/*    */     //   #38	-> 130
/*    */     //   #39	-> 143
/*    */     //   #40	-> 163
/*    */     //   #42	-> 190
/*    */     //   #44	-> 212
/*    */     //   #46	-> 231
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   91	38	5	m$iv	Lnet/integr/modules/management/Module;
/*    */     //   58	72	3	$i$f$getByClass	I
/*    */     //   56	74	2	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*    */     //   0	232	0	this	Lnet/integr/modules/impl/NofallModule;
/*    */     //   0	232	1	event	Lnet/integr/event/SendPacketEvent;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\NofallModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */