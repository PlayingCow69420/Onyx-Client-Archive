/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1309;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020 \n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J-\020\017\032\0020\0162\006\020\t\032\0020\b2\006\020\n\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\017\020\020R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\021R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\022\032\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$MultiSelectionMode;", "Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "killauraMode", "rotMode", "", "Lnet/minecraft/class_1309;", "entities", "", "run", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */ public final class MultiSelectionMode
/*     */   extends KillAuraModule.SelectionMode
/*     */ {
/*     */   @NotNull
/*     */   private final SettingsBuilder settings;
/*     */   @NotNull
/*     */   private final KillAuraModule.ModeHandler modes;
/*     */   
/*     */   public MultiSelectionMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) {
/* 128 */     super("Multi"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */    public void run(@NotNull String killauraMode, @NotNull String rotMode, @NotNull List entities) {
/* 130 */     Intrinsics.checkNotNullParameter(killauraMode, "killauraMode"); Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entities, "entities"); for (KillAuraModule.KillAuraMode mode : this.modes.getKillAuraModes()) {
/* 131 */       if (Intrinsics.areEqual(mode.getName(), killauraMode)) {
/* 132 */         if (!entities.isEmpty()) {
/* 133 */           for (class_1309 entity : entities) mode.run(rotMode, entity);  break;
/* 134 */         }  RotationLocker.Companion.unLock();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillAuraModule$MultiSelectionMode.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */