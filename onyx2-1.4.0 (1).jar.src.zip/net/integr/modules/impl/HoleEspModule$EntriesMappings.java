package net.integr.modules.impl;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import net.minecraft.class_2350;



/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HoleEspModule$EntriesMappings.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */