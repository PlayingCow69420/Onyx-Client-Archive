/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.utilities.game.inventory.InvUtils;
/*    */ import net.minecraft.class_1792;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\002¢\006\004\b\t\020\003J\017\020\013\032\0020\nH\002¢\006\004\b\013\020\fJ\017\020\r\032\0020\nH\002¢\006\004\b\r\020\fR\030\020\017\032\004\030\0010\0168\002@\002X\016¢\006\006\n\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/AutoRefillModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/PreTickEvent;", "event", "", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "refillHand", "", "searchForItem", "()I", "searchInHotbar", "Lnet/minecraft/class_1792;", "lastItem", "Lnet/minecraft/class_1792;", "onyx2"})
/*    */ public final class AutoRefillModule
/*    */   extends Module
/*    */ {
/*    */   @Nullable
/*    */   private class_1792 lastItem;
/*    */   
/*    */   public AutoRefillModule() {
/* 29 */     super("Auto Refill", "Automatically gets the next stack of blocks", "autoRefill", Filter.Util, false, 16, null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PreTickEvent event) {
/* 36 */     Intrinsics.checkNotNullParameter(event, "event"); refillHand();
/*    */   }
/*    */   
/*    */   private final void refillHand() {
/* 40 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1724.method_31548().method_7391().method_7960()) {
/* 41 */       int slot = searchForItem();
/* 42 */       if (slot != -1) {
/* 43 */         InvUtils.Companion.quickMove(slot);
/* 44 */         if (searchInHotbar() != -1) {
/* 45 */           InvUtils.Companion.selectSlot(searchInHotbar());
/*    */         }
/*    */       } 
/*    */     } else {
/* 49 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); this.lastItem = (Onyx.Companion.getMC()).field_1724.method_31548().method_7391().method_7909();
/*    */     } 
/*    */   }
/*    */   
/*    */   private final int searchForItem() {
/* 54 */     int nextSlot = -1;
/*    */     
/* 56 */     for (int slot = 0; slot < 37; slot++) {
/* 57 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (Intrinsics.areEqual((Onyx.Companion.getMC()).field_1724.method_31548().method_5438(slot).method_7909(), this.lastItem))
/*    */       {
/* 59 */         if (nextSlot == -1) nextSlot = (slot < 9) ? (slot + 36) : slot; 
/*    */       }
/*    */     } 
/* 62 */     return nextSlot;
/*    */   }
/*    */   
/*    */   private final int searchInHotbar() {
/* 66 */     int nextSlot = -1;
/*    */     
/* 68 */     for (int slot = 0; slot < 9; slot++) {
/* 69 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (Intrinsics.areEqual((Onyx.Companion.getMC()).field_1724.method_31548().method_5438(slot).method_7909(), this.lastItem)) {
/* 70 */         return slot;
/*    */       }
/*    */     } 
/*    */     
/* 74 */     return nextSlot;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AutoRefillModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */