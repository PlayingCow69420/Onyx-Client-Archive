/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreEntityTakeDamageEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.eventsystem.Priority;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.minecraft.class_1109;
/*    */ import net.minecraft.class_1113;
/*    */ import net.minecraft.class_2394;
/*    */ import net.minecraft.class_2398;
/*    */ import net.minecraft.class_2400;
/*    */ import net.minecraft.class_3417;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\005\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\034\020\013\032\n \n*\004\030\0010\t0\t8\002X\004¢\006\006\n\004\b\013\020\fR\034\020\r\032\n \n*\004\030\0010\t0\t8\002X\004¢\006\006\n\004\b\r\020\f¨\006\016"}, d2 = {"Lnet/integr/modules/impl/HitEffectsModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/PreEntityTakeDamageEvent;", "event", "", "onEntityDamage", "(Lnet/integr/event/PreEntityTakeDamageEvent;)V", "Lnet/minecraft/class_1109;", "kotlin.jvm.PlatformType", "sound1", "Lnet/minecraft/class_1109;", "sound2", "onyx2"})
/*    */ public final class HitEffectsModule
/*    */   extends Module
/*    */ {
/*    */   private final class_1109 sound1;
/*    */   private final class_1109 sound2;
/*    */   
/*    */   public HitEffectsModule() {
/* 36 */     super("Hit Effects", "Does an effect when you hit a player", "hitEffects", Filter.Render, false, 16, null);
/*    */     
/* 38 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 46 */     this.sound1 = class_1109.method_4757(class_3417.field_14742, 1.3F, 0.1F);
/* 47 */     this.sound2 = class_1109.method_4757(class_3417.field_15145, 1.0F, 0.5F);
/*    */   }
/*    */   @EventListen(prio = Priority.FIRST)
/*    */   public final void onEntityDamage(@NotNull PreEntityTakeDamageEvent event) {
/* 51 */     Intrinsics.checkNotNullParameter(event, "event"); if (Intrinsics.areEqual(event.entity, (Onyx.Companion.getMC()).field_1724))
/* 52 */       return;  if (!(event.entity instanceof net.minecraft.class_1309)) {
/*    */       return;
/*    */     }
/* 55 */     Intrinsics.checkNotNull(getSettings().getById("sound")); if (((BooleanSetting)getSettings().getById("sound")).isEnabled()) {
/* 56 */       Onyx.Companion.getMC().method_1483().method_4873((class_1113)this.sound1);
/* 57 */       Onyx.Companion.getMC().method_1483().method_4873((class_1113)this.sound2);
/*    */     } 
/*    */     
/* 60 */     Intrinsics.checkNotNull(getSettings().getById("particles")); if (((BooleanSetting)getSettings().getById("particles")).isEnabled()) {
/* 61 */       double angle = 0.0D;
/* 62 */       while (angle <= 6.283185307179586D) {
/* 63 */         double x = Math.cos(angle);
/* 64 */         double z = Math.sin(angle);
/*    */         
/* 66 */         class_2400 effect = class_2398.field_11240;
/*    */         
/* 68 */         Intrinsics.checkNotNull(getSettings().getById("particleRange")); double range = ((SliderSetting)getSettings().getById("particleRange")).getSetValue();
/*    */         
/* 70 */         (Onyx.Companion.getMC()).field_1769.method_8568((class_2394)effect, true, event.entity.method_23317(), event.entity.method_23318(), event.entity.method_23321(), x * range, 0.0D, z * range);
/*    */         
/* 72 */         Intrinsics.checkNotNull(getSettings().getById("particleFrequency")); angle += ((SliderSetting)getSettings().getById("particleFrequency")).getSetValue();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HitEffectsModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */