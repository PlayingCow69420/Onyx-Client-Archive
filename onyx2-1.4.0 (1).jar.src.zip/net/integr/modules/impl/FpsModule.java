/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J/\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rR\026\020\017\032\0020\0168\002@\002X\016¢\006\006\n\004\b\017\020\020¨\006\021"}, d2 = {"Lnet/integr/modules/impl/FpsModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "background", "Lnet/integr/rendering/uisystem/Box;", "onyx2"})
/*    */ public final class FpsModule
/*    */   extends UiModule
/*    */ {
/*    */   @NotNull
/*    */   private Box background;
/*    */   
/*    */   public FpsModule() {
/* 27 */     super("Fps", "Renders your Fps", "fps", 22, 60, Filter.Render);
/* 28 */     this.background = new Box(0, 0, 60, 22, "Fps: ", false, false, false, 192, null);
/*    */   }
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/* 31 */     Intrinsics.checkNotNullParameter(context, "context"); this.background.setText("Fps: " + Onyx.Companion.getMC().method_47599());
/* 32 */     this.background.update(originX, originY).method_25394(context, 10, 10, delta);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\FpsModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */