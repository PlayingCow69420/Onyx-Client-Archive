/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\020\n\002\020!\n\002\020\016\n\002\020\002\n\002\b\003\020\005\032\0020\002*\b\022\004\022\0020\0010\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "", "", "invoke", "(Ljava/util/List;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<List<String>, Unit>
/*    */ {
/*    */   public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 41 */     Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(BhopFeature.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)BhopFeature.this.getSettings().getById("mode")).getElement());
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\BhopFeature$2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */