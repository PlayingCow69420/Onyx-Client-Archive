/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 46 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); String[] arrayOfString = new String[4]; arrayOfString[0] = "Normal"; arrayOfString[1] = "1.8"; arrayOfString[2] = "Wand"; arrayOfString[3] = "Mace"; $this$initSettings.add((Setting)new CyclerSetting("Mode: ", "The base mode to use", "mode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 47 */     arrayOfString = new String[2]; arrayOfString[0] = "Leftclick"; arrayOfString[1] = "Rightclick"; $this$initSettings.add((Setting)new CyclerSetting("Wand Type: ", "The wand mode to use", "wandMode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 48 */     $this$initSettings.add((Setting)new SliderSetting("Mace Height: ", "The height of mace mode to teleport", "maceHeight", 1.0D, 100.0D, 0.0D, 32, null));
/* 49 */     $this$initSettings.add((Setting)new BooleanSetting("Spoof Ground Mace", "Spoof ground for bypass on paper servers", "spoofGround", false, 8, null));
/* 50 */     arrayOfString = new String[3]; arrayOfString[0] = "Single"; arrayOfString[1] = "Switch"; arrayOfString[2] = "Multi"; $this$initSettings.add((Setting)new CyclerSetting("Attack Mode: ", "The mode to attack in", "attackMode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 51 */     arrayOfString = new String[4]; arrayOfString[0] = "Off"; arrayOfString[1] = "Instant"; arrayOfString[2] = "Lerp"; arrayOfString[3] = "Fake"; $this$initSettings.add((Setting)new CyclerSetting("Rotations: ", "The way to rotate in", "rotations", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 52 */     $this$initSettings.add((Setting)new SliderSetting("Range: ", "The maximum allowed range", "range", 1.0D, 7.0D, 0.0D, 32, null));
/* 53 */     $this$initSettings.add((Setting)new BooleanSetting("Critical", "Automatically do a Critical hit", "critical", false, 8, null));
/* 54 */     $this$initSettings.add((Setting)new BooleanSetting("AutoBlock", "Automatically block when attacking", "autoBlock", false, 8, null));
/* 55 */     arrayOfString = new String[3]; arrayOfString[0] = "All"; arrayOfString[1] = "Players"; arrayOfString[2] = "Mobs"; $this$initSettings.add((Setting)new CyclerSetting("Target: ", "The entities to target", "target", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillAuraModule$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */