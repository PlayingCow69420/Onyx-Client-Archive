/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005R\035\020\b\032\b\022\004\022\0020\0070\0068\006¢\006\f\n\004\b\b\020\t\032\004\b\n\020\013R\035\020\r\032\b\022\004\022\0020\f0\0068\006¢\006\f\n\004\b\r\020\t\032\004\b\016\020\013R\035\020\020\032\b\022\004\022\0020\0170\0068\006¢\006\f\n\004\b\020\020\t\032\004\b\021\020\013R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\022\032\004\b\023\020\024¨\006\025"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "killAuraModes", "Ljava/util/List;", "getKillAuraModes", "()Ljava/util/List;", "Lnet/integr/modules/impl/KillAuraModule$RotationMode;", "rotationModes", "getRotationModes", "Lnet/integr/modules/impl/KillAuraModule$SelectionMode;", "selectionModes", "getSelectionModes", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */ public final class ModeHandler
/*     */ {
/*     */   @NotNull
/*     */   private final SettingsBuilder settings;
/*     */   @NotNull
/*     */   private final List<KillAuraModule.KillAuraMode> killAuraModes;
/*     */   @NotNull
/*     */   private final List<KillAuraModule.SelectionMode> selectionModes;
/*     */   @NotNull
/*     */   private final List<KillAuraModule.RotationMode> rotationModes;
/*     */   
/*     */   public ModeHandler(@NotNull SettingsBuilder settings) {
/* 287 */     this.settings = settings;
/*     */     
/* 289 */     KillAuraModule.KillAuraMode[] arrayOfKillAuraMode = new KillAuraModule.KillAuraMode[4]; arrayOfKillAuraMode[0] = new KillAuraModule.NormalKillAuraMode(this.settings, this); arrayOfKillAuraMode[1] = 
/* 290 */       new KillAuraModule.OneDotEightKillAuraMode(this.settings, this);
/* 291 */     arrayOfKillAuraMode[2] = new KillAuraModule.WandKillAuraMode(this.settings, this);
/* 292 */     arrayOfKillAuraMode[3] = new KillAuraModule.MaceKillAuraMode(this.settings, this);
/*     */     
/*     */     this.killAuraModes = CollectionsKt.listOf((Object[])arrayOfKillAuraMode);
/*     */     
/* 296 */     KillAuraModule.SelectionMode[] arrayOfSelectionMode = new KillAuraModule.SelectionMode[3]; arrayOfSelectionMode[0] = new KillAuraModule.SingleSelectionMode(this.settings, this); arrayOfSelectionMode[1] = 
/* 297 */       new KillAuraModule.SwitchSelectionMode(this.settings, this);
/* 298 */     arrayOfSelectionMode[2] = new KillAuraModule.MultiSelectionMode(this.settings, this);
/*     */     
/*     */     this.selectionModes = CollectionsKt.listOf((Object[])arrayOfSelectionMode);
/*     */     
/* 302 */     KillAuraModule.RotationMode[] arrayOfRotationMode = new KillAuraModule.RotationMode[4]; arrayOfRotationMode[0] = new KillAuraModule.InstantRotationMode(this.settings, this); arrayOfRotationMode[1] = 
/* 303 */       new KillAuraModule.LerpRotationMode(this.settings, this);
/* 304 */     arrayOfRotationMode[2] = new KillAuraModule.FakeRotationMode(this.settings, this);
/* 305 */     arrayOfRotationMode[3] = new KillAuraModule.OffRotationMode(this.settings, this);
/*     */     this.rotationModes = CollectionsKt.listOf((Object[])arrayOfRotationMode);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final SettingsBuilder getSettings() {
/*     */     return this.settings;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final List<KillAuraModule.KillAuraMode> getKillAuraModes() {
/*     */     return this.killAuraModes;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final List<KillAuraModule.SelectionMode> getSelectionModes() {
/*     */     return this.selectionModes;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final List<KillAuraModule.RotationMode> getRotationModes() {
/*     */     return this.rotationModes;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillAuraModule$ModeHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */