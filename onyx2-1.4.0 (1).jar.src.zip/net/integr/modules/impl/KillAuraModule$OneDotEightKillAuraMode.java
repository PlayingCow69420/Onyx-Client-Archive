/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Variables;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.utilities.game.interaction.AttackUtils;
/*     */ import net.integr.utilities.game.interaction.ClickUtils;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\006\020\t\032\0020\b2\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\020\032\004\b\021\020\022¨\006\023"}, d2 = {"Lnet/integr/modules/impl/KillAuraModule$OneDotEightKillAuraMode;", "Lnet/integr/modules/impl/KillAuraModule$KillAuraMode;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "modes", "<init>", "(Lnet/integr/modules/management/settings/SettingsBuilder;Lnet/integr/modules/impl/KillAuraModule$ModeHandler;)V", "", "rotMode", "Lnet/minecraft/class_1309;", "entity", "", "run", "(Ljava/lang/String;Lnet/minecraft/class_1309;)V", "Lnet/integr/modules/impl/KillAuraModule$ModeHandler;", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "onyx2"})
/*     */ public final class OneDotEightKillAuraMode
/*     */   extends KillAuraModule.KillAuraMode
/*     */ {
/*     */   @NotNull
/*     */   private final SettingsBuilder settings;
/*     */   @NotNull
/*     */   private final KillAuraModule.ModeHandler modes;
/*     */   
/*     */   public OneDotEightKillAuraMode(@NotNull SettingsBuilder settings, @NotNull KillAuraModule.ModeHandler modes) {
/* 162 */     super("1.8"); this.settings = settings; this.modes = modes; } @NotNull public final SettingsBuilder getSettings() { return this.settings; }
/*     */    public void run(@NotNull String rotMode, @NotNull class_1309 entity) {
/* 164 */     Intrinsics.checkNotNullParameter(rotMode, "rotMode"); Intrinsics.checkNotNullParameter(entity, "entity"); Intrinsics.checkNotNull(this.settings.getById("critical")); boolean critical = ((BooleanSetting)this.settings.getById("critical")).isEnabled();
/* 165 */     Intrinsics.checkNotNull(this.settings.getById("autoBlock")); boolean autoBlock = ((BooleanSetting)this.settings.getById("autoBlock")).isEnabled();
/*     */     
/* 167 */     boolean found = false;
/*     */     
/* 169 */     for (KillAuraModule.RotationMode mode : this.modes.getRotationModes()) {
/* 170 */       if (Intrinsics.areEqual(mode.getName(), rotMode)) {
/* 171 */         Variables.Companion.setTarget(entity);
/* 172 */         if (AttackUtils.Companion.canAttack()) {
/* 173 */           AttackUtils.Companion.attackWithoutReset$default(AttackUtils.Companion, (class_1297)entity, critical, false, 4, null);
/*     */         }
/*     */         
/* 176 */         if (autoBlock) ClickUtils.Companion.rightClick();
/*     */         
/* 178 */         mode.run(entity);
/* 179 */         found = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 184 */     if (!found) RotationLocker.Companion.unLock(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KillAuraModule$OneDotEightKillAuraMode.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */