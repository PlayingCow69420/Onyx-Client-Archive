/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.utilities.game.command.CommandUtils;
/*     */ import net.integr.utilities.game.interaction.ClickUtils;
/*     */ import net.integr.utilities.game.interaction.RotationUtils;
/*     */ import net.integr.utilities.game.inventory.InvUtils;
/*     */ import net.integr.utilities.game.pausers.CombatPauser;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\b\020\tR\026\020\013\032\0020\n8\002@\002X\016¢\006\006\n\004\b\013\020\f¨\006\r"}, d2 = {"Lnet/integr/modules/impl/AutoMendModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onDisable", "Lnet/integr/event/PreTickEvent;", "event", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "", "redupeCounter", "I", "onyx2"})
/*     */ public final class AutoMendModule
/*     */   extends Module
/*     */ {
/*     */   private int redupeCounter;
/*     */   
/*     */   public AutoMendModule() {
/*  35 */     super("Auto Mend", "Automatically repairs your armor", "autoMend", Filter.Util, false, 16, null);
/*     */     
/*  37 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  44 */     RotationLocker.Companion.unLock();
/*  45 */     CombatPauser.Companion.resume();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*  52 */     Intrinsics.checkNotNullParameter(event, "event"); if (this.redupeCounter > 0) {
/*  53 */       int i = this.redupeCounter; this.redupeCounter = i + -1;
/*     */     } 
/*     */     
/*  56 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(3), "get(...)"); class_1799 helmetItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(3);
/*  57 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(2), "get(...)"); class_1799 chestPlateItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(2);
/*  58 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(1), "get(...)"); class_1799 leggingsItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(1);
/*  59 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(0), "get(...)"); class_1799 bootsItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(0);
/*     */     
/*  61 */     double helmetPercent = (helmetItem.method_7936() != 0) ? ((helmetItem.method_7936() - helmetItem.method_7919()) / helmetItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/*  62 */     double chestPlatePercent = (chestPlateItem.method_7936() != 0) ? ((chestPlateItem.method_7936() - chestPlateItem.method_7919()) / chestPlateItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/*  63 */     double leggingsPercent = (leggingsItem.method_7936() != 0) ? ((leggingsItem.method_7936() - leggingsItem.method_7919()) / leggingsItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/*  64 */     double bootsPercent = (bootsItem.method_7936() != 0) ? ((bootsItem.method_7936() - bootsItem.method_7919()) / bootsItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/*     */     
/*  66 */     if (helmetPercent >= 100.0D && chestPlatePercent >= 100.0D && leggingsPercent >= 100.0D && bootsPercent >= 100.0D) {
/*  67 */       RotationLocker.Companion.unLock();
/*  68 */       CombatPauser.Companion.resume();
/*     */       
/*  70 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  74 */     Intrinsics.checkNotNull(getSettings().getById("pauseCombat")); boolean pauseCombat = ((BooleanSetting)getSettings().getById("pauseCombat")).isEnabled();
/*     */     
/*  76 */     Intrinsics.checkNotNullExpressionValue(class_1802.field_8287, "EXPERIENCE_BOTTLE"); int slot = InvUtils.Companion.findInHotbar(class_1802.field_8287);
/*     */     
/*  78 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (slot != -1 && !(Onyx.Companion.getMC()).field_1687.method_8320((Onyx.Companion.getMC()).field_1724.method_24515().method_10074()).method_26215()) {
/*  79 */       if (pauseCombat)
/*  80 */       { CombatPauser.Companion.pause(); }
/*  81 */       else { CombatPauser.Companion.resume(); }
/*     */       
/*  83 */       int pre = InvUtils.Companion.getSelectedSlot();
/*  84 */       InvUtils.Companion.selectSlotPacket(slot);
/*  85 */       InvUtils.Companion.selectSlot(slot);
/*     */       
/*  87 */       if (this.redupeCounter == 0) {
/*  88 */         CommandUtils.Companion.sendCommand("dupe 2");
/*     */         
/*  90 */         this.redupeCounter = 20;
/*     */       } 
/*     */       
/*  93 */       RotationLocker.Companion.lock();
/*  94 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, -1.0D, 0.0D), "add(...)"); RotationUtils.Companion.lookAt((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, -1.0D, 0.0D), true);
/*     */       
/*  96 */       ClickUtils.Companion.rightClick();
/*  97 */       InvUtils.Companion.selectSlot(pre);
/*     */     } else {
/*  99 */       RotationLocker.Companion.unLock();
/* 100 */       CombatPauser.Companion.resume();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\AutoMendModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */