/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.event.RenderWorldEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.UiModule;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.Slider;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_490;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Quaternionf;
/*     */ import org.joml.Vector3f;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000`\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\020\007\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\004\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\002\n\002\020\006\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003JG\020\020\032\0020\0172\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\t\032\0020\0062\006\020\013\032\0020\n2\006\020\f\032\0020\n2\006\020\016\032\0020\rH\002¢\006\004\b\020\020\021J/\020\022\032\0020\0172\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\016\032\0020\rH\002¢\006\004\b\022\020\023J\027\020\026\032\0020\0172\006\020\025\032\0020\024H\007¢\006\004\b\026\020\027J/\020\033\032\0020\0172\006\020\005\032\0020\0042\006\020\030\032\0020\0062\006\020\031\032\0020\0062\006\020\032\032\0020\nH\026¢\006\004\b\033\020\034J\017\020\035\032\0020\017H\002¢\006\004\b\035\020\003R\024\020\037\032\0020\0368\002X\004¢\006\006\n\004\b\037\020 R\026\020\"\032\0020!8\002@\002X\016¢\006\006\n\004\b\"\020#R\024\020%\032\0020$8\002X\004¢\006\006\n\004\b%\020&R\024\020'\032\0020$8\002X\004¢\006\006\n\004\b'\020&R\030\020)\032\004\030\0010(8\002@\002X\016¢\006\006\n\004\b)\020*R\024\020+\032\0020\0368\002X\004¢\006\006\n\004\b+\020 R\026\020-\032\0020,8\002@\002X\016¢\006\006\n\004\b-\020.¨\006/"}, d2 = {"Lnet/integr/modules/impl/TargetHudModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "x", "y", "size", "", "yaw", "pitch", "Lnet/minecraft/class_1309;", "entity", "", "drawEntity", "(Lnet/minecraft/class_332;IIIFFLnet/minecraft/class_1309;)V", "drawWithParams", "(Lnet/minecraft/class_332;IILnet/minecraft/class_1309;)V", "Lnet/integr/event/RenderWorldEvent;", "event", "onRender", "(Lnet/integr/event/RenderWorldEvent;)V", "originX", "originY", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "updateOffset", "Lnet/integr/rendering/uisystem/Box;", "backgroundBox", "Lnet/integr/rendering/uisystem/Box;", "", "currentYOffset", "D", "Lnet/integr/rendering/uisystem/Slider;", "defenseSlider", "Lnet/integr/rendering/uisystem/Slider;", "healthSlider", "Lnet/minecraft/class_243;", "lastPos", "Lnet/minecraft/class_243;", "nameBox", "", "travelsUp", "Z", "onyx2"})
/*     */ public final class TargetHudModule
/*     */   extends UiModule
/*     */ {
/*     */   private double currentYOffset;
/*     */   private boolean travelsUp;
/*     */   @Nullable
/*     */   private class_243 lastPos;
/*     */   
/*     */   public TargetHudModule() {
/*  43 */     super("Target Hud", "Shows info on the current target", "targetHud", 78, 202, Filter.Render);
/*     */     
/*  45 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     this.travelsUp = true;
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.backgroundBox = new Box(0, 0, 202, 78, null, false, true, false);
/*  57 */     this.nameBox = new Box(0, 0, 90, 20, "", false, false, false);
/*     */     
/*  59 */     this.healthSlider = new Slider(0, 100, 130, 20, " Health: ", false, "", 0.0D, 20.0D);
/*  60 */     this.defenseSlider = new Slider(0, 100, 130, 20, " Armor: ", false, "", 0.0D, 20.0D); } @NotNull private final Box backgroundBox; @NotNull
/*     */   private final Box nameBox; @NotNull
/*     */   private final Slider healthSlider; @NotNull
/*  63 */   private final Slider defenseSlider; public void render(@NotNull class_332 context, int originX, int originY, float delta) { Intrinsics.checkNotNullParameter(context, "context"); class_1309 target = Variables.Companion.getTarget();
/*     */     
/*  65 */     Intrinsics.checkNotNull(getSettings().getById("box")); if (target != null && ((BooleanSetting)getSettings().getById("box")).isEnabled()) {
/*  66 */       this.backgroundBox.update(originX, originY).method_25394(context, 0, 0, delta);
/*     */       
/*  68 */       if (target instanceof class_1657) { this.nameBox.setText(((class_1657)target).method_7334().getName()); } else { this.nameBox.setText(target.method_5864().method_5897().getString()); }
/*  69 */        this.nameBox.update(originX + 6, originY + 4).method_25394(context, 0, 0, delta);
/*     */       
/*  71 */       this.defenseSlider.setMax(20.0D);
/*  72 */       this.defenseSlider.setValue(target.method_6096());
/*  73 */       this.defenseSlider.update(originX + 5, originY + 26).method_25394(context, 0, 0, delta);
/*     */       
/*  75 */       this.healthSlider.setMax(target.method_6063() + target.method_52541());
/*  76 */       this.healthSlider.setValue(target.method_6032() + target.method_6067());
/*  77 */       this.healthSlider.update(originX + 5, originY + 51).method_25394(context, 0, 0, delta);
/*     */       
/*  79 */       drawWithParams(context, originX + 70, originY + 3, target);
/*     */     }  }
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onRender(@NotNull RenderWorldEvent event) {
/*  85 */     Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("circle")); if (((BooleanSetting)getSettings().getById("circle")).isEnabled() && Variables.Companion.getTarget() != null) {
/*  86 */       Intrinsics.checkNotNull(Variables.Companion.getTarget()); class_243 ePos = CoordinateUtils.Companion.getLerpedEntityPos((class_1297)Variables.Companion.getTarget(), event.tickDelta);
/*     */       
/*  88 */       if (this.lastPos != null) {
/*  89 */         Intrinsics.checkNotNull(this.lastPos); class_243 lerpedPos = CoordinateUtils.Companion.lerpPositionBetween(this.lastPos, ePos, 0.5F);
/*  90 */         this.lastPos = lerpedPos;
/*     */         
/*  92 */         Intrinsics.checkNotNullExpressionValue(lerpedPos.method_1031(0.0D, this.currentYOffset, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(lerpedPos.method_1031(0.0D, this.currentYOffset, 0.0D), 0.1D, 0.7D, 0.0F, true, event.matrices, Variables.Companion.getGuiColor());
/*  93 */         Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(lerpedPos, 0.1D, 0.7D, 0.0F, false, event.matrices, Variables.Companion.getGuiColor());
/*  94 */         Intrinsics.checkNotNull(Variables.Companion.getTarget()); Intrinsics.checkNotNullExpressionValue(lerpedPos.method_1031(0.0D, Variables.Companion.getTarget().method_5829().method_17940(), 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.circle(lerpedPos.method_1031(0.0D, Variables.Companion.getTarget().method_5829().method_17940(), 0.0D), 0.1D, 0.7D, 0.0F, false, event.matrices, Variables.Companion.getGuiColor());
/*     */       } else {
/*  96 */         this.lastPos = ePos;
/*     */       } 
/*     */       
/*  99 */       updateOffset();
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void updateOffset() {
/* 104 */     if (this.travelsUp) {
/* 105 */       this.currentYOffset += 0.05D;
/* 106 */       Intrinsics.checkNotNull(Variables.Companion.getTarget()); if (this.currentYOffset >= Variables.Companion.getTarget().method_5829().method_17940()) {
/* 107 */         this.travelsUp = false;
/*     */       }
/*     */     } else {
/* 110 */       this.currentYOffset -= 0.05D;
/* 111 */       if (this.currentYOffset <= 0.0D) {
/* 112 */         this.travelsUp = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void drawWithParams(class_332 context, int x, int y, class_1309 entity) {
/* 118 */     float yawN = class_3532.method_15393(entity.field_5982 + (entity.method_36454() - entity.field_5982) * Onyx.Companion.getMC().method_60646().method_60637(true)) - 45;
/* 119 */     drawEntity(context, x, y, 35, yawN, entity.method_36455(), entity);
/*     */   }
/*     */ 
/*     */   
/*     */   private final void drawEntity(class_332 context, int x, int y, int size, float yaw, float pitch, class_1309 entity) {
/* 124 */     float tanYaw = (float)Math.atan((yaw / 40.0F));
/* 125 */     float tanPitch = (float)Math.atan((pitch / 40.0F));
/*     */     
/* 127 */     Quaternionf quaternion = (new Quaternionf()).rotateZ(3.1415927F);
/*     */ 
/*     */     
/* 130 */     float previousBodyYaw = entity.field_6283;
/* 131 */     float previousYaw = entity.method_36454();
/* 132 */     float previousPitch = entity.method_36455();
/* 133 */     float previousPrevHeadYaw = entity.field_6259;
/* 134 */     float prevHeadYaw = entity.field_6241;
/*     */     
/* 136 */     entity.field_6283 = 180.0F + tanYaw * 20.0F;
/* 137 */     entity.method_36456(180.0F + tanYaw * 40.0F);
/* 138 */     entity.method_36457(-tanPitch * 20.0F);
/* 139 */     entity.field_6241 = entity.method_36454();
/* 140 */     entity.field_6259 = entity.method_36454();
/*     */     
/* 142 */     class_490.method_48472(context, (x + getWidth() / 2), y + getHeight() * 0.9F, size, new Vector3f(), quaternion, null, entity);
/*     */     
/* 144 */     entity.field_6283 = previousBodyYaw;
/* 145 */     entity.method_36456(previousYaw);
/* 146 */     entity.method_36457(previousPitch);
/* 147 */     entity.field_6259 = previousPrevHeadYaw;
/* 148 */     entity.field_6241 = prevHeadYaw;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\TargetHudModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */