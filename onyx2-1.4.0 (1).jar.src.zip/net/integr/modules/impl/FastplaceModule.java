/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*    */ import net.integr.utilities.game.interaction.ClickUtils;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020\b\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\026\020\n\032\0020\t8\002@\002X\016¢\006\006\n\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/modules/impl/FastplaceModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/PreTickEvent;", "event", "", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "", "timer", "I", "onyx2"})
/*    */ public final class FastplaceModule
/*    */   extends Module
/*    */ {
/*    */   private int timer;
/*    */   
/*    */   public FastplaceModule() {
/* 30 */     super("Fastplace", "Place faster", "fastplace", Filter.Util, false, 16, null);
/*    */     
/* 32 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PreTickEvent event) {
/* 41 */     Intrinsics.checkNotNullParameter(event, "event"); if (this.timer > 0) {
/* 42 */       int i = this.timer; this.timer = i + -1;
/*    */       
/*    */       return;
/*    */     } 
/* 46 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if ((Onyx.Companion.getMC()).field_1690.field_1904.method_1434() && !(Onyx.Companion.getMC()).field_1724.method_6115()) ClickUtils.Companion.rightClickBlock();
/*    */     
/* 48 */     Intrinsics.checkNotNull(getSettings().getById("delay")); this.timer = ((IntSliderSetting)getSettings().getById("delay")).getSetValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\FastplaceModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */