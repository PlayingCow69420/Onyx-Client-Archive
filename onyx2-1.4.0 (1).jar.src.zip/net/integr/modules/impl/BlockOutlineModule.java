/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Variables;
/*    */ import net.integr.event.RenderWorldEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.rendering.RenderingEngine;
/*    */ import net.integr.utilities.game.CoordinateUtils;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_3965;
/*    */ import net.minecraft.class_3966;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\030\020\n\032\004\030\0010\t8\002@\002X\016¢\006\006\n\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/modules/impl/BlockOutlineModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/RenderWorldEvent;", "event", "", "onRender", "(Lnet/integr/event/RenderWorldEvent;)V", "Lnet/minecraft/class_243;", "oldPos", "Lnet/minecraft/class_243;", "onyx2"})
/*    */ public final class BlockOutlineModule extends Module {
/*    */   @Nullable
/*    */   private class_243 oldPos;
/*    */   
/*    */   public BlockOutlineModule() {
/* 36 */     super("Block Outline", "Changes your block outline", "blockOutline", Filter.Render, false, 16, null);
/*    */     
/* 38 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 45 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(BlockOutlineModule.this.getSettings().getById("mode")); $this$initHacklist.add(((CyclerSetting)BlockOutlineModule.this.getSettings().getById("mode")).getElement());
/*    */           } }
/*    */       );
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onRender(@NotNull RenderWorldEvent event) {
/* 53 */     Intrinsics.checkNotNullParameter(event, "event"); class_239 t = (Onyx.Companion.getMC()).field_1765;
/*    */     
/* 55 */     if (((t != null) ? t.method_17783() : null) == class_239.class_240.field_1332) {
/* 56 */       Intrinsics.checkNotNull(t, "null cannot be cast to non-null type net.minecraft.util.hit.BlockHitResult"); class_2338 posN = ((class_3965)t).method_17777();
/*    */       
/* 58 */       if (this.oldPos == null) {
/* 59 */         this.oldPos = posN.method_46558();
/*    */       }
/*    */       
/* 62 */       Intrinsics.checkNotNull(this.oldPos); Intrinsics.checkNotNullExpressionValue(posN.method_46558(), "toCenterPos(...)"); class_243 pos = CoordinateUtils.Companion.lerpPositionBetween(this.oldPos, posN.method_46558(), 0.5F);
/* 63 */       this.oldPos = pos;
/*    */       
/* 65 */       Intrinsics.checkNotNull(getSettings().getById("lerpMovement")); if (!((BooleanSetting)getSettings().getById("lerpMovement")).isEnabled()) {
/* 66 */         Intrinsics.checkNotNullExpressionValue(posN.method_46558(), "toCenterPos(...)"); pos = posN.method_46558();
/*    */       } 
/*    */       
/* 69 */       Intrinsics.checkNotNull(getSettings().getById("mode")); String str = ((CyclerSetting)getSettings().getById("mode")).getElement();
/* 70 */       if (Intrinsics.areEqual(str, "Full")) {
/* 71 */         Intrinsics.checkNotNullExpressionValue(pos.method_1031(0.0D, -0.5D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.box(pos.method_1031(0.0D, -0.5D, 0.0D), event.matrices, Variables.Companion.getGuiColor());
/*    */       
/*    */       }
/* 74 */       else if (Intrinsics.areEqual(str, "Lines")) {
/* 75 */         Intrinsics.checkNotNullExpressionValue(pos.method_1031(0.0D, -0.5D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.outlinedBox(pos.method_1031(0.0D, -0.5D, 0.0D), event.matrices, Variables.Companion.getGuiColor());
/*    */       } 
/*    */     } else {
/* 78 */       Intrinsics.checkNotNull(getSettings().getById("entityBox")); if (((t != null) ? t.method_17783() : null) == class_239.class_240.field_1331 && ((BooleanSetting)getSettings().getById("entityBox")).isEnabled()) {
/* 79 */         Intrinsics.checkNotNull(t, "null cannot be cast to non-null type net.minecraft.util.hit.EntityHitResult"); class_3966 te = (class_3966)t;
/*    */         
/* 81 */         if (!te.method_17782().method_5767()) {
/* 82 */           Intrinsics.checkNotNull(getSettings().getById("mode")); String str = ((CyclerSetting)getSettings().getById("mode")).getElement();
/* 83 */           if (Intrinsics.areEqual(str, "Full")) {
/* 84 */             Intrinsics.checkNotNullExpressionValue(te.method_17782(), "getEntity(...)"); Intrinsics.checkNotNullExpressionValue(te.method_17782(), "getEntity(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.box(CoordinateUtils.Companion.getEntityBox(te.method_17782()), CoordinateUtils.Companion.getLerpedEntityPos(te.method_17782(), event.tickDelta), event.matrices, Variables.Companion.getGuiColor());
/*    */           
/*    */           }
/* 87 */           else if (Intrinsics.areEqual(str, "Lines")) {
/* 88 */             Intrinsics.checkNotNullExpressionValue(te.method_17782(), "getEntity(...)"); Intrinsics.checkNotNullExpressionValue(te.method_17782(), "getEntity(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.outlinedBox(CoordinateUtils.Companion.getEntityBox(te.method_17782()), CoordinateUtils.Companion.getLerpedEntityPos(te.method_17782(), event.tickDelta), event.matrices, Variables.Companion.getGuiColor());
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\BlockOutlineModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */