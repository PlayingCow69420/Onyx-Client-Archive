/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\002\n\002\b\003\020\004\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "invoke", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "<anonymous>"})
/*    */ final class null
/*    */   extends Lambda
/*    */   implements Function1<SettingsBuilder, Unit>
/*    */ {
/*    */   public static final null INSTANCE = (null)new Object();
/*    */   
/*    */   public final void invoke(@NotNull SettingsBuilder $this$initSettings) {
/* 35 */     Intrinsics.checkNotNullParameter($this$initSettings, "$this$initSettings"); String[] arrayOfString = new String[2]; arrayOfString[0] = "Normal"; arrayOfString[1] = "Low"; $this$initSettings.add((Setting)new CyclerSetting("Mode: ", "The mode to use", "mode", CollectionsKt.mutableListOf((Object[])arrayOfString)));
/* 36 */     $this$initSettings.add((Setting)new SliderSetting("Speed: ", "The speed of the bhop", "speed", 1.0D, 10.0D, 0.0D, 32, null));
/* 37 */     $this$initSettings.add((Setting)new SliderSetting("Low Height: ", "The height of the Low mode jumps", "lowHeight", 15.0D, 40.0D, 0.0D, 32, null));
/*    */   }
/*    */   
/*    */   null() {
/*    */     super(1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\BhopFeature$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */