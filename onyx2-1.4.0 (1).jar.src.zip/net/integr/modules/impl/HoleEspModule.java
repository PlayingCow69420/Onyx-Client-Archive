/*     */ package net.integr.modules.impl;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.NoWhenBranchMatchedException;
/*     */ import kotlin.Unit;
/*     */ import kotlin.enums.EnumEntries;
/*     */ import kotlin.enums.EnumEntriesKt;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.event.RenderWorldEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.utilities.game.pathfind.PathfindingManager;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\030\0002\0020\001:\001\035B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ5\020\016\032\004\030\0010\n2\"\020\r\032\036\022\004\022\0020\n\022\004\022\0020\0130\tj\016\022\004\022\0020\n\022\004\022\0020\013`\fH\002¢\006\004\b\016\020\017J\027\020\021\032\0020\0062\006\020\020\032\0020\nH\002¢\006\004\b\021\020\022J\027\020\025\032\0020\0062\006\020\024\032\0020\023H\007¢\006\004\b\025\020\026J\027\020\030\032\0020\0062\006\020\024\032\0020\027H\007¢\006\004\b\030\020\031R0\020\r\032\036\022\004\022\0020\n\022\004\022\0020\0130\tj\016\022\004\022\0020\n\022\004\022\0020\013`\f8\002X\004¢\006\006\n\004\b\r\020\032R\026\020\033\032\0020\0048\002@\002X\016¢\006\006\n\004\b\033\020\034¨\006\036"}, d2 = {"Lnet/integr/modules/impl/HoleEspModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "range", "", "getHoles", "(I)V", "Ljava/util/HashMap;", "Lnet/minecraft/class_2338;", "Lnet/integr/modules/impl/HoleEspModule$HoleType;", "Lkotlin/collections/HashMap;", "holes", "getNextHole", "(Ljava/util/HashMap;)Lnet/minecraft/class_2338;", "blockPos", "handleHole", "(Lnet/minecraft/class_2338;)V", "Lnet/integr/event/RenderWorldEvent;", "event", "onRenderWorld", "(Lnet/integr/event/RenderWorldEvent;)V", "Lnet/integr/event/PreTickEvent;", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "Ljava/util/HashMap;", "timer", "I", "HoleType", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nHoleEspModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HoleEspModule.kt\nnet/integr/modules/impl/HoleEspModule\n+ 2 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,137:1\n215#2,2:138\n1#3:140\n526#4:141\n511#4,6:142\n2333#5,14:148\n*S KotlinDebug\n*F\n+ 1 HoleEspModule.kt\nnet/integr/modules/impl/HoleEspModule\n*L\n61#1:138,2\n88#1:141\n88#1:142,6\n88#1:148,14\n*E\n"})
/*     */ public final class HoleEspModule extends Module {
/*     */   @NotNull
/*     */   private final HashMap<class_2338, HoleType> holes;
/*     */   
/*     */   public HoleEspModule() {
/*  40 */     super("Hole Esp", "Shows all holes in close proximity", "holeEsp", Filter.Render, false, 16, null);
/*     */     
/*  42 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/*  49 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(HoleEspModule.this.getSettings().getById("range")); $this$initHacklist.add("" + ((IntSliderSetting)HoleEspModule.this.getSettings().getById("range")).getSetValue() + "m");
/*     */           } }
/*     */       );
/*     */     
/*  53 */     this.holes = new HashMap<>();
/*     */   } private int timer; @EventListen
/*     */   public final void onRenderWorld(@NotNull RenderWorldEvent event) {
/*     */     class_2338 next;
/*     */     Iterator<Map.Entry> iterator;
/*  58 */     Intrinsics.checkNotNullParameter(event, "event"); if (!this.holes.isEmpty())
/*  59 */     { if (getNextHole(this.holes) == null) { getNextHole(this.holes); return; }
/*     */       
/*  61 */       Map<class_2338, HoleType> $this$forEach$iv = this.holes; int $i$f$forEach = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       iterator = $this$forEach$iv.entrySet().iterator(); } else { return; }  if (iterator.hasNext()) { Map.Entry element$iv = iterator.next(), entry1 = element$iv; int $i$a$-forEach-HoleEspModule$onRenderWorld$1 = 0;
/*     */       class_2338 blockPos = (class_2338)entry1.getKey();
/*     */       HoleType holeType = (HoleType)entry1.getValue();
/*     */       Color color = holeType.getColor();
/*     */       Intrinsics.checkNotNullExpressionValue(blockPos.method_46558(), "toCenterPos(...)");
/*     */       Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices");
/*     */       RenderingEngine.ThreeDimensional.Companion.floorQuad(blockPos.method_46558(), event.matrices, color.getRGB()); }
/*     */     
/*     */     Intrinsics.checkNotNull(getSettings().getById("autoPathfind"));
/*     */     if (((BooleanSetting)getSettings().getById("autoPathfind")).isEnabled()) {
/*     */       Intrinsics.checkNotNull(this.holes.get(next));
/*     */       Path.render$default(PathfindingManager.Companion.getPathToBlock$default(PathfindingManager.Companion, next, null, 2, null).smoothened(), this.holes.get(next).getColor().getRGB(), 0, 2, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListen
/*     */   public final void onTick(@NotNull PreTickEvent event) {
/*     */     Intrinsics.checkNotNullParameter(event, "event");
/*     */     if (this.timer >= 0) {
/*     */       int i = this.timer;
/*     */       this.timer = i + -1;
/*     */       return;
/*     */     } 
/*     */     this.holes.clear();
/*     */     Intrinsics.checkNotNull(getSettings().getById("range"));
/*     */     getHoles(((IntSliderSetting)getSettings().getById("range")).getSetValue());
/*     */     Intrinsics.checkNotNull(getSettings().getById("delay"));
/*     */     this.timer = (int)((SliderSetting)getSettings().getById("delay")).getSetValue();
/*     */   }
/*     */   
/*     */   private final class_2338 getNextHole(HashMap holes) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: checkcast java/util/Map
/*     */     //   4: invokeinterface entrySet : ()Ljava/util/Set;
/*     */     //   9: checkcast java/lang/Iterable
/*     */     //   12: astore #4
/*     */     //   14: aload #4
/*     */     //   16: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   21: astore #5
/*     */     //   23: aload #5
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifne -> 41
/*     */     //   33: new java/util/NoSuchElementException
/*     */     //   36: dup
/*     */     //   37: invokespecial <init> : ()V
/*     */     //   40: athrow
/*     */     //   41: aload #5
/*     */     //   43: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   48: astore #6
/*     */     //   50: aload #5
/*     */     //   52: invokeinterface hasNext : ()Z
/*     */     //   57: ifne -> 65
/*     */     //   60: aload #6
/*     */     //   62: goto -> 151
/*     */     //   65: aload #6
/*     */     //   67: checkcast java/util/Map$Entry
/*     */     //   70: astore #7
/*     */     //   72: iconst_0
/*     */     //   73: istore #9
/*     */     //   75: aload #7
/*     */     //   77: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   82: checkcast net/integr/modules/impl/HoleEspModule$HoleType
/*     */     //   85: invokevirtual ordinal : ()I
/*     */     //   88: istore #7
/*     */     //   90: aload #5
/*     */     //   92: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   97: astore #9
/*     */     //   99: aload #9
/*     */     //   101: checkcast java/util/Map$Entry
/*     */     //   104: astore #10
/*     */     //   106: iconst_0
/*     */     //   107: istore #12
/*     */     //   109: aload #10
/*     */     //   111: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   116: checkcast net/integr/modules/impl/HoleEspModule$HoleType
/*     */     //   119: invokevirtual ordinal : ()I
/*     */     //   122: istore #10
/*     */     //   124: iload #7
/*     */     //   126: iload #10
/*     */     //   128: if_icmple -> 139
/*     */     //   131: aload #9
/*     */     //   133: astore #6
/*     */     //   135: iload #10
/*     */     //   137: istore #7
/*     */     //   139: aload #5
/*     */     //   141: invokeinterface hasNext : ()Z
/*     */     //   146: ifne -> 90
/*     */     //   149: aload #6
/*     */     //   151: checkcast java/util/Map$Entry
/*     */     //   154: astore_2
/*     */     //   155: aload_1
/*     */     //   156: checkcast java/util/Map
/*     */     //   159: astore_3
/*     */     //   160: iconst_0
/*     */     //   161: istore #4
/*     */     //   163: aload_3
/*     */     //   164: astore #5
/*     */     //   166: new java/util/LinkedHashMap
/*     */     //   169: dup
/*     */     //   170: invokespecial <init> : ()V
/*     */     //   173: checkcast java/util/Map
/*     */     //   176: astore #6
/*     */     //   178: iconst_0
/*     */     //   179: istore #7
/*     */     //   181: aload #5
/*     */     //   183: invokeinterface entrySet : ()Ljava/util/Set;
/*     */     //   188: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   193: astore #9
/*     */     //   195: aload #9
/*     */     //   197: invokeinterface hasNext : ()Z
/*     */     //   202: ifeq -> 273
/*     */     //   205: aload #9
/*     */     //   207: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   212: checkcast java/util/Map$Entry
/*     */     //   215: astore #10
/*     */     //   217: aload #10
/*     */     //   219: astore #12
/*     */     //   221: iconst_0
/*     */     //   222: istore #13
/*     */     //   224: aload #12
/*     */     //   226: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   231: aload_2
/*     */     //   232: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   237: if_acmpne -> 244
/*     */     //   240: iconst_1
/*     */     //   241: goto -> 245
/*     */     //   244: iconst_0
/*     */     //   245: ifeq -> 195
/*     */     //   248: aload #6
/*     */     //   250: aload #10
/*     */     //   252: invokeinterface getKey : ()Ljava/lang/Object;
/*     */     //   257: aload #10
/*     */     //   259: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   264: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   269: pop
/*     */     //   270: goto -> 195
/*     */     //   273: aload #6
/*     */     //   275: nop
/*     */     //   276: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   281: checkcast java/lang/Iterable
/*     */     //   284: astore_3
/*     */     //   285: iconst_0
/*     */     //   286: istore #4
/*     */     //   288: aload_3
/*     */     //   289: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   294: astore #5
/*     */     //   296: aload #5
/*     */     //   298: invokeinterface hasNext : ()Z
/*     */     //   303: ifne -> 310
/*     */     //   306: aconst_null
/*     */     //   307: goto -> 477
/*     */     //   310: aload #5
/*     */     //   312: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   317: astore #6
/*     */     //   319: aload #5
/*     */     //   321: invokeinterface hasNext : ()Z
/*     */     //   326: ifne -> 334
/*     */     //   329: aload #6
/*     */     //   331: goto -> 477
/*     */     //   334: aload #6
/*     */     //   336: checkcast net/minecraft/class_2338
/*     */     //   339: astore #7
/*     */     //   341: iconst_0
/*     */     //   342: istore #9
/*     */     //   344: getstatic net/integr/utilities/game/CoordinateUtils.Companion : Lnet/integr/utilities/game/CoordinateUtils$Companion;
/*     */     //   347: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   350: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   353: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   356: dup
/*     */     //   357: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   360: invokevirtual method_19538 : ()Lnet/minecraft/class_243;
/*     */     //   363: dup
/*     */     //   364: ldc_w 'getPos(...)'
/*     */     //   367: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   370: aload #7
/*     */     //   372: invokevirtual method_46558 : ()Lnet/minecraft/class_243;
/*     */     //   375: dup
/*     */     //   376: ldc 'toCenterPos(...)'
/*     */     //   378: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   381: invokevirtual distanceBetween : (Lnet/minecraft/class_243;Lnet/minecraft/class_243;)D
/*     */     //   384: dstore #7
/*     */     //   386: aload #5
/*     */     //   388: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   393: astore #9
/*     */     //   395: aload #9
/*     */     //   397: checkcast net/minecraft/class_2338
/*     */     //   400: astore #10
/*     */     //   402: iconst_0
/*     */     //   403: istore #12
/*     */     //   405: getstatic net/integr/utilities/game/CoordinateUtils.Companion : Lnet/integr/utilities/game/CoordinateUtils$Companion;
/*     */     //   408: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   411: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   414: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   417: dup
/*     */     //   418: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   421: invokevirtual method_19538 : ()Lnet/minecraft/class_243;
/*     */     //   424: dup
/*     */     //   425: ldc_w 'getPos(...)'
/*     */     //   428: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   431: aload #10
/*     */     //   433: invokevirtual method_46558 : ()Lnet/minecraft/class_243;
/*     */     //   436: dup
/*     */     //   437: ldc 'toCenterPos(...)'
/*     */     //   439: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   442: invokevirtual distanceBetween : (Lnet/minecraft/class_243;Lnet/minecraft/class_243;)D
/*     */     //   445: dstore #10
/*     */     //   447: dload #7
/*     */     //   449: dload #10
/*     */     //   451: invokestatic compare : (DD)I
/*     */     //   454: ifle -> 465
/*     */     //   457: aload #9
/*     */     //   459: astore #6
/*     */     //   461: dload #10
/*     */     //   463: dstore #7
/*     */     //   465: aload #5
/*     */     //   467: invokeinterface hasNext : ()Z
/*     */     //   472: ifne -> 386
/*     */     //   475: aload #6
/*     */     //   477: checkcast net/minecraft/class_2338
/*     */     //   480: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #86	-> 0
/*     */     //   #140	-> 72
/*     */     //   #86	-> 75
/*     */     //   #86	-> 88
/*     */     //   #140	-> 106
/*     */     //   #86	-> 109
/*     */     //   #86	-> 122
/*     */     //   #86	-> 154
/*     */     //   #88	-> 155
/*     */     //   #141	-> 163
/*     */     //   #142	-> 181
/*     */     //   #142	-> 193
/*     */     //   #143	-> 217
/*     */     //   #88	-> 224
/*     */     //   #143	-> 245
/*     */     //   #144	-> 248
/*     */     //   #147	-> 273
/*     */     //   #141	-> 275
/*     */     //   #88	-> 276
/*     */     //   #148	-> 288
/*     */     //   #149	-> 296
/*     */     //   #150	-> 310
/*     */     //   #151	-> 319
/*     */     //   #152	-> 334
/*     */     //   #88	-> 344
/*     */     //   #152	-> 384
/*     */     //   #154	-> 386
/*     */     //   #155	-> 395
/*     */     //   #88	-> 405
/*     */     //   #155	-> 445
/*     */     //   #156	-> 447
/*     */     //   #157	-> 457
/*     */     //   #158	-> 461
/*     */     //   #160	-> 465
/*     */     //   #161	-> 475
/*     */     //   #88	-> 480
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   75	13	9	$i$a$-minByOrThrow-HoleEspModule$getNextHole$bestType$1	I
/*     */     //   72	16	7	it	Ljava/util/Map$Entry;
/*     */     //   109	13	12	$i$a$-minByOrThrow-HoleEspModule$getNextHole$bestType$1	I
/*     */     //   106	16	10	it	Ljava/util/Map$Entry;
/*     */     //   224	21	13	$i$a$-filter-HoleEspModule$getNextHole$1	I
/*     */     //   221	24	12	it	Ljava/util/Map$Entry;
/*     */     //   217	53	10	element$iv$iv	Ljava/util/Map$Entry;
/*     */     //   181	94	7	$i$f$filterTo	I
/*     */     //   178	97	5	$this$filterTo$iv$iv	Ljava/util/Map;
/*     */     //   178	97	6	destination$iv$iv	Ljava/util/Map;
/*     */     //   163	113	4	$i$f$filter	I
/*     */     //   160	116	3	$this$filter$iv	Ljava/util/Map;
/*     */     //   344	40	9	$i$a$-minByOrNull-HoleEspModule$getNextHole$2	I
/*     */     //   341	43	7	it	Lnet/minecraft/class_2338;
/*     */     //   405	40	12	$i$a$-minByOrNull-HoleEspModule$getNextHole$2	I
/*     */     //   402	43	10	it	Lnet/minecraft/class_2338;
/*     */     //   395	70	9	e$iv	Ljava/lang/Object;
/*     */     //   447	18	10	v$iv	D
/*     */     //   288	189	4	$i$f$minByOrNull	I
/*     */     //   296	181	5	iterator$iv	Ljava/util/Iterator;
/*     */     //   319	158	6	minElem$iv	Ljava/lang/Object;
/*     */     //   386	91	7	minValue$iv	D
/*     */     //   285	192	3	$this$minByOrNull$iv	Ljava/lang/Iterable;
/*     */     //   155	326	2	bestType	Ljava/util/Map$Entry;
/*     */     //   0	481	0	this	Lnet/integr/modules/impl/HoleEspModule;
/*     */     //   0	481	1	holes	Ljava/util/HashMap;
/*     */   }
/*     */   
/*     */   private final void getHoles(int range) {
/*     */     int i = -range;
/*     */     if (i <= range)
/*     */       while (true) {
/*     */         int j = -range;
/*     */         if (j <= range)
/*     */           while (true) {
/*     */             int k = -range;
/*     */             if (k <= range)
/*     */               while (true) {
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */                 Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724);
/*     */                 handleHole(new class_2338((Onyx.Companion.getMC()).field_1724.method_31477() + i, (Onyx.Companion.getMC()).field_1724.method_31478() + j, (Onyx.Companion.getMC()).field_1724.method_31479() + k));
/*     */                 if (k != range) {
/*     */                   k++;
/*     */                   continue;
/*     */                 } 
/*     */                 break;
/*     */               }  
/*     */             if (j != range) {
/*     */               j++;
/*     */               continue;
/*     */             } 
/*     */             break;
/*     */           }  
/*     */         if (i != range) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       }  
/*     */   }
/*     */   
/*     */   private final void handleHole(class_2338 blockPos) {
/*     */     int verySafe = 0;
/*     */     int safe = 0;
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(blockPos), "getBlockState(...)");
/*     */     class_2680 checkStateCenter = (Onyx.Companion.getMC()).field_1687.method_8320(blockPos);
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(blockPos.method_10069(0, 1, 0)), "getBlockState(...)");
/*     */     class_2680 checkStateCenterOffset = (Onyx.Companion.getMC()).field_1687.method_8320(blockPos.method_10069(0, 1, 0));
/*     */     if (!checkStateCenter.method_26215() || !checkStateCenterOffset.method_26215())
/*     */       return; 
/*     */     for (class_2350 direction : EntriesMappings.entries$0) {
/*     */       if (direction != class_2350.field_11036) {
/*     */         Intrinsics.checkNotNullExpressionValue(blockPos.method_10093(direction), "offset(...)");
/*     */         class_2338 offsetPos = blockPos.method_10093(direction);
/*     */         Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1687.method_8320(offsetPos), "getBlockState(...)");
/*     */         class_2680 state = (Onyx.Companion.getMC()).field_1687.method_8320(offsetPos);
/*     */         if (Intrinsics.areEqual(state.method_26204(), class_2246.field_9987)) {
/*     */           verySafe++;
/*     */           continue;
/*     */         } 
/*     */         if (Intrinsics.areEqual(state.method_26204(), class_2246.field_38420)) {
/*     */           verySafe++;
/*     */           continue;
/*     */         } 
/*     */         if (Intrinsics.areEqual(state.method_26204(), class_2246.field_10540)) {
/*     */           safe++;
/*     */           continue;
/*     */         } 
/*     */         if (direction == class_2350.field_11033)
/*     */           return; 
/*     */       } 
/*     */     } 
/*     */     if (safe + verySafe == 5)
/*     */       this.holes.put(blockPos, (safe == 5) ? HoleType.Obsidian : ((verySafe == 5) ? HoleType.Bedrock : HoleType.Mixed)); 
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\020\n\002\b\002\n\002\030\002\n\002\b\006\b\002\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006j\002\b\007j\002\b\bj\002\b\t¨\006\n"}, d2 = {"Lnet/integr/modules/impl/HoleEspModule$HoleType;", "", "<init>", "(Ljava/lang/String;I)V", "Ljava/awt/Color;", "getColor", "()Ljava/awt/Color;", "Bedrock", "Mixed", "Obsidian", "onyx2"})
/*     */   private enum HoleType {
/*     */     Bedrock, Mixed, Obsidian;
/*     */     
/*     */     @NotNull
/*     */     public final Color getColor() {
/*     */       switch (WhenMappings.$EnumSwitchMapping$0[ordinal()]) {
/*     */         case 1:
/*     */         
/*     */         case 2:
/*     */         
/*     */         case 3:
/*     */         
/*     */       } 
/*     */       throw new NoWhenBranchMatchedException();
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public static EnumEntries<HoleType> getEntries() {
/*     */       return $ENTRIES;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\HoleEspModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */