/*    */ package net.integr.modules.impl;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\006\030\0002\0020\001B\007¢\006\004\b\002\020\003J/\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rR\026\020\017\032\0020\0168\002@\002X\016¢\006\006\n\004\b\017\020\020R\026\020\021\032\0020\0168\002@\002X\016¢\006\006\n\004\b\021\020\020R\026\020\022\032\0020\0168\002@\002X\016¢\006\006\n\004\b\022\020\020R\026\020\023\032\0020\0168\002@\002X\016¢\006\006\n\004\b\023\020\020¨\006\024"}, d2 = {"Lnet/integr/modules/impl/CoordinatesModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "background", "Lnet/integr/rendering/uisystem/Box;", "coordinatesXBox", "coordinatesYBox", "coordinatesZBox", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nCoordinatesModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CoordinatesModule.kt\nnet/integr/modules/impl/CoordinatesModule\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,61:1\n1#2:62\n*E\n"})
/*    */ public final class CoordinatesModule extends UiModule {
/*    */   @NotNull
/*    */   private Box background;
/*    */   @NotNull
/*    */   private Box coordinatesXBox;
/*    */   @NotNull
/*    */   private Box coordinatesYBox;
/*    */   @NotNull
/*    */   private Box coordinatesZBox;
/*    */   
/*    */   public CoordinatesModule() {
/* 28 */     super("Coordinates", "Renders your Coordinates", "coordinates", 60, 100, Filter.Render);
/*    */     
/* 30 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 37 */     this.background = new Box(0, 0, 100, 60, null, false, false, false, 192, null);
/*    */     
/* 39 */     this.coordinatesXBox = new Box(0, 0, 100, 20, null, false, false, false, 128, null);
/* 40 */     this.coordinatesYBox = new Box(0, 0, 100, 20, null, false, false, false, 128, null);
/* 41 */     this.coordinatesZBox = new Box(0, 0, 100, 20, null, false, false, false, 128, null);
/*    */   }
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/* 44 */     Intrinsics.checkNotNullParameter(context, "context"); int x = 0; Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); x = (Onyx.Companion.getMC()).field_1724.method_31477();
/* 45 */     int y = 0; Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); y = (Onyx.Companion.getMC()).field_1724.method_31478();
/* 46 */     int z = 0; Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); z = (Onyx.Companion.getMC()).field_1724.method_31479();
/*    */     
/* 48 */     Intrinsics.checkNotNull(getSettings().getById("swapXY")); if (((BooleanSetting)getSettings().getById("swapXY")).isEnabled()) { int i = y, it = i;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 62 */       int $i$a$-also-CoordinatesModule$render$1 = 0; y = x; x = i; }  Intrinsics.checkNotNull(getSettings().getById("swapYZ")); if (((BooleanSetting)getSettings().getById("swapYZ")).isEnabled()) { int i = z, it = i; int $i$a$-also-CoordinatesModule$render$2 = 0; z = y; y = i; }  Intrinsics.checkNotNull(getSettings().getById("swapZX")); if (((BooleanSetting)getSettings().getById("swapZX")).isEnabled()) { int i = x, it = i; int $i$a$-also-CoordinatesModule$render$3 = 0;
/*    */       x = z;
/*    */       z = i; }
/*    */     
/*    */     this.coordinatesXBox.setText(" X: " + x);
/*    */     this.coordinatesYBox.setText(" Y: " + y);
/*    */     this.coordinatesZBox.setText(" Z: " + z);
/*    */     this.background.update(originX, originY).method_25394(context, 10, 10, delta);
/*    */     this.coordinatesXBox.update(originX, originY).method_25394(context, 10, 10, delta);
/*    */     this.coordinatesYBox.update(originX, originY + 20).method_25394(context, 10, 10, delta);
/*    */     this.coordinatesZBox.update(originX, originY + 40).method_25394(context, 10, 10, delta);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CoordinatesModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */