/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.PreTickEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.SliderSetting;
/*    */ import net.integr.utilities.game.notification.NotificationHandler;
/*    */ import net.minecraft.class_1799;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020\b\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\026\020\n\032\0020\t8\002@\002X\016¢\006\006\n\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/modules/impl/ArmorDurabilityNotifierModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/PreTickEvent;", "event", "", "onTick", "(Lnet/integr/event/PreTickEvent;)V", "", "timer", "I", "onyx2"})
/*    */ public final class ArmorDurabilityNotifierModule
/*    */   extends Module
/*    */ {
/*    */   private int timer;
/*    */   
/*    */   public ArmorDurabilityNotifierModule() {
/* 29 */     super("Armor Durability Notifier", "Notifies you when your armor is low on durability", "armorDurabilityNotifier", Filter.Util, false, 16, null);
/*    */     
/* 31 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */     
/* 35 */     initHacklist(new Function1<List<String>, Unit>() { public final void invoke(@NotNull List<String> $this$initHacklist) {
/* 36 */             Intrinsics.checkNotNullParameter($this$initHacklist, "$this$initHacklist"); Intrinsics.checkNotNull(ArmorDurabilityNotifierModule.this.getSettings().getById("minDura")); $this$initHacklist.add("" + ((SliderSetting)ArmorDurabilityNotifierModule.this.getSettings().getById("minDura")).getSetValue() + "%");
/*    */           } }
/*    */       );
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onTick(@NotNull PreTickEvent event) {
/* 44 */     Intrinsics.checkNotNullParameter(event, "event"); if (this.timer > 0) {
/* 45 */       int i = this.timer; this.timer = i + -1;
/*    */       
/*    */       return;
/*    */     } 
/* 49 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(3), "get(...)"); class_1799 helmetItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(3);
/* 50 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(2), "get(...)"); class_1799 chestPlateItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(2);
/* 51 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(1), "get(...)"); class_1799 leggingsItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(1);
/* 52 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue(((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(0), "get(...)"); class_1799 bootsItem = (class_1799)((Onyx.Companion.getMC()).field_1724.method_31548()).field_7548.get(0);
/*    */     
/* 54 */     double helmetPercent = (helmetItem.method_7936() != 0) ? ((helmetItem.method_7936() - helmetItem.method_7919()) / helmetItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/* 55 */     double chestPlatePercent = (chestPlateItem.method_7936() != 0) ? ((chestPlateItem.method_7936() - chestPlateItem.method_7919()) / chestPlateItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/* 56 */     double leggingsPercent = (leggingsItem.method_7936() != 0) ? ((leggingsItem.method_7936() - leggingsItem.method_7919()) / leggingsItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/* 57 */     double bootsPercent = (bootsItem.method_7936() != 0) ? ((bootsItem.method_7936() - bootsItem.method_7919()) / bootsItem.method_7936() * 100.0D) : Double.MAX_VALUE;
/*    */     
/* 59 */     Intrinsics.checkNotNull(getSettings().getById("minDura")); double min = ((SliderSetting)getSettings().getById("minDura")).getSetValue();
/*    */     
/* 61 */     if (helmetPercent < min || chestPlatePercent < min || leggingsPercent < min || bootsPercent < min) {
/* 62 */       NotificationHandler.Companion.notify("You should repair your Armor!");
/* 63 */       NotificationHandler.Companion.ping();
/*    */     } 
/*    */     
/* 66 */     this.timer = 60;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\ArmorDurabilityNotifierModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */