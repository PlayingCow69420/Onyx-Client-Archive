/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.event.UiRenderEvent;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2586;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector4f;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000¸\001\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\020\006\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\n\002\020%\n\002\030\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\004\n\002\030\002\n\002\b\005\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ7\020\021\032\0020\0202\006\020\n\032\0020\t2\006\020\013\032\0020\t2\006\020\f\032\0020\t2\006\020\016\032\0020\r2\006\020\017\032\0020\rH\002¢\006\004\b\021\020\022J\027\020\026\032\0020\0252\006\020\024\032\0020\023H\002¢\006\004\b\026\020\027J\025\020\032\032\b\022\004\022\0020\0310\030H\002¢\006\004\b\032\020\033J\025\020\035\032\b\022\004\022\0020\0340\030H\002¢\006\004\b\035\020\033J\027\020!\032\0020 2\006\020\037\032\0020\036H\002¢\006\004\b!\020\"J\027\020%\032\0020\0062\006\020$\032\0020#H\007¢\006\004\b%\020&J\027\020(\032\0020\0062\006\020$\032\0020'H\007¢\006\004\b(\020)J\027\020+\032\0020\0062\006\020$\032\0020*H\007¢\006\004\b+\020,J\027\020.\032\0020\0062\006\020$\032\0020-H\007¢\006\004\b.\020/J\017\0200\032\0020\006H\002¢\006\004\b0\020\003J\017\0201\032\0020\006H\002¢\006\004\b1\020\003J\027\0203\032\0020\0202\006\0202\032\0020\rH\002¢\006\004\b3\0204J\027\0207\032\0020\0062\006\0206\032\00205H\002¢\006\004\b7\0208J\017\0209\032\0020\006H\002¢\006\004\b9\020\003R \020=\032\016\022\004\022\0020;\022\004\022\0020<0:8\002X\004¢\006\006\n\004\b=\020>R\024\020?\032\0020\r8\002X\004¢\006\006\n\004\b?\020@R \020A\032\016\022\004\022\0020;\022\004\022\0020<0:8\002X\004¢\006\006\n\004\bA\020>R\024\020B\032\002058\002X\004¢\006\006\n\004\bB\020CR\030\020E\032\004\030\0010D8\002@\002X\016¢\006\006\n\004\bE\020FR\024\020G\032\002058\002X\004¢\006\006\n\004\bG\020CR\024\0202\032\0020\r8\002X\004¢\006\006\n\004\b2\020@R\024\020H\032\0020\r8\002X\004¢\006\006\n\004\bH\020@R\024\020I\032\0020\r8\002X\004¢\006\006\n\004\bI\020@R\"\020M\032\016\022\004\022\0020K\022\004\022\0020L0J8\002@\002X\016¢\006\006\n\004\bM\020NR\030\020O\032\004\030\0010D8\002@\002X\016¢\006\006\n\004\bO\020FR\024\020P\032\002058\002X\004¢\006\006\n\004\bP\020CR\030\020R\032\004\030\0010Q8\002@\002X\016¢\006\006\n\004\bR\020SR\026\020T\032\0020\t8\002@\002X\016¢\006\006\n\004\bT\020U¨\006V"}, d2 = {"Lnet/integr/modules/impl/EspModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/minecraft/class_4587;", "matrices", "", "bobView", "(Lnet/minecraft/class_4587;)V", "", "x", "y", "z", "Lorg/joml/Vector3d;", "min", "max", "", "checkCorner", "(DDDLorg/joml/Vector3d;Lorg/joml/Vector3d;)Z", "Lnet/minecraft/class_2338;", "blockPos", "Lnet/minecraft/class_1799;", "getDefenseItemFromBp", "(Lnet/minecraft/class_2338;)Lnet/minecraft/class_1799;", "Ljava/util/stream/Stream;", "Lnet/minecraft/class_2586;", "getLoadedBlockEntities", "()Ljava/util/stream/Stream;", "Lnet/minecraft/class_2818;", "getLoadedChunks", "Lnet/minecraft/class_1657;", "playerEntity", "", "getPing", "(Lnet/minecraft/class_1657;)I", "Lnet/integr/event/EntityHasLabelEvent;", "event", "onEntityHasLabel", "(Lnet/integr/event/EntityHasLabelEvent;)V", "Lnet/integr/event/RenderWorldEvent;", "onRenderTick", "(Lnet/integr/event/RenderWorldEvent;)V", "Lnet/integr/event/UiRenderEvent;", "onRenderUI", "(Lnet/integr/event/UiRenderEvent;)V", "Lnet/integr/event/UpdateWorldRenderEvent;", "onUpdateWorldRender", "(Lnet/integr/event/UpdateWorldRenderEvent;)V", "prepChestEsp", "scaledProjection", "pos", "to2D", "(Lorg/joml/Vector3d;)Z", "Lorg/joml/Vector4f;", "vec", "toScreen", "(Lorg/joml/Vector4f;)V", "unscaledProjection", "", "Lnet/minecraft/class_1297;", "Lnet/integr/rendering/uisystem/Slider;", "armorSliders", "Ljava/util/Map;", "cameraNegated", "Lorg/joml/Vector3d;", "healthSliders", "mmMat4", "Lorg/joml/Vector4f;", "Lorg/joml/Matrix4f;", "model", "Lorg/joml/Matrix4f;", "pmMat4", "pos1", "pos2", "Ljava/util/HashMap;", "Lnet/minecraft/class_243;", "", "positions", "Ljava/util/HashMap;", "projection", "vec4", "Lnet/minecraft/class_8251;", "vertexSorter", "Lnet/minecraft/class_8251;", "windowScale", "D", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nEspModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EspModule.kt\nnet/integr/modules/impl/EspModule\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,445:1\n1#2:446\n*E\n"})
/*     */ public final class EspModule extends Module {
/*     */   @Nullable
/*     */   private class_8251 vertexSorter;
/*     */   @NotNull
/*     */   private final Vector3d pos1;
/*     */   @NotNull
/*     */   private final Vector3d pos2;
/*     */   @NotNull
/*     */   private final Vector3d pos;
/*     */   @NotNull
/*     */   private HashMap<class_243, String> positions;
/*     */   @NotNull
/*     */   private final Map<class_1297, Slider> healthSliders;
/*     */   @NotNull
/*     */   private final Map<class_1297, Slider> armorSliders;
/*     */   @NotNull
/*     */   private final Vector4f vec4;
/*     */   @NotNull
/*     */   private final Vector4f mmMat4;
/*     */   @NotNull
/*     */   private final Vector4f pmMat4;
/*     */   @NotNull
/*     */   private final Vector3d cameraNegated;
/*     */   @Nullable
/*     */   private Matrix4f model;
/*     */   @Nullable
/*     */   private Matrix4f projection;
/*     */   private double windowScale;
/*     */   
/*  61 */   public EspModule() { super("Esp", "See trough walls", "esp", Filter.Render, false, 16, null);
/*     */     
/*  63 */     initSettings(null.INSTANCE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.pos1 = new Vector3d();
/*  78 */     this.pos2 = new Vector3d();
/*  79 */     this.pos = new Vector3d();
/*     */     
/*  81 */     this.positions = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.healthSliders = new LinkedHashMap<>();
/* 164 */     this.armorSliders = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     this.vec4 = new Vector4f();
/* 354 */     this.mmMat4 = new Vector4f();
/* 355 */     this.pmMat4 = new Vector4f();
/* 356 */     this.cameraNegated = new Vector3d(); }
/*     */   @EventListen public final void onUpdateWorldRender(@NotNull UpdateWorldRenderEvent event) { Intrinsics.checkNotNullParameter(event, "event"); this.model = event.matrix4f; this.projection = RenderSystem.getProjectionMatrix(); class_243 pos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19326(); this.cameraNegated.set((Vector3dc)new Vector3d(pos.field_1352, pos.field_1351, pos.field_1350)); this.cameraNegated.negate(); this.windowScale = Onyx.Companion.getMC().method_22683().method_4476(1, false); }
/*     */   private final void unscaledProjection() { this.vertexSorter = RenderSystem.getVertexSorting(); RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, Onyx.Companion.getMC().method_22683().method_4489(), Onyx.Companion.getMC().method_22683().method_4506(), 0.0F, 1000.0F, 21000.0F), class_8251.field_43361); }
/*     */   private final void scaledProjection() { RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)(Onyx.Companion.getMC().method_22683().method_4489() / Onyx.Companion.getMC().method_22683().method_4495()), (float)(Onyx.Companion.getMC().method_22683().method_4506() / Onyx.Companion.getMC().method_22683().method_4495()), 0.0F, 1000.0F, 21000.0F), this.vertexSorter); }
/*     */   @EventListen public final void onEntityHasLabel(@NotNull EntityHasLabelEvent event) { Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("hideNametags"));
/*     */     if (event.entity instanceof class_1657 && ((BooleanSetting)getSettings().getById("hideNametags")).isEnabled())
/* 362 */       event.setCallback(Boolean.valueOf(false));  } private final boolean to2D(Vector3d pos) { this.vec4.set(this.cameraNegated.x + pos.x, this.cameraNegated.y + pos.y, this.cameraNegated.z + pos.z, 1.0D);
/*     */     
/* 364 */     this.vec4.mul((Matrix4fc)this.model, this.mmMat4);
/* 365 */     this.mmMat4.mul((Matrix4fc)this.projection, this.pmMat4);
/*     */     
/* 367 */     boolean behind = (this.pmMat4.w <= 0.0F);
/*     */     
/* 369 */     if (behind) return false;
/*     */     
/* 371 */     toScreen(this.pmMat4);
/* 372 */     double x = (this.pmMat4.x * Onyx.Companion.getMC().method_22683().method_4489());
/* 373 */     double y = (this.pmMat4.y * Onyx.Companion.getMC().method_22683().method_4506());
/*     */     
/* 375 */     if (Double.isInfinite(x) || Double.isInfinite(y)) return false;
/*     */     
/* 377 */     pos.set(x / this.windowScale, Onyx.Companion.getMC().method_22683().method_4506() - y / this.windowScale, 
/* 378 */         this.pmMat4.z);
/* 379 */     return true; }
/*     */   @EventListen public final void onRenderTick(@NotNull RenderWorldEvent event) { Intrinsics.checkNotNullParameter(event, "event"); Intrinsics.checkNotNull(getSettings().getById("tracers")); if (((BooleanSetting)getSettings().getById("tracers")).isEnabled() && (Onyx.Companion.getMC()).field_1690.method_31044() == class_5498.field_26664) { Vector3f pos = new Vector3f(0.0F, 0.0F, 1.0F); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1690.method_42448().method_41753(), "getValue(...)"); if (((Boolean)(Onyx.Companion.getMC()).field_1690.method_42448().method_41753()).booleanValue()) { class_4587 bobViewMatrices = new class_4587(); bobView(bobViewMatrices); pos.mulPosition((Matrix4fc)bobViewMatrices.method_23760().method_23761().invert()); }  class_243 center = (new class_243(pos.x, -(pos.y), pos.z)).method_1037(-((float)Math.toRadians((Onyx.Companion.getMC()).field_1773.method_19418().method_19329()))).method_1024(-((float)Math.toRadians((Onyx.Companion.getMC()).field_1773.method_19418().method_19330()))).method_1019((Onyx.Companion.getMC()).field_1773.method_19418().method_19326()); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); for (class_1297 e : (Onyx.Companion.getMC()).field_1687.method_18112()) { if (Intrinsics.areEqual(e.method_5864(), class_1299.field_6097) && !Intrinsics.areEqual(e, (Onyx.Companion.getMC()).field_1719)) { Intrinsics.checkNotNull(center); Intrinsics.checkNotNull(e); Intrinsics.checkNotNullExpressionValue(CoordinateUtils.Companion.getLerpedEntityPos(e, event.tickDelta).method_1031(0.0D, e.method_17682() / 2.0D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(event.matrices, "matrices"); RenderingEngine.ThreeDimensional.Companion.line(center, CoordinateUtils.Companion.getLerpedEntityPos(e, event.tickDelta).method_1031(0.0D, e.method_17682() / 2.0D, 0.0D), event.matrices, Variables.Companion.getGuiColor()); }  }  }  }
/*     */   private final void bobView(class_4587 matrices) { class_1297 cameraEntity = Onyx.Companion.getMC().method_1560(); if (cameraEntity instanceof class_1657) { float f = TickDelta.Companion.get(); float g = cameraEntity.field_5973 - cameraEntity.field_6039; float h = -(cameraEntity.field_5973 + g * f); float i = class_3532.method_16439(f, ((class_1657)cameraEntity).field_7505, ((class_1657)cameraEntity).field_7483); matrices.method_22904(-((class_3532.method_15374(h * 3.1415927F) * i) * 0.5D), Math.abs((class_3532.method_15362(h * 3.1415927F) * i)), 0.0D); matrices.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_15374(h * 3.1415927F) * i * 3)); matrices.method_22907(class_7833.field_40714.rotationDegrees((float)(Math.abs((class_3532.method_15362(h * 3.1415927F - 0.2F) * i)) * 5))); }  }
/*     */   @EventListen public final void onRenderUI(@NotNull UiRenderEvent event) { Intrinsics.checkNotNullParameter(event, "event"); unscaledProjection(); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); for (class_1297 e : (Onyx.Companion.getMC()).field_1687.method_18112()) { if (!Intrinsics.areEqual(e.method_5864(), class_1299.field_6043) && !Intrinsics.areEqual(e.method_5864(), class_1299.field_28401) && !Intrinsics.areEqual(e.method_5864(), class_1299.field_6131) && !Intrinsics.areEqual(e.method_5864(), class_1299.field_6110)) { Intrinsics.checkNotNull(getSettings().getById("mobs")); Intrinsics.checkNotNull(getSettings().getById("items")); if ((((BooleanSetting)getSettings().getById("mobs")).isEnabled() || Intrinsics.areEqual(e.method_5864(), class_1299.field_6052) || Intrinsics.areEqual(e.method_5864(), class_1299.field_6097)) && (((BooleanSetting)getSettings().getById("items")).isEnabled() || !Intrinsics.areEqual(e.method_5864(), class_1299.field_6052))) { Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull(getSettings().getById("self")); if (!Intrinsics.areEqual(e, (Onyx.Companion.getMC()).field_1724) || ((BooleanSetting)getSettings().getById("self")).isEnabled()) { Intrinsics.checkNotNull(getSettings().getById("expand")); class_238 box = e.method_5829().method_1014(((SliderSetting)getSettings().getById("expand")).getSetValue()); double x = class_3532.method_16436(event.tickDelta, e.field_6038, e.method_23317()) - e.method_23317(); double y = class_3532.method_16436(event.tickDelta, e.field_5971, e.method_23318()) - e.method_23318(); double z = class_3532.method_16436(event.tickDelta, e.field_5989, e.method_23321()) - e.method_23321(); this.pos1.set(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE); this.pos2.set(0.0D, 0.0D, 0.0D); if (!checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1324 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1324 + z, this.pos1, this.pos2)) if (!checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1324 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1324 + z, this.pos1, this.pos2)) { Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos1.x, (float)this.pos1.y, (float)this.pos1.x, (float)this.pos2.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos2.x, (float)this.pos1.y, (float)this.pos2.x, (float)this.pos2.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos1.x, (float)this.pos1.y, (float)this.pos2.x, (float)this.pos1.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos1.x, (float)this.pos2.y, (float)this.pos2.x, (float)this.pos2.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719); if (e instanceof class_1657 || (Onyx.Companion.getMC()).field_1719.method_5739(e) <= 80.0F) { Intrinsics.checkNotNull(getSettings().getById("nametags")); if (((BooleanSetting)getSettings().getById("nametags")).isEnabled()) { String name = (e instanceof class_1657) ? ((class_1657)e).method_7334().getName() : e.method_5864().method_5897().getString(); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719); String distText = "△ " + (int)(Onyx.Companion.getMC()).field_1719.method_5739(e) + "m"; String pingText = "↓ " + ((e instanceof class_1657) ? getPing((class_1657)e) : 0) + "ms"; String friendText = Intrinsics.areEqual(e, (Onyx.Companion.getMC()).field_1724) ? "● You" : ((e instanceof class_1657 && FriendStorage.Companion.contains((class_1657)e)) ? "✓ Friend" : "✕ Enemy"); int maxLen = Math.max(Math.max(Math.max((Onyx.Companion.getMC()).field_1772.method_1727(name), (Onyx.Companion.getMC()).field_1772.method_1727(distText)), (Onyx.Companion.getMC()).field_1772.method_1727(pingText)), (Onyx.Companion.getMC()).field_1772.method_1727(friendText)); Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, (float)this.pos1.x, (float)this.pos1.y - 55.0F - 15, (float)this.pos1.x + maxLen + 5 + 5, (float)this.pos1.y - 5 - 15, Variables.Companion.getGuiBack(), Variables.Companion.getGuiColor(), event.context, 0.1F, 9.0F, false, 512, null); (Onyx.Companion.getMC()).field_1772.method_27521(name, (float)this.pos1.x + 5, (float)this.pos1.y - 20.0F - 15, Variables.Companion.getGuiColor(), false, event.context.method_51448().method_23760().method_23761(), (class_4597)event.context.method_51450(), class_327.class_6415.field_33994, 0, 10); (Onyx.Companion.getMC()).field_1772.method_27521(distText, (float)this.pos1.x + 5, (float)this.pos1.y - 50.0F - 15, Variables.Companion.getGuiColor(), false, event.context.method_51448().method_23760().method_23761(), (class_4597)event.context.method_51450(), class_327.class_6415.field_33994, 0, 10); (Onyx.Companion.getMC()).field_1772.method_27521(pingText, (float)this.pos1.x + 5, (float)this.pos1.y - 40.0F - 15, Variables.Companion.getGuiColor(), false, event.context.method_51448().method_23760().method_23761(), (class_4597)event.context.method_51450(), class_327.class_6415.field_33994, 0, 10); (Onyx.Companion.getMC()).field_1772.method_27521(friendText, (float)this.pos1.x + 5, (float)this.pos1.y - 30.0F - 15, Variables.Companion.getGuiColor(), false, event.context.method_51448().method_23760().method_23761(), (class_4597)event.context.method_51450(), class_327.class_6415.field_33994, 0, 10); }  Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719); Intrinsics.checkNotNull(getSettings().getById("data")); if (e instanceof class_1309 && (Onyx.Companion.getMC()).field_1719.method_5739(e) < 50.0F && ((BooleanSetting)getSettings().getById("data")).isEnabled()) { Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, (float)(this.pos1.x + this.pos2.x - this.pos1.x + 18), (float)this.pos1.y - 2, (float)(this.pos1.x + this.pos2.x - this.pos1.x + 122.0F), (float)this.pos1.y + 22.0F + 24.0F, Variables.Companion.getGuiBack(), Variables.Companion.getGuiColor(), event.context, 0.1F, 9.0F, false, 512, null); if (this.healthSliders.containsKey(e)) { Intrinsics.checkNotNull(this.healthSliders.get(e)); this.healthSliders.get(e).setMax(((class_1309)e).method_6063() + ((class_1309)e).method_52541()); Intrinsics.checkNotNull(this.healthSliders.get(e)); this.healthSliders.get(e).setXPos((int)(this.pos1.x + this.pos2.x - this.pos1.x + 20)); Intrinsics.checkNotNull(this.healthSliders.get(e)); this.healthSliders.get(e).setYPos((int)this.pos1.y); Intrinsics.checkNotNull(this.healthSliders.get(e)); this.healthSliders.get(e).setValue(((class_1309)e).method_6032() + ((class_1309)e).method_6067()); Intrinsics.checkNotNull(this.healthSliders.get(e)); Intrinsics.checkNotNullExpressionValue(event.context, "context"); this.healthSliders.get(e).method_25394(event.context, 0, 0, 1.0F); } else { this.healthSliders.put(e, new Slider((int)(this.pos1.x + this.pos2.x - this.pos1.x + 20), (int)this.pos1.y, 100, 20, "Health: ", false, "", 0.0D, ((class_1309)e).method_6063() + ((class_1309)e).method_52541())); }  if (this.armorSliders.containsKey(e)) { Intrinsics.checkNotNull(this.armorSliders.get(e)); this.armorSliders.get(e).setMax(20.0D); Intrinsics.checkNotNull(this.armorSliders.get(e)); this.armorSliders.get(e).setXPos((int)(this.pos1.x + this.pos2.x - this.pos1.x + 20)); Intrinsics.checkNotNull(this.armorSliders.get(e)); this.armorSliders.get(e).setYPos((int)this.pos1.y + 24); Intrinsics.checkNotNull(this.armorSliders.get(e)); this.armorSliders.get(e).setValue(((class_1309)e).method_6096()); Intrinsics.checkNotNull(this.armorSliders.get(e)); Intrinsics.checkNotNullExpressionValue(event.context, "context"); this.armorSliders.get(e).method_25394(event.context, 0, 0, 1.0F); } else { this.armorSliders.put(e, new Slider((int)(this.pos1.x + this.pos2.x - this.pos1.x + 20), (int)this.pos1.y + 24, 100, 20, "Armor: ", false, "", 0.0D, 20.0D)); }  if (e instanceof class_1657) { Intrinsics.checkNotNullExpressionValue((((class_1657)e).method_31548()).field_7548.get(3), "get(...)"); class_1799 helmetItem = (class_1799)(((class_1657)e).method_31548()).field_7548.get(3); Intrinsics.checkNotNullExpressionValue((((class_1657)e).method_31548()).field_7548.get(2), "get(...)"); class_1799 chestPlateItem = (class_1799)(((class_1657)e).method_31548()).field_7548.get(2); Intrinsics.checkNotNullExpressionValue((((class_1657)e).method_31548()).field_7548.get(1), "get(...)"); class_1799 leggingsItem = (class_1799)(((class_1657)e).method_31548()).field_7548.get(1); Intrinsics.checkNotNullExpressionValue((((class_1657)e).method_31548()).field_7548.get(0), "get(...)"); class_1799 bootsItem = (class_1799)(((class_1657)e).method_31548()).field_7548.get(0); if (!Intrinsics.areEqual(helmetItem.method_7909(), class_1802.field_8162) || !Intrinsics.areEqual(chestPlateItem.method_7909(), class_1802.field_8162) || !Intrinsics.areEqual(leggingsItem.method_7909(), class_1802.field_8162) || !Intrinsics.areEqual(bootsItem.method_7909(), class_1802.field_8162)) { Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, (float)this.pos1.x - 25 - 20.0F, (float)this.pos1.y - 5, (float)this.pos1.x - 5 - 15, (float)this.pos1.y + 65 + 15, Variables.Companion.getGuiBack(), Variables.Companion.getGuiColor(), event.context, 0.1F, 9.0F, false, 512, null); event.context.method_51427(helmetItem, (int)this.pos1.x - 20 - 20, (int)this.pos1.y); event.context.method_51427(chestPlateItem, (int)this.pos1.x - 20 - 20, (int)this.pos1.y + 20); event.context.method_51427(leggingsItem, (int)this.pos1.x - 20 - 20, (int)this.pos1.y + 40); event.context.method_51427(bootsItem, (int)this.pos1.x - 20 - 20, (int)this.pos1.y + 60); }  Intrinsics.checkNotNullExpressionValue(((class_1657)e).method_24515().method_10069(0, 0, -1), "add(...)"); class_1799 b1 = getDefenseItemFromBp(((class_1657)e).method_24515().method_10069(0, 0, -1)); Intrinsics.checkNotNullExpressionValue(((class_1657)e).method_24515().method_10069(0, 0, 1), "add(...)"); class_1799 b2 = getDefenseItemFromBp(((class_1657)e).method_24515().method_10069(0, 0, 1)); Intrinsics.checkNotNullExpressionValue(((class_1657)e).method_24515().method_10069(-1, 0, 0), "add(...)"); class_1799 b3 = getDefenseItemFromBp(((class_1657)e).method_24515().method_10069(-1, 0, 0)); Intrinsics.checkNotNullExpressionValue(((class_1657)e).method_24515().method_10069(1, 0, 0), "add(...)"); class_1799 b4 = getDefenseItemFromBp(((class_1657)e).method_24515().method_10069(1, 0, 0)); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1719); if ((!Intrinsics.areEqual(b1.method_7909(), class_1802.field_8162) || !Intrinsics.areEqual(b2.method_7909(), class_1802.field_8162) || !Intrinsics.areEqual(b3.method_7909(), class_1802.field_8162) || !Intrinsics.areEqual(b4.method_7909(), class_1802.field_8162)) && (Onyx.Companion.getMC()).field_1719.method_5739(e) < 7.0F) { Intrinsics.checkNotNullExpressionValue(event.context, "context"); RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, (float)this.pos2.x + 20, (float)this.pos2.y - 60, (float)this.pos2.x + 20 + 60 + 5, (float)this.pos2.y + 5, Variables.Companion.getGuiBack(), Variables.Companion.getGuiColor(), event.context, 0.1F, 9.0F, false, 512, null); event.context.method_51427(b1, (int)this.pos2.x + 20 + 20 + 5, (int)this.pos2.y - 20 - 20 - 20 + 5); event.context.method_51427(b2, (int)this.pos2.x + 20 + 20 + 5, (int)this.pos2.y - 20 + 5); event.context.method_51427(b3, (int)this.pos2.x + 20 + 20 + 20 + 5, (int)this.pos2.y - 20 - 20 + 5); event.context.method_51427(b4, (int)this.pos2.x + 20 + 5, (int)this.pos2.y - 20 - 20 + 5); }  }  } else { this.healthSliders.remove(e); this.armorSliders.remove(e); }  event.context.method_51452(); }  }   }  }  }  }  Intrinsics.checkNotNull(getSettings().getById("containers")); if (((BooleanSetting)getSettings().getById("containers")).isEnabled()) { prepChestEsp(); for (class_243 v : this.positions.keySet()) { class_238 box = new class_238(class_2338.method_49638((class_2374)v)); double x = 0.0D; double y = 0.0D; double z = 0.0D; this.pos1.set(Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE); this.pos2.set(0.0D, 0.0D, 0.0D); if (!checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1323 + x, box.field_1322 + y, box.field_1324 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1322 + y, box.field_1324 + z, this.pos1, this.pos2)) if (!checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1321 + z, this.pos1, this.pos2) && !checkCorner(box.field_1323 + x, box.field_1325 + y, box.field_1324 + z, this.pos1, this.pos2) && !checkCorner(box.field_1320 + x, box.field_1325 + y, box.field_1324 + z, this.pos1, this.pos2)) { Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos1.x, (float)this.pos1.y, (float)this.pos1.x, (float)this.pos2.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos2.x, (float)this.pos1.y, (float)this.pos2.x, (float)this.pos2.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos1.x, (float)this.pos1.y, (float)this.pos2.x, (float)this.pos1.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); Intrinsics.checkNotNullExpressionValue(event.context.method_51448().method_23760().method_23761(), "getPositionMatrix(...)"); RenderingEngine.TwoDimensional.Companion.line((float)this.pos1.x, (float)this.pos2.y, (float)this.pos2.x, (float)this.pos2.y, Variables.Companion.getGuiColor(), event.context.method_51448().method_23760().method_23761()); (Onyx.Companion.getMC()).field_1772.method_27521(this.positions.get(v), (float)this.pos1.x, (float)this.pos1.y - 10.0F, Variables.Companion.getGuiColor(), false, event.context.method_51448().method_23760().method_23761(), (class_4597)event.context.method_51450(), class_327.class_6415.field_33994, 0, 10); event.context.method_51452(); }   }  }  scaledProjection(); }
/* 383 */   private final boolean checkCorner(double x, double y, double z, Vector3d min, Vector3d max) { this.pos.set(x, y, z); if (!to2D(this.pos)) return true;  if (this.pos.x < min.x) min.x = this.pos.x;  if (this.pos.y < min.y) min.y = this.pos.y;  if (this.pos.z < min.z) min.z = this.pos.z;  if (this.pos.x > max.x) max.x = this.pos.x;  if (this.pos.y > max.y) max.y = this.pos.y;  if (this.pos.z > max.z) max.z = this.pos.z;  return false; } private final void toScreen(Vector4f vec) { float newW = 1.0F / vec.w * 0.5F;
/*     */     
/* 385 */     vec.x = vec.x * newW + 0.5F;
/* 386 */     vec.y = vec.y * newW + 0.5F;
/* 387 */     vec.z = vec.z * newW + 0.5F;
/* 388 */     vec.w = newW; }
/*     */ 
/*     */   
/*     */   private final void prepChestEsp() {
/* 392 */     this.positions.clear();
/* 393 */     Intrinsics.checkNotNull(getSettings().getById("containers")); if (((BooleanSetting)getSettings().getById("containers")).isEnabled()) {
/* 394 */       for (class_2586 e : getLoadedBlockEntities().toList()) {
/* 395 */         class_2586 class_25861 = e;
/* 396 */         if (class_25861 instanceof net.minecraft.class_2646) { HashMap<class_243, String> hashMap = this.positions; Intrinsics.checkNotNullExpressionValue(e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); class_243 class_243 = e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D); String str = "Trapped Chest"; hashMap.put(class_243, str); continue; }
/* 397 */          if (class_25861 instanceof net.minecraft.class_2595) { HashMap<class_243, String> hashMap = this.positions; Intrinsics.checkNotNullExpressionValue(e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); class_243 class_243 = e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D); String str = "Chest"; hashMap.put(class_243, str); continue; }
/* 398 */          if (class_25861 instanceof net.minecraft.class_2611) { HashMap<class_243, String> hashMap = this.positions; Intrinsics.checkNotNullExpressionValue(e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); class_243 class_243 = e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D); String str = "Ender Chest"; hashMap.put(class_243, str); continue; }
/* 399 */          if (class_25861 instanceof net.minecraft.class_2627) { HashMap<class_243, String> hashMap = this.positions; Intrinsics.checkNotNullExpressionValue(e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); class_243 class_243 = e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D); String str = "Shulker Box"; hashMap.put(class_243, str); continue; }
/* 400 */          if (class_25861 instanceof net.minecraft.class_3719) { HashMap<class_243, String> hashMap = this.positions; Intrinsics.checkNotNullExpressionValue(e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D), "add(...)"); class_243 class_243 = e.method_11016().method_46558().method_1031(0.0D, -0.5D, 0.0D); String str = "Barrel"; hashMap.put(class_243, str); }
/*     */       
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final Stream<class_2586> getLoadedBlockEntities()
/*     */   {
/* 408 */     Intrinsics.checkNotNullExpressionValue(getLoadedChunks().flatMap(EspModule$getLoadedBlockEntities$1.INSTANCE::getLoadedBlockEntities$lambda$0), "flatMap(...)"); return (Stream)getLoadedChunks().flatMap(EspModule$getLoadedBlockEntities$1.INSTANCE::getLoadedBlockEntities$lambda$0); } private static final Stream getLoadedBlockEntities$lambda$0(Function1 $tmp0, Object p0) { Intrinsics.checkNotNullParameter($tmp0, "$tmp0"); return (Stream)$tmp0.invoke(p0); } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\004\020\007\032*\022\016\b\001\022\n \004*\004\030\0010\0030\003 \004*\024\022\016\b\001\022\n \004*\004\030\0010\0030\003\030\0010\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\005\020\006"}, d2 = {"Lnet/minecraft/class_2818;", "chunk", "Ljava/util/stream/Stream;", "Lnet/minecraft/class_2586;", "kotlin.jvm.PlatformType", "invoke", "(Lnet/minecraft/class_2818;)Ljava/util/stream/Stream;", "<anonymous>"}) static final class EspModule$getLoadedBlockEntities$1 extends Lambda implements Function1<class_2818, Stream<? extends class_2586>> { public static final EspModule$getLoadedBlockEntities$1 INSTANCE = new EspModule$getLoadedBlockEntities$1(); EspModule$getLoadedBlockEntities$1() { super(1); } public final Stream<? extends class_2586> invoke(@NotNull class_2818 chunk) { Intrinsics.checkNotNullParameter(chunk, "chunk"); return chunk.method_12214().values().stream(); }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Stream<class_2818> getLoadedChunks() {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   4: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   7: getfield field_1690 : Lnet/minecraft/class_315;
/*     */     //   10: invokevirtual method_38521 : ()I
/*     */     //   13: invokestatic coerceAtLeast : (II)I
/*     */     //   16: iconst_3
/*     */     //   17: iadd
/*     */     //   18: istore_1
/*     */     //   19: iload_1
/*     */     //   20: iconst_2
/*     */     //   21: imul
/*     */     //   22: iconst_1
/*     */     //   23: iadd
/*     */     //   24: istore_2
/*     */     //   25: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   28: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   31: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   34: dup
/*     */     //   35: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   38: invokevirtual method_31476 : ()Lnet/minecraft/class_1923;
/*     */     //   41: dup
/*     */     //   42: ldc_w 'getChunkPos(...)'
/*     */     //   45: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   48: astore_3
/*     */     //   49: new net/minecraft/class_1923
/*     */     //   52: dup
/*     */     //   53: aload_3
/*     */     //   54: getfield field_9181 : I
/*     */     //   57: iload_1
/*     */     //   58: isub
/*     */     //   59: aload_3
/*     */     //   60: getfield field_9180 : I
/*     */     //   63: iload_1
/*     */     //   64: isub
/*     */     //   65: invokespecial <init> : (II)V
/*     */     //   68: astore #4
/*     */     //   70: new net/minecraft/class_1923
/*     */     //   73: dup
/*     */     //   74: aload_3
/*     */     //   75: getfield field_9181 : I
/*     */     //   78: iload_1
/*     */     //   79: iadd
/*     */     //   80: aload_3
/*     */     //   81: getfield field_9180 : I
/*     */     //   84: iload_1
/*     */     //   85: iadd
/*     */     //   86: invokespecial <init> : (II)V
/*     */     //   89: astore #5
/*     */     //   91: aload #4
/*     */     //   93: aload #5
/*     */     //   95: aload #4
/*     */     //   97: <illegal opcode> apply : (Lnet/minecraft/class_1923;Lnet/minecraft/class_1923;)Ljava/util/function/UnaryOperator;
/*     */     //   102: invokestatic iterate : (Ljava/lang/Object;Ljava/util/function/UnaryOperator;)Ljava/util/stream/Stream;
/*     */     //   105: iload_2
/*     */     //   106: iload_2
/*     */     //   107: imul
/*     */     //   108: i2l
/*     */     //   109: invokeinterface limit : (J)Ljava/util/stream/Stream;
/*     */     //   114: getstatic net/integr/modules/impl/EspModule$getLoadedChunks$stream$2.INSTANCE : Lnet/integr/modules/impl/EspModule$getLoadedChunks$stream$2;
/*     */     //   117: checkcast kotlin/jvm/functions/Function1
/*     */     //   120: <illegal opcode> test : (Lkotlin/jvm/functions/Function1;)Ljava/util/function/Predicate;
/*     */     //   125: invokeinterface filter : (Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
/*     */     //   130: getstatic net/integr/modules/impl/EspModule$getLoadedChunks$stream$3.INSTANCE : Lnet/integr/modules/impl/EspModule$getLoadedChunks$stream$3;
/*     */     //   133: checkcast kotlin/jvm/functions/Function1
/*     */     //   136: <illegal opcode> apply : (Lkotlin/jvm/functions/Function1;)Ljava/util/function/Function;
/*     */     //   141: invokeinterface map : (Ljava/util/function/Function;)Ljava/util/stream/Stream;
/*     */     //   146: <illegal opcode> test : ()Ljava/util/function/Predicate;
/*     */     //   151: invokeinterface filter : (Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
/*     */     //   156: dup
/*     */     //   157: ldc_w 'filter(...)'
/*     */     //   160: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   163: astore #6
/*     */     //   165: aload #6
/*     */     //   167: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #412	-> 0
/*     */     //   #413	-> 19
/*     */     //   #415	-> 25
/*     */     //   #416	-> 49
/*     */     //   #417	-> 70
/*     */     //   #419	-> 91
/*     */     //   #429	-> 105
/*     */     //   #419	-> 163
/*     */     //   #430	-> 165
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   19	149	1	radius	I
/*     */     //   25	143	2	diameter	I
/*     */     //   49	119	3	center	Lnet/minecraft/class_1923;
/*     */     //   70	98	4	min	Lnet/minecraft/class_1923;
/*     */     //   91	77	5	max	Lnet/minecraft/class_1923;
/*     */     //   165	3	6	stream	Ljava/util/stream/Stream;
/*     */     //   0	168	0	this	Lnet/integr/modules/impl/EspModule;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class_1923 getLoadedChunks$lambda$2(class_1923 $max, class_1923 $min, class_1923 pos) {
/* 420 */     Intrinsics.checkNotNullParameter($max, "$max"); Intrinsics.checkNotNullParameter($min, "$min"); Intrinsics.checkNotNullParameter(pos, "pos"); int x = pos.field_9181;
/* 421 */     int z = pos.field_9180;
/* 422 */     x++;
/* 423 */     if (x > $max.field_9181) {
/* 424 */       x = $min.field_9181;
/* 425 */       z++;
/*     */     } 
/* 427 */     if (!((z <= $max.field_9180) ? 1 : 0)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 446 */       int $i$a$-check-EspModule$getLoadedChunks$stream$1$1 = 0;
/*     */       String str = "Stream limit didn't work.";
/*     */       throw new IllegalStateException(str.toString());
/*     */     } 
/*     */     return new class_1923(x, z);
/*     */   }
/*     */   
/*     */   private static final boolean getLoadedChunks$lambda$3(Function1 $tmp0, Object p0) {
/*     */     Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
/*     */     return ((Boolean)$tmp0.invoke(p0)).booleanValue();
/*     */   }
/*     */   
/*     */   private static final class_2818 getLoadedChunks$lambda$4(Function1 $tmp0, Object p0) {
/*     */     Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
/*     */     return (class_2818)$tmp0.invoke(p0);
/*     */   }
/*     */   
/*     */   private static final boolean getLoadedChunks$lambda$5(Object obj) {
/*     */     return Objects.nonNull(obj);
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\003\020\005\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Lnet/minecraft/class_1923;", "c", "", "invoke", "(Lnet/minecraft/class_1923;)Ljava/lang/Boolean;", "<anonymous>"})
/*     */   static final class EspModule$getLoadedChunks$stream$2 extends Lambda implements Function1<class_1923, Boolean> {
/*     */     public static final EspModule$getLoadedChunks$stream$2 INSTANCE = new EspModule$getLoadedChunks$stream$2();
/*     */     
/*     */     EspModule$getLoadedChunks$stream$2() {
/*     */       super(1);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final Boolean invoke(@NotNull class_1923 c) {
/*     */       Intrinsics.checkNotNullParameter(c, "c");
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       return Boolean.valueOf((Onyx.Companion.getMC()).field_1687.method_8393(c.field_9181, c.field_9180));
/*     */     }
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\004\020\006\032\n \003*\004\030\0010\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\004\020\005"}, d2 = {"Lnet/minecraft/class_1923;", "c", "Lnet/minecraft/class_2818;", "kotlin.jvm.PlatformType", "invoke", "(Lnet/minecraft/class_1923;)Lnet/minecraft/class_2818;", "<anonymous>"})
/*     */   static final class EspModule$getLoadedChunks$stream$3 extends Lambda implements Function1<class_1923, class_2818> {
/*     */     public static final EspModule$getLoadedChunks$stream$3 INSTANCE = new EspModule$getLoadedChunks$stream$3();
/*     */     
/*     */     EspModule$getLoadedChunks$stream$3() {
/*     */       super(1);
/*     */     }
/*     */     
/*     */     public final class_2818 invoke(@NotNull class_1923 c) {
/*     */       Intrinsics.checkNotNullParameter(c, "c");
/*     */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */       return (Onyx.Companion.getMC()).field_1687.method_8497(c.field_9181, c.field_9180);
/*     */     }
/*     */   }
/*     */   
/*     */   private final int getPing(class_1657 playerEntity) {
/*     */     class_640 playerListEntry;
/*     */     if (Onyx.Companion.getMC().method_1562() == null)
/*     */       return 0; 
/*     */     Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1562());
/*     */     if (Onyx.Companion.getMC().method_1562().method_2871(playerEntity.method_5667()) == null) {
/*     */       Onyx.Companion.getMC().method_1562().method_2871(playerEntity.method_5667());
/*     */       return 0;
/*     */     } 
/*     */     return playerListEntry.method_2959();
/*     */   }
/*     */   
/*     */   private final class_1799 getDefenseItemFromBp(class_2338 blockPos) {
/*     */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687);
/*     */     class_2680 state = (Onyx.Companion.getMC()).field_1687.method_8320(blockPos);
/*     */     Intrinsics.checkNotNullExpressionValue(state.method_26204().method_8389().method_7854(), "getDefaultStack(...)");
/*     */     return state.method_26204().method_8389().method_7854();
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\EspModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */