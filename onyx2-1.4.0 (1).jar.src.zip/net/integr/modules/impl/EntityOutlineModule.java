/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Variables;
/*    */ import net.integr.event.EntityHasOutlineEvent;
/*    */ import net.integr.event.RenderEntityEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_4618;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Lnet/integr/modules/impl/EntityOutlineModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/EntityHasOutlineEvent;", "event", "", "onEntityHasOutline", "(Lnet/integr/event/EntityHasOutlineEvent;)V", "Lnet/integr/event/RenderEntityEvent;", "onRenderEntity", "(Lnet/integr/event/RenderEntityEvent;)V", "onyx2"})
/*    */ public final class EntityOutlineModule
/*    */   extends Module
/*    */ {
/*    */   public EntityOutlineModule() {
/* 32 */     super("Entity Outline", "Draw Entity Outlines", "entityOutline", Filter.Render, false, 16, null);
/*    */   }
/*    */   @EventListen
/*    */   public final void onRenderEntity(@NotNull RenderEntityEvent event) {
/* 36 */     Intrinsics.checkNotNullParameter(event, "event"); if (event.vertexConsumers instanceof class_4618) {
/* 37 */       if (event.entity instanceof class_1309) {
/* 38 */         Intrinsics.checkNotNull(event.entity, "null cannot be cast to non-null type net.minecraft.entity.LivingEntity"); if (((class_1309)event.entity).field_6235 > 0) {
/* 39 */           Intrinsics.checkNotNull(event.vertexConsumers, "null cannot be cast to non-null type net.minecraft.client.render.OutlineVertexConsumerProvider"); ((class_4618)event.vertexConsumers).method_23286(224, 36, 7, 255);
/*    */         } else {
/* 41 */           Color c = new Color(Variables.Companion.getGuiColor());
/* 42 */           Intrinsics.checkNotNull(event.vertexConsumers, "null cannot be cast to non-null type net.minecraft.client.render.OutlineVertexConsumerProvider"); ((class_4618)event.vertexConsumers).method_23286(c.getRed(), c.getGreen(), c.getBlue(), 255);
/*    */         } 
/*    */       } else {
/* 45 */         Color c = new Color(Variables.Companion.getGuiColor());
/* 46 */         Intrinsics.checkNotNull(event.vertexConsumers, "null cannot be cast to non-null type net.minecraft.client.render.OutlineVertexConsumerProvider"); ((class_4618)event.vertexConsumers).method_23286(c.getRed(), c.getGreen(), c.getBlue(), 255);
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @EventListen
/*    */   public final void onEntityHasOutline(@NotNull EntityHasOutlineEvent event) {
/* 53 */     Intrinsics.checkNotNullParameter(event, "event"); class_1299 et = event.entity.method_5864();
/* 54 */     if (!Intrinsics.areEqual(et, class_1299.field_6131) && !Intrinsics.areEqual(et, class_1299.field_6043) && !Intrinsics.areEqual(et, class_1299.field_28401))
/* 55 */       event.setCallback(Boolean.valueOf(true)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\EntityOutlineModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */