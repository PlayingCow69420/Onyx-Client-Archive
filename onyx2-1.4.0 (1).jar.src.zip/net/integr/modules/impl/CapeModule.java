/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.GetCapeIdEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.minecraft.class_2960;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/modules/impl/CapeModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/integr/event/GetCapeIdEvent;", "event", "", "onGetCapeIdEvent", "(Lnet/integr/event/GetCapeIdEvent;)V", "onyx2"})
/*    */ public final class CapeModule
/*    */   extends Module
/*    */ {
/*    */   public CapeModule() {
/* 28 */     super("Cape", "Displays a custom cape on your player", "cape", Filter.Render, false, 16, null);
/*    */   } @EventListen
/*    */   public final void onGetCapeIdEvent(@NotNull GetCapeIdEvent event) {
/* 31 */     Intrinsics.checkNotNullParameter(event, "event"); if (Intrinsics.areEqual(event.player, (Onyx.Companion.getMC()).field_1724)) event.setCallback(class_2960.method_60655("onyx", "cape/cape.png")); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\CapeModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */