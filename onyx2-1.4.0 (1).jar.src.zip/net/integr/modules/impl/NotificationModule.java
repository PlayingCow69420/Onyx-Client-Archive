/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J/\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\r¨\006\016"}, d2 = {"Lnet/integr/modules/impl/NotificationModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nNotificationModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NotificationModule.kt\nnet/integr/modules/impl/NotificationModule\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,128:1\n766#2:129\n857#2,2:130\n*S KotlinDebug\n*F\n+ 1 NotificationModule.kt\nnet/integr/modules/impl/NotificationModule\n*L\n126#1:129\n126#1:130,2\n*E\n"})
/*    */ public final class NotificationModule
/*    */   extends UiModule
/*    */ {
/*    */   public NotificationModule() {
/* 28 */     super("Notifications", "Renders various notifications on your HUD", "notifications", 20, 200, Filter.Render);
/*    */   }
/*    */   
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: ldc 'context'
/*    */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*    */     //   6: getstatic net/integr/utilities/game/notification/NotificationHandler.Companion : Lnet/integr/utilities/game/notification/NotificationHandler$Companion;
/*    */     //   9: invokevirtual getNotifications : ()Ljava/util/List;
/*    */     //   12: astore #5
/*    */     //   14: iconst_0
/*    */     //   15: istore #6
/*    */     //   17: iload_2
/*    */     //   18: bipush #10
/*    */     //   20: isub
/*    */     //   21: aload_1
/*    */     //   22: invokevirtual method_51421 : ()I
/*    */     //   25: iconst_2
/*    */     //   26: idiv
/*    */     //   27: if_icmplt -> 569
/*    */     //   30: iload_3
/*    */     //   31: bipush #50
/*    */     //   33: isub
/*    */     //   34: aload_1
/*    */     //   35: invokevirtual method_51443 : ()I
/*    */     //   38: iconst_2
/*    */     //   39: idiv
/*    */     //   40: if_icmplt -> 306
/*    */     //   43: aload #5
/*    */     //   45: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   50: astore #7
/*    */     //   52: aload #7
/*    */     //   54: invokeinterface hasNext : ()Z
/*    */     //   59: ifeq -> 1052
/*    */     //   62: aload #7
/*    */     //   64: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   69: checkcast kotlin/Pair
/*    */     //   72: astore #8
/*    */     //   74: aload #8
/*    */     //   76: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   79: checkcast kotlin/Pair
/*    */     //   82: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   85: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   88: invokevirtual get : ()I
/*    */     //   91: istore #9
/*    */     //   93: new net/integr/rendering/uisystem/Box
/*    */     //   96: dup
/*    */     //   97: iload_2
/*    */     //   98: sipush #200
/*    */     //   101: iadd
/*    */     //   102: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   105: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   108: getfield field_1772 : Lnet/minecraft/class_327;
/*    */     //   111: aload #8
/*    */     //   113: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   116: checkcast java/lang/String
/*    */     //   119: invokevirtual method_1727 : (Ljava/lang/String;)I
/*    */     //   122: bipush #20
/*    */     //   124: iadd
/*    */     //   125: isub
/*    */     //   126: iload #9
/*    */     //   128: iadd
/*    */     //   129: iload_3
/*    */     //   130: iload #6
/*    */     //   132: isub
/*    */     //   133: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   136: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   139: getfield field_1772 : Lnet/minecraft/class_327;
/*    */     //   142: aload #8
/*    */     //   144: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   147: checkcast java/lang/String
/*    */     //   150: invokevirtual method_1727 : (Ljava/lang/String;)I
/*    */     //   153: bipush #20
/*    */     //   155: iadd
/*    */     //   156: bipush #20
/*    */     //   158: aload #8
/*    */     //   160: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   163: checkcast java/lang/String
/*    */     //   166: iconst_1
/*    */     //   167: iconst_0
/*    */     //   168: iconst_0
/*    */     //   169: sipush #192
/*    */     //   172: aconst_null
/*    */     //   173: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*    */     //   176: aload_1
/*    */     //   177: iconst_0
/*    */     //   178: iconst_0
/*    */     //   179: fload #4
/*    */     //   181: invokevirtual method_25394 : (Lnet/minecraft/class_332;IIF)V
/*    */     //   184: aload #8
/*    */     //   186: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   189: checkcast kotlin/Pair
/*    */     //   192: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   195: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   198: invokevirtual get : ()I
/*    */     //   201: bipush #12
/*    */     //   203: if_icmpgt -> 237
/*    */     //   206: iload #9
/*    */     //   208: bipush #80
/*    */     //   210: if_icmpgt -> 263
/*    */     //   213: aload #8
/*    */     //   215: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   218: checkcast kotlin/Pair
/*    */     //   221: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   224: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   227: iload #9
/*    */     //   229: iconst_3
/*    */     //   230: iadd
/*    */     //   231: invokevirtual set : (I)V
/*    */     //   234: goto -> 263
/*    */     //   237: iload #9
/*    */     //   239: ifle -> 263
/*    */     //   242: aload #8
/*    */     //   244: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   247: checkcast kotlin/Pair
/*    */     //   250: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   253: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   256: iload #9
/*    */     //   258: iconst_3
/*    */     //   259: isub
/*    */     //   260: invokevirtual set : (I)V
/*    */     //   263: aload #8
/*    */     //   265: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   268: checkcast kotlin/Pair
/*    */     //   271: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   274: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   277: aload #8
/*    */     //   279: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   282: checkcast kotlin/Pair
/*    */     //   285: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   288: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   291: invokevirtual get : ()I
/*    */     //   294: iconst_1
/*    */     //   295: isub
/*    */     //   296: invokevirtual set : (I)V
/*    */     //   299: iinc #6, 30
/*    */     //   302: nop
/*    */     //   303: goto -> 52
/*    */     //   306: aload #5
/*    */     //   308: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   313: astore #7
/*    */     //   315: aload #7
/*    */     //   317: invokeinterface hasNext : ()Z
/*    */     //   322: ifeq -> 1052
/*    */     //   325: aload #7
/*    */     //   327: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   332: checkcast kotlin/Pair
/*    */     //   335: astore #8
/*    */     //   337: aload #8
/*    */     //   339: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   342: checkcast kotlin/Pair
/*    */     //   345: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   348: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   351: invokevirtual get : ()I
/*    */     //   354: istore #9
/*    */     //   356: new net/integr/rendering/uisystem/Box
/*    */     //   359: dup
/*    */     //   360: iload_2
/*    */     //   361: sipush #200
/*    */     //   364: iadd
/*    */     //   365: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   368: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   371: getfield field_1772 : Lnet/minecraft/class_327;
/*    */     //   374: aload #8
/*    */     //   376: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   379: checkcast java/lang/String
/*    */     //   382: invokevirtual method_1727 : (Ljava/lang/String;)I
/*    */     //   385: bipush #20
/*    */     //   387: iadd
/*    */     //   388: isub
/*    */     //   389: iload #9
/*    */     //   391: iadd
/*    */     //   392: iload_3
/*    */     //   393: iload #6
/*    */     //   395: iadd
/*    */     //   396: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   399: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   402: getfield field_1772 : Lnet/minecraft/class_327;
/*    */     //   405: aload #8
/*    */     //   407: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   410: checkcast java/lang/String
/*    */     //   413: invokevirtual method_1727 : (Ljava/lang/String;)I
/*    */     //   416: bipush #20
/*    */     //   418: iadd
/*    */     //   419: bipush #20
/*    */     //   421: aload #8
/*    */     //   423: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   426: checkcast java/lang/String
/*    */     //   429: iconst_1
/*    */     //   430: iconst_0
/*    */     //   431: iconst_0
/*    */     //   432: sipush #192
/*    */     //   435: aconst_null
/*    */     //   436: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*    */     //   439: aload_1
/*    */     //   440: iconst_0
/*    */     //   441: iconst_0
/*    */     //   442: fload #4
/*    */     //   444: invokevirtual method_25394 : (Lnet/minecraft/class_332;IIF)V
/*    */     //   447: aload #8
/*    */     //   449: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   452: checkcast kotlin/Pair
/*    */     //   455: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   458: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   461: invokevirtual get : ()I
/*    */     //   464: bipush #12
/*    */     //   466: if_icmpgt -> 500
/*    */     //   469: iload #9
/*    */     //   471: bipush #80
/*    */     //   473: if_icmpgt -> 526
/*    */     //   476: aload #8
/*    */     //   478: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   481: checkcast kotlin/Pair
/*    */     //   484: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   487: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   490: iload #9
/*    */     //   492: iconst_3
/*    */     //   493: iadd
/*    */     //   494: invokevirtual set : (I)V
/*    */     //   497: goto -> 526
/*    */     //   500: iload #9
/*    */     //   502: ifle -> 526
/*    */     //   505: aload #8
/*    */     //   507: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   510: checkcast kotlin/Pair
/*    */     //   513: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   516: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   519: iload #9
/*    */     //   521: iconst_3
/*    */     //   522: isub
/*    */     //   523: invokevirtual set : (I)V
/*    */     //   526: aload #8
/*    */     //   528: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   531: checkcast kotlin/Pair
/*    */     //   534: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   537: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   540: aload #8
/*    */     //   542: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   545: checkcast kotlin/Pair
/*    */     //   548: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   551: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   554: invokevirtual get : ()I
/*    */     //   557: iconst_1
/*    */     //   558: isub
/*    */     //   559: invokevirtual set : (I)V
/*    */     //   562: iinc #6, 30
/*    */     //   565: nop
/*    */     //   566: goto -> 315
/*    */     //   569: iload_3
/*    */     //   570: bipush #50
/*    */     //   572: isub
/*    */     //   573: aload_1
/*    */     //   574: invokevirtual method_51443 : ()I
/*    */     //   577: iconst_2
/*    */     //   578: idiv
/*    */     //   579: if_icmplt -> 817
/*    */     //   582: aload #5
/*    */     //   584: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   589: astore #7
/*    */     //   591: aload #7
/*    */     //   593: invokeinterface hasNext : ()Z
/*    */     //   598: ifeq -> 1052
/*    */     //   601: aload #7
/*    */     //   603: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   608: checkcast kotlin/Pair
/*    */     //   611: astore #8
/*    */     //   613: aload #8
/*    */     //   615: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   618: checkcast kotlin/Pair
/*    */     //   621: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   624: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   627: invokevirtual get : ()I
/*    */     //   630: istore #9
/*    */     //   632: new net/integr/rendering/uisystem/Box
/*    */     //   635: dup
/*    */     //   636: iload_2
/*    */     //   637: iload #9
/*    */     //   639: isub
/*    */     //   640: iload_3
/*    */     //   641: iload #6
/*    */     //   643: isub
/*    */     //   644: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   647: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   650: getfield field_1772 : Lnet/minecraft/class_327;
/*    */     //   653: aload #8
/*    */     //   655: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   658: checkcast java/lang/String
/*    */     //   661: invokevirtual method_1727 : (Ljava/lang/String;)I
/*    */     //   664: bipush #20
/*    */     //   666: iadd
/*    */     //   667: bipush #20
/*    */     //   669: aload #8
/*    */     //   671: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   674: checkcast java/lang/String
/*    */     //   677: iconst_1
/*    */     //   678: iconst_0
/*    */     //   679: iconst_0
/*    */     //   680: sipush #192
/*    */     //   683: aconst_null
/*    */     //   684: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*    */     //   687: aload_1
/*    */     //   688: iconst_0
/*    */     //   689: iconst_0
/*    */     //   690: fload #4
/*    */     //   692: invokevirtual method_25394 : (Lnet/minecraft/class_332;IIF)V
/*    */     //   695: aload #8
/*    */     //   697: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   700: checkcast kotlin/Pair
/*    */     //   703: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   706: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   709: invokevirtual get : ()I
/*    */     //   712: bipush #12
/*    */     //   714: if_icmpgt -> 748
/*    */     //   717: iload #9
/*    */     //   719: bipush #80
/*    */     //   721: if_icmpgt -> 774
/*    */     //   724: aload #8
/*    */     //   726: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   729: checkcast kotlin/Pair
/*    */     //   732: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   735: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   738: iload #9
/*    */     //   740: iconst_3
/*    */     //   741: iadd
/*    */     //   742: invokevirtual set : (I)V
/*    */     //   745: goto -> 774
/*    */     //   748: iload #9
/*    */     //   750: ifle -> 774
/*    */     //   753: aload #8
/*    */     //   755: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   758: checkcast kotlin/Pair
/*    */     //   761: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   764: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   767: iload #9
/*    */     //   769: iconst_3
/*    */     //   770: isub
/*    */     //   771: invokevirtual set : (I)V
/*    */     //   774: aload #8
/*    */     //   776: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   779: checkcast kotlin/Pair
/*    */     //   782: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   785: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   788: aload #8
/*    */     //   790: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   793: checkcast kotlin/Pair
/*    */     //   796: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   799: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   802: invokevirtual get : ()I
/*    */     //   805: iconst_1
/*    */     //   806: isub
/*    */     //   807: invokevirtual set : (I)V
/*    */     //   810: iinc #6, 30
/*    */     //   813: nop
/*    */     //   814: goto -> 591
/*    */     //   817: aload #5
/*    */     //   819: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   824: astore #7
/*    */     //   826: aload #7
/*    */     //   828: invokeinterface hasNext : ()Z
/*    */     //   833: ifeq -> 1052
/*    */     //   836: aload #7
/*    */     //   838: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   843: checkcast kotlin/Pair
/*    */     //   846: astore #8
/*    */     //   848: aload #8
/*    */     //   850: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   853: checkcast kotlin/Pair
/*    */     //   856: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   859: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   862: invokevirtual get : ()I
/*    */     //   865: istore #9
/*    */     //   867: new net/integr/rendering/uisystem/Box
/*    */     //   870: dup
/*    */     //   871: iload_2
/*    */     //   872: iload #9
/*    */     //   874: isub
/*    */     //   875: iload_3
/*    */     //   876: iload #6
/*    */     //   878: iadd
/*    */     //   879: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*    */     //   882: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*    */     //   885: getfield field_1772 : Lnet/minecraft/class_327;
/*    */     //   888: aload #8
/*    */     //   890: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   893: checkcast java/lang/String
/*    */     //   896: invokevirtual method_1727 : (Ljava/lang/String;)I
/*    */     //   899: bipush #20
/*    */     //   901: iadd
/*    */     //   902: bipush #20
/*    */     //   904: aload #8
/*    */     //   906: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   909: checkcast java/lang/String
/*    */     //   912: iconst_1
/*    */     //   913: iconst_0
/*    */     //   914: iconst_0
/*    */     //   915: sipush #192
/*    */     //   918: aconst_null
/*    */     //   919: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*    */     //   922: aload_1
/*    */     //   923: iconst_0
/*    */     //   924: iconst_0
/*    */     //   925: fload #4
/*    */     //   927: invokevirtual method_25394 : (Lnet/minecraft/class_332;IIF)V
/*    */     //   930: aload #8
/*    */     //   932: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   935: checkcast kotlin/Pair
/*    */     //   938: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   941: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   944: invokevirtual get : ()I
/*    */     //   947: bipush #12
/*    */     //   949: if_icmpgt -> 983
/*    */     //   952: iload #9
/*    */     //   954: bipush #80
/*    */     //   956: if_icmpgt -> 1009
/*    */     //   959: aload #8
/*    */     //   961: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   964: checkcast kotlin/Pair
/*    */     //   967: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   970: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   973: iload #9
/*    */     //   975: iconst_3
/*    */     //   976: iadd
/*    */     //   977: invokevirtual set : (I)V
/*    */     //   980: goto -> 1009
/*    */     //   983: iload #9
/*    */     //   985: ifle -> 1009
/*    */     //   988: aload #8
/*    */     //   990: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   993: checkcast kotlin/Pair
/*    */     //   996: invokevirtual getFirst : ()Ljava/lang/Object;
/*    */     //   999: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   1002: iload #9
/*    */     //   1004: iconst_3
/*    */     //   1005: isub
/*    */     //   1006: invokevirtual set : (I)V
/*    */     //   1009: aload #8
/*    */     //   1011: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   1014: checkcast kotlin/Pair
/*    */     //   1017: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   1020: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   1023: aload #8
/*    */     //   1025: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   1028: checkcast kotlin/Pair
/*    */     //   1031: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   1034: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   1037: invokevirtual get : ()I
/*    */     //   1040: iconst_1
/*    */     //   1041: isub
/*    */     //   1042: invokevirtual set : (I)V
/*    */     //   1045: iinc #6, 30
/*    */     //   1048: nop
/*    */     //   1049: goto -> 826
/*    */     //   1052: getstatic net/integr/utilities/game/notification/NotificationHandler.Companion : Lnet/integr/utilities/game/notification/NotificationHandler$Companion;
/*    */     //   1055: getstatic net/integr/utilities/game/notification/NotificationHandler.Companion : Lnet/integr/utilities/game/notification/NotificationHandler$Companion;
/*    */     //   1058: invokevirtual getNotifications : ()Ljava/util/List;
/*    */     //   1061: checkcast java/lang/Iterable
/*    */     //   1064: astore #7
/*    */     //   1066: astore #16
/*    */     //   1068: iconst_0
/*    */     //   1069: istore #8
/*    */     //   1071: aload #7
/*    */     //   1073: astore #9
/*    */     //   1075: new java/util/ArrayList
/*    */     //   1078: dup
/*    */     //   1079: invokespecial <init> : ()V
/*    */     //   1082: checkcast java/util/Collection
/*    */     //   1085: astore #10
/*    */     //   1087: iconst_0
/*    */     //   1088: istore #11
/*    */     //   1090: aload #9
/*    */     //   1092: invokeinterface iterator : ()Ljava/util/Iterator;
/*    */     //   1097: astore #12
/*    */     //   1099: aload #12
/*    */     //   1101: invokeinterface hasNext : ()Z
/*    */     //   1106: ifeq -> 1169
/*    */     //   1109: aload #12
/*    */     //   1111: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   1116: astore #13
/*    */     //   1118: aload #13
/*    */     //   1120: checkcast kotlin/Pair
/*    */     //   1123: astore #14
/*    */     //   1125: iconst_0
/*    */     //   1126: istore #15
/*    */     //   1128: aload #14
/*    */     //   1130: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   1133: checkcast kotlin/Pair
/*    */     //   1136: invokevirtual getSecond : ()Ljava/lang/Object;
/*    */     //   1139: checkcast java/util/concurrent/atomic/AtomicInteger
/*    */     //   1142: invokevirtual get : ()I
/*    */     //   1145: ifle -> 1152
/*    */     //   1148: iconst_1
/*    */     //   1149: goto -> 1153
/*    */     //   1152: iconst_0
/*    */     //   1153: ifeq -> 1099
/*    */     //   1156: aload #10
/*    */     //   1158: aload #13
/*    */     //   1160: invokeinterface add : (Ljava/lang/Object;)Z
/*    */     //   1165: pop
/*    */     //   1166: goto -> 1099
/*    */     //   1169: aload #10
/*    */     //   1171: checkcast java/util/List
/*    */     //   1174: nop
/*    */     //   1175: aload #16
/*    */     //   1177: swap
/*    */     //   1178: invokevirtual setNotifications : (Ljava/util/List;)V
/*    */     //   1181: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 6
/*    */     //   #32	-> 14
/*    */     //   #34	-> 17
/*    */     //   #36	-> 30
/*    */     //   #38	-> 43
/*    */     //   #39	-> 74
/*    */     //   #41	-> 93
/*    */     //   #43	-> 184
/*    */     //   #44	-> 206
/*    */     //   #45	-> 213
/*    */     //   #48	-> 237
/*    */     //   #49	-> 242
/*    */     //   #53	-> 263
/*    */     //   #55	-> 302
/*    */     //   #59	-> 306
/*    */     //   #60	-> 337
/*    */     //   #62	-> 356
/*    */     //   #64	-> 447
/*    */     //   #65	-> 469
/*    */     //   #66	-> 476
/*    */     //   #69	-> 500
/*    */     //   #70	-> 505
/*    */     //   #74	-> 526
/*    */     //   #76	-> 565
/*    */     //   #81	-> 569
/*    */     //   #83	-> 582
/*    */     //   #84	-> 613
/*    */     //   #86	-> 632
/*    */     //   #88	-> 695
/*    */     //   #89	-> 717
/*    */     //   #90	-> 724
/*    */     //   #93	-> 748
/*    */     //   #94	-> 753
/*    */     //   #98	-> 774
/*    */     //   #100	-> 813
/*    */     //   #104	-> 817
/*    */     //   #105	-> 848
/*    */     //   #107	-> 867
/*    */     //   #109	-> 930
/*    */     //   #110	-> 952
/*    */     //   #111	-> 959
/*    */     //   #114	-> 983
/*    */     //   #115	-> 988
/*    */     //   #119	-> 1009
/*    */     //   #121	-> 1048
/*    */     //   #126	-> 1052
/*    */     //   #129	-> 1071
/*    */     //   #130	-> 1090
/*    */     //   #126	-> 1128
/*    */     //   #130	-> 1153
/*    */     //   #131	-> 1169
/*    */     //   #129	-> 1174
/*    */     //   #126	-> 1178
/*    */     //   #127	-> 1181
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   93	210	9	renderProg	I
/*    */     //   74	229	8	notification	Lkotlin/Pair;
/*    */     //   356	210	9	renderProg	I
/*    */     //   337	229	8	notification	Lkotlin/Pair;
/*    */     //   632	182	9	renderProg	I
/*    */     //   613	201	8	notification	Lkotlin/Pair;
/*    */     //   867	182	9	renderProg	I
/*    */     //   848	201	8	notification	Lkotlin/Pair;
/*    */     //   1128	25	15	$i$a$-filter-NotificationModule$render$1	I
/*    */     //   1125	28	14	it	Lkotlin/Pair;
/*    */     //   1118	48	13	element$iv$iv	Ljava/lang/Object;
/*    */     //   1090	81	11	$i$f$filterTo	I
/*    */     //   1087	84	9	$this$filterTo$iv$iv	Ljava/lang/Iterable;
/*    */     //   1087	84	10	destination$iv$iv	Ljava/util/Collection;
/*    */     //   1071	104	8	$i$f$filter	I
/*    */     //   1068	107	7	$this$filter$iv	Ljava/lang/Iterable;
/*    */     //   14	1168	5	notifications	Ljava/util/List;
/*    */     //   17	1165	6	counter	I
/*    */     //   0	1182	0	this	Lnet/integr/modules/impl/NotificationModule;
/*    */     //   0	1182	1	context	Lnet/minecraft/class_332;
/*    */     //   0	1182	2	originX	I
/*    */     //   0	1182	3	originY	I
/*    */     //   0	1182	4	delta	F
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\NotificationModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */