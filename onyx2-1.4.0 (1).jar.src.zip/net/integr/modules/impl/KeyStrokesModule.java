/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.integr.rendering.uisystem.ToggleButton;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\007\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\030\0002\0020\001B\007¢\006\004\b\002\020\003J/\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rR\026\020\017\032\0020\0168\002@\002X\016¢\006\006\n\004\b\017\020\020R\026\020\022\032\0020\0218\002@\002X\016¢\006\006\n\004\b\022\020\023R\026\020\024\032\0020\0218\002@\002X\016¢\006\006\n\004\b\024\020\023R\026\020\025\032\0020\0218\002@\002X\016¢\006\006\n\004\b\025\020\023R\026\020\026\032\0020\0218\002@\002X\016¢\006\006\n\004\b\026\020\023R\026\020\027\032\0020\0218\002@\002X\016¢\006\006\n\004\b\027\020\023¨\006\030"}, d2 = {"Lnet/integr/modules/impl/KeyStrokesModule;", "Lnet/integr/modules/management/UiModule;", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "originX", "originY", "", "delta", "", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "background", "Lnet/integr/rendering/uisystem/Box;", "Lnet/integr/rendering/uisystem/ToggleButton;", "keyA", "Lnet/integr/rendering/uisystem/ToggleButton;", "keyD", "keyS", "keySpace", "keyW", "onyx2"})
/*    */ public final class KeyStrokesModule extends UiModule {
/*    */   @NotNull
/*    */   private Box background;
/*    */   @NotNull
/*    */   private ToggleButton keyW;
/*    */   @NotNull
/*    */   private ToggleButton keyA;
/*    */   
/*    */   public KeyStrokesModule() {
/* 29 */     super("Keystrokes", "Renders your Key Inputs", "keystrokes", 79, 80, Filter.Render);
/*    */     
/* 31 */     initSettings(null.INSTANCE);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     this.background = new Box(0, 0, 79, 80, null, false, false, false, 192, null);
/*    */     
/* 38 */     this.keyW = new ToggleButton(0, 0, 20, 20, "  W", true, "", false, null, 256, null);
/* 39 */     this.keyA = new ToggleButton(0, 0, 20, 20, "  A", true, "", false, null, 256, null);
/* 40 */     this.keyS = new ToggleButton(0, 0, 20, 20, "  S", true, "", false, null, 256, null);
/* 41 */     this.keyD = new ToggleButton(0, 0, 20, 20, "  D", true, "", false, null, 256, null);
/* 42 */     this.keySpace = new ToggleButton(0, 0, 68, 20, "  ━━━━━━━━", true, "", false, null, 256, null); } @NotNull
/*    */   private ToggleButton keyS; @NotNull
/*    */   private ToggleButton keyD; @NotNull
/* 45 */   private ToggleButton keySpace; public void render(@NotNull class_332 context, int originX, int originY, float delta) { Intrinsics.checkNotNullParameter(context, "context"); this.keyW.setEnabled((Onyx.Companion.getMC()).field_1690.field_1894.method_1434());
/* 46 */     this.keyA.setEnabled((Onyx.Companion.getMC()).field_1690.field_1913.method_1434());
/* 47 */     this.keyS.setEnabled((Onyx.Companion.getMC()).field_1690.field_1881.method_1434());
/* 48 */     this.keyD.setEnabled((Onyx.Companion.getMC()).field_1690.field_1849.method_1434());
/* 49 */     this.keySpace.setEnabled((Onyx.Companion.getMC()).field_1690.field_1903.method_1434());
/*    */     
/* 51 */     Intrinsics.checkNotNull(getSettings().getById("spaceBar")); boolean renderSpace = ((BooleanSetting)getSettings().getById("spaceBar")).isEnabled();
/*    */     
/* 53 */     if (!renderSpace) {
/* 54 */       this.background.setYSize(55);
/* 55 */       setHeight(55);
/*    */     } else {
/* 57 */       this.background.setYSize(80);
/* 58 */       setHeight(80);
/*    */     } 
/* 60 */     this.background.update(originX, originY).method_25394(context, 0, 0, delta);
/*    */     
/* 62 */     this.keyW.update(originX + 29, originY + 5).method_25394(context, 0, 0, delta);
/* 63 */     this.keyA.update(originX + 5, originY + 29).method_25394(context, 0, 0, delta);
/* 64 */     this.keyS.update(originX + 29, originY + 29).method_25394(context, 0, 0, delta);
/* 65 */     this.keyD.update(originX + 53, originY + 29).method_25394(context, 0, 0, delta);
/*    */     
/* 67 */     if (renderSpace) this.keySpace.update(originX + 5, originY + 53).method_25394(context, 0, 0, delta);  }
/*    */ 
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\KeyStrokesModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */