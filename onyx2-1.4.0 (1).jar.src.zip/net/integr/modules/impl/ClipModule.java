/*    */ package net.integr.modules.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.KeyEvent;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.KeyBindSetting;
/*    */ import net.integr.utilities.game.highlight.Highlighter;
/*    */ import net.integr.utilities.game.interaction.MovementUtil;
/*    */ import net.integr.utilities.game.notification.NotificationHandler;
/*    */ import net.minecraft.class_243;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\020\006\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0042\006\020\007\032\0020\006H\026¢\006\004\b\b\020\tR\026\020\013\032\0020\n8\002@\002X\016¢\006\006\n\004\b\013\020\f¨\006\r"}, d2 = {"Lnet/integr/modules/impl/ClipModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "", "onEnable", "Lnet/integr/event/KeyEvent;", "event", "onKeyEvent", "(Lnet/integr/event/KeyEvent;)V", "", "distance", "D", "onyx2"})
/*    */ public final class ClipModule
/*    */   extends Module
/*    */ {
/*    */   private double distance;
/*    */   
/*    */   public ClipModule() {
/* 31 */     super("Clip", "Teleports you a set amount of blocks forward", "clip", Filter.Move, true);
/*    */     
/* 33 */     initSettings(null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onKeyEvent(@NotNull KeyEvent event) {
/* 42 */     Intrinsics.checkNotNullParameter(event, "event"); if (event.action == 1) {
/* 43 */       Intrinsics.checkNotNull(getSettings().getById("increase")); if (((KeyBindSetting)getSettings().getById("increase")).getBind() == null) { ((KeyBindSetting)getSettings().getById("increase")).getBind(); ((KeyBindSetting)getSettings().getById("increase")).getBind(); } else if (((KeyBindSetting)getSettings().getById("increase")).getBind() == ((KeyBindSetting)getSettings().getById("increase")).getBind().intValue())
/* 44 */       { double d = this.distance; this.distance = d + 1.0D;
/* 45 */         NotificationHandler.Companion.notify("Clip distance: " + this.distance); return; }
/*    */       
/* 47 */       Intrinsics.checkNotNull(getSettings().getById("decrease")); if (((KeyBindSetting)getSettings().getById("decrease")).getBind() == null) { ((KeyBindSetting)getSettings().getById("decrease")).getBind(); ((KeyBindSetting)getSettings().getById("decrease")).getBind(); } else if (((KeyBindSetting)getSettings().getById("decrease")).getBind() == ((KeyBindSetting)getSettings().getById("decrease")).getBind().intValue())
/* 48 */       { double d = this.distance; this.distance = d + -1.0D;
/* 49 */         NotificationHandler.Companion.notify("Clip distance: " + this.distance); }
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onEnable() {
/* 55 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_243 target = (Onyx.Companion.getMC()).field_1724.method_19538().method_1019((Onyx.Companion.getMC()).field_1724.method_5720().method_1021(this.distance));
/*    */     
/* 57 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, 0.5D, 0.0D), "add(...)"); Intrinsics.checkNotNullExpressionValue(target.method_1031(0.0D, 0.5D, 0.0D), "add(...)"); Highlighter.Companion.renderLine$default(Highlighter.Companion, (Onyx.Companion.getMC()).field_1724.method_19538().method_1031(0.0D, 0.5D, 0.0D), target.method_1031(0.0D, 0.5D, 0.0D), 0, 320, 4, null);
/* 58 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1724.method_19538(), "getPos(...)"); Highlighter.Companion.renderBlock((Onyx.Companion.getMC()).field_1724.method_19538(), 320);
/* 59 */     Intrinsics.checkNotNull(target); Highlighter.Companion.renderBlock(target, 320);
/*    */     
/* 61 */     MovementUtil.Companion.spoofGroundOnlyFromDistance(this.distance);
/*    */     
/* 63 */     MovementUtil.Companion.move(target);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\ClipModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */