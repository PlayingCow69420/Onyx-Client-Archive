/*     */ package net.integr.modules.impl;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.PreMoveEvent;
/*     */ import net.integr.eventsystem.EventListen;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.utilities.game.interaction.BlockUtil;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2346;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_2682;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\020\002\n\002\b\004\n\002\020\b\n\002\b\004\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J'\020\n\032\0020\t2\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\006H\002¢\006\004\b\n\020\013J\027\020\f\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\f\020\rJ\017\020\017\032\0020\016H\002¢\006\004\b\017\020\020J\017\020\021\032\0020\tH\026¢\006\004\b\021\020\003J\017\020\022\032\0020\tH\026¢\006\004\b\022\020\003J\027\020\025\032\0020\t2\006\020\024\032\0020\023H\007¢\006\004\b\025\020\026¨\006\027"}, d2 = {"Lnet/integr/modules/impl/ScaffoldModule;", "Lnet/integr/modules/management/Module;", "<init>", "()V", "Lnet/minecraft/class_2338;", "pos", "", "rotate", "silent", "", "attemptPlacement", "(Lnet/minecraft/class_2338;ZZ)V", "canPlace", "(Lnet/minecraft/class_2338;)Z", "", "findBlock", "()I", "onDisable", "onEnable", "Lnet/integr/event/PreMoveEvent;", "event", "onPreMove", "(Lnet/integr/event/PreMoveEvent;)V", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nScaffoldModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ScaffoldModule.kt\nnet/integr/modules/impl/ScaffoldModule\n+ 2 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n*L\n1#1,105:1\n71#2,7:106\n71#2,7:113\n71#2,7:120\n*S KotlinDebug\n*F\n+ 1 ScaffoldModule.kt\nnet/integr/modules/impl/ScaffoldModule\n*L\n49#1:106,7\n71#1:113,7\n72#1:120,7\n*E\n"})
/*     */ public final class ScaffoldModule
/*     */   extends Module
/*     */ {
/*     */   public ScaffoldModule() {
/*  41 */     super("Scaffold", "Automatically bridges for you", "scaffold", Filter.Move, false, 16, null);
/*     */     
/*  43 */     initSettings(null.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*     */     // Byte code:
/*     */     //   0: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   3: astore_2
/*     */     //   4: iconst_0
/*     */     //   5: istore_3
/*     */     //   6: aload_2
/*     */     //   7: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   10: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   15: astore #4
/*     */     //   17: aload #4
/*     */     //   19: invokeinterface hasNext : ()Z
/*     */     //   24: ifeq -> 77
/*     */     //   27: aload #4
/*     */     //   29: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   34: checkcast net/integr/modules/management/Module
/*     */     //   37: astore #5
/*     */     //   39: aload #5
/*     */     //   41: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   44: ldc net/integr/modules/impl/BhopFeature
/*     */     //   46: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   49: ifeq -> 17
/*     */     //   52: aload #5
/*     */     //   54: dup
/*     */     //   55: ifnonnull -> 68
/*     */     //   58: new java/lang/NullPointerException
/*     */     //   61: dup
/*     */     //   62: ldc 'null cannot be cast to non-null type net.integr.modules.impl.BhopFeature'
/*     */     //   64: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   67: athrow
/*     */     //   68: checkcast net/integr/modules/impl/BhopFeature
/*     */     //   71: checkcast net/integr/modules/management/Module
/*     */     //   74: goto -> 78
/*     */     //   77: aconst_null
/*     */     //   78: dup
/*     */     //   79: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   82: checkcast net/integr/modules/impl/BhopFeature
/*     */     //   85: astore_1
/*     */     //   86: aload_1
/*     */     //   87: invokevirtual isEnabled : ()Z
/*     */     //   90: ifeq -> 113
/*     */     //   93: aload_1
/*     */     //   94: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   97: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   100: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   103: dup
/*     */     //   104: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   107: invokevirtual method_23318 : ()D
/*     */     //   110: invokevirtual setStartHeight : (D)V
/*     */     //   113: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #49	-> 0
/*     */     //   #106	-> 6
/*     */     //   #107	-> 39
/*     */     //   #108	-> 52
/*     */     //   #112	-> 77
/*     */     //   #49	-> 78
/*     */     //   #50	-> 86
/*     */     //   #51	-> 113
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   39	38	5	m$iv	Lnet/integr/modules/management/Module;
/*     */     //   6	72	3	$i$f$getByClass	I
/*     */     //   4	74	2	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   86	28	1	bhop	Lnet/integr/modules/impl/BhopFeature;
/*     */     //   0	114	0	this	Lnet/integr/modules/impl/ScaffoldModule;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  54 */     RotationLocker.Companion.unLock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListen
/*     */   public final void onPreMove(@NotNull PreMoveEvent event) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'event'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_0
/*     */     //   7: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   10: ldc 'rotate'
/*     */     //   12: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   15: dup
/*     */     //   16: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   19: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   22: invokevirtual isEnabled : ()Z
/*     */     //   25: istore_2
/*     */     //   26: aload_0
/*     */     //   27: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   30: ldc 'silent'
/*     */     //   32: invokevirtual getById : (Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;
/*     */     //   35: dup
/*     */     //   36: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   39: checkcast net/integr/modules/management/settings/impl/BooleanSetting
/*     */     //   42: invokevirtual isEnabled : ()Z
/*     */     //   45: istore_3
/*     */     //   46: aload_0
/*     */     //   47: invokespecial findBlock : ()I
/*     */     //   50: istore #4
/*     */     //   52: iload #4
/*     */     //   54: iconst_m1
/*     */     //   55: if_icmpeq -> 405
/*     */     //   58: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*     */     //   61: invokevirtual getSelectedSlot : ()I
/*     */     //   64: istore #5
/*     */     //   66: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*     */     //   69: iload #4
/*     */     //   71: invokevirtual selectSlot : (I)V
/*     */     //   74: iload_2
/*     */     //   75: ifeq -> 87
/*     */     //   78: getstatic net/integr/utilities/game/rotationfake/RotationLocker.Companion : Lnet/integr/utilities/game/rotationfake/RotationLocker$Companion;
/*     */     //   81: invokevirtual lock : ()V
/*     */     //   84: goto -> 93
/*     */     //   87: getstatic net/integr/utilities/game/rotationfake/RotationLocker.Companion : Lnet/integr/utilities/game/rotationfake/RotationLocker$Companion;
/*     */     //   90: invokevirtual unLock : ()V
/*     */     //   93: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   96: astore #6
/*     */     //   98: iconst_0
/*     */     //   99: istore #7
/*     */     //   101: aload #6
/*     */     //   103: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   106: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   111: astore #8
/*     */     //   113: aload #8
/*     */     //   115: invokeinterface hasNext : ()Z
/*     */     //   120: ifeq -> 173
/*     */     //   123: aload #8
/*     */     //   125: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   130: checkcast net/integr/modules/management/Module
/*     */     //   133: astore #9
/*     */     //   135: aload #9
/*     */     //   137: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   140: ldc net/integr/modules/impl/BhopFeature
/*     */     //   142: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   145: ifeq -> 113
/*     */     //   148: aload #9
/*     */     //   150: dup
/*     */     //   151: ifnonnull -> 164
/*     */     //   154: new java/lang/NullPointerException
/*     */     //   157: dup
/*     */     //   158: ldc 'null cannot be cast to non-null type net.integr.modules.impl.BhopFeature'
/*     */     //   160: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   163: athrow
/*     */     //   164: checkcast net/integr/modules/impl/BhopFeature
/*     */     //   167: checkcast net/integr/modules/management/Module
/*     */     //   170: goto -> 174
/*     */     //   173: aconst_null
/*     */     //   174: dup
/*     */     //   175: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   178: checkcast net/integr/modules/impl/BhopFeature
/*     */     //   181: invokevirtual isEnabled : ()Z
/*     */     //   184: ifeq -> 360
/*     */     //   187: aload_0
/*     */     //   188: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   191: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   194: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   197: dup
/*     */     //   198: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   201: invokevirtual method_24515 : ()Lnet/minecraft/class_2338;
/*     */     //   204: invokevirtual method_10263 : ()I
/*     */     //   207: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   210: astore #6
/*     */     //   212: istore #11
/*     */     //   214: astore #10
/*     */     //   216: iconst_0
/*     */     //   217: istore #7
/*     */     //   219: aload #6
/*     */     //   221: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   224: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   229: astore #8
/*     */     //   231: aload #8
/*     */     //   233: invokeinterface hasNext : ()Z
/*     */     //   238: ifeq -> 291
/*     */     //   241: aload #8
/*     */     //   243: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   248: checkcast net/integr/modules/management/Module
/*     */     //   251: astore #9
/*     */     //   253: aload #9
/*     */     //   255: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   258: ldc net/integr/modules/impl/BhopFeature
/*     */     //   260: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   263: ifeq -> 231
/*     */     //   266: aload #9
/*     */     //   268: dup
/*     */     //   269: ifnonnull -> 282
/*     */     //   272: new java/lang/NullPointerException
/*     */     //   275: dup
/*     */     //   276: ldc 'null cannot be cast to non-null type net.integr.modules.impl.BhopFeature'
/*     */     //   278: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   281: athrow
/*     */     //   282: checkcast net/integr/modules/impl/BhopFeature
/*     */     //   285: checkcast net/integr/modules/management/Module
/*     */     //   288: goto -> 292
/*     */     //   291: aconst_null
/*     */     //   292: astore #12
/*     */     //   294: aload #10
/*     */     //   296: iload #11
/*     */     //   298: aload #12
/*     */     //   300: dup
/*     */     //   301: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   304: checkcast net/integr/modules/impl/BhopFeature
/*     */     //   307: invokevirtual getStartHeight : ()D
/*     */     //   310: iconst_1
/*     */     //   311: i2d
/*     */     //   312: dsub
/*     */     //   313: d2i
/*     */     //   314: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   317: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   320: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   323: dup
/*     */     //   324: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   327: invokevirtual method_24515 : ()Lnet/minecraft/class_2338;
/*     */     //   330: invokevirtual method_10260 : ()I
/*     */     //   333: istore #13
/*     */     //   335: istore #14
/*     */     //   337: istore #15
/*     */     //   339: new net/minecraft/class_2338
/*     */     //   342: dup
/*     */     //   343: iload #15
/*     */     //   345: iload #14
/*     */     //   347: iload #13
/*     */     //   349: invokespecial <init> : (III)V
/*     */     //   352: iload_2
/*     */     //   353: iload_3
/*     */     //   354: invokespecial attemptPlacement : (Lnet/minecraft/class_2338;ZZ)V
/*     */     //   357: goto -> 394
/*     */     //   360: aload_0
/*     */     //   361: getstatic net/integr/Onyx.Companion : Lnet/integr/Onyx$Companion;
/*     */     //   364: invokevirtual getMC : ()Lnet/minecraft/class_310;
/*     */     //   367: getfield field_1724 : Lnet/minecraft/class_746;
/*     */     //   370: dup
/*     */     //   371: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   374: invokevirtual method_24515 : ()Lnet/minecraft/class_2338;
/*     */     //   377: iconst_0
/*     */     //   378: iconst_m1
/*     */     //   379: iconst_0
/*     */     //   380: invokevirtual method_10069 : (III)Lnet/minecraft/class_2338;
/*     */     //   383: dup
/*     */     //   384: ldc 'add(...)'
/*     */     //   386: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   389: iload_2
/*     */     //   390: iload_3
/*     */     //   391: invokespecial attemptPlacement : (Lnet/minecraft/class_2338;ZZ)V
/*     */     //   394: getstatic net/integr/utilities/game/inventory/InvUtils.Companion : Lnet/integr/utilities/game/inventory/InvUtils$Companion;
/*     */     //   397: iload #5
/*     */     //   399: invokevirtual selectSlot : (I)V
/*     */     //   402: goto -> 411
/*     */     //   405: getstatic net/integr/utilities/game/rotationfake/RotationLocker.Companion : Lnet/integr/utilities/game/rotationfake/RotationLocker$Companion;
/*     */     //   408: invokevirtual unLock : ()V
/*     */     //   411: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #60	-> 6
/*     */     //   #61	-> 26
/*     */     //   #63	-> 46
/*     */     //   #65	-> 52
/*     */     //   #66	-> 58
/*     */     //   #67	-> 66
/*     */     //   #69	-> 74
/*     */     //   #71	-> 93
/*     */     //   #113	-> 101
/*     */     //   #114	-> 135
/*     */     //   #115	-> 148
/*     */     //   #119	-> 173
/*     */     //   #71	-> 174
/*     */     //   #72	-> 187
/*     */     //   #120	-> 219
/*     */     //   #121	-> 253
/*     */     //   #122	-> 266
/*     */     //   #126	-> 291
/*     */     //   #72	-> 307
/*     */     //   #73	-> 360
/*     */     //   #75	-> 394
/*     */     //   #76	-> 405
/*     */     //   #77	-> 411
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   135	38	9	m$iv	Lnet/integr/modules/management/Module;
/*     */     //   101	73	7	$i$f$getByClass	I
/*     */     //   98	76	6	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   253	38	9	m$iv	Lnet/integr/modules/management/Module;
/*     */     //   219	73	7	$i$f$getByClass	I
/*     */     //   216	76	6	this_$iv	Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   66	336	5	pre	I
/*     */     //   26	386	2	rotate	Z
/*     */     //   46	366	3	silent	Z
/*     */     //   52	360	4	next	I
/*     */     //   0	412	0	this	Lnet/integr/modules/impl/ScaffoldModule;
/*     */     //   0	412	1	event	Lnet/integr/event/PreMoveEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int findBlock() {
/*  80 */     for (int i = 0; i < 9; i++) {
/*  81 */       Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); class_1799 stack = (Onyx.Companion.getMC()).field_1724.method_31548().method_5438(i);
/*     */       
/*  83 */       Intrinsics.checkNotNull(stack); if (!stack.method_7960() && stack.method_7909() instanceof net.minecraft.class_1747) {
/*     */         
/*  85 */         class_2248 block = class_2248.method_9503(stack.method_7909());
/*  86 */         if (block.method_9564().method_26234((class_1922)class_2682.field_12294, class_2338.field_10980)) {
/*     */           
/*  88 */           Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1724); if (!(block instanceof class_2346) || !class_2346.method_10128((Onyx.Companion.getMC()).field_1687.method_8320((Onyx.Companion.getMC()).field_1724.method_24515().method_10059(new class_2382(0, 1, 0)))))
/*     */           {
/*  90 */             return i; } 
/*     */         } 
/*     */       } 
/*  93 */     }  return -1;
/*     */   }
/*     */   
/*     */   private final boolean canPlace(class_2338 pos) {
/*  97 */     Intrinsics.checkNotNull((Onyx.Companion.getMC()).field_1687); return !(Onyx.Companion.getMC()).field_1687.method_8320(pos).method_26234((class_1922)class_2682.field_12294, class_2338.field_10980);
/*     */   }
/*     */   
/*     */   private final void attemptPlacement(class_2338 pos, boolean rotate, boolean silent) {
/* 101 */     if (canPlace(pos))
/* 102 */       BlockUtil.Companion.placeBlock$default(BlockUtil.Companion, pos, rotate, silent, false, 8, null); 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\impl\ScaffoldModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */