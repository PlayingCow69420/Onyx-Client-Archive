/*     */ package net.integr.modules.management;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonObject;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlin.Pair;
/*     */ import kotlin.TuplesKt;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.collections.MapsKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.SourceDebugExtension;
/*     */ import kotlin.text.Charsets;
/*     */ import kotlin.text.StringsKt;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Settings;
/*     */ import net.integr.utilities.LogUtils;
/*     */ import net.integr.utilities.file.FileSelector;
/*     */ import net.integr.utilities.game.notification.NotificationHandler;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000J\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\n\002\020 \n\002\b\t\n\002\020!\n\002\b\003\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ\036\020\013\032\004\030\0018\000\"\n\b\000\020\n\030\001*\0020\tH\b¢\006\004\b\013\020\fJ\033\020\013\032\004\030\0010\t2\n\020\016\032\006\022\002\b\0030\r¢\006\004\b\013\020\017J\027\020\022\032\004\030\0010\t2\006\020\021\032\0020\020¢\006\004\b\022\020\023J\023\020\025\032\b\022\004\022\0020\t0\024¢\006\004\b\025\020\026J\023\020\027\032\b\022\004\022\0020\t0\024¢\006\004\b\027\020\026J\r\020\030\032\0020\006¢\006\004\b\030\020\003J\017\020\031\032\0020\006H\002¢\006\004\b\031\020\003J\r\020\032\032\0020\006¢\006\004\b\032\020\003J\027\020\033\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\033\020\bJ\r\020\034\032\0020\006¢\006\004\b\034\020\003J\r\020\035\032\0020\006¢\006\004\b\035\020\003R\035\020\037\032\b\022\004\022\0020\t0\0368\006¢\006\f\n\004\b\037\020 \032\004\b!\020\026R\034\020$\032\n #*\004\030\0010\"0\"8\002X\004¢\006\006\n\004\b$\020%R\034\020&\032\b\022\004\022\0020\t0\0368\002@\002X\016¢\006\006\n\004\b&\020 ¨\006'"}, d2 = {"Lnet/integr/modules/management/ModuleManager$Companion;", "", "<init>", "()V", "Ljava/nio/file/Path;", "file", "", "exportToOCGAtPath", "(Ljava/nio/file/Path;)V", "Lnet/integr/modules/management/Module;", "T", "getByClass", "()Lnet/integr/modules/management/Module;", "Ljava/lang/Class;", "klass", "(Ljava/lang/Class;)Lnet/integr/modules/management/Module;", "", "id", "getById", "(Ljava/lang/String;)Lnet/integr/modules/management/Module;", "", "getEnabledModules", "()Ljava/util/List;", "getUiModules", "init", "load", "loadFromOCG", "loadFromOCGAtPath", "save", "saveToOCG", "", "modules", "Ljava/util/List;", "getModules", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "saveService", "Ljava/util/concurrent/ExecutorService;", "uiModules", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nModuleManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,201:1\n1855#2,2:202\n766#2:204\n857#2,2:205\n766#2:207\n857#2,2:208\n*S KotlinDebug\n*F\n+ 1 ModuleManager.kt\nnet/integr/modules/management/ModuleManager$Companion\n*L\n47#1:202,2\n54#1:204\n54#1:205,2\n95#1:207\n95#1:208,2\n*E\n"})
/*     */ public final class Companion {
/*     */   private Companion() {}
/*     */   
/*     */   @NotNull
/*     */   public final List<Module> getModules() {
/*  39 */     return ModuleManager.access$getModules$cp();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void init() {
/*  45 */     List<Class<?>> loaded = ModuleLoader.Companion.load();
/*     */     
/*  47 */     Iterable<Class<?>> $this$forEach$iv = loaded; int $i$f$forEach = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     Iterator<Class<?>> iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object<?> element$iv = (Object<?>)iterator.next(); Class it = (Class)element$iv; int $i$a$-forEach-ModuleManager$Companion$init$1 = 0; Object v = it.getConstructor(new Class[0]).newInstance(new Object[0]); Intrinsics.checkNotNull(v, "null cannot be cast to non-null type net.integr.modules.management.Module"); ModuleManager.Companion.getModules().add((Module)v); }
/*     */      load(); Iterable<Module> $this$filter$iv = getModules(); int $i$f$filter = 0;
/* 204 */     Iterable<Module> iterable1 = $this$filter$iv; Collection<Object> destination$iv$iv = new ArrayList(); int $i$f$filterTo = 0;
/* 205 */     for (Module element$iv$iv : iterable1) { Module it = element$iv$iv; int $i$a$-filter-ModuleManager$Companion$init$2 = 0; if (UiModule.class.isAssignableFrom(it.getClass())) destination$iv$iv.add(element$iv$iv);  }
/* 206 */      ModuleManager.access$setUiModules$cp(CollectionsKt.toMutableList(destination$iv$iv)); LogUtils.Companion.sendLog("Loaded " + loaded.size() - ModuleManager.access$getUiModules$cp().size() + " module/s"); LogUtils.Companion.sendLog("Loaded " + ModuleManager.access$getUiModules$cp().size() + " UI module/s"); } @NotNull public final List<Module> getEnabledModules() { Iterable<Module> $this$filter$iv = getModules(); int $i$f$filter = 0;
/* 207 */     Iterable<Module> iterable1 = $this$filter$iv; Collection<Object> destination$iv$iv = new ArrayList(); int $i$f$filterTo = 0;
/* 208 */     for (Module element$iv$iv : iterable1) { Module it = element$iv$iv; int $i$a$-filter-ModuleManager$Companion$getEnabledModules$1 = 0; if (it.isEnabled()) destination$iv$iv.add(element$iv$iv);  }
/* 209 */      return (List)destination$iv$iv; }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Module getById(@NotNull String id) {
/*     */     Intrinsics.checkNotNullParameter(id, "id");
/*     */     for (Module m : getModules()) {
/*     */       if (Intrinsics.areEqual(m.getId(), id))
/*     */         return m; 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public final Module getByClass(@NotNull Class klass) {
/*     */     Intrinsics.checkNotNullParameter(klass, "klass");
/*     */     for (Module m : getModules()) {
/*     */       if (Intrinsics.areEqual(m.getClass(), klass))
/*     */         return m; 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final List<Module> getUiModules() {
/*     */     return ModuleManager.access$getUiModules$cp();
/*     */   }
/*     */   
/*     */   public final void save() {
/*     */     for (Module m : getModules())
/*     */       m.save(); 
/*     */     Settings.Companion.getINSTANCE().save();
/*     */   }
/*     */   
/*     */   public final void loadFromOCG() {
/*     */     ModuleManager.access$getSaveService$cp().execute(Companion::loadFromOCG$lambda$3);
/*     */   }
/*     */   
/*     */   private static final void loadFromOCG$lambda$3() {
/*     */     try {
/*     */       String path = FileSelector.Companion.getImportableFile("./");
/*     */       if (path != null) {
/*     */         Intrinsics.checkNotNullExpressionValue(Paths.get(StringsKt.replace$default(path, "\\", "/", false, 4, null), new String[0]), "get(...)");
/*     */         ModuleManager.Companion.loadFromOCGAtPath(Paths.get(StringsKt.replace$default(path, "\\", "/", false, 4, null), new String[0]));
/*     */         NotificationHandler.Companion.notify("Import successful");
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       NotificationHandler.Companion.notify("Import failed");
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void saveToOCG() {
/*     */     ModuleManager.access$getSaveService$cp().execute(Companion::saveToOCG$lambda$4);
/*     */   }
/*     */   
/*     */   private static final void saveToOCG$lambda$4() {
/*     */     try {
/*     */       String path = FileSelector.Companion.getExportPath("./");
/*     */       if (path != null) {
/*     */         Intrinsics.checkNotNullExpressionValue(Paths.get(StringsKt.replace$default(path, "\\", "/", false, 4, null), new String[0]), "get(...)");
/*     */         ModuleManager.Companion.exportToOCGAtPath(Paths.get(StringsKt.replace$default(path, "\\", "/", false, 4, null), new String[0]));
/*     */         NotificationHandler.Companion.notify("Export successful");
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       NotificationHandler.Companion.notify("Export failed");
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void loadFromOCGAtPath(Path file) {
/*     */     String json = PathsKt.readText$default(file, null, 1, null);
/*     */     JsonObject jsonObj = (JsonObject)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson(json, JsonObject.class);
/*     */     JsonObject sObj = jsonObj.get("settings").getAsJsonObject();
/*     */     Intrinsics.checkNotNull(sObj);
/*     */     Settings.Companion.getINSTANCE().load(sObj);
/*     */     for (Module m : getModules()) {
/*     */       JsonObject jObj = jsonObj.get(m.getId()).getAsJsonObject();
/*     */       Intrinsics.checkNotNull(jObj);
/*     */       m.load(jObj);
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void exportToOCGAtPath(Path file) {
/*     */     Pair[] arrayOfPair = new Pair[1];
/*     */     arrayOfPair[0] = TuplesKt.to("settings", Settings.Companion.getINSTANCE());
/*     */     Map<String, Module> mods = MapsKt.mutableMapOf(arrayOfPair);
/*     */     for (Module m : getModules())
/*     */       mods.put(m.getId(), m); 
/*     */     String json = (new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().toJson(mods);
/*     */     Intrinsics.checkNotNullExpressionValue(file.getParent(), "getParent(...)");
/*     */     Path path = file.getParent();
/*     */     FileAttribute[] arrayOfFileAttribute = new FileAttribute[0];
/*     */     Intrinsics.checkNotNullExpressionValue(Files.createDirectories(path, (FileAttribute<?>[])Arrays.copyOf(arrayOfFileAttribute, arrayOfFileAttribute.length)), "createDirectories(...)");
/*     */     Files.createDirectories(path, (FileAttribute<?>[])Arrays.copyOf(arrayOfFileAttribute, arrayOfFileAttribute.length));
/*     */     Intrinsics.checkNotNull(json);
/*     */     String str1 = json;
/*     */     Intrinsics.checkNotNullExpressionValue(str1.getBytes(Charsets.UTF_8), "getBytes(...)");
/*     */     Files.write(file, str1.getBytes(Charsets.UTF_8), new java.nio.file.OpenOption[0]);
/*     */   }
/*     */   
/*     */   private final void load() {
/*     */     Intrinsics.checkNotNullExpressionValue(Path.of(Onyx.Companion.getCONFIG().toString(), new String[0]), "of(...)");
/*     */     Path path = Path.of(Onyx.Companion.getCONFIG().toString(), new String[0]);
/*     */     LinkOption[] arrayOfLinkOption = new LinkOption[0];
/*     */     if (!Files.exists(path, Arrays.<LinkOption>copyOf(arrayOfLinkOption, arrayOfLinkOption.length)))
/*     */       save(); 
/*     */     Intrinsics.checkNotNullExpressionValue(Path.of("" + Onyx.Companion.getCONFIG() + "/settings", new String[0]), "of(...)");
/*     */     path = Path.of("" + Onyx.Companion.getCONFIG() + "/settings", new String[0]);
/*     */     arrayOfLinkOption = new LinkOption[0];
/*     */     if (!Files.exists(path, Arrays.<LinkOption>copyOf(arrayOfLinkOption, arrayOfLinkOption.length)))
/*     */       save(); 
/*     */     if (!Settings.Companion.getINSTANCE().exist())
/*     */       Settings.Companion.getINSTANCE().save(); 
/*     */     try {
/*     */       Settings.Companion.getINSTANCE().load();
/*     */     } catch (Exception e) {
/*     */       LogUtils.Companion.sendLog("Something went wrong while loading Settings, resetting to default!");
/*     */       Settings.Companion.getINSTANCE().save();
/*     */     } 
/*     */     for (Module m : getModules()) {
/*     */       if (!m.exists())
/*     */         m.save(); 
/*     */       try {
/*     */         m.load();
/*     */       } catch (Exception e) {
/*     */         LogUtils.Companion.sendLog("Something went wrong while loading " + m.getId() + ", resetting the module!");
/*     */         m.save();
/*     */       } 
/*     */       if (m.getEnabled())
/*     */         EventSystem.Companion.register(m); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\ModuleManager$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */