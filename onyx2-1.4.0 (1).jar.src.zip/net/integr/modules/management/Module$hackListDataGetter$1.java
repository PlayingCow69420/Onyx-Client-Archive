/*    */ package net.integr.modules.management;
/*    */ 
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\020!\n\002\020\016\n\000\n\002\020\002\n\002\b\003\020\006\032\0020\0032\f\020\002\032\b\022\004\022\0020\0010\000H\n¢\006\004\b\004\020\005"}, d2 = {"", "", "it", "", "invoke", "(Ljava/util/List;)V", "<anonymous>"})
/*    */ final class Module$hackListDataGetter$1
/*    */   extends Lambda
/*    */   implements Function1<List<String>, Unit>
/*    */ {
/*    */   public static final Module$hackListDataGetter$1 INSTANCE = new Module$hackListDataGetter$1();
/*    */   
/*    */   Module$hackListDataGetter$1() {
/*    */     super(1);
/*    */   }
/*    */   
/*    */   public final void invoke(@NotNull List it) {
/* 41 */     Intrinsics.checkNotNullParameter(it, "it");
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\Module$hackListDataGetter$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */