/*    */ package net.integr.modules.management;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Path;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.filters.Filter;
/*    */ import net.integr.rendering.uisystem.MovableBox;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000@\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\007\n\002\b#\b\026\030\0002\0020\001B7\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\006\020\007\032\0020\006\022\006\020\b\032\0020\006\022\006\020\n\032\0020\t¢\006\004\b\013\020\fJ\r\020\016\032\0020\r¢\006\004\b\016\020\017J\017\020\021\032\0020\020H\026¢\006\004\b\021\020\022J/\020\031\032\0020\0202\006\020\024\032\0020\0232\006\020\025\032\0020\0062\006\020\026\032\0020\0062\006\020\030\032\0020\027H\026¢\006\004\b\031\020\032J\035\020\033\032\0020\0202\006\020\024\032\0020\0232\006\020\030\032\0020\027¢\006\004\b\033\020\034J\035\020\037\032\0020\0202\006\020\035\032\0020\0062\006\020\036\032\0020\006¢\006\004\b\037\020 R\"\020\003\032\0020\0028\026@\026X\016¢\006\022\n\004\b\003\020!\032\004\b\"\020#\"\004\b$\020%R\"\020\n\032\0020\t8\026@\026X\016¢\006\022\n\004\b\n\020&\032\004\b'\020(\"\004\b)\020*R\"\020\007\032\0020\0068\006@\006X\016¢\006\022\n\004\b\007\020+\032\004\b,\020-\"\004\b.\020/R\"\020\005\032\0020\0028\026@\026X\016¢\006\022\n\004\b\005\020!\032\004\b0\020#\"\004\b1\020%R\"\020\025\032\0020\0068\006@\006X\016¢\006\022\n\004\b\025\020+\032\004\b2\020-\"\004\b3\020/R\"\020\026\032\0020\0068\006@\006X\016¢\006\022\n\004\b\026\020+\032\004\b4\020-\"\004\b5\020/R\"\020\004\032\0020\0028\026@\026X\016¢\006\022\n\004\b\004\020!\032\004\b6\020#\"\004\b7\020%R\"\020\b\032\0020\0068\006@\006X\016¢\006\022\n\004\b\b\020+\032\004\b8\020-\"\004\b9\020/¨\006:"}, d2 = {"Lnet/integr/modules/management/UiModule;", "Lnet/integr/modules/management/Module;", "", "displayName", "toolTip", "id", "", "height", "width", "Lnet/integr/modules/filters/Filter;", "filter", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IILnet/integr/modules/filters/Filter;)V", "Lnet/integr/rendering/uisystem/MovableBox;", "getPlaceholderBox", "()Lnet/integr/rendering/uisystem/MovableBox;", "", "load", "()V", "Lnet/minecraft/class_332;", "context", "originX", "originY", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "runRender", "(Lnet/minecraft/class_332;F)V", "x", "y", "updatePosition", "(II)V", "Ljava/lang/String;", "getDisplayName", "()Ljava/lang/String;", "setDisplayName", "(Ljava/lang/String;)V", "Lnet/integr/modules/filters/Filter;", "getFilter", "()Lnet/integr/modules/filters/Filter;", "setFilter", "(Lnet/integr/modules/filters/Filter;)V", "I", "getHeight", "()I", "setHeight", "(I)V", "getId", "setId", "getOriginX", "setOriginX", "getOriginY", "setOriginY", "getToolTip", "setToolTip", "getWidth", "setWidth", "onyx2"})
/*    */ public class UiModule extends Module {
/*    */   @NotNull
/*    */   private String displayName;
/*    */   @NotNull
/*    */   private String toolTip;
/*    */   @NotNull
/*    */   private String id;
/*    */   private int height;
/*    */   private int width;
/*    */   @NotNull
/*    */   private Filter filter;
/*    */   @Expose
/*    */   private int originX;
/*    */   @Expose
/*    */   private int originY;
/*    */   
/* 31 */   public UiModule(@NotNull String displayName, @NotNull String toolTip, @NotNull String id, int height, int width, @NotNull Filter filter) { super(displayName, toolTip, id, filter, false, 16, null); this.displayName = displayName; this.toolTip = toolTip; this.id = id; this.height = height; this.width = width; this.filter = filter;
/* 32 */     this.originX = 20;
/* 33 */     this.originY = 20; } @NotNull public String getDisplayName() { return this.displayName; } public void setDisplayName(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.displayName = <set-?>; } @NotNull public String getToolTip() { return this.toolTip; } public void setToolTip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.toolTip = <set-?>; } @NotNull public String getId() { return this.id; } public void setId(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.id = <set-?>; } public final int getHeight() { return this.height; } public final int getOriginY() { return this.originY; } public final void setHeight(int <set-?>) { this.height = <set-?>; } public final int getWidth() { return this.width; } public final void setWidth(int <set-?>) { this.width = <set-?>; } @NotNull public Filter getFilter() { return this.filter; } public void setFilter(@NotNull Filter <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.filter = <set-?>; } public final int getOriginX() { return this.originX; } public final void setOriginX(int <set-?>) { this.originX = <set-?>; } public final void setOriginY(int <set-?>) { this.originY = <set-?>; }
/*    */   
/*    */   public final void runRender(@NotNull class_332 context, float delta) {
/* 36 */     Intrinsics.checkNotNullParameter(context, "context"); render(context, this.originX, this.originY, delta);
/*    */   }
/*    */   
/*    */   public final void updatePosition(int x, int y) {
/* 40 */     this.originX = x;
/* 41 */     this.originY = y;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(@NotNull class_332 context, int originX, int originY, float delta) {
/* 46 */     Intrinsics.checkNotNullParameter(context, "context");
/*    */   }
/*    */   public void load() {
/* 49 */     Intrinsics.checkNotNullExpressionValue(Files.readAllLines(Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0])), "readAllLines(...)"); String json = CollectionsKt.joinToString$default(Files.readAllLines(Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0])), "", null, null, 0, null, null, 62, null);
/* 50 */     JsonObject jsonObj = (JsonObject)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson(json, JsonObject.class);
/*    */     
/* 52 */     setEnabled(jsonObj.get("enabled").getAsBoolean());
/* 53 */     this.originX = jsonObj.get("originX").getAsInt();
/* 54 */     this.originY = jsonObj.get("originY").getAsInt();
/*    */     
/* 56 */     Intrinsics.checkNotNull(jsonObj); setSettings(getSettings().load(jsonObj));
/*    */   }
/*    */   @NotNull
/*    */   public final MovableBox getPlaceholderBox() {
/* 60 */     return new MovableBox(this.originX, this.originY, this.width, this.height, getDisplayName());
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\UiModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */