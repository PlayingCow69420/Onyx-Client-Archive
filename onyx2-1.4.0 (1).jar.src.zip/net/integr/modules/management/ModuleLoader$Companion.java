/*    */ package net.integr.modules.management;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.function.Predicate;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.reflections.Configuration;
/*    */ import org.reflections.Reflections;
/*    */ import org.reflections.util.ConfigurationBuilder;
/*    */ import org.reflections.util.FilterBuilder;
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\006\032\f\022\b\022\006\022\002\b\0030\0050\004¢\006\004\b\006\020\007¨\006\b"}, d2 = {"Lnet/integr/modules/management/ModuleLoader$Companion;", "", "<init>", "()V", "", "Ljava/lang/Class;", "load", "()Ljava/util/List;", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nModuleLoader.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ModuleLoader.kt\nnet/integr/modules/management/ModuleLoader$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,41:1\n1855#2,2:42\n*S KotlinDebug\n*F\n+ 1 ModuleLoader.kt\nnet/integr/modules/management/ModuleLoader$Companion\n*L\n34#1:42,2\n*E\n"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final List<Class<?>> load() {
/* 26 */     List<Class<?>> l = new ArrayList();
/*    */     
/* 28 */     Reflections reflections = new Reflections(
/* 29 */         (Configuration)(new ConfigurationBuilder())
/* 30 */         .forPackage("net.integr.modules.impl", new ClassLoader[0])
/* 31 */         .filterInputsBy((Predicate)(new FilterBuilder()).includePackage("net.integr.modules.impl")));
/*    */ 
/*    */     
/* 34 */     Intrinsics.checkNotNullExpressionValue(reflections.getSubTypesOf(Module.class), "getSubTypesOf(...)"); Iterable $this$forEach$iv = reflections.getSubTypesOf(Module.class); int $i$f$forEach = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 42 */     Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); Class<?> it = (Class)element$iv; int $i$a$-forEach-ModuleLoader$Companion$load$1 = 0;
/*    */       if (!Intrinsics.areEqual(it, UiModule.class))
/*    */         l.add(it);  }
/*    */     
/*    */     return l;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\ModuleLoader$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */