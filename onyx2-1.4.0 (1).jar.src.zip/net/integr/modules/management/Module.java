/*     */ package net.integr.modules.management;
/*     */ 
/*     */ import com.google.gson.JsonObject;
/*     */ import java.nio.file.Path;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.settings.SettingsBuilder;
/*     */ import net.integr.utilities.game.notification.NotificationHandler;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000^\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\020\002\n\002\b\b\n\002\020 \n\002\b\002\n\002\030\002\n\002\020!\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\026\n\002\030\002\n\002\b\020\b\026\030\0002\0020\001B1\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\006\020\007\032\0020\006\022\b\b\002\020\t\032\0020\b¢\006\004\b\n\020\013J\r\020\r\032\0020\f¢\006\004\b\r\020\016J\r\020\017\032\0020\f¢\006\004\b\017\020\016J\r\020\020\032\0020\b¢\006\004\b\020\020\021J\027\020\023\032\0020\0022\b\b\002\020\022\032\0020\b¢\006\004\b\023\020\024J\023\020\026\032\b\022\004\022\0020\0020\025¢\006\004\b\026\020\027J,\020\034\032\0020\f2\035\020\033\032\031\022\n\022\b\022\004\022\0020\0020\031\022\004\022\0020\f0\030¢\006\002\b\032¢\006\004\b\034\020\035J&\020\037\032\0020\f2\027\020\033\032\023\022\004\022\0020\036\022\004\022\0020\f0\030¢\006\002\b\032¢\006\004\b\037\020\035J\r\020 \032\0020\b¢\006\004\b \020\021J\017\020!\032\0020\fH\026¢\006\004\b!\020\016J\025\020!\032\0020\f2\006\020#\032\0020\"¢\006\004\b!\020$J\017\020%\032\0020\fH\026¢\006\004\b%\020\016J\017\020&\032\0020\fH\026¢\006\004\b&\020\016J\027\020)\032\0020\f2\006\020(\032\0020'H\026¢\006\004\b)\020*J\r\020+\032\0020\f¢\006\004\b+\020\016J\025\020-\032\0020\f2\006\020,\032\0020\b¢\006\004\b-\020.J\r\020/\032\0020\f¢\006\004\b/\020\016R\"\020\003\032\0020\0028\026@\026X\016¢\006\022\n\004\b\003\0200\032\004\b1\0202\"\004\b3\0204R\"\0205\032\0020\b8\006@\006X\016¢\006\022\n\004\b5\0206\032\004\b7\020\021\"\004\b8\020.R\"\020\007\032\0020\0068\026@\026X\016¢\006\022\n\004\b\007\0209\032\004\b:\020;\"\004\b<\020=R7\020A\032#\022\031\022\027\022\004\022\0020\0020\031¢\006\f\b>\022\b\b?\022\004\b\b(@\022\004\022\0020\f0\0308\002@\002X\016¢\006\006\n\004\bA\020BR\"\020\005\032\0020\0028\026@\026X\016¢\006\022\n\004\b\005\0200\032\004\bC\0202\"\004\bD\0204R\"\020\t\032\0020\b8\006@\006X\016¢\006\022\n\004\b\t\0206\032\004\b\t\020\021\"\004\bE\020.R\"\020F\032\0020\0368\006@\006X\016¢\006\022\n\004\bF\020G\032\004\bH\020I\"\004\bJ\020KR\"\020\004\032\0020\0028\026@\026X\016¢\006\022\n\004\b\004\0200\032\004\bL\0202\"\004\bM\0204¨\006N"}, d2 = {"Lnet/integr/modules/management/Module;", "", "", "displayName", "toolTip", "id", "Lnet/integr/modules/filters/Filter;", "filter", "", "isExecuted", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/integr/modules/filters/Filter;Z)V", "", "disable", "()V", "enable", "exists", "()Z", "left", "getHacklistData", "(Z)Ljava/lang/String;", "", "getSearchingTags", "()Ljava/util/List;", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "getter", "initHacklist", "(Lkotlin/jvm/functions/Function1;)V", "Lnet/integr/modules/management/settings/SettingsBuilder;", "initSettings", "isEnabled", "load", "Lcom/google/gson/JsonObject;", "jsonObj", "(Lcom/google/gson/JsonObject;)V", "onDisable", "onEnable", "Lnet/integr/event/KeyEvent;", "event", "onKeyEvent", "(Lnet/integr/event/KeyEvent;)V", "save", "en", "setState", "(Z)V", "toggle", "Ljava/lang/String;", "getDisplayName", "()Ljava/lang/String;", "setDisplayName", "(Ljava/lang/String;)V", "enabled", "Z", "getEnabled", "setEnabled", "Lnet/integr/modules/filters/Filter;", "getFilter", "()Lnet/integr/modules/filters/Filter;", "setFilter", "(Lnet/integr/modules/filters/Filter;)V", "Lkotlin/ParameterName;", "name", "it", "hackListDataGetter", "Lkotlin/jvm/functions/Function1;", "getId", "setId", "setExecuted", "settings", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "setSettings", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "getToolTip", "setToolTip", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Module.kt\nnet/integr/modules/management/Module\n+ 2 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,173:1\n429#2:174\n502#2,5:175\n429#2:180\n502#2,5:181\n429#2:186\n502#2,5:187\n429#2:192\n502#2,5:193\n*S KotlinDebug\n*F\n+ 1 Module.kt\nnet/integr/modules/management/Module\n*L\n156#1:174\n156#1:175,5\n158#1:180\n158#1:181,5\n158#1:186\n158#1:187,5\n158#1:192\n158#1:193,5\n*E\n"})
/*     */ public class Module {
/*     */   @NotNull
/*     */   private String displayName;
/*     */   @NotNull
/*     */   private String toolTip;
/*     */   @NotNull
/*     */   private String id;
/*     */   @NotNull
/*     */   private Filter filter;
/*     */   private boolean isExecuted;
/*     */   @Expose
/*     */   private boolean enabled;
/*     */   @Expose
/*     */   @NotNull
/*     */   private SettingsBuilder settings;
/*     */   @NotNull
/*     */   private Function1<? super List<String>, Unit> hackListDataGetter;
/*     */   
/*  37 */   public Module(@NotNull String displayName, @NotNull String toolTip, @NotNull String id, @NotNull Filter filter, boolean isExecuted) { this.displayName = displayName; this.toolTip = toolTip; this.id = id; this.filter = filter; this.isExecuted = isExecuted;
/*     */     
/*  39 */     this.settings = new SettingsBuilder(false, 1, null);
/*     */     
/*  41 */     this.hackListDataGetter = Module$hackListDataGetter$1.INSTANCE; } @NotNull public String getDisplayName() { return this.displayName; } public void setDisplayName(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.displayName = <set-?>; } @NotNull public String getToolTip() { return this.toolTip; } public void setToolTip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.toolTip = <set-?>; } @NotNull public String getId() { return this.id; } public void setId(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.id = <set-?>; } @NotNull public Filter getFilter() { return this.filter; } public void setFilter(@NotNull Filter <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.filter = <set-?>; } public final boolean isExecuted() { return this.isExecuted; } public final void setExecuted(boolean <set-?>) { this.isExecuted = <set-?>; } public final boolean getEnabled() { return this.enabled; } public final void setEnabled(boolean <set-?>) { this.enabled = <set-?>; } @NotNull public final SettingsBuilder getSettings() { return this.settings; } public final void setSettings(@NotNull SettingsBuilder <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.settings = <set-?>; } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\022\n\002\020!\n\002\020\016\n\000\n\002\020\002\n\002\b\003\020\006\032\0020\0032\f\020\002\032\b\022\004\022\0020\0010\000H\n¢\006\004\b\004\020\005"}, d2 = {"", "", "it", "", "invoke", "(Ljava/util/List;)V", "<anonymous>"}) static final class Module$hackListDataGetter$1 extends Lambda implements Function1<List<String>, Unit> { public final void invoke(@NotNull List it) { Intrinsics.checkNotNullParameter(it, "it"); }
/*     */     
/*     */     public static final Module$hackListDataGetter$1 INSTANCE = new Module$hackListDataGetter$1();
/*     */     Module$hackListDataGetter$1() {
/*     */       super(1);
/*     */     } }
/*     */   public void onEnable() {}
/*     */   
/*     */   public void onDisable() {}
/*     */   
/*     */   public final void initSettings(@NotNull Function1 getter) {
/*  52 */     Intrinsics.checkNotNullParameter(getter, "getter"); getter.invoke(this.settings);
/*     */   }
/*     */   
/*     */   public final void initHacklist(@NotNull Function1<? super List<String>, Unit> getter) {
/*  56 */     Intrinsics.checkNotNullParameter(getter, "getter"); this.hackListDataGetter = getter;
/*     */   }
/*     */   
/*     */   public final void enable() {
/*  60 */     onEnable();
/*  61 */     if (!this.isExecuted) {
/*  62 */       this.enabled = true;
/*  63 */       NotificationHandler.Companion.notify(getDisplayName() + " " + getDisplayName() + "on");
/*  64 */       EventSystem.Companion.register(this);
/*     */     } else {
/*  66 */       NotificationHandler.Companion.notify(getDisplayName() + " triggered");
/*  67 */       disable();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void setState(boolean en) {
/*  72 */     if (en) {
/*  73 */       onEnable();
/*  74 */       if (!this.isExecuted) {
/*  75 */         this.enabled = true;
/*  76 */         NotificationHandler.Companion.notify(getDisplayName() + " " + getDisplayName() + "on");
/*  77 */         EventSystem.Companion.register(this);
/*     */       } else {
/*  79 */         NotificationHandler.Companion.notify(getDisplayName() + " triggered");
/*  80 */         disable();
/*     */       } 
/*     */     } else {
/*  83 */       this.enabled = false;
/*  84 */       EventSystem.Companion.unRegister(this);
/*  85 */       onDisable();
/*  86 */       if (!this.isExecuted) NotificationHandler.Companion.notify(getDisplayName() + " " + getDisplayName() + "off"); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void disable() {
/*  91 */     this.enabled = false;
/*  92 */     onDisable();
/*  93 */     EventSystem.Companion.unRegister(this);
/*  94 */     if (!this.isExecuted) NotificationHandler.Companion.notify(getDisplayName() + " " + getDisplayName() + "off"); 
/*     */   }
/*     */   
/*     */   public final void toggle() {
/*  98 */     this.enabled = !this.enabled;
/*     */     
/* 100 */     if (this.enabled) {
/* 101 */       onEnable();
/* 102 */       if (!this.isExecuted) {
/* 103 */         NotificationHandler.Companion.notify(getDisplayName() + " " + getDisplayName() + "on");
/* 104 */         EventSystem.Companion.register(this);
/*     */       } else {
/* 106 */         NotificationHandler.Companion.notify(getDisplayName() + " triggered");
/* 107 */         disable();
/*     */       } 
/*     */     } else {
/* 110 */       EventSystem.Companion.unRegister(this);
/* 111 */       onDisable();
/* 112 */       if (!this.isExecuted) NotificationHandler.Companion.notify(getDisplayName() + " " + getDisplayName() + "off"); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final boolean isEnabled() {
/* 117 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onKeyEvent(@NotNull KeyEvent event) {
/* 122 */     Intrinsics.checkNotNullParameter(event, "event");
/*     */   }
/*     */   public final void save() {
/* 125 */     String json = (new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().toJson(this);
/*     */     
/*     */     try {
/* 128 */       Files.createDirectories(Path.of(Onyx.Companion.getCONFIG().toString(), new String[0]), (FileAttribute<?>[])new FileAttribute[0]);
/* 129 */       Intrinsics.checkNotNull(json); String str = json; Intrinsics.checkNotNullExpressionValue(str.getBytes(Charsets.UTF_8), "getBytes(...)"); Files.write(Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0]), str.getBytes(Charsets.UTF_8), new java.nio.file.OpenOption[0]);
/* 130 */     } catch (IOException e) {
/* 131 */       LogUtils.Companion.sendLog("Could not save config [" + getId() + "]!");
/* 132 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final boolean exists() {
/* 137 */     Intrinsics.checkNotNullExpressionValue(Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0]), "of(...)"); Path path = Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0]); LinkOption[] arrayOfLinkOption = new LinkOption[0]; return Files.exists(path, Arrays.<LinkOption>copyOf(arrayOfLinkOption, arrayOfLinkOption.length));
/*     */   }
/*     */   
/*     */   public void load() {
/* 141 */     Intrinsics.checkNotNullExpressionValue(Files.readAllLines(Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0])), "readAllLines(...)"); String json = CollectionsKt.joinToString$default(Files.readAllLines(Path.of("" + Onyx.Companion.getCONFIG() + "/" + Onyx.Companion.getCONFIG() + ".json", new String[0])), "", null, null, 0, null, null, 62, null);
/* 142 */     JsonObject jsonObj = (JsonObject)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson(json, JsonObject.class);
/*     */     
/* 144 */     this.enabled = jsonObj.get("enabled").getAsBoolean();
/* 145 */     Intrinsics.checkNotNull(jsonObj); this.settings = this.settings.load(jsonObj);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void load(@NotNull JsonObject jsonObj) {
/* 150 */     Intrinsics.checkNotNullParameter(jsonObj, "jsonObj"); this.enabled = jsonObj.get("enabled").getAsBoolean();
/* 151 */     this.settings = this.settings.load(jsonObj);
/*     */   }
/*     */   @NotNull
/*     */   public final List<String> getSearchingTags() {
/* 155 */     List<String> fList = new ArrayList();
/* 156 */     List<String> list1 = fList; Intrinsics.checkNotNullExpressionValue(getFilter().name().toLowerCase(Locale.ROOT), "toLowerCase(...)"); String str1 = getFilter().name().toLowerCase(Locale.ROOT); int $i$f$filter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     String str2 = str1; Appendable destination$iv$iv = new StringBuilder(); int $i$f$filterTo = 0; int index$iv$iv, i;
/* 175 */     for (index$iv$iv = 0, i = str2.length(); index$iv$iv < i; index$iv$iv++) {
/* 176 */       char element$iv$iv = str2.charAt(index$iv$iv);
/* 177 */       char it = element$iv$iv; int $i$a$-filter-Module$getSearchingTags$1 = 0; if ((it != ' ')) destination$iv$iv.append(element$iv$iv); 
/*     */     } 
/* 179 */     Intrinsics.checkNotNullExpressionValue(((StringBuilder)destination$iv$iv).toString(), "toString(...)"); String $this$filter$iv = ((StringBuilder)destination$iv$iv).toString(); list1.add($this$filter$iv); String[] arrayOfString1 = new String[4]; Intrinsics.checkNotNullExpressionValue(getDisplayName().toLowerCase(Locale.ROOT), "toLowerCase(...)"); $this$filter$iv = getDisplayName().toLowerCase(Locale.ROOT); byte b = 0; String[] arrayOfString2 = arrayOfString1; $i$f$filter = 0;
/* 180 */     CharSequence $this$filterTo$iv$iv = $this$filter$iv; destination$iv$iv = new StringBuilder(); $i$f$filterTo = 0;
/* 181 */     for (index$iv$iv = 0, i = $this$filterTo$iv$iv.length(); index$iv$iv < i; index$iv$iv++) {
/* 182 */       char element$iv$iv = $this$filterTo$iv$iv.charAt(index$iv$iv);
/* 183 */       char it = element$iv$iv; int $i$a$-filter-Module$getSearchingTags$2 = 0; if ((it != ' ')) destination$iv$iv.append(element$iv$iv); 
/*     */     } 
/* 185 */     Intrinsics.checkNotNullExpressionValue(((StringBuilder)destination$iv$iv).toString(), "toString(...)"); String str3 = ((StringBuilder)destination$iv$iv).toString(); arrayOfString2[b] = str3; Intrinsics.checkNotNullExpressionValue(getToolTip().toLowerCase(Locale.ROOT), "toLowerCase(...)"); $this$filter$iv = getToolTip().toLowerCase(Locale.ROOT); b = 1; arrayOfString2 = arrayOfString1; $i$f$filter = 0;
/* 186 */     $this$filterTo$iv$iv = $this$filter$iv; destination$iv$iv = new StringBuilder(); $i$f$filterTo = 0;
/* 187 */     for (index$iv$iv = 0, i = $this$filterTo$iv$iv.length(); index$iv$iv < i; index$iv$iv++) {
/* 188 */       char element$iv$iv = $this$filterTo$iv$iv.charAt(index$iv$iv);
/* 189 */       char it = element$iv$iv; int $i$a$-filter-Module$getSearchingTags$3 = 0; if ((it != ' ')) destination$iv$iv.append(element$iv$iv); 
/*     */     } 
/* 191 */     Intrinsics.checkNotNullExpressionValue(((StringBuilder)destination$iv$iv).toString(), "toString(...)"); str3 = ((StringBuilder)destination$iv$iv).toString(); arrayOfString2[b] = str3; Intrinsics.checkNotNullExpressionValue(getId().toLowerCase(Locale.ROOT), "toLowerCase(...)"); $this$filter$iv = getId().toLowerCase(Locale.ROOT); b = 2; arrayOfString2 = arrayOfString1; $i$f$filter = 0;
/* 192 */     $this$filterTo$iv$iv = $this$filter$iv; destination$iv$iv = new StringBuilder(); $i$f$filterTo = 0;
/* 193 */     for (index$iv$iv = 0, i = $this$filterTo$iv$iv.length(); index$iv$iv < i; index$iv$iv++) {
/* 194 */       char element$iv$iv = $this$filterTo$iv$iv.charAt(index$iv$iv);
/* 195 */       char it = element$iv$iv; int $i$a$-filter-Module$getSearchingTags$4 = 0; if ((it != ' ')) destination$iv$iv.append(element$iv$iv); 
/*     */     } 
/* 197 */     Intrinsics.checkNotNullExpressionValue(((StringBuilder)destination$iv$iv).toString(), "toString(...)"); str3 = ((StringBuilder)destination$iv$iv).toString();
/*     */     arrayOfString2[b] = str3;
/*     */     arrayOfString1[3] = CollectionsKt.joinToString$default(fList, "", null, null, 0, null, null, 62, null);
/*     */     return CollectionsKt.listOf((Object[])arrayOfString1);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final String getHacklistData(boolean left) {
/*     */     List data = new ArrayList();
/*     */     this.hackListDataGetter.invoke(data);
/*     */     return data.isEmpty() ? "" : (left ? (CollectionsKt.joinToString$default(data, " ", null, null, 0, null, null, 62, null) + " ") : (" " + CollectionsKt.joinToString$default(data, " ", null, null, 0, null, null, 62, null)));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\Module.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */