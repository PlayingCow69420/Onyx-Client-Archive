/*    */ package net.integr.modules.management.settings;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.jvm.internal.SourceDebugExtension;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020!\n\002\b\005\030\0002\0020\001B\021\022\b\b\002\020\003\032\0020\002¢\006\004\b\004\020\005J\025\020\b\032\0020\0002\006\020\007\032\0020\006¢\006\004\b\b\020\tJ!\020\r\032\004\030\0018\000\"\b\b\000\020\n*\0020\0062\006\020\f\032\0020\013¢\006\004\b\r\020\016J\025\020\021\032\0020\0002\006\020\020\032\0020\017¢\006\004\b\021\020\022R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\023R \020\025\032\b\022\004\022\0020\0060\0248\006X\004¢\006\f\n\004\b\025\020\026\032\004\b\027\020\030¨\006\031"}, d2 = {"Lnet/integr/modules/management/settings/SettingsBuilder;", "", "", "hasBind", "<init>", "(Z)V", "Lnet/integr/modules/management/settings/Setting;", "setting", "add", "(Lnet/integr/modules/management/settings/Setting;)Lnet/integr/modules/management/settings/SettingsBuilder;", "T", "", "id", "getById", "(Ljava/lang/String;)Lnet/integr/modules/management/settings/Setting;", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/SettingsBuilder;", "Z", "", "options", "Ljava/util/List;", "getOptions", "()Ljava/util/List;", "onyx2"})
/*    */ @SourceDebugExtension({"SMAP\nSettingsBuilder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsBuilder.kt\nnet/integr/modules/management/settings/SettingsBuilder\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,51:1\n1855#2,2:52\n*S KotlinDebug\n*F\n+ 1 SettingsBuilder.kt\nnet/integr/modules/management/settings/SettingsBuilder\n*L\n32#1:52,2\n*E\n"})
/*    */ public final class SettingsBuilder {
/*    */   private final boolean hasBind;
/*    */   @Expose
/*    */   @NotNull
/*    */   private final List<Setting> options;
/*    */   
/* 23 */   public SettingsBuilder(boolean hasBind) { this.hasBind = hasBind;
/* 24 */     Setting[] arrayOfSetting = new Setting[1]; arrayOfSetting[0] = (Setting)new KeyBindSetting("Keybind: ", "The Key to toggle this Module", "bind"); this.options = this.hasBind ? CollectionsKt.mutableListOf((Object[])arrayOfSetting) : new ArrayList<>(); } @NotNull public final List<Setting> getOptions() { return this.options; }
/*    */    @NotNull
/*    */   public final SettingsBuilder add(@NotNull Setting setting) {
/* 27 */     Intrinsics.checkNotNullParameter(setting, "setting"); if (this.hasBind) { this.options.add(this.options.size() - 1, setting); } else { this.options.add(setting); }
/* 28 */      return this;
/*    */   }
/*    */   @NotNull
/*    */   public final SettingsBuilder load(@NotNull JsonObject obj) {
/* 32 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNullExpressionValue(obj.get("settings").getAsJsonObject().get("options").getAsJsonArray(), "getAsJsonArray(...)"); Iterable $this$forEach$iv = (Iterable)obj.get("settings").getAsJsonObject().get("options").getAsJsonArray(); int $i$f$forEach = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     Iterator iterator = $this$forEach$iv.iterator(); if (iterator.hasNext()) { Object element$iv = iterator.next(); JsonElement it = (JsonElement)element$iv; int $i$a$-forEach-SettingsBuilder$load$1 = 0;
/*    */       Iterator<Setting> iterator1 = this.options.iterator(); }
/*    */     
/*    */     return this;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public final <T extends Setting> T getById(@NotNull String id) {
/*    */     Intrinsics.checkNotNullParameter(id, "id");
/*    */     for (Setting s : this.options) {
/*    */       if (Intrinsics.areEqual(s.getId(), id)) {
/*    */         Intrinsics.checkNotNull(s, "null cannot be cast to non-null type T of net.integr.modules.management.settings.SettingsBuilder.getById");
/*    */         return (T)s;
/*    */       } 
/*    */     } 
/*    */     return null;
/*    */   }
/*    */   
/*    */   public SettingsBuilder() {
/*    */     this(false, 1, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\SettingsBuilder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */