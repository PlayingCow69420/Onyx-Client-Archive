/*    */ package net.integr.modules.management.settings;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\006\b\026\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\021\020\007\032\004\030\0010\006H\026¢\006\004\b\007\020\bJ\031\020\013\032\004\030\0010\0002\006\020\n\032\0020\tH\026¢\006\004\b\013\020\fJ\027\020\017\032\0020\0162\006\020\r\032\0020\006H\026¢\006\004\b\017\020\020R\032\020\003\032\0020\0028\006X\004¢\006\f\n\004\b\003\020\021\032\004\b\022\020\023¨\006\024"}, d2 = {"Lnet/integr/modules/management/settings/Setting;", "", "", "id", "<init>", "(Ljava/lang/String;)V", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "el", "", "onUpdate", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "Ljava/lang/String;", "getId", "()Ljava/lang/String;", "onyx2"})
/*    */ public class Setting
/*    */ {
/*    */   @Expose
/*    */   @NotNull
/*    */   private final String id;
/*    */   
/*    */   public Setting(@NotNull String id) {
/* 23 */     this.id = id; } @NotNull public final String getId() { return this.id; } @Nullable
/*    */   public HelixUiElement getUiElement() {
/* 25 */     return null;
/*    */   }
/*    */   @Nullable
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 29 */     Intrinsics.checkNotNullParameter(obj, "obj"); return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate(@NotNull HelixUiElement el) {
/* 34 */     Intrinsics.checkNotNullParameter(el, "el");
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\Setting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */