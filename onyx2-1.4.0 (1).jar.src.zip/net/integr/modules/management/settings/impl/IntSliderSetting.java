/*    */ package net.integr.modules.management.settings.impl;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.rendering.uisystem.IntSlider;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\020\b\n\002\b\007\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\004\n\002\020\006\n\002\b\007\030\0002\0020\001B9\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\006\020\007\032\0020\006\022\006\020\b\032\0020\006\022\b\b\002\020\t\032\0020\006¢\006\004\b\n\020\013J\r\020\f\032\0020\006¢\006\004\b\f\020\rJ\017\020\017\032\0020\016H\026¢\006\004\b\017\020\020J\027\020\023\032\0020\0012\006\020\022\032\0020\021H\026¢\006\004\b\023\020\024J\027\020\027\032\0020\0262\006\020\025\032\0020\016H\026¢\006\004\b\027\020\030R\024\020\t\032\0020\0068\002X\004¢\006\006\n\004\b\t\020\031R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\032R\026\020\b\032\0020\0068\002@\002X\016¢\006\006\n\004\b\b\020\031R\026\020\007\032\0020\0068\002@\002X\016¢\006\006\n\004\b\007\020\031R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020\032R\"\020\034\032\0020\0338\006@\006X\016¢\006\022\n\004\b\034\020\035\032\004\b\036\020\037\"\004\b \020!¨\006\""}, d2 = {"Lnet/integr/modules/management/settings/impl/IntSliderSetting;", "Lnet/integr/modules/management/settings/Setting;", "", "displayName", "tooltip", "id", "", "min", "max", "default", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V", "getSetValue", "()I", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "el", "", "onUpdate", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "I", "Ljava/lang/String;", "", "value", "D", "getValue", "()D", "setValue", "(D)V", "onyx2"})
/*    */ public final class IntSliderSetting extends Setting {
/*    */   @NotNull
/*    */   private final String displayName;
/*    */   @NotNull
/*    */   private final String tooltip;
/*    */   private int min;
/*    */   private int max;
/*    */   private final int default;
/*    */   @Expose
/*    */   private double value;
/*    */   
/*    */   public IntSliderSetting(@NotNull String displayName, @NotNull String tooltip, @NotNull String id, int min, int max, int default) {
/* 28 */     super(id); this.displayName = displayName; this.tooltip = tooltip; this.min = min; this.max = max; this.default = default;
/* 29 */     this.value = this.default; } public final double getValue() { return this.value; } public final void setValue(double <set-?>) { this.value = <set-?>; }
/*    */    @NotNull
/*    */   public HelixUiElement getUiElement() {
/* 32 */     IntSlider uie = new IntSlider(0, 0, 200, 20, this.displayName, true, this.tooltip, this.min, this.max);
/* 33 */     uie.setFillX(uie.xFillFromValue(this.value));
/* 34 */     uie.setText2(uie.getText() + uie.getText());
/* 35 */     return (HelixUiElement)uie;
/*    */   }
/*    */   @NotNull
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 39 */     Intrinsics.checkNotNullParameter(obj, "obj"); this.value = ((IntSliderSetting)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson((JsonElement)obj, IntSliderSetting.class)).value;
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public void onUpdate(@NotNull HelixUiElement el) {
/* 44 */     Intrinsics.checkNotNullParameter(el, "el"); this.value = ((IntSlider)el).valueFromFillX();
/*    */   }
/*    */   
/*    */   public final int getSetValue() {
/* 48 */     return (int)this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\impl\IntSliderSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */