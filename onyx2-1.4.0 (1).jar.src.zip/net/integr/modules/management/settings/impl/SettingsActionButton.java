/*    */ package net.integr.modules.management.settings.impl;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.rendering.uisystem.Button;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\030\002\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\030\0002\0020\001B-\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\f\020\b\032\b\022\004\022\0020\0070\006¢\006\004\b\t\020\nJ\017\020\f\032\0020\013H\026¢\006\004\b\f\020\rJ\027\020\020\032\0020\0012\006\020\017\032\0020\016H\026¢\006\004\b\020\020\021R\034\020\b\032\b\022\004\022\0020\0070\0068\002@\002X\016¢\006\006\n\004\b\b\020\022R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\023R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020\023¨\006\024"}, d2 = {"Lnet/integr/modules/management/settings/impl/SettingsActionButton;", "Lnet/integr/modules/management/settings/Setting;", "", "displayName", "tooltip", "id", "Lkotlin/Function0;", "", "action", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "Lkotlin/jvm/functions/Function0;", "Ljava/lang/String;", "onyx2"})
/*    */ public final class SettingsActionButton
/*    */   extends Setting {
/*    */   @NotNull
/*    */   private final String displayName;
/*    */   @NotNull
/*    */   private final String tooltip;
/*    */   @NotNull
/*    */   private Function0<Unit> action;
/*    */   
/*    */   public SettingsActionButton(@NotNull String displayName, @NotNull String tooltip, @NotNull String id, @NotNull Function0<Unit> action) {
/* 24 */     super(id); this.displayName = displayName; this.tooltip = tooltip; this.action = action; }
/*    */   @NotNull
/* 26 */   public HelixUiElement getUiElement() { Button uie = new Button(0, 0, 200, 20, this.displayName, true, this.tooltip, false, this.action::getUiElement$lambda$0);
/* 27 */     return (HelixUiElement)uie; }
/*    */   
/*    */   @NotNull
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 31 */     Intrinsics.checkNotNullParameter(obj, "obj"); return this;
/*    */   }
/*    */   
/*    */   private static final void getUiElement$lambda$0(Function0 $tmp0) {
/*    */     Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
/*    */     $tmp0.invoke();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\impl\SettingsActionButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */