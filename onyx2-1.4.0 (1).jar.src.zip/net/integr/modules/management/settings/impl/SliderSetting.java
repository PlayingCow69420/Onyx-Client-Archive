/*    */ package net.integr.modules.management.settings.impl;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.rendering.uisystem.Slider;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import net.integr.utilities.ExtensionsKt;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\020\006\n\002\b\007\n\002\020\007\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\t\030\0002\0020\001B9\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\006\020\007\032\0020\006\022\006\020\b\032\0020\006\022\b\b\002\020\t\032\0020\006¢\006\004\b\n\020\013J\r\020\f\032\0020\006¢\006\004\b\f\020\rJ\r\020\017\032\0020\016¢\006\004\b\017\020\020J\017\020\022\032\0020\021H\026¢\006\004\b\022\020\023J\027\020\026\032\0020\0012\006\020\025\032\0020\024H\026¢\006\004\b\026\020\027J\027\020\032\032\0020\0312\006\020\030\032\0020\021H\026¢\006\004\b\032\020\033R\024\020\t\032\0020\0068\002X\004¢\006\006\n\004\b\t\020\034R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\035R\026\020\b\032\0020\0068\002@\002X\016¢\006\006\n\004\b\b\020\034R\026\020\007\032\0020\0068\002@\002X\016¢\006\006\n\004\b\007\020\034R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020\035R\"\020\036\032\0020\0068\006@\006X\016¢\006\022\n\004\b\036\020\034\032\004\b\037\020\r\"\004\b \020!¨\006\""}, d2 = {"Lnet/integr/modules/management/settings/impl/SliderSetting;", "Lnet/integr/modules/management/settings/Setting;", "", "displayName", "tooltip", "id", "", "min", "max", "default", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDD)V", "getSetValue", "()D", "", "getSetValueAsFloat", "()F", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "el", "", "onUpdate", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "D", "Ljava/lang/String;", "value", "getValue", "setValue", "(D)V", "onyx2"})
/*    */ public final class SliderSetting extends Setting {
/*    */   @NotNull
/*    */   private final String displayName;
/*    */   @NotNull
/*    */   private final String tooltip;
/*    */   private double min;
/*    */   private double max;
/*    */   private final double default;
/*    */   @Expose
/*    */   private double value;
/*    */   
/* 27 */   public SliderSetting(@NotNull String displayName, @NotNull String tooltip, @NotNull String id, double min, double max, double default) { super(id); this.displayName = displayName; this.tooltip = tooltip; this.min = min; this.max = max; this.default = default;
/* 28 */     this.value = this.default; } public final double getValue() { return this.value; } public final void setValue(double <set-?>) { this.value = <set-?>; }
/*    */    @NotNull
/*    */   public HelixUiElement getUiElement() {
/* 31 */     Slider uie = new Slider(0, 0, 200, 20, this.displayName, true, this.tooltip, this.min, this.max);
/* 32 */     uie.setFillX(uie.xFillFromValue(this.value));
/* 33 */     uie.setText2(uie.getText() + uie.getText());
/* 34 */     return (HelixUiElement)uie;
/*    */   }
/*    */   @NotNull
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 38 */     Intrinsics.checkNotNullParameter(obj, "obj"); this.value = ((SliderSetting)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson((JsonElement)obj, SliderSetting.class)).value;
/* 39 */     return this;
/*    */   }
/*    */   
/*    */   public void onUpdate(@NotNull HelixUiElement el) {
/* 43 */     Intrinsics.checkNotNullParameter(el, "el"); this.value = ((Slider)el).valueFromFillX();
/*    */   }
/*    */   
/*    */   public final double getSetValue() {
/* 47 */     return ExtensionsKt.round(this.value, 1);
/*    */   }
/*    */   
/*    */   public final float getSetValueAsFloat() {
/* 51 */     return (float)ExtensionsKt.round(this.value, 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\impl\SliderSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */