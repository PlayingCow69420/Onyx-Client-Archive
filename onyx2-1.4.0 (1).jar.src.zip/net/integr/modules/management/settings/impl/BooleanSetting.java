/*    */ package net.integr.modules.management.settings.impl;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.rendering.uisystem.ToggleButton;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\t\030\0002\0020\001B)\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\b\b\002\020\007\032\0020\006¢\006\004\b\b\020\tJ\017\020\013\032\0020\nH\026¢\006\004\b\013\020\fJ\r\020\r\032\0020\006¢\006\004\b\r\020\016J\027\020\021\032\0020\0012\006\020\020\032\0020\017H\026¢\006\004\b\021\020\022J\027\020\025\032\0020\0242\006\020\023\032\0020\nH\026¢\006\004\b\025\020\026R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\027R\"\020\030\032\0020\0068\006@\006X\016¢\006\022\n\004\b\030\020\031\032\004\b\032\020\016\"\004\b\033\020\034R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020\027¨\006\035"}, d2 = {"Lnet/integr/modules/management/settings/impl/BooleanSetting;", "Lnet/integr/modules/management/settings/Setting;", "", "displayName", "tooltip", "id", "", "default", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "isEnabled", "()Z", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "el", "", "onUpdate", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "Ljava/lang/String;", "enabled", "Z", "getEnabled", "setEnabled", "(Z)V", "onyx2"})
/*    */ public final class BooleanSetting
/*    */   extends Setting {
/*    */   @NotNull
/*    */   private final String displayName;
/*    */   @NotNull
/*    */   private final String tooltip;
/*    */   @Expose
/*    */   private boolean enabled;
/*    */   
/*    */   public BooleanSetting(@NotNull String displayName, @NotNull String tooltip, @NotNull String id, boolean default) {
/* 26 */     super(id); this.displayName = displayName; this.tooltip = tooltip;
/* 27 */     this.enabled = default; } public final boolean getEnabled() { return this.enabled; } public final void setEnabled(boolean <set-?>) { this.enabled = <set-?>; }
/*    */    @NotNull
/*    */   public HelixUiElement getUiElement() {
/* 30 */     ToggleButton uie = new ToggleButton(0, 0, 200, 20, this.displayName, true, this.tooltip, false, null, 384, null);
/* 31 */     uie.setEnabled(this.enabled);
/* 32 */     return (HelixUiElement)uie;
/*    */   }
/*    */   @NotNull
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 36 */     Intrinsics.checkNotNullParameter(obj, "obj"); this.enabled = ((BooleanSetting)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson((JsonElement)obj, BooleanSetting.class)).enabled;
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public void onUpdate(@NotNull HelixUiElement el) {
/* 41 */     Intrinsics.checkNotNullParameter(el, "el"); this.enabled = ((ToggleButton)el).getEnabled();
/*    */   }
/*    */   
/*    */   public final boolean isEnabled() {
/* 45 */     return this.enabled;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\impl\BooleanSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */