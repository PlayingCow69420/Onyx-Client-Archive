/*    */ package net.integr.modules.management.settings.impl;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import java.util.Locale;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.rendering.uisystem.KeyBind;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.lwjgl.glfw.GLFW;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\007\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\t\030\0002\0020\001B\037\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002¢\006\004\b\006\020\007J\017\020\b\032\004\030\0010\002¢\006\004\b\b\020\tJ\017\020\013\032\004\030\0010\n¢\006\004\b\013\020\fJ\017\020\016\032\0020\rH\026¢\006\004\b\016\020\017J\r\020\021\032\0020\020¢\006\004\b\021\020\022J\027\020\025\032\0020\0012\006\020\024\032\0020\023H\026¢\006\004\b\025\020\026J\027\020\031\032\0020\0302\006\020\027\032\0020\rH\026¢\006\004\b\031\020\032R$\020\033\032\004\030\0010\n8\006@\006X\016¢\006\022\n\004\b\033\020\034\032\004\b\035\020\f\"\004\b\036\020\037R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020 R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020 ¨\006!"}, d2 = {"Lnet/integr/modules/management/settings/impl/KeyBindSetting;", "Lnet/integr/modules/management/settings/Setting;", "", "displayName", "tooltip", "id", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getKeyChar", "()Ljava/lang/String;", "", "getSetBind", "()Ljava/lang/Integer;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "isBound", "()Z", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "el", "", "onUpdate", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "bind", "Ljava/lang/Integer;", "getBind", "setBind", "(Ljava/lang/Integer;)V", "Ljava/lang/String;", "onyx2"})
/*    */ public final class KeyBindSetting extends Setting {
/*    */   @NotNull
/*    */   private final String displayName;
/*    */   @NotNull
/*    */   private final String tooltip;
/*    */   @Expose
/*    */   @Nullable
/*    */   private Integer bind;
/*    */   
/* 27 */   public KeyBindSetting(@NotNull String displayName, @NotNull String tooltip, @NotNull String id) { super(id); this.displayName = displayName; this.tooltip = tooltip; }
/*    */   @Nullable
/* 29 */   public final Integer getBind() { return this.bind; } public final void setBind(@Nullable Integer <set-?>) { this.bind = <set-?>; }
/*    */    @NotNull
/*    */   public HelixUiElement getUiElement() {
/* 32 */     KeyBind uie = new KeyBind(0, 0, 200, 20, this.displayName, true, this.tooltip);
/* 33 */     uie.setBind(this.bind);
/* 34 */     Intrinsics.checkNotNull(uie.getBind()); Intrinsics.checkNotNull(GLFW.glfwGetKeyName(uie.getBind().intValue(), 0)); Intrinsics.checkNotNullExpressionValue(GLFW.glfwGetKeyName(uie.getBind().intValue(), 0).toUpperCase(Locale.ROOT), "toUpperCase(...)"); uie.setBindText((uie.getBind() != null) ? GLFW.glfwGetKeyName(uie.getBind().intValue(), 0).toUpperCase(Locale.ROOT) : "None");
/* 35 */     return (HelixUiElement)uie;
/*    */   }
/*    */   @NotNull
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 39 */     Intrinsics.checkNotNullParameter(obj, "obj"); this.bind = ((KeyBindSetting)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson((JsonElement)obj, KeyBindSetting.class)).bind;
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public void onUpdate(@NotNull HelixUiElement el) {
/* 44 */     Intrinsics.checkNotNullParameter(el, "el"); this.bind = ((KeyBind)el).getBind();
/*    */   }
/*    */   @Nullable
/*    */   public final Integer getSetBind() {
/* 48 */     return this.bind;
/*    */   }
/*    */   
/* 51 */   public final boolean isBound() { return (this.bind != null); } @Nullable
/*    */   public final String getKeyChar() {
/* 53 */     Intrinsics.checkNotNull(this.bind); return GLFW.glfwGetKeyName(this.bind.intValue(), 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\impl\KeyBindSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */