/*    */ package net.integr.modules.management.settings.impl;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.rendering.uisystem.Cycler;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\020!\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\002\n\002\b\004\n\002\020\b\n\002\b\b\030\0002\0020\001B-\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002\022\006\020\005\032\0020\002\022\f\020\007\032\b\022\004\022\0020\0020\006¢\006\004\b\b\020\tJ\r\020\n\032\0020\002¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\026¢\006\004\b\r\020\016J\027\020\021\032\0020\0012\006\020\020\032\0020\017H\026¢\006\004\b\021\020\022J\027\020\025\032\0020\0242\006\020\023\032\0020\fH\026¢\006\004\b\025\020\026R\026\020\027\032\0020\0028\002@\002X\016¢\006\006\n\004\b\027\020\030R\"\020\032\032\0020\0318\006@\006X\016¢\006\022\n\004\b\032\020\033\032\004\b\034\020\035\"\004\b\036\020\037R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\003\020\030R\034\020\007\032\b\022\004\022\0020\0020\0068\002@\002X\016¢\006\006\n\004\b\007\020 R\024\020\004\032\0020\0028\002X\004¢\006\006\n\004\b\004\020\030¨\006!"}, d2 = {"Lnet/integr/modules/management/settings/impl/CyclerSetting;", "Lnet/integr/modules/management/settings/Setting;", "", "displayName", "tooltip", "id", "", "items", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "getElement", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getUiElement", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "Lcom/google/gson/JsonObject;", "obj", "load", "(Lcom/google/gson/JsonObject;)Lnet/integr/modules/management/settings/Setting;", "el", "", "onUpdate", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "current", "Ljava/lang/String;", "", "currentIndex", "I", "getCurrentIndex", "()I", "setCurrentIndex", "(I)V", "Ljava/util/List;", "onyx2"})
/*    */ public final class CyclerSetting extends Setting {
/*    */   @NotNull
/*    */   private final String displayName;
/*    */   @NotNull
/*    */   private final String tooltip;
/*    */   @NotNull
/*    */   private List<String> items;
/*    */   @Expose
/*    */   private int currentIndex;
/*    */   @NotNull
/*    */   private String current;
/*    */   
/* 26 */   public CyclerSetting(@NotNull String displayName, @NotNull String tooltip, @NotNull String id, @NotNull List<String> items) { super(id); this.displayName = displayName; this.tooltip = tooltip; this.items = items;
/*    */     
/* 28 */     this.current = ""; }
/*    */   public final int getCurrentIndex() { return this.currentIndex; }
/*    */   @NotNull
/* 31 */   public HelixUiElement getUiElement() { Cycler uie = new Cycler(0, 0, 200, 20, this.displayName, true, this.tooltip, this.items);
/* 32 */     uie.setCurrentIndex(this.currentIndex);
/* 33 */     uie.setText2(uie.getText() + uie.getText());
/* 34 */     return (HelixUiElement)uie; } public final void setCurrentIndex(int <set-?>) {
/*    */     this.currentIndex = <set-?>;
/*    */   } @NotNull
/*    */   public Setting load(@NotNull JsonObject obj) {
/* 38 */     Intrinsics.checkNotNullParameter(obj, "obj"); this.currentIndex = ((CyclerSetting)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson((JsonElement)obj, CyclerSetting.class)).currentIndex;
/* 39 */     this.current = this.items.get(this.currentIndex);
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public void onUpdate(@NotNull HelixUiElement el) {
/* 44 */     Intrinsics.checkNotNullParameter(el, "el"); this.currentIndex = ((Cycler)el).getCurrentIndex();
/* 45 */     this.current = ((Cycler)el).getItems().get(this.currentIndex);
/*    */   }
/*    */   @NotNull
/*    */   public final String getElement() {
/* 49 */     return this.current;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\modules\management\settings\impl\CyclerSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */