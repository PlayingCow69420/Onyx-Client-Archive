/*     */ package net.integr.mixin;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import net.integr.event.UiRenderEvent;
/*     */ import net.integr.eventsystem.Event;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.integr.modules.impl.HotbarModule;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.ModuleManager;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_327;
/*     */ import net.minecraft.class_329;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_5250;
/*     */ import net.minecraft.class_5253;
/*     */ import net.minecraft.class_5348;
/*     */ import net.minecraft.class_9334;
/*     */ import net.minecraft.class_9779;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ @Mixin({class_329.class})
/*     */ public abstract class InGameHudMixin
/*     */ {
/*     */   @Shadow
/*     */   @Nullable
/*     */   private class_2561 field_2018;
/*     */   @Unique
/*     */   class_2561 uniqueOverlayMessage;
/*     */   @Shadow
/*     */   private int field_2041;
/*     */   @Unique
/*     */   int uniqueOverlayRemaining;
/*     */   @Shadow
/*     */   @Final
/*     */   private class_310 field_2035;
/*     */   @Shadow
/*     */   private boolean field_2038;
/*     */   @Unique
/*     */   boolean uniqueOverlayTinted;
/*     */   @Shadow
/*     */   private int field_2040;
/*     */   @Shadow
/*     */   private class_1799 field_2031;
/*     */   
/*     */   @Shadow
/*     */   public abstract class_327 method_1756();
/*     */   
/*     */   @Inject(method = {"render"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
/*  64 */     UiRenderEvent e = new UiRenderEvent(context, tickCounter.method_60637(true));
/*  65 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  67 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderOverlayMessage"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onRenderOverlayMessage(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
/*  72 */     if (((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).isEnabled() && ((BooleanSetting)Objects.requireNonNull(((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).getSettings().getById("locked"))).isEnabled()) {
/*  73 */       ci.cancel();
/*     */       
/*  75 */       class_327 textRenderer = method_1756();
/*  76 */       if (this.field_2018 != null && this.field_2041 > 0) {
/*  77 */         this.field_2035.method_16011().method_15396("overlayMessage");
/*  78 */         float f = this.field_2041 - tickCounter.method_60637(false);
/*  79 */         int i = (int)(f * 255.0F / 20.0F);
/*  80 */         if (i > 255) {
/*  81 */           i = 255;
/*     */         }
/*     */         
/*  84 */         if (i > 8) {
/*  85 */           int j; context.method_51448().method_22903();
/*  86 */           context.method_51448().method_46416((context.method_51421() / 2), (context.method_51443() - 68), 0.0F);
/*     */           
/*  88 */           if (this.field_2038) {
/*  89 */             j = class_3532.method_60599(f / 50.0F, 0.7F, 0.6F, i);
/*     */           } else {
/*  91 */             j = class_5253.class_5254.method_58144(i, -1);
/*     */           } 
/*     */           
/*  94 */           int k = textRenderer.method_27525((class_5348)this.field_2018);
/*  95 */           context.method_60649(textRenderer, this.field_2018, -k / 2, -54, k, j);
/*  96 */           context.method_51448().method_22909();
/*     */         } 
/*     */         
/*  99 */         this.field_2035.method_16011().method_15407();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderHealthBar"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void renderHealthBar(class_332 context, class_1657 player, int x, int y, int lines, int regeneratingHeartIndex, float maxHealth, int lastHealth, int health, int absorption, boolean blinking, CallbackInfo ci) {
/* 106 */     if (((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).isEnabled() && ((BooleanSetting)Objects.requireNonNull(((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).getSettings().getById("locked"))).isEnabled()) {
/* 107 */       ci.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderStatusBars"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void renderStatusBars(class_332 context, CallbackInfo ci) {
/* 113 */     if (((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).isEnabled() && ((BooleanSetting)Objects.requireNonNull(((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).getSettings().getById("locked"))).isEnabled()) {
/* 114 */       ci.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(method = {"renderHeldItemTooltip"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void renderHeldItemTooltip(class_332 context, CallbackInfo ci) {
/* 120 */     if (((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).isEnabled() && ((BooleanSetting)Objects.requireNonNull(((Module)Objects.<Module>requireNonNull(ModuleManager.Companion.getByClass(HotbarModule.class))).getSettings().getById("locked"))).isEnabled()) {
/* 121 */       ci.cancel();
/*     */       
/* 123 */       this.field_2035.method_16011().method_15396("selectedItemName");
/* 124 */       if (this.field_2040 > 0 && !this.field_2031.method_7960()) {
/* 125 */         class_5250 mutableText = class_2561.method_43473().method_10852(this.field_2031.method_7964()).method_27692(this.field_2031.method_7932().method_58413());
/* 126 */         if (this.field_2031.method_57826(class_9334.field_49631)) {
/* 127 */           mutableText.method_27692(class_124.field_1056);
/*     */         }
/*     */         
/* 130 */         int i = method_1756().method_27525((class_5348)mutableText);
/* 131 */         int j = (context.method_51421() - i) / 2;
/* 132 */         int k = context.method_51443() - 59;
/* 133 */         assert this.field_2035.field_1761 != null;
/* 134 */         if (!this.field_2035.field_1761.method_2908()) {
/* 135 */           k += 14;
/*     */         }
/*     */         
/* 138 */         int l = (int)(this.field_2040 * 256.0F / 10.0F);
/* 139 */         if (l > 255) {
/* 140 */           l = 255;
/*     */         }
/*     */         
/* 143 */         if (l > 0) {
/* 144 */           int var10001 = j - 2;
/* 145 */           int var10002 = k - 2;
/* 146 */           int var10003 = j + i + 2;
/* 147 */           Objects.requireNonNull(method_1756());
/* 148 */           context.method_25294(var10001, var10002, var10003, k + 9 + 2 - 50, this.field_2035.field_1690.method_19344(0));
/* 149 */           context.method_27535(method_1756(), (class_2561)mutableText, j, k - 50, 16777215 + (l << 24));
/*     */         } 
/*     */       } 
/*     */       
/* 153 */       this.field_2035.method_16011().method_15407();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\InGameHudMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */