/*     */ package net.integr.mixin;
/*     */ 
/*     */ import net.integr.event.PostMoveEvent;
/*     */ import net.integr.event.PreMoveEvent;
/*     */ import net.integr.event.PushOutOfBlocksEvent;
/*     */ import net.integr.event.SwingHandEvent;
/*     */ import net.integr.eventsystem.Event;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.integr.utilities.game.rotationfake.RotationFaker;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2828;
/*     */ import net.minecraft.class_2848;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_634;
/*     */ import net.minecraft.class_746;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_746.class})
/*     */ public abstract class ClientPlayerEntityMixin
/*     */   extends class_1297
/*     */ {
/*     */   @Shadow
/*     */   private boolean field_3920;
/*     */   @Shadow
/*     */   private boolean field_3927;
/*     */   @Shadow
/*     */   @Final
/*     */   protected class_310 field_3937;
/*     */   @Shadow
/*     */   @Final
/*     */   public class_634 field_3944;
/*     */   @Shadow
/*     */   private double field_3926;
/*     */   @Shadow
/*     */   private double field_3940;
/*     */   @Shadow
/*     */   private double field_3924;
/*     */   @Shadow
/*     */   private int field_3923;
/*     */   @Shadow
/*     */   private float field_3941;
/*     */   @Shadow
/*     */   private float field_3925;
/*     */   @Shadow
/*     */   private boolean field_3936;
/*     */   
/*     */   @Shadow
/*     */   protected abstract boolean method_3134();
/*     */   
/*     */   @Shadow
/*     */   protected abstract void method_46742();
/*     */   
/*     */   public ClientPlayerEntityMixin(class_1299<?> type, class_1937 world) {
/*  72 */     super(type, world);
/*     */   }
/*     */   
/*     */   @Inject(method = {"swingHand"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void swingHand(class_1268 hand, CallbackInfo ci) {
/*  77 */     SwingHandEvent e = new SwingHandEvent(hand);
/*  78 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  80 */     if (e.isCancelled())
/*  81 */       ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(at = {@At("HEAD")}, method = {"sendMovementPackets()V"}, cancellable = true)
/*     */   private void onSendMovementPacketsPre(CallbackInfo ci) {
/*  86 */     if (RotationLocker.Companion.isLocked()) {
/*  87 */       ci.cancel();
/*     */       
/*  89 */       method_46742();
/*  90 */       boolean bl = method_5715();
/*  91 */       if (bl != this.field_3936) {
/*  92 */         class_2848.class_2849 mode = bl ? class_2848.class_2849.field_12979 : class_2848.class_2849.field_12984;
/*  93 */         this.field_3944.method_52787((class_2596)new class_2848(this, mode));
/*  94 */         this.field_3936 = bl;
/*     */       } 
/*     */       
/*  97 */       if (method_3134()) {
/*  98 */         float fPreYaw = RotationFaker.Companion.getINSTANCE().getPreYaw();
/*  99 */         float fPrePitch = RotationFaker.Companion.getINSTANCE().getPrePitch();
/* 100 */         float fYaw = RotationFaker.Companion.getINSTANCE().getServerYaw();
/* 101 */         float fPitch = RotationFaker.Companion.getINSTANCE().getServerPitch();
/*     */         
/* 103 */         double d = method_23317() - this.field_3926;
/* 104 */         double d1 = method_23318() - this.field_3940;
/* 105 */         double f = method_23321() - this.field_3924;
/* 106 */         double g = (fYaw - fPreYaw);
/* 107 */         double h = (fPitch - fPrePitch);
/* 108 */         this.field_3923++;
/* 109 */         boolean bl2 = (class_3532.method_41190(d, d1, f) > class_3532.method_33723(2.0E-4D) || this.field_3923 >= 20);
/* 110 */         boolean bl3 = ((g != 0.0D || h != 0.0D) && (this.field_3941 != fYaw || this.field_3925 != fPitch));
/* 111 */         if (method_5765()) {
/* 112 */           class_243 vec3d = method_18798();
/* 113 */           this.field_3944.method_52787((class_2596)new class_2828.class_2830(vec3d.field_1352, -999.0D, vec3d.field_1350, fYaw, fPitch, method_24828()));
/* 114 */           bl2 = false;
/* 115 */         } else if (bl2 && bl3) {
/* 116 */           this.field_3944.method_52787((class_2596)new class_2828.class_2830(method_23317(), method_23318(), method_23321(), fYaw, fPitch, method_24828()));
/* 117 */         } else if (bl2) {
/* 118 */           this.field_3944.method_52787((class_2596)new class_2828.class_2829(method_23317(), method_23318(), method_23321(), method_24828()));
/* 119 */         } else if (bl3) {
/* 120 */           this.field_3944.method_52787((class_2596)new class_2828.class_2831(fYaw, fPitch, method_24828()));
/* 121 */         } else if (this.field_3920 != method_24828()) {
/* 122 */           this.field_3944.method_52787((class_2596)new class_2828.class_5911(method_24828()));
/*     */         } 
/*     */         
/* 125 */         if (bl2) {
/* 126 */           this.field_3926 = method_23317();
/* 127 */           this.field_3940 = method_23318();
/* 128 */           this.field_3924 = method_23321();
/* 129 */           this.field_3923 = 0;
/*     */         } 
/*     */         
/* 132 */         if (bl3) {
/* 133 */           RotationFaker.Companion.getINSTANCE().setPreYaw(fYaw);
/* 134 */           RotationFaker.Companion.getINSTANCE().setPrePitch(fPitch);
/*     */           
/* 136 */           this.field_3941 = fYaw;
/* 137 */           this.field_3925 = fPitch;
/*     */         } 
/*     */         
/* 140 */         this.field_3920 = method_24828();
/* 141 */         this.field_3927 = ((Boolean)this.field_3937.field_1690.method_42423().method_41753()).booleanValue();
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     PreMoveEvent e = new PreMoveEvent();
/* 146 */     EventSystem.Companion.post((Event)e);
/*     */     
/* 148 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(at = {@At("TAIL")}, method = {"sendMovementPackets()V"}, cancellable = true)
/*     */   private void onSendMovementPacketsPost(CallbackInfo ci) {
/* 153 */     PostMoveEvent e = new PostMoveEvent();
/* 154 */     EventSystem.Companion.post((Event)e);
/*     */     
/* 156 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"pushOutOfBlocks"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void onPushOutOfBlocks(double x, double d, CallbackInfo info) {
/* 161 */     PushOutOfBlocksEvent e = new PushOutOfBlocksEvent(x, d);
/* 162 */     EventSystem.Companion.post((Event)e);
/*     */     
/* 164 */     if (e.isCancelled()) info.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\ClientPlayerEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */