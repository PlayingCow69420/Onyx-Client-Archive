/*     */ package net.integr.mixin;
/*     */ 
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.AttackEvent;
/*     */ import net.integr.event.ClientEndEvent;
/*     */ import net.integr.event.DoItemPickEvent;
/*     */ import net.integr.event.EntityHasOutlineEvent;
/*     */ import net.integr.event.ItemUseEvent;
/*     */ import net.integr.event.JoinWorldEvent;
/*     */ import net.integr.event.PostTickEvent;
/*     */ import net.integr.event.PreTickEvent;
/*     */ import net.integr.event.UnsafePostTickEvent;
/*     */ import net.integr.event.UnsafePreTickEvent;
/*     */ import net.integr.eventsystem.Event;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_434;
/*     */ import net.minecraft.class_638;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_310.class})
/*     */ public class MinecraftClientMixin
/*     */ {
/*     */   @Inject(method = {"tick"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onTickPre(CallbackInfo ci) {
/*  37 */     PreTickEvent e = new PreTickEvent();
/*  38 */     UnsafePreTickEvent eu = new UnsafePreTickEvent();
/*  39 */     if ((Onyx.Companion.getMC()).field_1724 != null) EventSystem.Companion.post((Event)e);
/*     */     
/*  41 */     EventSystem.Companion.post((Event)eu);
/*     */     
/*  43 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"tick"}, at = {@At("TAIL")}, cancellable = true)
/*     */   public void onTickPost(CallbackInfo ci) {
/*  48 */     PostTickEvent e = new PostTickEvent();
/*  49 */     UnsafePostTickEvent eu = new UnsafePostTickEvent();
/*  50 */     if ((Onyx.Companion.getMC()).field_1724 != null) EventSystem.Companion.post((Event)e); 
/*  51 */     EventSystem.Companion.post((Event)eu);
/*     */     
/*  53 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"stop"}, at = {@At("HEAD")})
/*     */   public void onStop(CallbackInfo ci) {
/*  58 */     EventSystem.Companion.post((Event)new ClientEndEvent());
/*     */   }
/*     */   
/*     */   @Inject(method = {"cleanUpAfterCrash"}, at = {@At("HEAD")})
/*     */   public void onCrash(CallbackInfo ci) {
/*  63 */     EventSystem.Companion.post((Event)new ClientEndEvent());
/*     */   }
/*     */   
/*     */   @Inject(method = {"joinWorld"}, at = {@At("HEAD")})
/*     */   public void onJoinWorld(class_638 world, class_434.class_9678 worldEntryReason, CallbackInfo ci) {
/*  68 */     EventSystem.Companion.post((Event)new JoinWorldEvent(world));
/*     */   }
/*     */   
/*     */   @Inject(method = {"doItemUse"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onItemUse(CallbackInfo ci) {
/*  73 */     ItemUseEvent e = new ItemUseEvent();
/*  74 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  76 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"doAttack"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void onAttack(CallbackInfoReturnable<Boolean> cir) {
/*  81 */     AttackEvent e = new AttackEvent();
/*  82 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  84 */     if (e.isCancelled()) cir.setReturnValue(Boolean.valueOf(false)); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"doItemPick"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void onDoItemPick(CallbackInfo ci) {
/*  89 */     DoItemPickEvent e = new DoItemPickEvent();
/*  90 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  92 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"hasOutline"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void entityHasOutline(class_1297 entity, CallbackInfoReturnable<Boolean> ci) {
/*  97 */     EntityHasOutlineEvent e = new EntityHasOutlineEvent(entity);
/*  98 */     EventSystem.Companion.post((Event)e);
/*     */     
/* 100 */     if (e.getCallback() != null)
/* 101 */     { ci.setReturnValue(e.getCallback()); }
/* 102 */     else if (e.isCancelled()) { ci.cancel(); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\MinecraftClientMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */