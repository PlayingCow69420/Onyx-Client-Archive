package net.integr.mixin;

import net.minecraft.class_2886;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2886.class})
public interface PlayerInteractItemC2SPacketAccessor {
  @Mutable
  @Accessor("yaw")
  void setYaw(float paramFloat);
  
  @Mutable
  @Accessor("pitch")
  void setPitch(float paramFloat);
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\PlayerInteractItemC2SPacketAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */