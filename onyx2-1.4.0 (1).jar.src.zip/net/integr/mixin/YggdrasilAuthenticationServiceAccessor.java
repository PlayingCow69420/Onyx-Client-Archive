package net.integr.mixin;

import com.mojang.authlib.Environment;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({YggdrasilAuthenticationService.class})
public interface YggdrasilAuthenticationServiceAccessor {
  @Accessor("environment")
  Environment getEnvironment();
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\YggdrasilAuthenticationServiceAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */