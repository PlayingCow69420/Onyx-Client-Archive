/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.GetPlayerEntityScaleEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1007;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_742;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1007.class})
/*    */ public class PlayerEntityRendererMixin
/*    */ {
/*    */   @Inject(method = {"scale(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/util/math/MatrixStack;F)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onScale(class_742 player, class_4587 matrices, float amount, CallbackInfo ci) {
/* 33 */     GetPlayerEntityScaleEvent e = new GetPlayerEntityScaleEvent(player, matrices, amount);
/* 34 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 36 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\PlayerEntityRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */