/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.ApplySwingOffsetEvent;
/*    */ import net.integr.event.RenderArmEvent;
/*    */ import net.integr.event.RenderArmOrItemEvent;
/*    */ import net.integr.event.RenderHeldItemEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1306;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_742;
/*    */ import net.minecraft.class_759;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_759.class})
/*    */ public class HeldItemRendererMixin
/*    */ {
/*    */   @Inject(method = {"renderFirstPersonItem"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderArmHoldingItem(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IFFLnet/minecraft/util/Arm;)V")}, cancellable = true)
/*    */   private void onRenderArm(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
/* 41 */     RenderArmEvent e = new RenderArmEvent(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
/* 42 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 44 */     if (e.isCancelled()) ci.cancel();
/*    */     
/* 46 */     RenderArmOrItemEvent e2 = new RenderArmOrItemEvent(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
/* 47 */     EventSystem.Companion.post((Event)e2);
/*    */     
/* 49 */     if (e2.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderFirstPersonItem"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V")}, cancellable = true)
/*    */   private void onRenderItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
/* 54 */     RenderHeldItemEvent e = new RenderHeldItemEvent(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
/* 55 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 57 */     if (e.isCancelled()) ci.cancel();
/*    */     
/* 59 */     RenderArmOrItemEvent e2 = new RenderArmOrItemEvent(player, tickDelta, pitch, hand, swingProgress, item, equipProgress, matrices, vertexConsumers, light);
/* 60 */     EventSystem.Companion.post((Event)e2);
/*    */     
/* 62 */     if (e2.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"applySwingOffset"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onApplySwingOffset(class_4587 matrices, class_1306 arm, float swingProgress, CallbackInfo ci) {
/* 67 */     ApplySwingOffsetEvent e = new ApplySwingOffsetEvent();
/* 68 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 70 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\HeldItemRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */