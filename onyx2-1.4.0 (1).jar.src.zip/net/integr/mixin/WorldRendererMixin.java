/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.DrawOutlineFrameBufferEvent;
/*    */ import net.integr.event.PostRenderWorldEvent;
/*    */ import net.integr.event.PreRenderWorldEvent;
/*    */ import net.integr.event.RenderEntityEvent;
/*    */ import net.integr.event.SpawnParticleEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2394;
/*    */ import net.minecraft.class_279;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_703;
/*    */ import net.minecraft.class_757;
/*    */ import net.minecraft.class_761;
/*    */ import net.minecraft.class_765;
/*    */ import net.minecraft.class_9779;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.joml.Matrix4f;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_761.class})
/*    */ public abstract class WorldRendererMixin
/*    */ {
/*    */   @Shadow
/*    */   @Nullable
/*    */   public class_279 field_4059;
/*    */   
/*    */   @Inject(method = {"renderEntity"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void renderEntity(class_1297 entity, double cameraX, double cameraY, double cameraZ, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
/* 53 */     RenderEntityEvent e = new RenderEntityEvent(entity, cameraX, cameraY, cameraZ, tickDelta, matrices, vertexConsumers);
/* 54 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 56 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"spawnParticle(Lnet/minecraft/particle/ParticleEffect;ZZDDDDDD)Lnet/minecraft/client/particle/Particle;"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void spawnParticle(class_2394 parameters, boolean alwaysSpawn, boolean canSpawnOnMinimal, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<class_703> cir) {
/* 61 */     SpawnParticleEvent e = new SpawnParticleEvent(parameters, alwaysSpawn, canSpawnOnMinimal, x, y, z, velocityX, velocityY, velocityZ);
/* 62 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 64 */     if (e.isCancelled()) {
/* 65 */       cir.cancel();
/* 66 */     } else if (e.getCallback() != null) {
/* 67 */       cir.setReturnValue(e.getCallback());
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onRenderHead(class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci) {
/* 73 */     PreRenderWorldEvent e = new PreRenderWorldEvent();
/* 74 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 76 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/OutlineVertexConsumerProvider;draw()V")}, cancellable = true)
/*    */   private void onRender(class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci) {
/* 81 */     PostRenderWorldEvent e = new PostRenderWorldEvent();
/* 82 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 84 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/gl/PostEffectProcessor;render(F)V", ordinal = 0)}, cancellable = true)
/*    */   private void onRenderOutlineShader(class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci) {
/* 89 */     DrawOutlineFrameBufferEvent e = new DrawOutlineFrameBufferEvent();
/* 90 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 92 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\WorldRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */