/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.Onyx;
/*    */ import net.integr.event.EntityDeathEvent;
/*    */ import net.integr.event.GetHandSwingDurationEvent;
/*    */ import net.integr.event.PostEntityTakeDamageEvent;
/*    */ import net.integr.event.PreEntityTakeDamageEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1282;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1937;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1309.class})
/*    */ public abstract class LivingEntityMixin
/*    */   extends class_1297
/*    */ {
/*    */   public LivingEntityMixin(class_1299<?> type, class_1937 world) {
/* 39 */     super(type, world);
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"getHandSwingDuration"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getDuration(CallbackInfoReturnable<Integer> cir) {
/* 45 */     if (!equals((Onyx.Companion.getMC()).field_1724))
/*    */       return; 
/* 47 */     GetHandSwingDurationEvent e = new GetHandSwingDurationEvent();
/* 48 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 50 */     if (e.getCallback() != null)
/* 51 */     { cir.setReturnValue(Integer.valueOf(((Integer)e.getCallback()).intValue())); }
/* 52 */     else if (e.isCancelled()) { cir.cancel(); }
/*    */   
/*    */   }
/*    */   @Inject(method = {"damage"}, at = {@At("HEAD")})
/*    */   private void onDamagePre(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
/* 57 */     PreEntityTakeDamageEvent e = new PreEntityTakeDamageEvent(this, source, amount);
/* 58 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 60 */     if (e.isCancelled()) cir.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"damage"}, at = {@At("TAIL")})
/*    */   private void onDamagePost(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
/* 65 */     PostEntityTakeDamageEvent e = new PostEntityTakeDamageEvent(this, source, amount);
/* 66 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 68 */     if (e.isCancelled()) cir.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"onDeath"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onDeath(class_1282 damageSource, CallbackInfo ci) {
/* 73 */     EntityDeathEvent e = new EntityDeathEvent(this);
/* 74 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 76 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\LivingEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */