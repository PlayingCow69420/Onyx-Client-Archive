/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.RenderTitleScreenEvent;
/*    */ import net.integr.event.TitleScreenMouseClickedEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_442;
/*    */ import net.minecraft.class_8519;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_442.class})
/*    */ public class TitleScreenMixin
/*    */ {
/*    */   @Shadow
/*    */   @Nullable
/*    */   private class_8519 field_2586;
/*    */   
/*    */   @Inject(at = {@At("TAIL")}, method = {"init"})
/*    */   private void initTitleScreen(CallbackInfo ci) {
/* 41 */     this.field_2586 = null;
/*    */   }
/*    */   
/*    */   @Inject(at = {@At("TAIL")}, method = {"render"}, cancellable = true)
/*    */   private void renderTitleScreen(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
/* 46 */     RenderTitleScreenEvent e = new RenderTitleScreenEvent(context, mouseX, mouseY, delta);
/* 47 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 49 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(at = {@At("TAIL")}, method = {"mouseClicked"}, cancellable = true)
/*    */   private void titleScreenMouseClickedEvent(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
/* 54 */     TitleScreenMouseClickedEvent e = new TitleScreenMouseClickedEvent(mouseX, mouseY, button);
/* 55 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 57 */     if (e.getCallback() != null) { cir.setReturnValue(e.getCallback()); }
/* 58 */     else if (e.isCancelled()) { cir.cancel(); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\TitleScreenMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */