/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.RenderArmorEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1304;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_572;
/*    */ import net.minecraft.class_970;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_970.class})
/*    */ public class ArmorFeatureRendererMixin<T extends class_1309, A extends class_572<T>>
/*    */ {
/*    */   @Inject(method = {"renderArmor"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onRenderArmor(class_4587 matrices, class_4597 vertexConsumers, T entity, class_1304 armorSlot, int light, A model, CallbackInfo ci) {
/* 36 */     RenderArmorEvent e = new RenderArmorEvent((class_572)model, light, armorSlot, (class_1297)entity, vertexConsumers, matrices);
/* 37 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 39 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\ArmorFeatureRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */