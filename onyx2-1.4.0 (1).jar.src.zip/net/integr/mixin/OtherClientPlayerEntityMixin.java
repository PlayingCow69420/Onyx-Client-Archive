/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.EntityDeathEvent;
/*    */ import net.integr.event.PostEntityTakeDamageEvent;
/*    */ import net.integr.event.PreEntityTakeDamageEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1282;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_745;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_745.class})
/*    */ public abstract class OtherClientPlayerEntityMixin
/*    */   extends class_1297
/*    */ {
/*    */   @Unique
/*    */   private int lockTimer;
/*    */   
/*    */   public OtherClientPlayerEntityMixin(class_1299<?> type, class_1937 world) {
/* 41 */     super(type, world);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     this.lockTimer = 0;
/*    */   }
/*    */   
/*    */   @Inject(method = {"tick"}, at = {@At("TAIL")}, cancellable = true)
/*    */   private void onTick(CallbackInfo ci) {
/* 66 */     if (this.lockTimer > 0) {
/* 67 */       this.lockTimer--;
/*    */       
/*    */       return;
/*    */     } 
/* 71 */     if (!method_5805() && this.lockTimer == 0) {
/* 72 */       EntityDeathEvent e = new EntityDeathEvent(this);
/* 73 */       EventSystem.Companion.post((Event)e);
/*    */       
/* 75 */       if (e.isCancelled()) ci.cancel();
/*    */       
/* 77 */       this.lockTimer = 20;
/*    */     } 
/*    */   }
/*    */   
/*    */   @Inject(method = {"damage"}, at = {@At("HEAD")})
/*    */   private void onDamagePre(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
/*    */     PreEntityTakeDamageEvent e = new PreEntityTakeDamageEvent(this, source, amount);
/*    */     EventSystem.Companion.post((Event)e);
/*    */     if (e.isCancelled())
/*    */       cir.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"damage"}, at = {@At("TAIL")})
/*    */   private void onDamagePost(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
/*    */     PostEntityTakeDamageEvent e = new PostEntityTakeDamageEvent(this, source, amount);
/*    */     EventSystem.Companion.post((Event)e);
/*    */     if (e.isCancelled())
/*    */       cir.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\OtherClientPlayerEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */