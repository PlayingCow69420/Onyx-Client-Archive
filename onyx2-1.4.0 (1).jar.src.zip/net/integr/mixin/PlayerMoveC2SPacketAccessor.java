package net.integr.mixin;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2828.class})
public interface PlayerMoveC2SPacketAccessor {
  @Mutable
  @Accessor("y")
  void setY(double paramDouble);
  
  @Mutable
  @Accessor("yaw")
  void setYaw(float paramFloat);
  
  @Mutable
  @Accessor("pitch")
  void setPitch(float paramFloat);
  
  @Mutable
  @Accessor("changeLook")
  void setChangeLook(boolean paramBoolean);
  
  @Mutable
  @Accessor("changePosition")
  void setChangePosition(boolean paramBoolean);
  
  @Mutable
  @Accessor("onGround")
  void setOnGround(boolean paramBoolean);
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\PlayerMoveC2SPacketAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */