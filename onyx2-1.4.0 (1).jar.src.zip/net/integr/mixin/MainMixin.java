/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.minecraft.client.main.Main;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({Main.class})
/*    */ public class MainMixin
/*    */ {
/*    */   @Inject(method = {"main"}, at = {@At("HEAD")})
/*    */   private static void onInitMain(String[] args, CallbackInfo ci) {
/* 29 */     System.setProperty("java.awt.headless", "false");
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\MainMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */