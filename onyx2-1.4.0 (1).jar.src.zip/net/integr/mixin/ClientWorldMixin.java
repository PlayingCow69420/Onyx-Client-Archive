/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.EntityRemoveEvent;
/*    */ import net.integr.event.PlaySoundEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_3414;
/*    */ import net.minecraft.class_3419;
/*    */ import net.minecraft.class_638;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_638.class})
/*    */ public class ClientWorldMixin
/*    */ {
/*    */   @Inject(method = {"playSound(DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FFZJ)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void playSound(double x, double y, double z, class_3414 event, class_3419 category, float volume, float pitch, boolean useDistance, long seed, CallbackInfo ci) {
/* 35 */     PlaySoundEvent e = new PlaySoundEvent(x, y, z, event, category, volume, pitch, useDistance, seed);
/* 36 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 38 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"removeEntity"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onRemoveEntity(int entityId, class_1297.class_5529 removalReason, CallbackInfo ci) {
/* 43 */     EntityRemoveEvent e = new EntityRemoveEvent(entityId, removalReason);
/* 44 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 46 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\ClientWorldMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */