/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.SpawnBreakingParticlesEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2248.class})
/*    */ public class BlockMixin
/*    */ {
/*    */   @Inject(method = {"spawnBreakParticles"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void spawnBreakingParticles(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, CallbackInfo ci) {
/* 35 */     SpawnBreakingParticlesEvent e = new SpawnBreakingParticlesEvent(world, player, pos, state);
/* 36 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 38 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\BlockMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */