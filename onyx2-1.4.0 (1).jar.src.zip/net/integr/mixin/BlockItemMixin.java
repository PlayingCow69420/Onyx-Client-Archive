/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.PlaceBlockEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_1747;
/*    */ import net.minecraft.class_1750;
/*    */ import net.minecraft.class_2680;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1747.class})
/*    */ public class BlockItemMixin
/*    */ {
/*    */   @Inject(method = {"place(Lnet/minecraft/item/ItemPlacementContext;Lnet/minecraft/block/BlockState;)Z"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onPlace(class_1750 context, class_2680 state, CallbackInfoReturnable<Boolean> info) {
/* 33 */     if (!(context.method_8045()).field_9236)
/*    */       return; 
/* 35 */     PlaceBlockEvent e = new PlaceBlockEvent(context, state);
/*    */     
/* 37 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 39 */     if (e.isCancelled()) info.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\BlockItemMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */