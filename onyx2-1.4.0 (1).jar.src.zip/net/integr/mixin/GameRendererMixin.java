/*    */ package net.integr.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.sugar.Local;
/*    */ import net.integr.event.DamageTiltEvent;
/*    */ import net.integr.event.DrawFrameBufferEvent;
/*    */ import net.integr.event.RenderWorldEvent;
/*    */ import net.integr.event.ResizeScreenEvent;
/*    */ import net.integr.event.UpdateWorldRenderEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_757;
/*    */ import net.minecraft.class_9779;
/*    */ import org.joml.Matrix4f;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_757.class})
/*    */ public class GameRendererMixin
/*    */ {
/*    */   @Inject(at = {@At(value = "FIELD", target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode = 180, ordinal = 0)}, method = {"renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V"}, cancellable = true)
/*    */   public void onRenderWorld(class_9779 tickCounter, CallbackInfo ci, @Local(ordinal = 1) Matrix4f matrix4f2, @Local(ordinal = 1) float tickDelta) {
/* 41 */     class_4587 matrices = new class_4587();
/* 42 */     matrices.method_34425(matrix4f2);
/*    */     
/* 44 */     RenderWorldEvent e = new RenderWorldEvent(tickCounter.method_60637(true), matrices);
/* 45 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 47 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderWorld"}, at = {@At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V", args = {"ldc=hand"})}, locals = LocalCapture.CAPTURE_FAILEXCEPTION, cancellable = true)
/*    */   private void onRenderWorld1(class_9779 tickCounter, CallbackInfo ci, @Local(ordinal = 1) Matrix4f matrix4f2, @Local(ordinal = 1) float tickDelta, @Local class_4587 matrixStack) {
/* 52 */     UpdateWorldRenderEvent e = new UpdateWorldRenderEvent(matrixStack, matrix4f2);
/* 53 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 55 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(at = {@At("HEAD")}, method = {"tiltViewWhenHurt"}, cancellable = true)
/*    */   private void onTiltViewWhenHurt(class_4587 matrices, float tickDelta, CallbackInfo ci) {
/* 60 */     DamageTiltEvent e = new DamageTiltEvent(matrices, tickDelta);
/* 61 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 63 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V")}, cancellable = true)
/*    */   private void onRender(CallbackInfo ci) {
/* 68 */     DrawFrameBufferEvent e = new DrawFrameBufferEvent();
/* 69 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 71 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"onResized"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onResized(int width, int height, CallbackInfo ci) {
/* 76 */     ResizeScreenEvent e = new ResizeScreenEvent(width, height);
/* 77 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 79 */     if (e.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\GameRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */