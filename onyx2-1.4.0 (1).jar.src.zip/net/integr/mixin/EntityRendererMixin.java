/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.EntityRenderLabelEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.integr.utilities.TickDelta;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_327;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_5348;
/*    */ import net.minecraft.class_897;
/*    */ import net.minecraft.class_898;
/*    */ import net.minecraft.class_9064;
/*    */ import org.joml.Matrix4f;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_897.class})
/*    */ public abstract class EntityRendererMixin<T extends class_1297>
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   protected class_898 field_4676;
/*    */   
/*    */   @Shadow
/*    */   public abstract class_327 method_3932();
/*    */   
/*    */   @Inject(at = {@At("HEAD")}, method = {"renderLabelIfPresent"}, cancellable = true)
/*    */   private void onRenderLabelIfPresent(T entity, class_2561 text, class_4587 matrices, class_4597 vertexConsumers, int light, float tickDelta, CallbackInfo ci) {
/* 49 */     EntityRenderLabelEvent e = new EntityRenderLabelEvent((class_1297)entity, text, matrices, vertexConsumers, light);
/* 50 */     EventSystem.Companion.post((Event)e);
/*    */     
/* 52 */     if (e.getCallback() != null)
/* 53 */     { ci.cancel();
/* 54 */       renderLabel(entity, (class_2561)e.getCallback(), matrices, vertexConsumers, light); }
/* 55 */     else if (e.isCancelled()) { ci.cancel(); }
/*    */   
/*    */   }
/*    */   @Unique
/*    */   protected void renderLabel(T entity, class_2561 text, class_4587 matrices, class_4597 vertexConsumers, int light) {
/* 60 */     double d = this.field_4676.method_23168((class_1297)entity);
/* 61 */     class_243 vec3d = entity.method_56072().method_55675(class_9064.field_47745, 0, entity.method_5705(TickDelta.Companion.get()));
/* 62 */     if (d <= 4096.0D) {
/* 63 */       boolean bl = !entity.method_21751();
/* 64 */       int i = "deadmau5".equals(text.getString()) ? -10 : 0;
/* 65 */       matrices.method_22903();
/* 66 */       assert vec3d != null;
/* 67 */       matrices.method_22904(vec3d.field_1352, vec3d.field_1351 + 0.5D, vec3d.field_1350);
/* 68 */       matrices.method_22907(this.field_4676.method_24197());
/* 69 */       matrices.method_22905(-0.025F, -0.025F, 0.025F);
/* 70 */       Matrix4f matrix4f = matrices.method_23760().method_23761();
/* 71 */       float g = (class_310.method_1551()).field_1690.method_19343(0.25F);
/* 72 */       int j = (int)(g * 255.0F) << 24;
/* 73 */       class_327 textRenderer = method_3932();
/* 74 */       float h = (-textRenderer.method_27525((class_5348)text) / 2);
/* 75 */       textRenderer.method_30882(text, h, i, 553648127, false, matrix4f, vertexConsumers, bl ? class_327.class_6415.field_33994 : class_327.class_6415.field_33993, j, light);
/* 76 */       if (bl) {
/* 77 */         textRenderer.method_30882(text, h, i, -1, false, matrix4f, vertexConsumers, class_327.class_6415.field_33993, 0, light);
/*    */       }
/*    */       
/* 80 */       matrices.method_22909();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\EntityRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */