/*    */ package net.integr.mixin;
/*    */ 
/*    */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*    */ import com.mojang.authlib.minecraft.UserApiService;
/*    */ import com.mojang.authlib.yggdrasil.ProfileResult;
/*    */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*    */ import java.net.Proxy;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import net.minecraft.class_1071;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_320;
/*    */ import net.minecraft.class_5520;
/*    */ import net.minecraft.class_6360;
/*    */ import net.minecraft.class_7574;
/*    */ import net.minecraft.class_7853;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Mutable;
/*    */ import org.spongepowered.asm.mixin.gen.Accessor;
/*    */ import org.spongepowered.asm.mixin.gen.Invoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_310.class})
/*    */ public interface MinecraftClientAccessor
/*    */ {
/*    */   @Accessor("currentFps")
/*    */   static int getFps() {
/* 42 */     return 0;
/*    */   }
/*    */   
/*    */   @Mutable
/*    */   @Accessor("session")
/*    */   void setSession(class_320 paramclass_320);
/*    */   
/*    */   @Accessor("networkProxy")
/*    */   Proxy getProxy();
/*    */   
/*    */   @Accessor("resourceReloadLogger")
/*    */   class_6360 getResourceReloadLogger();
/*    */   
/*    */   @Invoker("doAttack")
/*    */   boolean leftClick();
/*    */   
/*    */   @Mutable
/*    */   @Accessor("profileKeys")
/*    */   void setProfileKeys(class_7853 paramclass_7853);
/*    */   
/*    */   @Accessor("authenticationService")
/*    */   YggdrasilAuthenticationService getAuthenticationService();
/*    */   
/*    */   @Mutable
/*    */   @Accessor
/*    */   void setUserApiService(UserApiService paramUserApiService);
/*    */   
/*    */   @Mutable
/*    */   @Accessor("sessionService")
/*    */   void setSessionService(MinecraftSessionService paramMinecraftSessionService);
/*    */   
/*    */   @Mutable
/*    */   @Accessor("authenticationService")
/*    */   void setAuthenticationService(YggdrasilAuthenticationService paramYggdrasilAuthenticationService);
/*    */   
/*    */   @Mutable
/*    */   @Accessor("skinProvider")
/*    */   void setSkinProvider(class_1071 paramclass_1071);
/*    */   
/*    */   @Mutable
/*    */   @Accessor("socialInteractionsManager")
/*    */   void setSocialInteractionsManager(class_5520 paramclass_5520);
/*    */   
/*    */   @Mutable
/*    */   @Accessor("abuseReportContext")
/*    */   void setAbuseReportContext(class_7574 paramclass_7574);
/*    */   
/*    */   @Mutable
/*    */   @Accessor("gameProfileFuture")
/*    */   void setGameProfileFuture(CompletableFuture<ProfileResult> paramCompletableFuture);
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\MinecraftClientAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */