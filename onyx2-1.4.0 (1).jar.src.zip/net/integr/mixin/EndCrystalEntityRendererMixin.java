/*     */ package net.integr.mixin;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import net.integr.modules.impl.CrystalTweaksModule;
/*     */ import net.integr.modules.management.ModuleManager;
/*     */ import net.integr.modules.management.settings.impl.SliderSetting;
/*     */ import net.minecraft.class_1511;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_892;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.ModifyArgs;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*     */ import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_892.class})
/*     */ public class EndCrystalEntityRendererMixin
/*     */ {
/*     */   @ModifyArgs(method = {"render(Lnet/minecraft/entity/decoration/EndCrystalEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;scale(FFF)V", ordinal = 0))
/*     */   private void modifyScale(Args args) {
/*  43 */     CrystalTweaksModule module = (CrystalTweaksModule)ModuleManager.Companion.getByClass(CrystalTweaksModule.class);
/*  44 */     if (module == null || !module.isEnabled())
/*     */       return; 
/*  46 */     float scale = ((SliderSetting)Objects.requireNonNull(module.getSettings().getById("scale"))).getSetValueAsFloat();
/*     */     
/*  48 */     args.set(0, Float.valueOf(2.0F * scale));
/*  49 */     args.set(1, Float.valueOf(2.0F * scale));
/*  50 */     args.set(2, Float.valueOf(2.0F * scale));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(method = {"getYOffset"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private static void findYOffset(class_1511 crystal, float tickDelta, CallbackInfoReturnable<Float> cir) {
/*  72 */     CrystalTweaksModule module = (CrystalTweaksModule)ModuleManager.Companion.getByClass(CrystalTweaksModule.class);
/*  73 */     if (module == null || !module.isEnabled()) {
/*  74 */       cir.setReturnValue(Float.valueOf(getYOffsetL(crystal, tickDelta)));
/*     */       
/*     */       return;
/*     */     } 
/*  78 */     float bounce = ((SliderSetting)Objects.requireNonNull(module.getSettings().getById("bounce"))).getSetValueAsFloat();
/*     */     
/*  80 */     float f = crystal.field_7034 + tickDelta;
/*  81 */     float g = class_3532.method_15374(f * 0.2F) / 2.0F + 0.5F;
/*  82 */     g = (g * g + g) * 0.4F * bounce;
/*  83 */     cir.setReturnValue(Float.valueOf(g - 1.4F));
/*     */   }
/*     */   
/*     */   @Unique
/*     */   private static float getYOffsetL(class_1511 crystal, float tickDelta) {
/*  88 */     float f = crystal.field_7034 + tickDelta;
/*  89 */     float g = class_3532.method_15374(f * 0.2F) / 2.0F + 0.5F;
/*  90 */     g = (g * g + g) * 0.4F;
/*  91 */     return g - 1.4F;
/*     */   }
/*     */   
/*     */   @ModifyArgs(method = {"render(Lnet/minecraft/entity/decoration/EndCrystalEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/RotationAxis;rotationDegrees(F)Lorg/joml/Quaternionf;"))
/*     */   private void modifySpeed(Args args) {
/*  96 */     CrystalTweaksModule module = (CrystalTweaksModule)ModuleManager.Companion.getByClass(CrystalTweaksModule.class);
/*  97 */     if (module == null || !module.isEnabled())
/*     */       return; 
/*  99 */     float speed = ((SliderSetting)Objects.requireNonNull(module.getSettings().getById("speed"))).getSetValueAsFloat();
/*     */ 
/*     */     
/* 102 */     args.set(0, Float.valueOf(((Float)args.get(0)).floatValue() * speed));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\EndCrystalEntityRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */