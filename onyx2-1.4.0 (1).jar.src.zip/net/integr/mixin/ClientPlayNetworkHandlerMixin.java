/*     */ package net.integr.mixin;
/*     */ 
/*     */ import com.mojang.brigadier.ParseResults;
/*     */ import java.time.Instant;
/*     */ import java.util.Objects;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.EntityPopTotemEvent;
/*     */ import net.integr.event.ExplosionVelocityEvent;
/*     */ import net.integr.event.SendChatMessageEvent;
/*     */ import net.integr.event.SendCommandEvent;
/*     */ import net.integr.eventsystem.Event;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.minecraft.class_2172;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2663;
/*     */ import net.minecraft.class_2664;
/*     */ import net.minecraft.class_2797;
/*     */ import net.minecraft.class_3515;
/*     */ import net.minecraft.class_634;
/*     */ import net.minecraft.class_7469;
/*     */ import net.minecraft.class_7472;
/*     */ import net.minecraft.class_7608;
/*     */ import net.minecraft.class_7610;
/*     */ import net.minecraft.class_7637;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.Unique;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_634.class})
/*     */ public abstract class ClientPlayNetworkHandlerMixin
/*     */ {
/*     */   @Shadow
/*     */   private class_7610.class_7612 field_39808;
/*     */   @Shadow
/*     */   private class_7637 field_39858;
/*     */   
/*     */   @Shadow
/*     */   protected abstract ParseResults<class_2172> method_45733(String paramString);
/*     */   
/*     */   @Inject(method = {"sendChatMessage"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void onChatMessage(String message, CallbackInfo ci) {
/*  56 */     SendChatMessageEvent e = new SendChatMessageEvent(message);
/*  57 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  59 */     if (e.getCallback() != null)
/*  60 */     { message = (String)e.getCallback();
/*  61 */       ci.cancel();
/*     */       
/*  63 */       sendChatMessageU(message); }
/*  64 */     else if (e.isCancelled()) { ci.cancel(); }
/*     */   
/*     */   }
/*     */   @Unique
/*     */   public void sendChatMessageU(String content) {
/*  69 */     Instant instant = Instant.now();
/*  70 */     long l = class_3515.class_7426.method_43531();
/*  71 */     class_7637.class_7816 lastSeenMessages = this.field_39858.method_46266();
/*  72 */     class_7469 messageSignatureData = this.field_39808.pack(new class_7608(content, instant, l, lastSeenMessages.comp_1073()));
/*  73 */     ((class_634)Objects.<class_634>requireNonNull(Onyx.Companion.getMC().method_1562())).method_52787((class_2596)new class_2797(content, instant, l, messageSignatureData, lastSeenMessages.comp_1074()));
/*     */   }
/*     */   
/*     */   @Inject(method = {"sendChatCommand"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void onCommand(String command, CallbackInfo ci) {
/*  78 */     SendCommandEvent e = new SendCommandEvent(command);
/*  79 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  81 */     if (e.getCallback() != null)
/*  82 */     { command = (String)e.getCallback();
/*  83 */       ci.cancel();
/*     */       
/*  85 */       sendChatCommandU(command); }
/*  86 */     else if (e.isCancelled()) { ci.cancel(); }
/*     */   
/*     */   }
/*     */   @Unique
/*     */   public void sendChatCommandU(String command) {
/*  91 */     ((class_634)Objects.<class_634>requireNonNull(Onyx.Companion.getMC().method_1562())).method_52787((class_2596)new class_7472(command));
/*     */   }
/*     */   
/*     */   @Inject(method = {"onExplosion"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/util/thread/ThreadExecutor;)V", shift = At.Shift.AFTER)}, cancellable = true)
/*     */   private void onExplosionVelocity(class_2664 packet, CallbackInfo ci) {
/*  96 */     ExplosionVelocityEvent e = new ExplosionVelocityEvent(packet);
/*  97 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  99 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */   
/*     */   @Inject(method = {"onEntityStatus"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/particle/ParticleManager;addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V")}, cancellable = true)
/*     */   public void onEntityPopTotem(class_2663 packet, CallbackInfo ci) {
/* 104 */     EntityPopTotemEvent e = new EntityPopTotemEvent(packet);
/* 105 */     EventSystem.Companion.post((Event)e);
/*     */     
/* 107 */     if (e.isCancelled()) ci.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\ClientPlayNetworkHandlerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */