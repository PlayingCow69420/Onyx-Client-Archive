/*    */ package net.integr.mixin;
/*    */ 
/*    */ import net.integr.event.UpdateLightMapTextureManagerEvent;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.integr.eventsystem.EventSystem;
/*    */ import net.minecraft.class_765;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArgs;
/*    */ import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_765.class})
/*    */ public class LightMapTextureManagerMixin
/*    */ {
/*    */   @ModifyArgs(method = {"update"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/texture/NativeImage;setColor(III)V"))
/*    */   private void update(Args args) {
/* 31 */     UpdateLightMapTextureManagerEvent e = new UpdateLightMapTextureManagerEvent(args);
/* 32 */     EventSystem.Companion.post((Event)e);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\LightMapTextureManagerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */