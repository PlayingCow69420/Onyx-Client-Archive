/*     */ package net.integr.mixin;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.event.EntityHasLabelEvent;
/*     */ import net.integr.eventsystem.Event;
/*     */ import net.integr.eventsystem.EventSystem;
/*     */ import net.integr.utilities.game.rotationfake.RotationLocker;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1921;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_3887;
/*     */ import net.minecraft.class_4050;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_4588;
/*     */ import net.minecraft.class_4597;
/*     */ import net.minecraft.class_5617;
/*     */ import net.minecraft.class_583;
/*     */ import net.minecraft.class_897;
/*     */ import net.minecraft.class_922;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_922.class})
/*     */ public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>>
/*     */   extends class_897<T>
/*     */ {
/*     */   @Shadow
/*     */   protected M field_4737;
/*     */   @Shadow
/*     */   @Final
/*     */   protected List<class_3887<T, M>> field_4738;
/*     */   
/*     */   protected LivingEntityRendererMixin(class_5617.class_5618 ctx) {
/*  64 */     super(ctx); } @Shadow
/*     */   protected abstract float method_23185(T paramT, float paramFloat); @Shadow
/*     */   @Nullable
/*     */   protected abstract class_1921 method_24302(T paramT, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3); @Shadow
/*     */   public static int method_23622(class_1309 entity, float whiteOverlayProgress) {
/*  69 */     return 0;
/*     */   }
/*     */   @Shadow
/*     */   protected abstract boolean method_4056(T paramT);
/*     */   @Shadow
/*     */   protected abstract float method_4044(T paramT, float paramFloat);
/*     */   
/*     */   @Shadow
/*     */   public static boolean method_38563(class_1309 entity) {
/*  78 */     return false;
/*     */   } @Shadow
/*     */   protected abstract float method_4045(T paramT, float paramFloat);
/*     */   @Shadow
/*     */   protected abstract void method_4042(T paramT, class_4587 paramclass_4587, float paramFloat);
/*     */   @Shadow
/*     */   protected abstract void method_4058(T paramT, class_4587 paramclass_4587, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*     */   @Inject(at = {@At("HEAD")}, method = {"hasLabel(Lnet/minecraft/entity/LivingEntity;)Z"}, cancellable = true)
/*     */   public void hasLabel(class_1309 entity, CallbackInfoReturnable<Boolean> ci) {
/*  87 */     EntityHasLabelEvent e = new EntityHasLabelEvent(entity);
/*  88 */     EventSystem.Companion.post((Event)e);
/*     */     
/*  90 */     if (e.isCancelled()) { ci.cancel(); } else if (e.getCallback() != null) { ci.setReturnValue(e.getCallback()); }
/*     */   
/*     */   }
/*     */   @Inject(method = {"render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, at = {@At("HEAD")}, cancellable = true)
/*     */   public void renderEntity(T livingEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
/*  95 */     if (livingEntity == (Onyx.Companion.getMC()).field_1724) {
/*  96 */       float h, j, m; ci.cancel();
/*     */       
/*  98 */       matrixStack.method_22903();
/*  99 */       ((class_583)this.field_4737).field_3447 = method_4044(livingEntity, g);
/* 100 */       ((class_583)this.field_4737).field_3449 = livingEntity.method_5765();
/* 101 */       ((class_583)this.field_4737).field_3448 = livingEntity.method_6109();
/*     */ 
/*     */ 
/*     */       
/* 105 */       if (RotationLocker.Companion.isLocked())
/* 106 */       { h = class_3532.method_17821(g, RotationLocker.Companion.getFakeYaw(), RotationLocker.Companion.getFakeYaw()); }
/* 107 */       else { h = class_3532.method_17821(g, ((class_1309)livingEntity).field_6220, ((class_1309)livingEntity).field_6283); }
/*     */       
/* 109 */       if (RotationLocker.Companion.isLocked())
/* 110 */       { j = class_3532.method_17821(g, RotationLocker.Companion.getFakeYaw(), RotationLocker.Companion.getFakeYaw()); }
/* 111 */       else { j = class_3532.method_17821(g, ((class_1309)livingEntity).field_6259, ((class_1309)livingEntity).field_6241); }
/*     */       
/* 113 */       float k = j - h;
/*     */       
/* 115 */       if (livingEntity.method_5765()) {
/* 116 */         class_1297 var11 = livingEntity.method_5854();
/* 117 */         if (var11 instanceof class_1309) { class_1309 livingEntity2 = (class_1309)var11;
/* 118 */           h = class_3532.method_17821(g, livingEntity2.field_6220, livingEntity2.field_6283);
/* 119 */           k = j - h;
/* 120 */           float f1 = class_3532.method_15393(k);
/* 121 */           if (f1 < -85.0F) {
/* 122 */             f1 = -85.0F;
/*     */           }
/*     */           
/* 125 */           if (f1 >= 85.0F) {
/* 126 */             f1 = 85.0F;
/*     */           }
/*     */           
/* 129 */           h = j - f1;
/* 130 */           if (f1 * f1 > 2500.0F) {
/* 131 */             h += f1 * 0.2F;
/*     */           }
/*     */           
/* 134 */           k = j - h; }
/*     */       
/*     */       } 
/*     */ 
/*     */       
/* 139 */       if (RotationLocker.Companion.isLocked())
/* 140 */       { m = class_3532.method_16439(g, RotationLocker.Companion.getFakePitch(), RotationLocker.Companion.getFakePitch()); }
/* 141 */       else { m = class_3532.method_16439(g, ((class_1309)livingEntity).field_6004, livingEntity.method_36455()); }
/*     */       
/* 143 */       if (method_38563((class_1309)livingEntity)) {
/* 144 */         m *= -1.0F;
/* 145 */         k *= -1.0F;
/*     */       } 
/*     */       
/* 148 */       k = class_3532.method_15393(k);
/*     */       
/* 150 */       if (livingEntity.method_41328(class_4050.field_18078)) {
/* 151 */         class_2350 direction = livingEntity.method_18401();
/* 152 */         if (direction != null) {
/* 153 */           float f1 = livingEntity.method_18381(class_4050.field_18076) - 0.1F;
/* 154 */           matrixStack.method_46416(-direction.method_10148() * f1, 0.0F, -direction.method_10165() * f1);
/*     */         } 
/*     */       } 
/*     */       
/* 158 */       float l = livingEntity.method_55693();
/* 159 */       matrixStack.method_22905(l, l, l);
/* 160 */       float n = method_4045(livingEntity, g);
/* 161 */       method_4058(livingEntity, matrixStack, n, h, g, l);
/* 162 */       matrixStack.method_22905(-1.0F, -1.0F, 1.0F);
/* 163 */       method_4042(livingEntity, matrixStack, g);
/* 164 */       matrixStack.method_46416(0.0F, -1.501F, 0.0F);
/* 165 */       float o = 0.0F;
/* 166 */       float p = 0.0F;
/* 167 */       if (!livingEntity.method_5765() && livingEntity.method_5805()) {
/* 168 */         o = ((class_1309)livingEntity).field_42108.method_48570(g);
/* 169 */         p = ((class_1309)livingEntity).field_42108.method_48572(g);
/* 170 */         if (livingEntity.method_6109()) {
/* 171 */           p *= 3.0F;
/*     */         }
/*     */         
/* 174 */         if (o > 1.0F) {
/* 175 */           o = 1.0F;
/*     */         }
/*     */       } 
/*     */       
/* 179 */       this.field_4737.method_2816((class_1297)livingEntity, p, o, g);
/* 180 */       this.field_4737.method_2819((class_1297)livingEntity, p, o, n, k, m);
/* 181 */       class_310 minecraftClient = class_310.method_1551();
/* 182 */       boolean bl = method_4056(livingEntity);
/* 183 */       boolean bl2 = (!bl && !livingEntity.method_5756((class_1657)minecraftClient.field_1724));
/* 184 */       boolean bl3 = minecraftClient.method_27022((class_1297)livingEntity);
/* 185 */       class_1921 renderLayer = method_24302(livingEntity, bl, bl2, bl3);
/* 186 */       if (renderLayer != null) {
/* 187 */         class_4588 vertexConsumer = vertexConsumerProvider.getBuffer(renderLayer);
/* 188 */         int q = method_23622((class_1309)livingEntity, method_23185(livingEntity, g));
/* 189 */         this.field_4737.method_2828(matrixStack, vertexConsumer, i, q, bl2 ? 654311423 : -1);
/*     */       } 
/*     */       
/* 192 */       if (!livingEntity.method_7325())
/*     */       {
/* 194 */         for (class_3887<T, M> feature : this.field_4738) {
/* 195 */           feature.method_4199(matrixStack, vertexConsumerProvider, i, (class_1297)livingEntity, p, o, g, n, k, m);
/*     */         }
/*     */       }
/*     */       
/* 199 */       matrixStack.method_22909();
/* 200 */       method_3936((class_1297)livingEntity, f, g, matrixStack, vertexConsumerProvider, i);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\LivingEntityRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */