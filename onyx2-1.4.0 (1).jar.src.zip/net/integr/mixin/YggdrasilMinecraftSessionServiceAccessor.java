/*    */ package net.integr.mixin;
/*    */ 
/*    */ import com.mojang.authlib.Environment;
/*    */ import com.mojang.authlib.yggdrasil.ServicesKeySet;
/*    */ import com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService;
/*    */ import java.net.Proxy;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.gen.Invoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({YggdrasilMinecraftSessionService.class})
/*    */ public interface YggdrasilMinecraftSessionServiceAccessor
/*    */ {
/*    */   @Invoker("<init>")
/*    */   static YggdrasilMinecraftSessionService createYggdrasilMinecraftSessionService(ServicesKeySet servicesKeySet, Proxy proxy, Environment env) {
/* 17 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\mixin\YggdrasilMinecraftSessionServiceAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */