/*    */ package net.integr;
/*    */ 
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.google.gson.annotations.Expose;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.LinkOption;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.attribute.FileAttribute;
/*    */ import java.util.Arrays;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.collections.CollectionsKt;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.text.Charsets;
/*    */ import net.integr.modules.management.settings.Setting;
/*    */ import net.integr.modules.management.settings.SettingsBuilder;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.modules.management.settings.impl.CyclerSetting;
/*    */ import net.integr.modules.management.settings.impl.IntSliderSetting;
/*    */ import net.integr.utilities.LogUtils;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\030\000 \0242\0020\001:\001\024B\007¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006J\r\020\b\032\0020\007¢\006\004\b\b\020\003J\025\020\b\032\0020\0072\006\020\n\032\0020\t¢\006\004\b\b\020\013J\r\020\f\032\0020\007¢\006\004\b\f\020\003R\"\020\016\032\0020\r8\006@\006X\016¢\006\022\n\004\b\016\020\017\032\004\b\020\020\021\"\004\b\022\020\023¨\006\025"}, d2 = {"Lnet/integr/Settings;", "", "<init>", "()V", "", "exist", "()Z", "", "load", "Lcom/google/gson/JsonObject;", "jsonObj", "(Lcom/google/gson/JsonObject;)V", "save", "Lnet/integr/modules/management/settings/SettingsBuilder;", "settings", "Lnet/integr/modules/management/settings/SettingsBuilder;", "getSettings", "()Lnet/integr/modules/management/settings/SettingsBuilder;", "setSettings", "(Lnet/integr/modules/management/settings/SettingsBuilder;)V", "Companion", "onyx2"})
/*    */ public final class Settings
/*    */ {
/*    */   public Settings() {
/* 40 */     String[] arrayOfString = new String[11]; arrayOfString[0] = "Orange"; arrayOfString[1] = "Rgb"; arrayOfString[2] = "Red"; arrayOfString[3] = "Green"; arrayOfString[4] = "Yellow"; arrayOfString[5] = "Pink"; arrayOfString[6] = "Purple"; arrayOfString[7] = "Blue"; arrayOfString[8] = "Cyan"; arrayOfString[9] = "White"; arrayOfString[10] = "Black";
/* 41 */     arrayOfString = new String[5]; arrayOfString[0] = "Dark"; arrayOfString[1] = "Light"; arrayOfString[2] = "Blue"; arrayOfString[3] = "Gray"; arrayOfString[4] = "Mango";
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 46 */     this.settings = (new SettingsBuilder(false)).add((Setting)new CyclerSetting("Accent: ", "The accent for the Client", "accent", CollectionsKt.mutableListOf((Object[])arrayOfString))).add((Setting)new CyclerSetting("Theme: ", "The theme for the Client", "theme", CollectionsKt.mutableListOf((Object[])arrayOfString))).add((Setting)new BooleanSetting("Glow", "Toggle the glowing effects", "glow", false, 8, null)).add((Setting)new BooleanSetting("DiscordRPC", "Toggle the discord Presence", "discordRpc", false, 8, null)).add((Setting)new BooleanSetting("Watermark", "Toggle the watermark", "watermark", false, 8, null)).add((Setting)new IntSliderSetting("Pathfinding Speed: ", "The Speed multiplier for the auto path traversal", "pathfindingSpeed", 1, 10, 2)).add((Setting)new BooleanSetting("Smol Int", "Find out yourself what this does (wont disappoint you finally find out)", "smol", true));
/*    */   } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/Settings$Companion;", "", "<init>", "()V", "Lnet/integr/Settings;", "INSTANCE", "Lnet/integr/Settings;", "getINSTANCE", "()Lnet/integr/Settings;", "onyx2"}) public static final class Companion {
/*    */     private Companion() {} @NotNull public final Settings getINSTANCE() { return Settings.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @Expose @NotNull
/* 49 */   private SettingsBuilder settings; public final void save() { String json = (new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().toJson(this);
/*    */     
/*    */     try {
/* 52 */       Files.createDirectories(Path.of("" + Onyx.Companion.getCONFIG() + "/settings", new String[0]), (FileAttribute<?>[])new FileAttribute[0]);
/* 53 */       Intrinsics.checkNotNull(json); String str = json; Intrinsics.checkNotNullExpressionValue(str.getBytes(Charsets.UTF_8), "getBytes(...)"); Files.write(Path.of("" + Onyx.Companion.getCONFIG() + "/settings/settings.json", new String[0]), str.getBytes(Charsets.UTF_8), new java.nio.file.OpenOption[0]);
/* 54 */     } catch (IOException e) {
/* 55 */       LogUtils.Companion.sendLog("Could not save config [Settings]!");
/* 56 */       e.printStackTrace();
/*    */     }  }
/*    */   @NotNull private static final Settings INSTANCE = new Settings();
/*    */   @NotNull
/*    */   public final SettingsBuilder getSettings() { return this.settings; } public final void setSettings(@NotNull SettingsBuilder <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
/* 61 */     this.settings = <set-?>; } public final boolean exist() { Intrinsics.checkNotNullExpressionValue(Path.of("" + Onyx.Companion.getCONFIG() + "/settings/settings.json", new String[0]), "of(...)"); Path path = Path.of("" + Onyx.Companion.getCONFIG() + "/settings/settings.json", new String[0]); LinkOption[] arrayOfLinkOption = new LinkOption[0]; return Files.exists(path, Arrays.<LinkOption>copyOf(arrayOfLinkOption, arrayOfLinkOption.length)); }
/*    */ 
/*    */   
/*    */   public final void load() {
/* 65 */     Intrinsics.checkNotNullExpressionValue(Files.readAllLines(Path.of("" + Onyx.Companion.getCONFIG() + "/settings/settings.json", new String[0])), "readAllLines(...)"); String json = CollectionsKt.joinToString$default(Files.readAllLines(Path.of("" + Onyx.Companion.getCONFIG() + "/settings/settings.json", new String[0])), "", null, null, 0, null, null, 62, null);
/* 66 */     JsonObject jsonObj = (JsonObject)(new GsonBuilder()).excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().fromJson(json, JsonObject.class);
/*    */     
/* 68 */     Intrinsics.checkNotNull(jsonObj); this.settings = this.settings.load(jsonObj);
/*    */   }
/*    */   
/*    */   public final void load(@NotNull JsonObject jsonObj) {
/* 72 */     Intrinsics.checkNotNullParameter(jsonObj, "jsonObj"); this.settings = this.settings.load(jsonObj);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\Settings.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */