/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PushOutOfBlocksEvent
/*    */   extends Event
/*    */ {
/*    */   public double x;
/*    */   public double d;
/*    */   
/*    */   public PushOutOfBlocksEvent(double x, double d) {
/* 26 */     this.x = x;
/* 27 */     this.d = d;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\PushOutOfBlocksEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */