/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1297;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityDeathEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1297 entity;
/*    */   
/*    */   public EntityDeathEvent(class_1297 entity) {
/* 26 */     this.entity = entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\EntityDeathEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */