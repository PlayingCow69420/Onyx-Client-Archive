/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpawnBreakingParticlesEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1937 world;
/*    */   public class_1657 player;
/*    */   public class_2338 pos;
/*    */   public class_2680 state;
/*    */   
/*    */   public SpawnBreakingParticlesEvent(class_1937 world, class_1657 player, class_2338 pos, class_2680 state) {
/* 32 */     this.world = world;
/* 33 */     this.player = player;
/* 34 */     this.pos = pos;
/* 35 */     this.state = state;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\SpawnBreakingParticlesEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */