/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_2664;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExplosionVelocityEvent
/*    */   extends Event
/*    */ {
/*    */   public class_2664 packet;
/*    */   
/*    */   public ExplosionVelocityEvent(class_2664 packet) {
/* 26 */     this.packet = packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\ExplosionVelocityEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */