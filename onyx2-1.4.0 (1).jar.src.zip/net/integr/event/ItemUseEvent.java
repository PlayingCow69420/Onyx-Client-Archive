package net.integr.event;

import net.integr.eventsystem.Event;

public class ItemUseEvent extends Event {}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\ItemUseEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */