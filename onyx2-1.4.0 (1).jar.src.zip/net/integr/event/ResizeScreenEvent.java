/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResizeScreenEvent
/*    */   extends Event
/*    */ {
/*    */   public int width;
/*    */   public int height;
/*    */   
/*    */   public ResizeScreenEvent(int width, int height) {
/* 26 */     this.width = width;
/* 27 */     this.height = height;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\ResizeScreenEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */