/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityRenderLabelEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1297 entity;
/*    */   public class_2561 text;
/*    */   public class_4587 matrices;
/*    */   public class_4597 vertexConsumers;
/*    */   public int light;
/*    */   
/*    */   public EntityRenderLabelEvent(class_1297 entity, class_2561 text, class_4587 matrices, class_4597 vertexConsumers, int light) {
/* 33 */     this.entity = entity;
/* 34 */     this.text = text;
/* 35 */     this.matrices = matrices;
/* 36 */     this.vertexConsumers = vertexConsumers;
/* 37 */     this.light = light;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\EntityRenderLabelEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */