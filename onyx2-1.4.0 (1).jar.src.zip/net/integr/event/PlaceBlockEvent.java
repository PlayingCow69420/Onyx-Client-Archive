/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1750;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaceBlockEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1750 context;
/*    */   public class_2680 state;
/*    */   
/*    */   public PlaceBlockEvent(class_1750 context, class_2680 state) {
/* 28 */     this.context = context;
/* 29 */     this.state = state;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\PlaceBlockEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */