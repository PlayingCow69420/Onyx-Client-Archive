/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderTitleScreenEvent
/*    */   extends Event
/*    */ {
/*    */   public class_332 context;
/*    */   public int mouseX;
/*    */   public int mouseY;
/*    */   public float delta;
/*    */   
/*    */   public RenderTitleScreenEvent(class_332 context, int mouseX, int mouseY, float delta) {
/* 29 */     this.context = context;
/* 30 */     this.mouseX = mouseX;
/* 31 */     this.mouseY = mouseY;
/* 32 */     this.delta = delta;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\RenderTitleScreenEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */