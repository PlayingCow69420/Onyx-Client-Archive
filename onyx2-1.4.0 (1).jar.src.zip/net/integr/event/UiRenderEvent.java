/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UiRenderEvent
/*    */   extends Event
/*    */ {
/*    */   public class_332 context;
/*    */   public float tickDelta;
/*    */   
/*    */   public UiRenderEvent(class_332 context, float tickDelta) {
/* 27 */     this.context = context;
/* 28 */     this.tickDelta = tickDelta;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\UiRenderEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */