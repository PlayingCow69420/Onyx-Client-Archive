/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReceivePacketEvent
/*    */   extends Event
/*    */ {
/*    */   public class_2596<?> packet;
/*    */   
/*    */   public ReceivePacketEvent(class_2596<?> packet) {
/* 26 */     this.packet = packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\ReceivePacketEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */