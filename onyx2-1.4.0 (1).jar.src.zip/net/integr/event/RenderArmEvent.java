/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_742;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderArmEvent
/*    */   extends Event
/*    */ {
/*    */   public class_742 player;
/*    */   public float tickDelta;
/*    */   public float pitch;
/*    */   public class_1268 hand;
/*    */   public float swingProgress;
/*    */   public class_1799 item;
/*    */   public float equipProgress;
/*    */   public class_4587 matrices;
/*    */   public class_4597 vertexConsumers;
/*    */   public int light;
/*    */   
/*    */   public RenderArmEvent(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light) {
/* 39 */     this.player = player;
/* 40 */     this.tickDelta = tickDelta;
/* 41 */     this.pitch = pitch;
/* 42 */     this.hand = hand;
/* 43 */     this.swingProgress = swingProgress;
/* 44 */     this.item = item;
/* 45 */     this.equipProgress = equipProgress;
/* 46 */     this.matrices = matrices;
/* 47 */     this.vertexConsumers = vertexConsumers;
/* 48 */     this.light = light;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\RenderArmEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */