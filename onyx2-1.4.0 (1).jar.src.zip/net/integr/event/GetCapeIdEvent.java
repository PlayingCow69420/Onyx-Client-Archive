/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_742;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetCapeIdEvent
/*    */   extends Event
/*    */ {
/*    */   public class_742 player;
/*    */   
/*    */   public GetCapeIdEvent(class_742 player) {
/* 26 */     this.player = player;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\GetCapeIdEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */