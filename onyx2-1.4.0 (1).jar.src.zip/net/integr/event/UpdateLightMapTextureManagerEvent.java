/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateLightMapTextureManagerEvent
/*    */   extends Event
/*    */ {
/*    */   public Args args;
/*    */   
/*    */   public UpdateLightMapTextureManagerEvent(Args args) {
/* 26 */     this.args = args;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\UpdateLightMapTextureManagerEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */