/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_3414;
/*    */ import net.minecraft.class_3419;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaySoundEvent
/*    */   extends Event
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   public class_3414 event;
/*    */   public class_3419 category;
/*    */   public float volume;
/*    */   public float pitch;
/*    */   public boolean useDistance;
/*    */   public long seed;
/*    */   
/*    */   public PlaySoundEvent(double x, double y, double z, class_3414 event, class_3419 category, float volume, float pitch, boolean useDistance, long seed) {
/* 39 */     this.x = x;
/* 40 */     this.y = y;
/* 41 */     this.z = z;
/* 42 */     this.event = event;
/* 43 */     this.category = category;
/* 44 */     this.volume = volume;
/* 45 */     this.pitch = pitch;
/* 46 */     this.useDistance = useDistance;
/* 47 */     this.seed = seed;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\PlaySoundEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */