/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_742;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetPlayerEntityScaleEvent
/*    */   extends Event
/*    */ {
/*    */   public class_742 player;
/*    */   public class_4587 matrices;
/*    */   public float amount;
/*    */   
/*    */   public GetPlayerEntityScaleEvent(class_742 player, class_4587 matrices, float amount) {
/* 29 */     this.player = player;
/* 30 */     this.matrices = matrices;
/* 31 */     this.amount = amount;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\GetPlayerEntityScaleEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */