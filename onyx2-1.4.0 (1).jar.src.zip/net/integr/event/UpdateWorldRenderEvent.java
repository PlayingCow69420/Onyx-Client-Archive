/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_4587;
/*    */ import org.joml.Matrix4f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateWorldRenderEvent
/*    */   extends Event
/*    */ {
/*    */   public class_4587 matrices;
/*    */   public Matrix4f matrix4f;
/*    */   
/*    */   public UpdateWorldRenderEvent(class_4587 matrices, Matrix4f matrix4f) {
/* 28 */     this.matrices = matrices;
/* 29 */     this.matrix4f = matrix4f;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\UpdateWorldRenderEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */