/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1268;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwingHandEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1268 hand;
/*    */   
/*    */   public SwingHandEvent(class_1268 hand) {
/* 26 */     this.hand = hand;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\SwingHandEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */