/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1304;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_572;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderArmorEvent
/*    */   extends Event
/*    */ {
/*    */   public class_4587 matrices;
/*    */   public class_4597 vertexConsumers;
/*    */   public class_1297 entity;
/*    */   public class_1304 armorSlot;
/*    */   public int light;
/*    */   public class_572<?> model;
/*    */   
/*    */   public RenderArmorEvent(class_572<?> model, int light, class_1304 armorSlot, class_1297 entity, class_4597 vertexConsumers, class_4587 matrices) {
/* 35 */     this.model = model;
/* 36 */     this.light = light;
/* 37 */     this.armorSlot = armorSlot;
/* 38 */     this.entity = entity;
/* 39 */     this.vertexConsumers = vertexConsumers;
/* 40 */     this.matrices = matrices;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\RenderArmorEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */