/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TitleScreenMouseClickedEvent
/*    */   extends Event
/*    */ {
/*    */   public double mouseX;
/*    */   public double mouseY;
/*    */   public int button;
/*    */   
/*    */   public TitleScreenMouseClickedEvent(double mouseX, double mouseY, int button) {
/* 27 */     this.mouseX = mouseX;
/* 28 */     this.mouseY = mouseY;
/* 29 */     this.button = button;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\TitleScreenMouseClickedEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */