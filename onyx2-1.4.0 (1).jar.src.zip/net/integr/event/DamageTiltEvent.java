/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DamageTiltEvent
/*    */   extends Event
/*    */ {
/*    */   public class_4587 matrices;
/*    */   public float tickDelta;
/*    */   
/*    */   public DamageTiltEvent(class_4587 matrices, float tickDelta) {
/* 27 */     this.matrices = matrices;
/* 28 */     this.tickDelta = tickDelta;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\DamageTiltEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */