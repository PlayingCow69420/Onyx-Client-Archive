/*    */ package net.integr.event;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_638;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityRemoveEvent
/*    */   extends Event
/*    */ {
/*    */   public int entityId;
/*    */   public class_1297.class_5529 removalReason;
/*    */   public class_1297 entity;
/*    */   
/*    */   public EntityRemoveEvent(int entityId, class_1297.class_5529 removalReason) {
/* 32 */     this.entityId = entityId;
/* 33 */     this.removalReason = removalReason;
/*    */     
/* 35 */     this.entity = ((class_638)Objects.<class_638>requireNonNull((Onyx.Companion.getMC()).field_1687)).method_8469(entityId);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\EntityRemoveEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */