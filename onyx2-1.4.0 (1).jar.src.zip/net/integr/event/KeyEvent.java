/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyEvent
/*    */   extends Event
/*    */ {
/*    */   public int key;
/*    */   public int scancode;
/*    */   public int action;
/*    */   public int modifiers;
/*    */   
/*    */   public KeyEvent(int key, int scancode, int action, int modifiers) {
/* 28 */     this.key = key;
/* 29 */     this.scancode = scancode;
/* 30 */     this.action = action;
/* 31 */     this.modifiers = modifiers;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\KeyEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */