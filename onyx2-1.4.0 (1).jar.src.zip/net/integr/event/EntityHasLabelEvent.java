/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1309;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityHasLabelEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1309 entity;
/*    */   
/*    */   public EntityHasLabelEvent(class_1309 entity) {
/* 26 */     this.entity = entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\EntityHasLabelEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */