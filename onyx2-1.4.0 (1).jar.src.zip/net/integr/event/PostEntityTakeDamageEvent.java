/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1282;
/*    */ import net.minecraft.class_1297;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostEntityTakeDamageEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1297 entity;
/*    */   public class_1282 source;
/*    */   public float amount;
/*    */   
/*    */   public PostEntityTakeDamageEvent(class_1297 entity, class_1282 source, float amount) {
/* 29 */     this.entity = entity;
/* 30 */     this.source = source;
/* 31 */     this.amount = amount;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\PostEntityTakeDamageEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */