/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SendCommandEvent
/*    */   extends Event
/*    */ {
/*    */   public String command;
/*    */   
/*    */   public SendCommandEvent(String command) {
/* 25 */     this.command = command;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\SendCommandEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */