/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_2394;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpawnParticleEvent
/*    */   extends Event
/*    */ {
/*    */   public class_2394 parameters;
/*    */   public boolean alwaysSpawn;
/*    */   public boolean canSpawnOnMinimal;
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   public double velocityX;
/*    */   public double velocityY;
/*    */   public double velocityZ;
/*    */   
/*    */   public SpawnParticleEvent(class_2394 parameters, boolean alwaysSpawn, boolean canSpawnOnMinimal, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
/* 34 */     this.parameters = parameters;
/* 35 */     this.alwaysSpawn = alwaysSpawn;
/* 36 */     this.canSpawnOnMinimal = canSpawnOnMinimal;
/* 37 */     this.x = x;
/* 38 */     this.y = y;
/* 39 */     this.z = z;
/* 40 */     this.velocityX = velocityX;
/* 41 */     this.velocityY = velocityY;
/* 42 */     this.velocityZ = velocityZ;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\SpawnParticleEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */