/*    */ package net.integr.event;
/*    */ 
/*    */ import net.integr.eventsystem.Event;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderEntityEvent
/*    */   extends Event
/*    */ {
/*    */   public class_1297 entity;
/*    */   public double cameraX;
/*    */   public double cameraY;
/*    */   public double cameraZ;
/*    */   public float tickDelta;
/*    */   public class_4587 matrices;
/*    */   public class_4597 vertexConsumers;
/*    */   
/*    */   public RenderEntityEvent(class_1297 entity, double cameraX, double cameraY, double cameraZ, float tickDelta, class_4587 matrices, class_4597 vertexConsumers) {
/* 34 */     this.entity = entity;
/* 35 */     this.cameraX = cameraX;
/* 36 */     this.cameraY = cameraY;
/* 37 */     this.cameraZ = cameraZ;
/* 38 */     this.tickDelta = tickDelta;
/* 39 */     this.matrices = matrices;
/* 40 */     this.vertexConsumers = vertexConsumers;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\event\RenderEntityEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */