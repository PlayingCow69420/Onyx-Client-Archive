/*    */ package net.integr;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/Settings$Companion;", "", "<init>", "()V", "Lnet/integr/Settings;", "INSTANCE", "Lnet/integr/Settings;", "getINSTANCE", "()Lnet/integr/Settings;", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final Settings getINSTANCE() {
/* 36 */     return Settings.access$getINSTANCE$cp();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\Settings$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */