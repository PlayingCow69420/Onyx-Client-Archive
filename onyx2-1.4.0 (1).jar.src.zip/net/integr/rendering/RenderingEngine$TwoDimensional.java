/*     */ package net.integr.rendering;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.internal.ProgressionUtilKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Settings;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.minecraft.class_1921;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4588;
/*     */ import net.minecraft.class_5253;
/*     */ import net.minecraft.class_5944;
/*     */ import net.minecraft.class_757;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/RenderingEngine$TwoDimensional;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class TwoDimensional
/*     */ {
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\007\n\002\b\004\n\002\020\b\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J?\020\016\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\b\020\f\032\004\030\0010\013¢\006\004\b\016\020\017J_\020\027\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\020\032\0020\t2\006\020\022\032\0020\0212\006\020\023\032\0020\0042\006\020\024\032\0020\0042\b\b\002\020\026\032\0020\025¢\006\004\b\027\020\030JW\020\032\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\031\032\0020\t2\006\020\023\032\0020\0042\006\020\024\032\0020\0042\006\020\f\032\0020\013H\002¢\006\004\b\032\020\033JM\020\034\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\022\032\0020\0212\006\020\023\032\0020\0042\006\020\024\032\0020\004¢\006\004\b\034\020\035JO\020\036\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\023\032\0020\0042\006\020\024\032\0020\0042\006\020\f\032\0020\013H\002¢\006\004\b\036\020\037J=\020 \032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\f\032\0020\013¢\006\004\b \020\017¨\006!"}, d2 = {"Lnet/integr/rendering/RenderingEngine$TwoDimensional$Companion;", "", "<init>", "()V", "", "xp1", "yp1", "xp2", "yp2", "", "color", "Lorg/joml/Matrix4f;", "matrix4f", "", "fill", "(FFFFILorg/joml/Matrix4f;)V", "outlineColor", "Lnet/minecraft/class_332;", "context", "precision", "radius", "", "glow", "fillRound", "(FFFFIILnet/minecraft/class_332;FFZ)V", "colorOutline", "fillRoundM4f", "(FFFFIIFFLorg/joml/Matrix4f;)V", "fillRoundNoOutline", "(FFFFILnet/minecraft/class_332;FF)V", "fillRoundNoOutlineM4f", "(FFFFIFFLorg/joml/Matrix4f;)V", "line", "onyx2"})
/*     */   public static final class Companion
/*     */   {
/*     */     private Companion() {}
/*     */     
/*     */     private static final class_5944 line$lambda$0() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */     
/*     */     public final void line(float xp1, float yp1, float xp2, float yp2, int color, @NotNull Matrix4f matrix4f) {
/* 618 */       Intrinsics.checkNotNullParameter(matrix4f, "matrix4f"); float x1 = xp1;
/* 619 */       float y1 = yp1;
/* 620 */       float x2 = xp2;
/* 621 */       float y2 = yp2;
/* 622 */       GL11.glDisable(2929);
/*     */       
/* 624 */       float i = 0.0F;
/* 625 */       if (x1 < x2) {
/* 626 */         i = x1;
/* 627 */         x1 = x2;
/* 628 */         x2 = i;
/*     */       } 
/*     */       
/* 631 */       if (y1 < y2) {
/* 632 */         i = y1;
/* 633 */         y1 = y2;
/* 634 */         y2 = i;
/*     */       } 
/*     */       
/* 637 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 639 */       RenderSystem.setShader(Companion::line$lambda$0);
/* 640 */       Color col = new Color(color);
/*     */       
/* 642 */       RenderSystem.setShaderColor(
/* 643 */           col.getRed() / 255.0F, 
/* 644 */           col.getGreen() / 255.0F, 
/* 645 */           col.getBlue() / 255.0F, 
/* 646 */           0.5F);
/*     */ 
/*     */       
/* 649 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/*     */ 
/*     */       
/* 652 */       bufferBuilder.method_22918(matrix4f, x1, y1, 0.0F);
/* 653 */       bufferBuilder.method_22918(matrix4f, x2, y2, 0.0F);
/*     */ 
/*     */       
/* 656 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */       
/* 658 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 659 */       GL11.glEnable(2929);
/*     */     }
/*     */     
/*     */     private final void fillRoundM4f(float xp1, float yp1, float xp2, float yp2, int color, int colorOutline, float precision, float radius, Matrix4f matrix4f) {
/* 663 */       float x1 = xp1;
/* 664 */       float y1 = yp1;
/* 665 */       float x2 = xp2;
/* 666 */       float y2 = yp2;
/*     */       
/* 668 */       GL11.glEnable(3042);
/*     */       
/* 670 */       GL11.glEnable(2848);
/* 671 */       GL11.glEnable(2881);
/*     */       
/* 673 */       float i = 0.0F;
/* 674 */       if (x1 < x2) {
/* 675 */         i = x1;
/* 676 */         x1 = x2;
/* 677 */         x2 = i;
/*     */       } 
/*     */       
/* 680 */       if (y1 < y2) {
/* 681 */         i = y1;
/* 682 */         y1 = y2;
/* 683 */         y2 = i;
/*     */       } 
/*     */       
/* 686 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 688 */       RenderSystem.setShader(Companion::fillRoundM4f$lambda$1);
/* 689 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */       
/* 691 */       Color colOut = new Color(colorOutline);
/* 692 */       RenderSystem.setShaderColor(
/* 693 */           colOut.getRed() / 255.0F, 
/* 694 */           colOut.getGreen() / 255.0F, 
/* 695 */           colOut.getBlue() / 255.0F, 
/* 696 */           colOut.getAlpha() / 255.0F);
/*     */ 
/*     */       
/* 699 */       double angle = 0.0D;
/* 700 */       while (angle <= 6.283185307179586D) {
/* 701 */         float x = (float)Math.cos(angle) * radius;
/* 702 */         float y = (float)Math.sin(angle) * radius;
/* 703 */         bufferBuilder.method_22918(matrix4f, x1 + 1.2F - radius + x, y1 + 1.2F - radius + y, 0.0F);
/* 704 */         bufferBuilder.method_22918(matrix4f, x1 + 1.2F - radius + x, y2 - 1.2F + radius - y, 0.0F);
/* 705 */         bufferBuilder.method_22918(matrix4f, x2 - 1.2F + radius - x, y2 - 1.2F + radius - y, 0.0F);
/* 706 */         bufferBuilder.method_22918(matrix4f, x2 - 1.2F + radius - x, y1 + 1.2F - radius + y, 0.0F);
/* 707 */         angle += precision;
/*     */       } 
/*     */       
/* 710 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */       
/* 712 */       bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */       
/* 714 */       Color col = new Color(color);
/* 715 */       RenderSystem.setShaderColor(
/* 716 */           col.getRed() / 255.0F, 
/* 717 */           col.getGreen() / 255.0F, 
/* 718 */           col.getBlue() / 255.0F, 
/* 719 */           col.getAlpha() / 255.0F);
/*     */ 
/*     */       
/* 722 */       angle = 0.0D;
/* 723 */       while (angle <= 6.283185307179586D) {
/* 724 */         float x = (float)Math.cos(angle) * radius;
/* 725 */         float y = (float)Math.sin(angle) * radius;
/* 726 */         bufferBuilder.method_22918(matrix4f, x1 - radius + x, y1 - radius + y, 0.0F);
/* 727 */         bufferBuilder.method_22918(matrix4f, x1 - radius + x, y2 + radius - y, 0.0F);
/* 728 */         bufferBuilder.method_22918(matrix4f, x2 + radius - x, y2 + radius - y, 0.0F);
/* 729 */         bufferBuilder.method_22918(matrix4f, x2 + radius - x, y1 - radius + y, 0.0F);
/* 730 */         angle += precision;
/*     */       } 
/*     */       
/* 733 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */       
/* 735 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 736 */       GL11.glDisable(2848);
/* 737 */       GL11.glDisable(2881);
/*     */       
/* 739 */       GL11.glDisable(3042);
/*     */     } private static final class_5944 fillRoundM4f$lambda$1() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */     private final void fillRoundNoOutlineM4f(float xp1, float yp1, float xp2, float yp2, int color, float precision, float radius, Matrix4f matrix4f) {
/* 744 */       float x1 = xp1;
/* 745 */       float y1 = yp1;
/* 746 */       float x2 = xp2;
/* 747 */       float y2 = yp2;
/*     */       
/* 749 */       GL11.glEnable(3042);
/*     */       
/* 751 */       GL11.glEnable(2848);
/* 752 */       GL11.glEnable(2881);
/*     */       
/* 754 */       float i = 0.0F;
/* 755 */       if (x1 < x2) {
/* 756 */         i = x1;
/* 757 */         x1 = x2;
/* 758 */         x2 = i;
/*     */       } 
/*     */       
/* 761 */       if (y1 < y2) {
/* 762 */         i = y1;
/* 763 */         y1 = y2;
/* 764 */         y2 = i;
/*     */       } 
/*     */       
/* 767 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 769 */       RenderSystem.setShader(Companion::fillRoundNoOutlineM4f$lambda$2);
/* 770 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */       
/* 772 */       Color col = new Color(color);
/* 773 */       RenderSystem.setShaderColor(
/* 774 */           col.getRed() / 255.0F, 
/* 775 */           col.getGreen() / 255.0F, 
/* 776 */           col.getBlue() / 255.0F, 
/* 777 */           col.getAlpha() / 255.0F);
/*     */ 
/*     */       
/* 780 */       double angle = 0.0D;
/* 781 */       while (angle <= 6.283185307179586D) {
/* 782 */         float x = (float)Math.cos(angle) * radius;
/* 783 */         float y = (float)Math.sin(angle) * radius;
/* 784 */         bufferBuilder.method_22918(matrix4f, x1 - radius + x, y1 - radius + y, 0.0F);
/* 785 */         bufferBuilder.method_22918(matrix4f, x1 - radius + x, y2 + radius - y, 0.0F);
/* 786 */         bufferBuilder.method_22918(matrix4f, x2 + radius - x, y2 + radius - y, 0.0F);
/* 787 */         bufferBuilder.method_22918(matrix4f, x2 + radius - x, y1 - radius + y, 0.0F);
/* 788 */         angle += precision;
/*     */       } 
/*     */       
/* 791 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */       
/* 793 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 794 */       GL11.glDisable(2848);
/* 795 */       GL11.glDisable(2881);
/*     */       
/* 797 */       GL11.glDisable(3042);
/*     */     } private static final class_5944 fillRoundNoOutlineM4f$lambda$2() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */     public final void fill(float xp1, float yp1, float xp2, float yp2, int color, @Nullable Matrix4f matrix4f) {
/* 802 */       float x1 = xp1;
/* 803 */       float y1 = yp1;
/* 804 */       float x2 = xp2;
/* 805 */       float y2 = yp2;
/* 806 */       GL11.glDisable(2929);
/*     */       
/* 808 */       float i = 0.0F;
/* 809 */       if (x1 < x2) {
/* 810 */         i = x1;
/* 811 */         x1 = x2;
/* 812 */         x2 = i;
/*     */       } 
/*     */       
/* 815 */       if (y1 < y2) {
/* 816 */         i = y1;
/* 817 */         y1 = y2;
/* 818 */         y2 = i;
/*     */       } 
/*     */       
/* 821 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 823 */       RenderSystem.setShader(Companion::fill$lambda$3);
/* 824 */       Color col = new Color(color);
/* 825 */       RenderSystem.setShaderColor(
/* 826 */           col.getRed() / 255.0F, 
/* 827 */           col.getGreen() / 255.0F, 
/* 828 */           col.getBlue() / 255.0F, 
/* 829 */           0.5F);
/*     */ 
/*     */       
/* 832 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */       
/* 834 */       bufferBuilder.method_22918(matrix4f, x1, y1, 0.0F);
/* 835 */       bufferBuilder.method_22918(matrix4f, x1, y2, 0.0F);
/* 836 */       bufferBuilder.method_22918(matrix4f, x2, y2, 0.0F);
/* 837 */       bufferBuilder.method_22918(matrix4f, x2, y1, 0.0F);
/*     */       
/* 839 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */       
/* 841 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 842 */       GL11.glEnable(2929);
/*     */     }
/*     */     
/*     */     public final void fillRoundNoOutline(float xp1, float yp1, float xp2, float yp2, int color, @NotNull class_332 context, float precision, float radius) {
/* 846 */       Intrinsics.checkNotNullParameter(context, "context"); float x1 = xp1;
/* 847 */       float y1 = yp1;
/* 848 */       float x2 = xp2;
/* 849 */       float y2 = yp2;
/*     */       
/* 851 */       Matrix4f matrix4f = context.method_51448().method_23760().method_23761();
/* 852 */       GL11.glEnable(2881);
/* 853 */       GL11.glEnable(3042);
/* 854 */       GL11.glBlendFunc(770, 1);
/* 855 */       GL11.glHint(3155, 4354);
/*     */       
/* 857 */       float i = 0.0F;
/* 858 */       if (x1 < x2) {
/* 859 */         i = x1;
/* 860 */         x1 = x2;
/* 861 */         x2 = i;
/*     */       } 
/*     */       
/* 864 */       if (y1 < y2) {
/* 865 */         i = y1;
/* 866 */         y1 = y2;
/* 867 */         y2 = i;
/*     */       } 
/*     */       
/* 870 */       float f = class_5253.class_5254.method_27762(color) / 255.0F;
/* 871 */       float g = class_5253.class_5254.method_27765(color) / 255.0F;
/* 872 */       float h = class_5253.class_5254.method_27766(color) / 255.0F;
/* 873 */       float j = class_5253.class_5254.method_27767(color) / 255.0F;
/* 874 */       class_4588 vertexConsumer = context.method_51450().getBuffer(class_1921.method_51784());
/*     */       
/* 876 */       double angle = 0.0D;
/* 877 */       while (angle <= 6.283185307179586D) {
/* 878 */         float x = (float)Math.cos(angle) * radius;
/* 879 */         float y = (float)Math.sin(angle) * radius;
/* 880 */         vertexConsumer.method_22918(matrix4f, x1 - radius + x, y1 - radius + y, 0.0F).method_22915(g, h, j, f);
/* 881 */         vertexConsumer.method_22918(matrix4f, x1 - radius + x, y2 + radius - y, 0.0F).method_22915(g, h, j, f);
/* 882 */         vertexConsumer.method_22918(matrix4f, x2 + radius - x, y2 + radius - y, 0.0F).method_22915(g, h, j, f);
/* 883 */         vertexConsumer.method_22918(matrix4f, x2 + radius - x, y1 - radius + y, 0.0F).method_22915(g, h, j, f);
/* 884 */         angle += precision;
/*     */       } 
/*     */       
/* 887 */       context.method_51452();
/*     */       
/* 889 */       GL11.glDisable(2881);
/* 890 */       GL11.glDisable(3042);
/*     */     } private static final class_5944 fill$lambda$3() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */     public final void fillRound(float xp1, float yp1, float xp2, float yp2, int color, int outlineColor, @NotNull class_332 context, float precision, float radius, boolean glow) {
/* 895 */       Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("glow")); if (glow && ((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("glow")).getEnabled()) {
/* 896 */         Color tColor = new Color(outlineColor);
/* 897 */         Color colorC = new Color(tColor.getRed(), tColor.getGreen(), tColor.getBlue(), 4);
/*     */         
/* 899 */         int i = 2, j = ProgressionUtilKt.getProgressionLastElement(2, 32, 4); if (i <= j)
/* 900 */           while (true) { int v = 1 + i / 10;
/* 901 */             fillRoundNoOutline(xp1 - v, yp1 - v, xp2 + v, yp2 + v, colorC.getRGB(), context, precision, radius); if (i != j) {
/*     */               i += 4; continue;
/*     */             }  break; }
/*     */            
/* 905 */       }  fillRoundNoOutline(xp1 - 1.1F, yp1 - 1.1F, xp2 + 1.1F, yp2 + 1.1F, outlineColor, context, precision, radius);
/*     */       
/* 907 */       fillRoundNoOutline(xp1, yp1, xp2, yp2, color, context, precision, radius);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\RenderingEngine$TwoDimensional.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */