/*    */ package net.integr.rendering.screens;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Settings;
/*    */ import net.integr.event.UiRenderEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.ModuleManager;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*    */ import net.integr.rendering.uisystem.Box;
/*    */ import net.minecraft.class_332;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\004\030\000 \f2\0020\001:\001\fB\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\026\020\n\032\0020\t8\002@\002X\016¢\006\006\n\004\b\n\020\013¨\006\r"}, d2 = {"Lnet/integr/rendering/screens/GameScreen;", "", "<init>", "()V", "Lnet/integr/event/UiRenderEvent;", "event", "", "onRenderUi", "(Lnet/integr/event/UiRenderEvent;)V", "Lnet/integr/rendering/uisystem/Box;", "branding", "Lnet/integr/rendering/uisystem/Box;", "Companion", "onyx2"})
/*    */ public final class GameScreen
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/GameScreen$Companion;", "", "<init>", "()V", "Lnet/integr/rendering/screens/GameScreen;", "INSTANCE", "Lnet/integr/rendering/screens/GameScreen;", "getINSTANCE", "()Lnet/integr/rendering/screens/GameScreen;", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     @NotNull
/*    */     public final GameScreen getINSTANCE() {
/* 30 */       return GameScreen.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @NotNull private static final GameScreen INSTANCE = new GameScreen();
/*    */   
/*    */   @NotNull
/* 33 */   private Box branding = new Box(5, 5, 70, 20, "Onyx v" + Onyx.Companion.getVERSION(), false, true, false, 128, null);
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onRenderUi(@NotNull UiRenderEvent event) {
/* 38 */     Intrinsics.checkNotNullParameter(event, "event"); class_332 context = event.context;
/* 39 */     float delta = event.tickDelta;
/*    */     
/* 41 */     for (Module m : ModuleManager.Companion.getUiModules()) {
/* 42 */       Intrinsics.checkNotNull(m, "null cannot be cast to non-null type net.integr.modules.management.UiModule"); UiModule module = (UiModule)m;
/* 43 */       if (m.isEnabled()) { Intrinsics.checkNotNull(context); module.runRender(context, delta); }
/*    */     
/*    */     } 
/* 46 */     Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("watermark")); if (((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("watermark")).isEnabled()) { Intrinsics.checkNotNull(context); this.branding.method_25394(context, 0, 0, delta); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\GameScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */