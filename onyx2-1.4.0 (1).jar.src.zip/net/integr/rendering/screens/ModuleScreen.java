/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.IconButton;
/*     */ import net.integr.rendering.uisystem.UiLayout;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.integr.rendering.uisystem.util.RenderLerper;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000b\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\002\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\006\n\002\b\n\n\002\030\002\n\000\n\002\020\007\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\006\n\002\020!\n\002\030\002\n\002\b\005\030\0002\0020\001:\0016B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\026¢\006\004\b\007\020\bJ'\020\016\032\0020\r2\006\020\n\032\0020\t2\006\020\013\032\0020\t2\006\020\f\032\0020\tH\026¢\006\004\b\016\020\017J'\020\024\032\0020\r2\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\023\032\0020\tH\026¢\006\004\b\024\020\025J'\020\026\032\0020\r2\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\023\032\0020\tH\026¢\006\004\b\026\020\025J/\020\031\032\0020\r2\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\027\032\0020\0202\006\020\030\032\0020\020H\026¢\006\004\b\031\020\032J/\020\037\032\0020\0062\006\020\034\032\0020\0332\006\020\021\032\0020\t2\006\020\022\032\0020\t2\006\020\036\032\0020\035H\026¢\006\004\b\037\020 J1\020!\032\0020\0062\b\020\034\032\004\030\0010\0332\006\020\021\032\0020\t2\006\020\022\032\0020\t2\006\020\036\032\0020\035H\026¢\006\004\b!\020 R\030\020#\032\004\030\0010\"8\002@\002X\016¢\006\006\n\004\b#\020$R\030\020&\032\004\030\0010%8\002@\002X\016¢\006\006\n\004\b&\020'R\026\020(\032\0020\t8\002@\002X\016¢\006\006\n\004\b(\020)R\024\020+\032\0020*8\002X\004¢\006\006\n\004\b+\020,R\030\020\003\032\004\030\0010\0028\002@\002X\016¢\006\006\n\004\b\003\020-R\026\020.\032\0020\t8\002@\002X\016¢\006\006\n\004\b.\020)R\026\020/\032\0020\t8\002@\002X\016¢\006\006\n\004\b/\020)R\026\0200\032\0020\t8\002@\002X\016¢\006\006\n\004\b0\020)R\032\0203\032\b\022\004\022\00202018\002X\004¢\006\006\n\004\b3\0204R\030\0205\032\004\030\0010\"8\002@\002X\016¢\006\006\n\004\b5\020$¨\0067"}, d2 = {"Lnet/integr/rendering/screens/ModuleScreen;", "Lnet/minecraft/class_437;", "Lnet/integr/modules/management/Module;", "mod", "<init>", "(Lnet/integr/modules/management/Module;)V", "", "close", "()V", "", "keyCode", "scanCode", "modifiers", "", "keyPressed", "(III)Z", "", "mouseX", "mouseY", "button", "mouseClicked", "(DDI)Z", "mouseReleased", "horizontalAmount", "verticalAmount", "mouseScrolled", "(DDDD)Z", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderBackground", "Lnet/integr/rendering/uisystem/Box;", "backgroundBox", "Lnet/integr/rendering/uisystem/Box;", "Lnet/integr/rendering/uisystem/IconButton;", "closeButton", "Lnet/integr/rendering/uisystem/IconButton;", "currentScrollPaneY", "I", "Lnet/integr/rendering/uisystem/UiLayout;", "layout", "Lnet/integr/rendering/uisystem/UiLayout;", "Lnet/integr/modules/management/Module;", "oldHeight", "preInitSizeX", "preInitSizeY", "", "Lnet/integr/rendering/screens/ModuleScreen$PosWrapper;", "settings", "Ljava/util/List;", "titleBox", "PosWrapper", "onyx2"})
/*     */ public final class ModuleScreen
/*     */   extends class_437
/*     */ {
/*     */   @NotNull
/*     */   private final UiLayout layout;
/*     */   @Nullable
/*     */   private Box backgroundBox;
/*     */   @Nullable
/*     */   private Box titleBox;
/*     */   @Nullable
/*     */   private IconButton closeButton;
/*     */   private int preInitSizeY;
/*     */   private int preInitSizeX;
/*     */   @NotNull
/*     */   private final List<PosWrapper> settings;
/*     */   private int currentScrollPaneY;
/*     */   @Nullable
/*     */   private Module mod;
/*     */   private int oldHeight;
/*     */   
/*     */   public ModuleScreen(@NotNull Module mod) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 'mod'
/*     */     //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_0
/*     */     //   7: aload_1
/*     */     //   8: invokevirtual getDisplayName : ()Ljava/lang/String;
/*     */     //   11: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   16: invokestatic method_43470 : (Ljava/lang/String;)Lnet/minecraft/class_5250;
/*     */     //   19: checkcast net/minecraft/class_2561
/*     */     //   22: invokespecial <init> : (Lnet/minecraft/class_2561;)V
/*     */     //   25: aload_0
/*     */     //   26: new net/integr/rendering/uisystem/UiLayout
/*     */     //   29: dup
/*     */     //   30: invokespecial <init> : ()V
/*     */     //   33: putfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   36: aload_0
/*     */     //   37: iconst_5
/*     */     //   38: putfield preInitSizeY : I
/*     */     //   41: aload_0
/*     */     //   42: sipush #210
/*     */     //   45: putfield preInitSizeX : I
/*     */     //   48: aload_0
/*     */     //   49: new java/util/ArrayList
/*     */     //   52: dup
/*     */     //   53: invokespecial <init> : ()V
/*     */     //   56: checkcast java/util/List
/*     */     //   59: putfield settings : Ljava/util/List;
/*     */     //   62: nop
/*     */     //   63: aload_0
/*     */     //   64: aload_1
/*     */     //   65: putfield mod : Lnet/integr/modules/management/Module;
/*     */     //   68: aload_0
/*     */     //   69: aload_0
/*     */     //   70: getfield field_22790 : I
/*     */     //   73: i2d
/*     */     //   74: ldc2_w 1.8
/*     */     //   77: ddiv
/*     */     //   78: d2i
/*     */     //   79: aload_1
/*     */     //   80: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   83: invokevirtual getOptions : ()Ljava/util/List;
/*     */     //   86: checkcast java/util/Collection
/*     */     //   89: invokeinterface size : ()I
/*     */     //   94: bipush #25
/*     */     //   96: imul
/*     */     //   97: invokestatic min : (II)I
/*     */     //   100: iconst_5
/*     */     //   101: iadd
/*     */     //   102: putfield preInitSizeY : I
/*     */     //   105: iconst_5
/*     */     //   106: istore_2
/*     */     //   107: aload_1
/*     */     //   108: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   111: invokevirtual getOptions : ()Ljava/util/List;
/*     */     //   114: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   119: astore_3
/*     */     //   120: aload_3
/*     */     //   121: invokeinterface hasNext : ()Z
/*     */     //   126: ifeq -> 196
/*     */     //   129: aload_3
/*     */     //   130: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   135: checkcast net/integr/modules/management/settings/Setting
/*     */     //   138: astore #4
/*     */     //   140: aload_0
/*     */     //   141: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   144: aload #4
/*     */     //   146: invokevirtual getUiElement : ()Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   149: dup
/*     */     //   150: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   153: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   156: astore #5
/*     */     //   158: aload #4
/*     */     //   160: invokevirtual getUiElement : ()Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   163: pop
/*     */     //   164: aload_0
/*     */     //   165: getfield settings : Ljava/util/List;
/*     */     //   168: checkcast java/util/Collection
/*     */     //   171: new net/integr/rendering/screens/ModuleScreen$PosWrapper
/*     */     //   174: dup
/*     */     //   175: aload #5
/*     */     //   177: aload #4
/*     */     //   179: iload_2
/*     */     //   180: invokespecial <init> : (Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)V
/*     */     //   183: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   188: pop
/*     */     //   189: iinc #2, 25
/*     */     //   192: nop
/*     */     //   193: goto -> 120
/*     */     //   196: aload_0
/*     */     //   197: aload_0
/*     */     //   198: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   201: new net/integr/rendering/uisystem/Box
/*     */     //   204: dup
/*     */     //   205: aload_0
/*     */     //   206: getfield field_22789 : I
/*     */     //   209: iconst_2
/*     */     //   210: idiv
/*     */     //   211: aload_0
/*     */     //   212: getfield preInitSizeX : I
/*     */     //   215: iconst_2
/*     */     //   216: idiv
/*     */     //   217: isub
/*     */     //   218: aload_0
/*     */     //   219: getfield field_22790 : I
/*     */     //   222: iconst_2
/*     */     //   223: idiv
/*     */     //   224: aload_0
/*     */     //   225: getfield preInitSizeY : I
/*     */     //   228: iconst_2
/*     */     //   229: idiv
/*     */     //   230: isub
/*     */     //   231: bipush #45
/*     */     //   233: isub
/*     */     //   234: aload_0
/*     */     //   235: getfield preInitSizeX : I
/*     */     //   238: bipush #20
/*     */     //   240: aload_1
/*     */     //   241: invokevirtual getDisplayName : ()Ljava/lang/String;
/*     */     //   244: iconst_0
/*     */     //   245: iconst_1
/*     */     //   246: iconst_0
/*     */     //   247: sipush #128
/*     */     //   250: aconst_null
/*     */     //   251: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   254: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   257: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   260: dup
/*     */     //   261: ldc 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   263: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   266: checkcast net/integr/rendering/uisystem/Box
/*     */     //   269: putfield titleBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   272: aload_0
/*     */     //   273: aload_0
/*     */     //   274: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   277: new net/integr/rendering/uisystem/Box
/*     */     //   280: dup
/*     */     //   281: aload_0
/*     */     //   282: getfield field_22789 : I
/*     */     //   285: iconst_2
/*     */     //   286: idiv
/*     */     //   287: aload_0
/*     */     //   288: getfield preInitSizeX : I
/*     */     //   291: iconst_2
/*     */     //   292: idiv
/*     */     //   293: isub
/*     */     //   294: aload_0
/*     */     //   295: getfield field_22790 : I
/*     */     //   298: iconst_2
/*     */     //   299: idiv
/*     */     //   300: aload_0
/*     */     //   301: getfield preInitSizeY : I
/*     */     //   304: iconst_2
/*     */     //   305: idiv
/*     */     //   306: isub
/*     */     //   307: aload_0
/*     */     //   308: getfield preInitSizeX : I
/*     */     //   311: aload_0
/*     */     //   312: getfield preInitSizeY : I
/*     */     //   315: aconst_null
/*     */     //   316: iconst_0
/*     */     //   317: iconst_0
/*     */     //   318: iconst_0
/*     */     //   319: sipush #192
/*     */     //   322: aconst_null
/*     */     //   323: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   326: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   329: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   332: dup
/*     */     //   333: ldc 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   335: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   338: checkcast net/integr/rendering/uisystem/Box
/*     */     //   341: putfield backgroundBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   344: aload_0
/*     */     //   345: aload_0
/*     */     //   346: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   349: new net/integr/rendering/uisystem/IconButton
/*     */     //   352: dup
/*     */     //   353: aload_0
/*     */     //   354: getfield field_22789 : I
/*     */     //   357: iconst_2
/*     */     //   358: idiv
/*     */     //   359: aload_0
/*     */     //   360: getfield preInitSizeX : I
/*     */     //   363: iconst_2
/*     */     //   364: idiv
/*     */     //   365: iadd
/*     */     //   366: bipush #15
/*     */     //   368: isub
/*     */     //   369: aload_0
/*     */     //   370: getfield field_22790 : I
/*     */     //   373: iconst_2
/*     */     //   374: idiv
/*     */     //   375: aload_0
/*     */     //   376: getfield preInitSizeY : I
/*     */     //   379: iconst_2
/*     */     //   380: idiv
/*     */     //   381: isub
/*     */     //   382: bipush #45
/*     */     //   384: isub
/*     */     //   385: bipush #19
/*     */     //   387: bipush #19
/*     */     //   389: ldc 'x'
/*     */     //   391: ldc 'Return to the main gui'
/*     */     //   393: aload_0
/*     */     //   394: <illegal opcode> run : (Lnet/integr/rendering/screens/ModuleScreen;)Ljava/lang/Runnable;
/*     */     //   399: invokespecial <init> : (IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
/*     */     //   402: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   405: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   408: dup
/*     */     //   409: ldc 'null cannot be cast to non-null type net.integr.rendering.uisystem.IconButton'
/*     */     //   411: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   414: checkcast net/integr/rendering/uisystem/IconButton
/*     */     //   417: putfield closeButton : Lnet/integr/rendering/uisystem/IconButton;
/*     */     //   420: nop
/*     */     //   421: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #36	-> 6
/*     */     //   #37	-> 25
/*     */     //   #43	-> 36
/*     */     //   #44	-> 41
/*     */     //   #46	-> 48
/*     */     //   #46	-> 59
/*     */     //   #54	-> 62
/*     */     //   #55	-> 63
/*     */     //   #56	-> 68
/*     */     //   #56	-> 94
/*     */     //   #56	-> 100
/*     */     //   #58	-> 105
/*     */     //   #60	-> 107
/*     */     //   #61	-> 140
/*     */     //   #63	-> 158
/*     */     //   #65	-> 164
/*     */     //   #67	-> 192
/*     */     //   #70	-> 196
/*     */     //   #72	-> 272
/*     */     //   #74	-> 344
/*     */     //   #78	-> 420
/*     */     //   #36	-> 421
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   158	35	5	b	Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   140	53	4	s	Lnet/integr/modules/management/settings/Setting;
/*     */     //   107	313	2	currY	I
/*     */     //   0	422	0	this	Lnet/integr/rendering/screens/ModuleScreen;
/*     */     //   0	422	1	mod	Lnet/integr/modules/management/Module;
/*     */   }
/*     */   
/*     */   private static final void _init_$lambda$0(ModuleScreen this$0) {
/*  75 */     Intrinsics.checkNotNullParameter(this$0, "this$0"); Onyx.Companion.getMC().method_1507(MenuScreen.Companion.getINSTANCE());
/*  76 */     this$0.oldHeight = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  81 */     Intrinsics.checkNotNullParameter(context, "context"); int nHeight = RenderLerper.Companion.lerpWithDefDelta(this.oldHeight, this.field_22790);
/*  82 */     this.oldHeight = nHeight;
/*     */     
/*  84 */     Intrinsics.checkNotNull(this.mod); this.preInitSizeY = Math.min((int)(nHeight / 1.8D), this.mod.getSettings().getOptions().size() * 25) + 5;
/*     */     
/*  86 */     Intrinsics.checkNotNull(this.backgroundBox); this.backgroundBox.setYSize(this.preInitSizeY);
/*  87 */     Intrinsics.checkNotNull(this.backgroundBox); this.backgroundBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2).method_25394(context, mouseX, mouseY, delta);
/*  88 */     Intrinsics.checkNotNull(this.titleBox); this.titleBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2 - 45).method_25394(context, mouseX, mouseY, delta);
/*  89 */     Intrinsics.checkNotNull(this.closeButton); this.closeButton.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 15, nHeight / 2 - this.preInitSizeY / 2 - 45).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  91 */     for (PosWrapper s : this.settings) {
/*  92 */       int cTop = nHeight / 2 - this.preInitSizeY / 2 + s.getYO() - this.currentScrollPaneY;
/*  93 */       int cBottom = nHeight / 2 - this.preInitSizeY / 2 + s.getYO() + 25 - this.currentScrollPaneY;
/*     */       
/*  95 */       Intrinsics.checkNotNull(this.backgroundBox); if (cBottom < nHeight / 2 - this.preInitSizeY / 2 + 5 || cTop > nHeight / 2 - this.preInitSizeY / 2 + this.backgroundBox.getYSize() - 5) {
/*  96 */         this.layout.lock(s.getElement());
/*     */       } else {
/*  98 */         this.layout.unLock(s.getElement());
/*     */       } 
/*     */       
/* 101 */       Intrinsics.checkNotNull(this.backgroundBox); Intrinsics.checkNotNull(this.backgroundBox); context.method_44379(this.field_22789 / 2 - this.preInitSizeX / 2 + 5, nHeight / 2 - this.preInitSizeY / 2 + 5, this.field_22789 / 2 - this.preInitSizeX / 2 + this.backgroundBox.getXSize() - 5, nHeight / 2 - this.preInitSizeY / 2 + this.backgroundBox.getYSize() - 5);
/* 102 */       s.getElement().update(this.field_22789 / 2 - this.preInitSizeX / 2 + 5, nHeight / 2 - this.preInitSizeY / 2 + s.getYO() - this.currentScrollPaneY).method_25394(context, mouseX, mouseY, delta);
/* 103 */       context.method_44380();
/*     */       
/* 105 */       if (s.getSetting() != null) s.getSetting().onUpdate(s.getElement());
/*     */     
/*     */     } 
/* 108 */     boolean shouldReset = true;
/*     */     
/* 110 */     for (PosWrapper s : this.settings) {
/* 111 */       int cTop = nHeight / 2 - this.preInitSizeY / 2 + s.getYO() - this.currentScrollPaneY;
/* 112 */       int cBottom = nHeight / 2 - this.preInitSizeY / 2 + s.getYO() + 25 - this.currentScrollPaneY;
/*     */       
/* 114 */       Intrinsics.checkNotNull(this.backgroundBox); if (cBottom < nHeight / 2 - this.preInitSizeY / 2 + 5 || cTop > nHeight / 2 - this.preInitSizeY / 2 + this.backgroundBox.getYSize() - 5) {
/*     */         continue;
/*     */       }
/*     */       
/* 118 */       if (s.getElement().renderTooltip(context, mouseX, mouseY, delta)) shouldReset = false;
/*     */     
/*     */     } 
/* 121 */     Intrinsics.checkNotNull(this.closeButton); if (this.closeButton.renderTooltip(context, mouseX, mouseY, delta)) shouldReset = false;
/*     */     
/* 123 */     if (shouldReset) this.layout.resetCursor(); 
/*     */   }
/*     */   
/*     */   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
/* 127 */     this.currentScrollPaneY -= (int)verticalAmount * 10;
/*     */     
/* 129 */     if (this.currentScrollPaneY <= 0) this.currentScrollPaneY = 0;
/*     */     
/* 131 */     this.currentScrollPaneY = Math.min(this.currentScrollPaneY, Math.max(0, this.settings.size() * 25 - this.preInitSizeY) + 5);
/* 132 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(@Nullable class_332 context, int mouseX, int mouseY, float delta) {}
/*     */ 
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 140 */     this.layout.onClick(mouseX, mouseY, button);
/* 141 */     return true;
/*     */   }
/*     */   
/*     */   public boolean method_25406(double mouseX, double mouseY, int button) {
/* 145 */     this.layout.onRelease(mouseX, mouseY, button);
/* 146 */     return true;
/*     */   }
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/* 150 */     boolean callback = this.layout.onKey(keyCode, scanCode, modifiers);
/* 151 */     return callback ? true : super.method_25404(keyCode, scanCode, modifiers);
/*     */   }
/*     */   
/*     */   public void method_25419() {
/* 155 */     Onyx.Companion.getMC().method_1507(MenuScreen.Companion.getINSTANCE());
/* 156 */     this.layout.resetCursor();
/* 157 */     this.oldHeight = 0; } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\f\n\002\020\013\n\002\b\003\n\002\020\016\n\002\b\t\b\b\030\0002\0020\001B!\022\006\020\003\032\0020\002\022\b\020\005\032\004\030\0010\004\022\006\020\007\032\0020\006¢\006\004\b\b\020\tJ\020\020\n\032\0020\002HÆ\003¢\006\004\b\n\020\013J\022\020\f\032\004\030\0010\004HÆ\003¢\006\004\b\f\020\rJ\020\020\016\032\0020\006HÆ\003¢\006\004\b\016\020\017J0\020\020\032\0020\0002\b\b\002\020\003\032\0020\0022\n\b\002\020\005\032\004\030\0010\0042\b\b\002\020\007\032\0020\006HÆ\001¢\006\004\b\020\020\021J\032\020\024\032\0020\0232\b\020\022\032\004\030\0010\001HÖ\003¢\006\004\b\024\020\025J\020\020\026\032\0020\006HÖ\001¢\006\004\b\026\020\017J\020\020\030\032\0020\027HÖ\001¢\006\004\b\030\020\031R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\032\032\004\b\033\020\013R\031\020\005\032\004\030\0010\0048\006¢\006\f\n\004\b\005\020\034\032\004\b\035\020\rR\027\020\007\032\0020\0068\006¢\006\f\n\004\b\007\020\036\032\004\b\037\020\017¨\006 "}, d2 = {"Lnet/integr/rendering/screens/ModuleScreen$PosWrapper;", "", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "element", "Lnet/integr/modules/management/settings/Setting;", "setting", "", "yO", "<init>", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)V", "component1", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "component2", "()Lnet/integr/modules/management/settings/Setting;", "component3", "()I", "copy", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)Lnet/integr/rendering/screens/ModuleScreen$PosWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getElement", "Lnet/integr/modules/management/settings/Setting;", "getSetting", "I", "getYO", "onyx2"})
/*     */   public static final class PosWrapper {
/*     */     @NotNull
/* 160 */     private final HelixUiElement element; public PosWrapper(@NotNull HelixUiElement element, @Nullable Setting setting, int yO) { this.element = element; this.setting = setting; this.yO = yO; } @Nullable private final Setting setting; private final int yO; @NotNull public final HelixUiElement getElement() { return this.element; } @Nullable public final Setting getSetting() { return this.setting; } public final int getYO() { return this.yO; }
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     public final HelixUiElement component1() {
/*     */       return this.element;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public final Setting component2() {
/*     */       return this.setting;
/*     */     }
/*     */     
/*     */     public final int component3() {
/*     */       return this.yO;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final PosWrapper copy(@NotNull HelixUiElement element, @Nullable Setting setting, int yO) {
/*     */       Intrinsics.checkNotNullParameter(element, "element");
/*     */       return new PosWrapper(element, setting, yO);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public String toString() {
/*     */       return "PosWrapper(element=" + this.element + ", setting=" + this.setting + ", yO=" + this.yO + ")";
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       result = this.element.hashCode();
/*     */       result = result * 31 + ((this.setting == null) ? 0 : this.setting.hashCode());
/*     */       return result * 31 + Integer.hashCode(this.yO);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/*     */       if (this == other)
/*     */         return true; 
/*     */       if (!(other instanceof PosWrapper))
/*     */         return false; 
/*     */       PosWrapper posWrapper = (PosWrapper)other;
/*     */       return !Intrinsics.areEqual(this.element, posWrapper.element) ? false : (!Intrinsics.areEqual(this.setting, posWrapper.setting) ? false : (!(this.yO != posWrapper.yO)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\ModuleScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */