/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.IconButton;
/*     */ import net.integr.rendering.uisystem.UiLayout;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.integr.rendering.uisystem.util.RenderLerper;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\\\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\020\b\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\006\n\002\b\006\n\002\030\002\n\000\n\002\020\007\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\020!\n\002\030\002\n\002\b\005\030\0002\0020\001:\001-B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J'\020\013\032\0020\n2\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\t\032\0020\006H\026¢\006\004\b\013\020\fJ'\020\021\032\0020\n2\006\020\016\032\0020\r2\006\020\017\032\0020\r2\006\020\020\032\0020\006H\026¢\006\004\b\021\020\022J'\020\023\032\0020\n2\006\020\016\032\0020\r2\006\020\017\032\0020\r2\006\020\020\032\0020\006H\026¢\006\004\b\023\020\022J/\020\030\032\0020\0042\006\020\025\032\0020\0242\006\020\016\032\0020\0062\006\020\017\032\0020\0062\006\020\027\032\0020\026H\026¢\006\004\b\030\020\031J1\020\032\032\0020\0042\b\020\025\032\004\030\0010\0242\006\020\016\032\0020\0062\006\020\017\032\0020\0062\006\020\027\032\0020\026H\026¢\006\004\b\032\020\031R\030\020\034\032\004\030\0010\0338\002@\002X\016¢\006\006\n\004\b\034\020\035R\030\020\037\032\004\030\0010\0368\002@\002X\016¢\006\006\n\004\b\037\020 R\024\020\"\032\0020!8\002X\004¢\006\006\n\004\b\"\020#R\026\020$\032\0020\0068\002@\002X\016¢\006\006\n\004\b$\020%R\026\020&\032\0020\0068\002@\002X\016¢\006\006\n\004\b&\020%R\026\020'\032\0020\0068\002@\002X\016¢\006\006\n\004\b'\020%R\032\020*\032\b\022\004\022\0020)0(8\002X\004¢\006\006\n\004\b*\020+R\030\020,\032\004\030\0010\0338\002@\002X\016¢\006\006\n\004\b,\020\035¨\006."}, d2 = {"Lnet/integr/rendering/screens/SettingsScreen;", "Lnet/minecraft/class_437;", "<init>", "()V", "", "close", "", "keyCode", "scanCode", "modifiers", "", "keyPressed", "(III)Z", "", "mouseX", "mouseY", "button", "mouseClicked", "(DDI)Z", "mouseReleased", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderBackground", "Lnet/integr/rendering/uisystem/Box;", "backgroundBox", "Lnet/integr/rendering/uisystem/Box;", "Lnet/integr/rendering/uisystem/IconButton;", "closeButton", "Lnet/integr/rendering/uisystem/IconButton;", "Lnet/integr/rendering/uisystem/UiLayout;", "layout", "Lnet/integr/rendering/uisystem/UiLayout;", "oldHeight", "I", "preInitSizeX", "preInitSizeY", "", "Lnet/integr/rendering/screens/SettingsScreen$PosWrapper;", "settings", "Ljava/util/List;", "titleBox", "PosWrapper", "onyx2"})
/*     */ public final class SettingsScreen
/*     */   extends class_437
/*     */ {
/*     */   @NotNull
/*     */   private final UiLayout layout;
/*     */   @Nullable
/*     */   private Box backgroundBox;
/*     */   @Nullable
/*     */   private Box titleBox;
/*     */   @Nullable
/*     */   private IconButton closeButton;
/*     */   private int preInitSizeY;
/*     */   private int preInitSizeX;
/*     */   @NotNull
/*     */   private final List<PosWrapper> settings;
/*     */   private int oldHeight;
/*     */   
/*     */   public SettingsScreen() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ldc 'Settings'
/*     */     //   3: invokestatic method_43470 : (Ljava/lang/String;)Lnet/minecraft/class_5250;
/*     */     //   6: checkcast net/minecraft/class_2561
/*     */     //   9: invokespecial <init> : (Lnet/minecraft/class_2561;)V
/*     */     //   12: aload_0
/*     */     //   13: new net/integr/rendering/uisystem/UiLayout
/*     */     //   16: dup
/*     */     //   17: invokespecial <init> : ()V
/*     */     //   20: putfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   23: aload_0
/*     */     //   24: iconst_5
/*     */     //   25: putfield preInitSizeY : I
/*     */     //   28: aload_0
/*     */     //   29: sipush #210
/*     */     //   32: putfield preInitSizeX : I
/*     */     //   35: aload_0
/*     */     //   36: new java/util/ArrayList
/*     */     //   39: dup
/*     */     //   40: invokespecial <init> : ()V
/*     */     //   43: checkcast java/util/List
/*     */     //   46: putfield settings : Ljava/util/List;
/*     */     //   49: nop
/*     */     //   50: aload_0
/*     */     //   51: aload_0
/*     */     //   52: getfield preInitSizeY : I
/*     */     //   55: getstatic net/integr/Settings.Companion : Lnet/integr/Settings$Companion;
/*     */     //   58: invokevirtual getINSTANCE : ()Lnet/integr/Settings;
/*     */     //   61: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   64: invokevirtual getOptions : ()Ljava/util/List;
/*     */     //   67: checkcast java/util/Collection
/*     */     //   70: invokeinterface size : ()I
/*     */     //   75: bipush #25
/*     */     //   77: imul
/*     */     //   78: iadd
/*     */     //   79: putfield preInitSizeY : I
/*     */     //   82: iconst_5
/*     */     //   83: istore_1
/*     */     //   84: getstatic net/integr/Settings.Companion : Lnet/integr/Settings$Companion;
/*     */     //   87: invokevirtual getINSTANCE : ()Lnet/integr/Settings;
/*     */     //   90: invokevirtual getSettings : ()Lnet/integr/modules/management/settings/SettingsBuilder;
/*     */     //   93: invokevirtual getOptions : ()Ljava/util/List;
/*     */     //   96: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   101: astore_2
/*     */     //   102: aload_2
/*     */     //   103: invokeinterface hasNext : ()Z
/*     */     //   108: ifeq -> 174
/*     */     //   111: aload_2
/*     */     //   112: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   117: checkcast net/integr/modules/management/settings/Setting
/*     */     //   120: astore_3
/*     */     //   121: aload_0
/*     */     //   122: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   125: aload_3
/*     */     //   126: invokevirtual getUiElement : ()Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   129: dup
/*     */     //   130: invokestatic checkNotNull : (Ljava/lang/Object;)V
/*     */     //   133: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   136: astore #4
/*     */     //   138: aload_3
/*     */     //   139: invokevirtual getUiElement : ()Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   142: pop
/*     */     //   143: aload_0
/*     */     //   144: getfield settings : Ljava/util/List;
/*     */     //   147: checkcast java/util/Collection
/*     */     //   150: new net/integr/rendering/screens/SettingsScreen$PosWrapper
/*     */     //   153: dup
/*     */     //   154: aload #4
/*     */     //   156: aload_3
/*     */     //   157: iload_1
/*     */     //   158: invokespecial <init> : (Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)V
/*     */     //   161: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   166: pop
/*     */     //   167: iinc #1, 25
/*     */     //   170: nop
/*     */     //   171: goto -> 102
/*     */     //   174: aload_0
/*     */     //   175: aload_0
/*     */     //   176: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   179: new net/integr/rendering/uisystem/Box
/*     */     //   182: dup
/*     */     //   183: aload_0
/*     */     //   184: getfield field_22789 : I
/*     */     //   187: iconst_2
/*     */     //   188: idiv
/*     */     //   189: aload_0
/*     */     //   190: getfield preInitSizeX : I
/*     */     //   193: iconst_2
/*     */     //   194: idiv
/*     */     //   195: isub
/*     */     //   196: aload_0
/*     */     //   197: getfield field_22790 : I
/*     */     //   200: iconst_2
/*     */     //   201: idiv
/*     */     //   202: aload_0
/*     */     //   203: getfield preInitSizeY : I
/*     */     //   206: iconst_2
/*     */     //   207: idiv
/*     */     //   208: isub
/*     */     //   209: bipush #45
/*     */     //   211: isub
/*     */     //   212: aload_0
/*     */     //   213: getfield preInitSizeX : I
/*     */     //   216: bipush #20
/*     */     //   218: ldc 'Settings'
/*     */     //   220: iconst_0
/*     */     //   221: iconst_1
/*     */     //   222: iconst_0
/*     */     //   223: sipush #128
/*     */     //   226: aconst_null
/*     */     //   227: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   230: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   233: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   236: dup
/*     */     //   237: ldc 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   239: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   242: checkcast net/integr/rendering/uisystem/Box
/*     */     //   245: putfield titleBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   248: aload_0
/*     */     //   249: aload_0
/*     */     //   250: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   253: new net/integr/rendering/uisystem/Box
/*     */     //   256: dup
/*     */     //   257: aload_0
/*     */     //   258: getfield field_22789 : I
/*     */     //   261: iconst_2
/*     */     //   262: idiv
/*     */     //   263: aload_0
/*     */     //   264: getfield preInitSizeX : I
/*     */     //   267: iconst_2
/*     */     //   268: idiv
/*     */     //   269: isub
/*     */     //   270: aload_0
/*     */     //   271: getfield field_22790 : I
/*     */     //   274: iconst_2
/*     */     //   275: idiv
/*     */     //   276: aload_0
/*     */     //   277: getfield preInitSizeY : I
/*     */     //   280: iconst_2
/*     */     //   281: idiv
/*     */     //   282: isub
/*     */     //   283: aload_0
/*     */     //   284: getfield preInitSizeX : I
/*     */     //   287: aload_0
/*     */     //   288: getfield preInitSizeY : I
/*     */     //   291: aconst_null
/*     */     //   292: iconst_0
/*     */     //   293: iconst_0
/*     */     //   294: iconst_0
/*     */     //   295: sipush #192
/*     */     //   298: aconst_null
/*     */     //   299: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   302: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   305: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   308: dup
/*     */     //   309: ldc 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   311: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   314: checkcast net/integr/rendering/uisystem/Box
/*     */     //   317: putfield backgroundBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   320: aload_0
/*     */     //   321: aload_0
/*     */     //   322: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   325: new net/integr/rendering/uisystem/IconButton
/*     */     //   328: dup
/*     */     //   329: aload_0
/*     */     //   330: getfield field_22789 : I
/*     */     //   333: iconst_2
/*     */     //   334: idiv
/*     */     //   335: aload_0
/*     */     //   336: getfield preInitSizeX : I
/*     */     //   339: iconst_2
/*     */     //   340: idiv
/*     */     //   341: iadd
/*     */     //   342: bipush #15
/*     */     //   344: isub
/*     */     //   345: aload_0
/*     */     //   346: getfield field_22790 : I
/*     */     //   349: iconst_2
/*     */     //   350: idiv
/*     */     //   351: aload_0
/*     */     //   352: getfield preInitSizeY : I
/*     */     //   355: iconst_2
/*     */     //   356: idiv
/*     */     //   357: isub
/*     */     //   358: bipush #45
/*     */     //   360: isub
/*     */     //   361: bipush #19
/*     */     //   363: bipush #19
/*     */     //   365: ldc 'x'
/*     */     //   367: ldc 'Return to the main gui'
/*     */     //   369: aload_0
/*     */     //   370: <illegal opcode> run : (Lnet/integr/rendering/screens/SettingsScreen;)Ljava/lang/Runnable;
/*     */     //   375: invokespecial <init> : (IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
/*     */     //   378: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   381: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   384: dup
/*     */     //   385: ldc 'null cannot be cast to non-null type net.integr.rendering.uisystem.IconButton'
/*     */     //   387: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   390: checkcast net/integr/rendering/uisystem/IconButton
/*     */     //   393: putfield closeButton : Lnet/integr/rendering/uisystem/IconButton;
/*     */     //   396: nop
/*     */     //   397: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #33	-> 0
/*     */     //   #34	-> 12
/*     */     //   #40	-> 23
/*     */     //   #41	-> 28
/*     */     //   #43	-> 35
/*     */     //   #43	-> 46
/*     */     //   #47	-> 49
/*     */     //   #48	-> 50
/*     */     //   #48	-> 75
/*     */     //   #50	-> 82
/*     */     //   #52	-> 84
/*     */     //   #53	-> 121
/*     */     //   #55	-> 138
/*     */     //   #57	-> 143
/*     */     //   #59	-> 170
/*     */     //   #62	-> 174
/*     */     //   #64	-> 248
/*     */     //   #66	-> 320
/*     */     //   #70	-> 396
/*     */     //   #33	-> 397
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   138	33	4	b	Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   121	50	3	s	Lnet/integr/modules/management/settings/Setting;
/*     */     //   84	312	1	currY	I
/*     */     //   0	398	0	this	Lnet/integr/rendering/screens/SettingsScreen;
/*     */   }
/*     */   
/*     */   private static final void _init_$lambda$0(SettingsScreen this$0) {
/*  67 */     Intrinsics.checkNotNullParameter(this$0, "this$0"); Onyx.Companion.getMC().method_1507(MenuScreen.Companion.getINSTANCE());
/*  68 */     this$0.oldHeight = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  73 */     Intrinsics.checkNotNullParameter(context, "context"); int nHeight = RenderLerper.Companion.lerpWithDefDelta(this.oldHeight, this.field_22790);
/*  74 */     this.oldHeight = nHeight;
/*     */     
/*  76 */     Intrinsics.checkNotNull(this.backgroundBox); this.backgroundBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2).method_25394(context, mouseX, mouseY, delta);
/*  77 */     Intrinsics.checkNotNull(this.titleBox); this.titleBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2 - 45).method_25394(context, mouseX, mouseY, delta);
/*  78 */     Intrinsics.checkNotNull(this.closeButton); this.closeButton.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 15, nHeight / 2 - this.preInitSizeY / 2 - 45).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  80 */     for (PosWrapper s : this.settings) {
/*  81 */       s.getElement().update(this.field_22789 / 2 - this.preInitSizeX / 2 + 5, nHeight / 2 - this.preInitSizeY / 2 + s.getYO()).method_25394(context, mouseX, mouseY, delta);
/*  82 */       if (s.getSetting() != null) s.getSetting().onUpdate(s.getElement());
/*     */     
/*     */     } 
/*  85 */     boolean shouldReset = true;
/*     */     
/*  87 */     for (PosWrapper s : this.settings) {
/*  88 */       if (s.getElement().renderTooltip(context, mouseX, mouseY, delta)) shouldReset = false;
/*     */     
/*     */     } 
/*  91 */     Intrinsics.checkNotNull(this.closeButton); if (this.closeButton.renderTooltip(context, mouseX, mouseY, delta)) shouldReset = false;
/*     */     
/*  93 */     if (shouldReset) this.layout.resetCursor();
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(@Nullable class_332 context, int mouseX, int mouseY, float delta) {}
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 101 */     this.layout.onClick(mouseX, mouseY, button);
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   public boolean method_25406(double mouseX, double mouseY, int button) {
/* 106 */     this.layout.onRelease(mouseX, mouseY, button);
/* 107 */     return true;
/*     */   }
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/* 111 */     boolean callback = this.layout.onKey(keyCode, scanCode, modifiers);
/* 112 */     return callback ? true : super.method_25404(keyCode, scanCode, modifiers);
/*     */   }
/*     */   
/*     */   public void method_25419() {
/* 116 */     Onyx.Companion.getMC().method_1507(MenuScreen.Companion.getINSTANCE());
/* 117 */     this.layout.resetCursor();
/* 118 */     this.oldHeight = 0; } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\f\n\002\020\013\n\002\b\003\n\002\020\016\n\002\b\t\b\b\030\0002\0020\001B!\022\006\020\003\032\0020\002\022\b\020\005\032\004\030\0010\004\022\006\020\007\032\0020\006¢\006\004\b\b\020\tJ\020\020\n\032\0020\002HÆ\003¢\006\004\b\n\020\013J\022\020\f\032\004\030\0010\004HÆ\003¢\006\004\b\f\020\rJ\020\020\016\032\0020\006HÆ\003¢\006\004\b\016\020\017J0\020\020\032\0020\0002\b\b\002\020\003\032\0020\0022\n\b\002\020\005\032\004\030\0010\0042\b\b\002\020\007\032\0020\006HÆ\001¢\006\004\b\020\020\021J\032\020\024\032\0020\0232\b\020\022\032\004\030\0010\001HÖ\003¢\006\004\b\024\020\025J\020\020\026\032\0020\006HÖ\001¢\006\004\b\026\020\017J\020\020\030\032\0020\027HÖ\001¢\006\004\b\030\020\031R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\032\032\004\b\033\020\013R\031\020\005\032\004\030\0010\0048\006¢\006\f\n\004\b\005\020\034\032\004\b\035\020\rR\027\020\007\032\0020\0068\006¢\006\f\n\004\b\007\020\036\032\004\b\037\020\017¨\006 "}, d2 = {"Lnet/integr/rendering/screens/SettingsScreen$PosWrapper;", "", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "element", "Lnet/integr/modules/management/settings/Setting;", "setting", "", "yO", "<init>", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)V", "component1", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "component2", "()Lnet/integr/modules/management/settings/Setting;", "component3", "()I", "copy", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)Lnet/integr/rendering/screens/SettingsScreen$PosWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getElement", "Lnet/integr/modules/management/settings/Setting;", "getSetting", "I", "getYO", "onyx2"})
/*     */   public static final class PosWrapper {
/*     */     @NotNull
/* 121 */     private final HelixUiElement element; public PosWrapper(@NotNull HelixUiElement element, @Nullable Setting setting, int yO) { this.element = element; this.setting = setting; this.yO = yO; } @Nullable private final Setting setting; private final int yO; @NotNull public final HelixUiElement getElement() { return this.element; } @Nullable public final Setting getSetting() { return this.setting; } public final int getYO() { return this.yO; }
/*     */ 
/*     */     
/*     */     @NotNull
/*     */     public final HelixUiElement component1() {
/*     */       return this.element;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public final Setting component2() {
/*     */       return this.setting;
/*     */     }
/*     */     
/*     */     public final int component3() {
/*     */       return this.yO;
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public final PosWrapper copy(@NotNull HelixUiElement element, @Nullable Setting setting, int yO) {
/*     */       Intrinsics.checkNotNullParameter(element, "element");
/*     */       return new PosWrapper(element, setting, yO);
/*     */     }
/*     */     
/*     */     @NotNull
/*     */     public String toString() {
/*     */       return "PosWrapper(element=" + this.element + ", setting=" + this.setting + ", yO=" + this.yO + ")";
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       result = this.element.hashCode();
/*     */       result = result * 31 + ((this.setting == null) ? 0 : this.setting.hashCode());
/*     */       return result * 31 + Integer.hashCode(this.yO);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other) {
/*     */       if (this == other)
/*     */         return true; 
/*     */       if (!(other instanceof PosWrapper))
/*     */         return false; 
/*     */       PosWrapper posWrapper = (PosWrapper)other;
/*     */       return !Intrinsics.areEqual(this.element, posWrapper.element) ? false : (!Intrinsics.areEqual(this.setting, posWrapper.setting) ? false : (!(this.yO != posWrapper.yO)));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\SettingsScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */