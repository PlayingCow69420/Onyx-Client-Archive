/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\020 \n\002\020\016\n\002\b\017\n\002\020\013\n\002\b\022\b\b\030\0002\0020\001B;\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\006\032\0020\004\022\n\b\002\020\b\032\004\030\0010\007\022\016\b\002\020\013\032\b\022\004\022\0020\n0\t¢\006\004\b\f\020\rJ\020\020\016\032\0020\002HÆ\003¢\006\004\b\016\020\017J\020\020\020\032\0020\004HÆ\003¢\006\004\b\020\020\021J\020\020\022\032\0020\004HÆ\003¢\006\004\b\022\020\021J\022\020\023\032\004\030\0010\007HÆ\003¢\006\004\b\023\020\024J\026\020\025\032\b\022\004\022\0020\n0\tHÆ\003¢\006\004\b\025\020\026JJ\020\027\032\0020\0002\b\b\002\020\003\032\0020\0022\b\b\002\020\005\032\0020\0042\b\b\002\020\006\032\0020\0042\n\b\002\020\b\032\004\030\0010\0072\016\b\002\020\013\032\b\022\004\022\0020\n0\tHÆ\001¢\006\004\b\027\020\030J\032\020\033\032\0020\0322\b\020\031\032\004\030\0010\001HÖ\003¢\006\004\b\033\020\034J\020\020\035\032\0020\004HÖ\001¢\006\004\b\035\020\021J\020\020\036\032\0020\nHÖ\001¢\006\004\b\036\020\037R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020 \032\004\b!\020\017R\031\020\b\032\004\030\0010\0078\006¢\006\f\n\004\b\b\020\"\032\004\b#\020\024R\035\020\013\032\b\022\004\022\0020\n0\t8\006¢\006\f\n\004\b\013\020$\032\004\b%\020\026R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020&\032\004\b'\020\021\"\004\b(\020)R\"\020\006\032\0020\0048\006@\006X\016¢\006\022\n\004\b\006\020&\032\004\b*\020\021\"\004\b+\020)¨\006,"}, d2 = {"Lnet/integr/rendering/screens/MenuScreen$PosWrapper;", "", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "element", "", "xO", "yO", "Lnet/integr/modules/filters/Filter;", "filter", "", "", "searchingTags", "<init>", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;IILnet/integr/modules/filters/Filter;Ljava/util/List;)V", "component1", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "component2", "()I", "component3", "component4", "()Lnet/integr/modules/filters/Filter;", "component5", "()Ljava/util/List;", "copy", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;IILnet/integr/modules/filters/Filter;Ljava/util/List;)Lnet/integr/rendering/screens/MenuScreen$PosWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getElement", "Lnet/integr/modules/filters/Filter;", "getFilter", "Ljava/util/List;", "getSearchingTags", "I", "getXO", "setXO", "(I)V", "getYO", "setYO", "onyx2"})
/*     */ public final class PosWrapper
/*     */ {
/*     */   @NotNull
/*     */   private final HelixUiElement element;
/*     */   private int xO;
/*     */   private int yO;
/*     */   @Nullable
/*     */   private final Filter filter;
/*     */   @NotNull
/*     */   private final List<String> searchingTags;
/*     */   
/*     */   public PosWrapper(@NotNull HelixUiElement element, int xO, int yO, @Nullable Filter filter, @NotNull List<String> searchingTags) {
/* 244 */     this.element = element;
/* 245 */     this.xO = xO;
/* 246 */     this.yO = yO;
/* 247 */     this.filter = filter;
/* 248 */     this.searchingTags = searchingTags; } @NotNull public final List<String> getSearchingTags() { return this.searchingTags; }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final HelixUiElement getElement() {
/*     */     return this.element;
/*     */   }
/*     */   
/*     */   public final int getXO() {
/*     */     return this.xO;
/*     */   }
/*     */   
/*     */   public final void setXO(int <set-?>) {
/*     */     this.xO = <set-?>;
/*     */   }
/*     */   
/*     */   public final int getYO() {
/*     */     return this.yO;
/*     */   }
/*     */   
/*     */   public final void setYO(int <set-?>) {
/*     */     this.yO = <set-?>;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public final Filter getFilter() {
/*     */     return this.filter;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final HelixUiElement component1() {
/*     */     return this.element;
/*     */   }
/*     */   
/*     */   public final int component2() {
/*     */     return this.xO;
/*     */   }
/*     */   
/*     */   public final int component3() {
/*     */     return this.yO;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public final Filter component4() {
/*     */     return this.filter;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final List<String> component5() {
/*     */     return this.searchingTags;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final PosWrapper copy(@NotNull HelixUiElement element, int xO, int yO, @Nullable Filter filter, @NotNull List<String> searchingTags) {
/*     */     Intrinsics.checkNotNullParameter(element, "element");
/*     */     Intrinsics.checkNotNullParameter(searchingTags, "searchingTags");
/*     */     return new PosWrapper(element, xO, yO, filter, searchingTags);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String toString() {
/*     */     return "PosWrapper(element=" + this.element + ", xO=" + this.xO + ", yO=" + this.yO + ", filter=" + this.filter + ", searchingTags=" + this.searchingTags + ")";
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     result = this.element.hashCode();
/*     */     result = result * 31 + Integer.hashCode(this.xO);
/*     */     result = result * 31 + Integer.hashCode(this.yO);
/*     */     result = result * 31 + ((this.filter == null) ? 0 : this.filter.hashCode());
/*     */     return result * 31 + this.searchingTags.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     if (this == other)
/*     */       return true; 
/*     */     if (!(other instanceof PosWrapper))
/*     */       return false; 
/*     */     PosWrapper posWrapper = (PosWrapper)other;
/*     */     return !Intrinsics.areEqual(this.element, posWrapper.element) ? false : ((this.xO != posWrapper.xO) ? false : ((this.yO != posWrapper.yO) ? false : ((this.filter != posWrapper.filter) ? false : (!!Intrinsics.areEqual(this.searchingTags, posWrapper.searchingTags)))));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\MenuScreen$PosWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */