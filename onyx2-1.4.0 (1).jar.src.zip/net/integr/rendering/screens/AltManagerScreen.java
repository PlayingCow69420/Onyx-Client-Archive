/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import com.mojang.authlib.Environment;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*     */ import com.mojang.authlib.minecraft.UserApiService;
/*     */ import com.mojang.authlib.yggdrasil.ProfileResult;
/*     */ import com.mojang.authlib.yggdrasil.ServicesKeyType;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*     */ import de.florianmichael.waybackauthlib.WaybackAuthLib;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.mixin.MinecraftClientAccessor;
/*     */ import net.integr.mixin.YggdrasilAuthenticationServiceAccessor;
/*     */ import net.integr.mixin.YggdrasilMinecraftSessionServiceAccessor;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.Button;
/*     */ import net.integr.rendering.uisystem.UiLayout;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.integr.utilities.ClipboardHelper;
/*     */ import net.minecraft.class_156;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_320;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_442;
/*     */ import net.minecraft.class_5520;
/*     */ import net.minecraft.class_7500;
/*     */ import net.minecraft.class_7569;
/*     */ import net.minecraft.class_7574;
/*     */ import net.minecraft.class_7853;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000N\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\020\006\n\002\b\002\n\002\020\b\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\020\007\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\030\000 \0362\0020\001:\002\037\036B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J'\020\f\032\0020\0132\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rJ/\020\022\032\0020\0042\006\020\017\032\0020\0162\006\020\007\032\0020\t2\006\020\b\032\0020\t2\006\020\021\032\0020\020H\026¢\006\004\b\022\020\023R\024\020\025\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026R\024\020\030\032\0020\0278\002X\004¢\006\006\n\004\b\030\020\031R\024\020\033\032\0020\0328\002X\004¢\006\006\n\004\b\033\020\034R\024\020\035\032\0020\0328\002X\004¢\006\006\n\004\b\035\020\034¨\006 "}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen;", "Lnet/minecraft/class_437;", "<init>", "()V", "", "close", "", "mouseX", "mouseY", "", "button", "", "mouseClicked", "(DDI)Z", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "Lnet/integr/rendering/uisystem/Box;", "accountBox", "Lnet/integr/rendering/uisystem/Box;", "Lnet/integr/rendering/uisystem/UiLayout;", "layout", "Lnet/integr/rendering/uisystem/UiLayout;", "Lnet/integr/rendering/uisystem/Button;", "logoutButton", "Lnet/integr/rendering/uisystem/Button;", "theAlteningButton", "Companion", "AccountHandler", "onyx2"})
/*     */ public final class AltManagerScreen
/*     */   extends class_437
/*     */ {
/*     */   public AltManagerScreen() {
/*  49 */     super((class_2561)class_2561.method_43470("Alt Manager"));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     this.layout = new UiLayout();
/*     */     
/*  56 */     Intrinsics.checkNotNull(this.layout.add((HelixUiElement)new Box(0, 0, 200, 55, null, false, true, false, 128, null)), "null cannot be cast to non-null type net.integr.rendering.uisystem.Box"); this.accountBox = (Box)this.layout.add((HelixUiElement)new Box(0, 0, 200, 55, null, false, true, false, 128, null));
/*  57 */     Intrinsics.checkNotNull(this.layout.add((HelixUiElement)new Button(0, 0, 190, 20, "TheAltening Login (Clipboard)", true, "Log into TheAltening from your clipboard", false, AltManagerScreen::theAlteningButton$lambda$0)), "null cannot be cast to non-null type net.integr.rendering.uisystem.Button"); this.theAlteningButton = (Button)this.layout.add((HelixUiElement)new Button(0, 0, 190, 20, "TheAltening Login (Clipboard)", true, "Log into TheAltening from your clipboard", false, AltManagerScreen::theAlteningButton$lambda$0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     Intrinsics.checkNotNull(this.layout.add((HelixUiElement)new Button(0, 0, 190, 20, "Reset Account", true, "Log back into the original account", false, AltManagerScreen::logoutButton$lambda$1)), "null cannot be cast to non-null type net.integr.rendering.uisystem.Button"); this.logoutButton = (Button)this.layout.add((HelixUiElement)new Button(0, 0, 190, 20, "Reset Account", true, "Log back into the original account", false, AltManagerScreen::logoutButton$lambda$1));
/*  65 */   } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$Companion;", "", "<init>", "()V", "Lnet/integr/rendering/screens/AltManagerScreen;", "INSTANCE", "Lnet/integr/rendering/screens/AltManagerScreen;", "getINSTANCE", "()Lnet/integr/rendering/screens/AltManagerScreen;", "onyx2"}) public static final class Companion { private Companion() {} @NotNull public final AltManagerScreen getINSTANCE() { return AltManagerScreen.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @NotNull private final UiLayout layout; @NotNull private final Box accountBox; @NotNull private final Button theAlteningButton; @NotNull private final Button logoutButton; @NotNull private static final AltManagerScreen INSTANCE = new AltManagerScreen(); private static final void theAlteningButton$lambda$0() { String token = ClipboardHelper.Companion.getClipboardString(); if (token != null) AccountHandler.TheAltening.Companion.login(token);  } private static final void logoutButton$lambda$1() { AccountHandler.Companion.loadSavedEnvironment(); }
/*     */ 
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  69 */     Intrinsics.checkNotNullParameter(context, "context"); method_25420(context, mouseX, mouseY, delta);
/*     */     
/*  71 */     boolean shouldReset = true;
/*     */     
/*  73 */     this.accountBox.update(this.field_22789 / 2 - 100, this.field_22790 / 2 - 25).method_25394(context, mouseX, mouseY, delta);
/*  74 */     this.theAlteningButton.update(this.field_22789 / 2 - 100 + 5, this.field_22790 / 2 - 25 + 5).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  76 */     this.logoutButton.update(this.field_22789 / 2 - 100 + 5, this.field_22790 / 2 - 25 + 5 + 20 + 5).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  78 */     if (this.theAlteningButton.renderTooltip(context, mouseX, mouseY, delta)) shouldReset = false; 
/*  79 */     if (this.logoutButton.renderTooltip(context, mouseX, mouseY, delta)) shouldReset = false;
/*     */     
/*  81 */     if (shouldReset) this.layout.resetCursor(); 
/*     */   }
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/*  85 */     this.layout.onClick(mouseX, mouseY, button);
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   public void method_25419() {
/*  90 */     this.layout.resetCursor();
/*  91 */     Onyx.Companion.getMC().method_1507((class_437)new class_442()); } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\005\030\000 \0042\0020\001:\002\004\005B\007¢\006\004\b\002\020\003¨\006\006"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler;", "", "<init>", "()V", "Companion", "TheAltening", "onyx2"}) public static final class AccountHandler { @NotNull
/*     */     public static final Companion Companion = new Companion(null); @Nullable
/*     */     private static class_320 originalSession; @Nullable
/*     */     private static YggdrasilAuthenticationService originalAuthService; @Nullable
/*     */     private static MinecraftSessionService originalSessionService; @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */     public static final class TheAltening { @NotNull
/*     */       public static final Companion Companion = new Companion(null); @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening$Companion;", "", "<init>", "()V", "", "token", "", "login", "(Ljava/lang/String;)V", "onyx2"})
/*  98 */       public static final class Companion { private Companion() {} public final void login(@NotNull String token) { Intrinsics.checkNotNullParameter(token, "token"); AltManagerScreen.AccountHandler.Companion.runEnvironmentPreserver();
/*     */           
/* 100 */           Environment environment = new Environment("http://sessionserver.thealtening.com", "http://authserver.thealtening.com", "The Altening");
/* 101 */           Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(((MinecraftClientAccessor)Onyx.Companion.getMC()).getProxy(), environment);
/*     */           
/* 103 */           WaybackAuthLib auth = new WaybackAuthLib(environment.servicesHost());
/*     */           
/* 105 */           auth.setUsername(token);
/* 106 */           auth.setPassword("Woah!");
/*     */           
/* 108 */           Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment), "createYggdrasilMinecraftSessionService(...)"); AltManagerScreen.AccountHandler.Companion.applyLoginEnvironment(service, (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment));
/* 109 */           auth.logIn();
/* 110 */           AltManagerScreen.AccountHandler.Companion.applySession(new class_320(auth.getCurrentProfile().getName(), auth.getCurrentProfile().getId(), auth.getAccessToken(), Optional.empty(), Optional.empty(), class_320.class_321.field_1988)); }
/*     */          }
/*     */        }
/*     */ 
/*     */     
/*     */     @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006¢\006\004\b\t\020\nJ\025\020\r\032\0020\b2\006\020\f\032\0020\013¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\002¢\006\004\b\020\020\021J\r\020\022\032\0020\b¢\006\004\b\022\020\003J\r\020\023\032\0020\b¢\006\004\b\023\020\003J\017\020\024\032\0020\bH\002¢\006\004\b\024\020\003R\030\020\025\032\004\030\0010\0048\002@\002X\016¢\006\006\n\004\b\025\020\026R\030\020\027\032\004\030\0010\0138\002@\002X\016¢\006\006\n\004\b\027\020\030R\030\020\031\032\004\030\0010\0068\002@\002X\016¢\006\006\n\004\b\031\020\032¨\006\033"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$Companion;", "", "<init>", "()V", "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;", "authService", "Lcom/mojang/authlib/minecraft/MinecraftSessionService;", "sessService", "", "applyLoginEnvironment", "(Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;Lcom/mojang/authlib/minecraft/MinecraftSessionService;)V", "Lnet/minecraft/class_320;", "session", "applySession", "(Lnet/minecraft/class_320;)V", "", "canLoadSavedEnvironment", "()Z", "loadSavedEnvironment", "runEnvironmentPreserver", "saveEnvironment", "originalAuthService", "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;", "originalSession", "Lnet/minecraft/class_320;", "originalSessionService", "Lcom/mojang/authlib/minecraft/MinecraftSessionService;", "onyx2"})
/*     */     public static final class Companion
/*     */     {
/*     */       private Companion() {}
/*     */       
/*     */       public final void runEnvironmentPreserver() {
/* 121 */         if (!canLoadSavedEnvironment()) saveEnvironment(); 
/*     */       }
/*     */       
/*     */       private final void saveEnvironment() {
/* 125 */         AltManagerScreen.AccountHandler.originalSession = Onyx.Companion.getMC().method_1548();
/*     */         
/* 127 */         Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/* 128 */         AltManagerScreen.AccountHandler.originalAuthService = mca.getAuthenticationService();
/* 129 */         AltManagerScreen.AccountHandler.originalSessionService = Onyx.Companion.getMC().method_1495();
/*     */       }
/*     */       
/*     */       private final boolean canLoadSavedEnvironment() {
/* 133 */         return (AltManagerScreen.AccountHandler.originalSession != null && AltManagerScreen.AccountHandler.originalAuthService != null && AltManagerScreen.AccountHandler.originalSessionService != null);
/*     */       }
/*     */       
/*     */       public final void loadSavedEnvironment() {
/* 137 */         if (!canLoadSavedEnvironment())
/*     */           return; 
/* 139 */         Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService, "null cannot be cast to non-null type net.integr.mixin.YggdrasilAuthenticationServiceAccessor"); YggdrasilAuthenticationServiceAccessor accessedService = (YggdrasilAuthenticationServiceAccessor)AltManagerScreen.AccountHandler.originalAuthService;
/* 140 */         Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService); Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService); Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService); Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(AltManagerScreen.AccountHandler.originalAuthService.getServicesKeySet(), AltManagerScreen.AccountHandler.originalAuthService.getProxy(), accessedService.getEnvironment()), "createYggdrasilMinecraftSessionService(...)"); applyLoginEnvironment(AltManagerScreen.AccountHandler.originalAuthService, (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(AltManagerScreen.AccountHandler.originalAuthService.getServicesKeySet(), AltManagerScreen.AccountHandler.originalAuthService.getProxy(), accessedService.getEnvironment()));
/* 141 */         Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalSession); applySession(AltManagerScreen.AccountHandler.originalSession);
/*     */       }
/*     */       
/*     */       public final void applySession(@NotNull class_320 session) {
/* 145 */         Intrinsics.checkNotNullParameter(session, "session"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/* 146 */         mca.setSession(session);
/* 147 */         UserApiService apiService = null;
/*     */         
/*     */         try {
/* 150 */           Intrinsics.checkNotNullExpressionValue(mca.getAuthenticationService().createUserApiService(session.method_1674()), "createUserApiService(...)"); apiService = mca.getAuthenticationService().createUserApiService(session.method_1674());
/*     */           
/* 152 */           mca.setUserApiService(apiService);
/* 153 */           mca.setSocialInteractionsManager(new class_5520(Onyx.Companion.getMC(), apiService));
/* 154 */           mca.setProfileKeys(class_7853.method_46532(apiService, session, (Onyx.Companion.getMC()).field_1697.toPath()));
/* 155 */           mca.setAbuseReportContext(class_7574.method_44599(class_7569.method_44586(), apiService));
/* 156 */           mca.setGameProfileFuture(CompletableFuture.supplyAsync(Companion::applySession$lambda$0, 
/*     */                 
/* 158 */                 class_156.method_27958()));
/* 159 */         } catch (AuthenticationException e) {
/* 160 */           e.printStackTrace();
/*     */         } 
/*     */       } private static final ProfileResult applySession$lambda$0() {
/*     */         return Onyx.Companion.getMC().method_1495().fetchProfile(Onyx.Companion.getMC().method_1548().method_44717(), true);
/*     */       }
/* 165 */       public final void applyLoginEnvironment(@NotNull YggdrasilAuthenticationService authService, @NotNull MinecraftSessionService sessService) { Intrinsics.checkNotNullParameter(authService, "authService"); Intrinsics.checkNotNullParameter(sessService, "sessService"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/* 166 */         mca.setAuthenticationService(authService);
/* 167 */         class_7500.method_44172(authService.getServicesKeySet(), ServicesKeyType.PROFILE_KEY);
/* 168 */         mca.setSessionService(sessService); } } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening;", "", "<init>", "()V", "Companion", "onyx2"}) public static final class TheAltening { @NotNull public static final Companion Companion = new Companion(null); @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening$Companion;", "", "<init>", "()V", "", "token", "", "login", "(Ljava/lang/String;)V", "onyx2"}) public static final class Companion { private Companion() {} public final void login(@NotNull String token) { Intrinsics.checkNotNullParameter(token, "token"); AltManagerScreen.AccountHandler.Companion.runEnvironmentPreserver(); Environment environment = new Environment("http://sessionserver.thealtening.com", "http://authserver.thealtening.com", "The Altening"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(((MinecraftClientAccessor)Onyx.Companion.getMC()).getProxy(), environment); WaybackAuthLib auth = new WaybackAuthLib(environment.servicesHost()); auth.setUsername(token); auth.setPassword("Woah!"); Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment), "createYggdrasilMinecraftSessionService(...)"); AltManagerScreen.AccountHandler.Companion.applyLoginEnvironment(service, (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment)); auth.logIn(); AltManagerScreen.AccountHandler.Companion.applySession(new class_320(auth.getCurrentProfile().getName(), auth.getCurrentProfile().getId(), auth.getAccessToken(), Optional.empty(), Optional.empty(), class_320.class_321.field_1988)); } } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening$Companion;", "", "<init>", "()V", "", "token", "", "login", "(Ljava/lang/String;)V", "onyx2"}) public static final class Companion { private Companion() {} public final void login(@NotNull String token) { Intrinsics.checkNotNullParameter(token, "token"); AltManagerScreen.AccountHandler.Companion.runEnvironmentPreserver(); Environment environment = new Environment("http://sessionserver.thealtening.com", "http://authserver.thealtening.com", "The Altening"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(((MinecraftClientAccessor)Onyx.Companion.getMC()).getProxy(), environment); WaybackAuthLib auth = new WaybackAuthLib(environment.servicesHost()); auth.setUsername(token); auth.setPassword("Woah!"); Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment), "createYggdrasilMinecraftSessionService(...)"); AltManagerScreen.AccountHandler.Companion.applyLoginEnvironment(service, (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment)); auth.logIn(); AltManagerScreen.AccountHandler.Companion.applySession(new class_320(auth.getCurrentProfile().getName(), auth.getCurrentProfile().getId(), auth.getAccessToken(), Optional.empty(), Optional.empty(), class_320.class_321.field_1988)); } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006¢\006\004\b\t\020\nJ\025\020\r\032\0020\b2\006\020\f\032\0020\013¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\002¢\006\004\b\020\020\021J\r\020\022\032\0020\b¢\006\004\b\022\020\003J\r\020\023\032\0020\b¢\006\004\b\023\020\003J\017\020\024\032\0020\bH\002¢\006\004\b\024\020\003R\030\020\025\032\004\030\0010\0048\002@\002X\016¢\006\006\n\004\b\025\020\026R\030\020\027\032\004\030\0010\0138\002@\002X\016¢\006\006\n\004\b\027\020\030R\030\020\031\032\004\030\0010\0068\002@\002X\016¢\006\006\n\004\b\031\020\032¨\006\033"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$Companion;", "", "<init>", "()V", "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;", "authService", "Lcom/mojang/authlib/minecraft/MinecraftSessionService;", "sessService", "", "applyLoginEnvironment", "(Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;Lcom/mojang/authlib/minecraft/MinecraftSessionService;)V", "Lnet/minecraft/class_320;", "session", "applySession", "(Lnet/minecraft/class_320;)V", "", "canLoadSavedEnvironment", "()Z", "loadSavedEnvironment", "runEnvironmentPreserver", "saveEnvironment", "originalAuthService", "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;", "originalSession", "Lnet/minecraft/class_320;", "originalSessionService", "Lcom/mojang/authlib/minecraft/MinecraftSessionService;", "onyx2"}) public static final class Companion { public final void applyLoginEnvironment(@NotNull YggdrasilAuthenticationService authService, @NotNull MinecraftSessionService sessService) { Intrinsics.checkNotNullParameter(authService, "authService"); Intrinsics.checkNotNullParameter(sessService, "sessService"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC(); mca.setAuthenticationService(authService); class_7500.method_44172(authService.getServicesKeySet(), ServicesKeyType.PROFILE_KEY); mca.setSessionService(sessService); }
/*     */ 
/*     */     
/*     */     private Companion() {}
/*     */     
/*     */     public final void runEnvironmentPreserver() {
/*     */       if (!canLoadSavedEnvironment())
/*     */         saveEnvironment(); 
/*     */     }
/*     */     
/*     */     private final void saveEnvironment() {
/*     */       AltManagerScreen.AccountHandler.originalSession = Onyx.Companion.getMC().method_1548();
/*     */       Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor");
/*     */       MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/*     */       AltManagerScreen.AccountHandler.originalAuthService = mca.getAuthenticationService();
/*     */       AltManagerScreen.AccountHandler.originalSessionService = Onyx.Companion.getMC().method_1495();
/*     */     }
/*     */     
/*     */     private final boolean canLoadSavedEnvironment() {
/*     */       return (AltManagerScreen.AccountHandler.originalSession != null && AltManagerScreen.AccountHandler.originalAuthService != null && AltManagerScreen.AccountHandler.originalSessionService != null);
/*     */     }
/*     */     
/*     */     public final void loadSavedEnvironment() {
/*     */       if (!canLoadSavedEnvironment())
/*     */         return; 
/*     */       Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService, "null cannot be cast to non-null type net.integr.mixin.YggdrasilAuthenticationServiceAccessor");
/*     */       YggdrasilAuthenticationServiceAccessor accessedService = (YggdrasilAuthenticationServiceAccessor)AltManagerScreen.AccountHandler.originalAuthService;
/*     */       Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService);
/*     */       Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService);
/*     */       Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalAuthService);
/*     */       Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(AltManagerScreen.AccountHandler.originalAuthService.getServicesKeySet(), AltManagerScreen.AccountHandler.originalAuthService.getProxy(), accessedService.getEnvironment()), "createYggdrasilMinecraftSessionService(...)");
/*     */       applyLoginEnvironment(AltManagerScreen.AccountHandler.originalAuthService, (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(AltManagerScreen.AccountHandler.originalAuthService.getServicesKeySet(), AltManagerScreen.AccountHandler.originalAuthService.getProxy(), accessedService.getEnvironment()));
/*     */       Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.originalSession);
/*     */       applySession(AltManagerScreen.AccountHandler.originalSession);
/*     */     }
/*     */     
/*     */     public final void applySession(@NotNull class_320 session) {
/*     */       Intrinsics.checkNotNullParameter(session, "session");
/*     */       Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor");
/*     */       MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/*     */       mca.setSession(session);
/*     */       UserApiService apiService = null;
/*     */       try {
/*     */         Intrinsics.checkNotNullExpressionValue(mca.getAuthenticationService().createUserApiService(session.method_1674()), "createUserApiService(...)");
/*     */         apiService = mca.getAuthenticationService().createUserApiService(session.method_1674());
/*     */         mca.setUserApiService(apiService);
/*     */         mca.setSocialInteractionsManager(new class_5520(Onyx.Companion.getMC(), apiService));
/*     */         mca.setProfileKeys(class_7853.method_46532(apiService, session, (Onyx.Companion.getMC()).field_1697.toPath()));
/*     */         mca.setAbuseReportContext(class_7574.method_44599(class_7569.method_44586(), apiService));
/*     */         mca.setGameProfileFuture(CompletableFuture.supplyAsync(Companion::applySession$lambda$0, class_156.method_27958()));
/*     */       } catch (AuthenticationException e) {
/*     */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*     */     private static final ProfileResult applySession$lambda$0() {
/*     */       return Onyx.Companion.getMC().method_1495().fetchProfile(Onyx.Companion.getMC().method_1548().method_44717(), true);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\AltManagerScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */