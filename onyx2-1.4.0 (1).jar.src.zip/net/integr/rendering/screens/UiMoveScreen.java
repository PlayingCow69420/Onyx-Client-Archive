/*    */ package net.integr.rendering.screens;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.modules.management.Module;
/*    */ import net.integr.modules.management.ModuleManager;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.rendering.uisystem.MovableBox;
/*    */ import net.integr.rendering.uisystem.UiLayout;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import net.integr.rendering.uisystem.util.RenderLerper;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_437;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000J\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\020\006\n\002\b\002\n\002\020\b\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\002\b\004\n\002\020!\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\030\000 \0352\0020\001:\002\036\035B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J'\020\f\032\0020\0132\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rJ'\020\016\032\0020\0132\006\020\007\032\0020\0062\006\020\b\032\0020\0062\006\020\n\032\0020\tH\026¢\006\004\b\016\020\rJ/\020\023\032\0020\0042\006\020\020\032\0020\0172\006\020\007\032\0020\t2\006\020\b\032\0020\t2\006\020\022\032\0020\021H\026¢\006\004\b\023\020\024J1\020\025\032\0020\0042\b\020\020\032\004\030\0010\0172\006\020\007\032\0020\t2\006\020\b\032\0020\t2\006\020\022\032\0020\021H\026¢\006\004\b\025\020\024R\032\020\030\032\b\022\004\022\0020\0270\0268\002X\004¢\006\006\n\004\b\030\020\031R\024\020\033\032\0020\0328\002X\004¢\006\006\n\004\b\033\020\034¨\006\037"}, d2 = {"Lnet/integr/rendering/screens/UiMoveScreen;", "Lnet/minecraft/class_437;", "<init>", "()V", "", "close", "", "mouseX", "mouseY", "", "button", "", "mouseClicked", "(DDI)Z", "mouseReleased", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderBackground", "", "Lnet/integr/rendering/screens/UiMoveScreen$BoxWrapper;", "boxes", "Ljava/util/List;", "Lnet/integr/rendering/uisystem/UiLayout;", "layout", "Lnet/integr/rendering/uisystem/UiLayout;", "Companion", "BoxWrapper", "onyx2"})
/*    */ public final class UiMoveScreen
/*    */   extends class_437
/*    */ {
/*    */   public UiMoveScreen() {
/* 29 */     super((class_2561)class_2561.method_43470("Onyx Ui-Move Screen"));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 34 */     this.layout = new UiLayout();
/*    */     
/* 36 */     this.boxes = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     for (Module m : ModuleManager.Companion.getUiModules()) {
/* 66 */       Intrinsics.checkNotNull(m, "null cannot be cast to non-null type net.integr.modules.management.UiModule"); UiModule module = (UiModule)m;
/*    */       
/* 68 */       Intrinsics.checkNotNull(this.layout.add((HelixUiElement)module.getPlaceholderBox()), "null cannot be cast to non-null type net.integr.rendering.uisystem.MovableBox"); MovableBox box = (MovableBox)this.layout.add((HelixUiElement)module.getPlaceholderBox());
/*    */       
/* 70 */       this.boxes.add(new BoxWrapper(box, module.getHeight() - module.getHeight() / 2, module.getWidth() - module.getHeight() / 2, module));
/*    */     } 
/*    */   } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/UiMoveScreen$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_437;", "INSTANCE", "Lnet/minecraft/class_437;", "getINSTANCE", "()Lnet/minecraft/class_437;", "onyx2"})
/*    */   public static final class Companion {
/*    */     private Companion() {} @NotNull
/*    */     public final class_437 getINSTANCE() {
/*    */       return UiMoveScreen.INSTANCE;
/*    */     } } @NotNull
/*    */   public static final Companion Companion = new Companion(null); @NotNull
/* 79 */   private final UiLayout layout; public boolean method_25402(double mouseX, double mouseY, int button) { this.layout.onClick(mouseX, mouseY, button);
/* 80 */     return true; }
/*    */   @NotNull private final List<BoxWrapper> boxes; @NotNull private static final class_437 INSTANCE = new UiMoveScreen(); public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) { Intrinsics.checkNotNullParameter(context, "context"); for (BoxWrapper w : this.boxes) { MovableBox box = w.getBox(); UiModule module = w.getModule(); box.setYSize(RenderLerper.Companion.lerpWithDefDelta(w.getOldHeight(), module.getHeight())); w.setOldHeight(box.getYSize()); box.setXSize(RenderLerper.Companion.lerpWithDefDelta(w.getOldWidth(), module.getWidth())); w.setOldWidth(box.getXSize()); box.method_25394(context, mouseX, mouseY, delta); module.updatePosition(box.getXPos(), box.getYPos()); }  boolean shouldReset = true; for (BoxWrapper w : this.boxes) { MovableBox box = w.getBox(); if (box.renderTooltip(context, mouseX, mouseY, delta))
/*    */         shouldReset = false;  }
/*    */      if (shouldReset)
/* 84 */       this.layout.resetCursor();  } public void method_25420(@Nullable class_332 context, int mouseX, int mouseY, float delta) {} public boolean method_25406(double mouseX, double mouseY, int button) { this.layout.onRelease(mouseX, mouseY, button);
/* 85 */     return true; }
/*    */ 
/*    */   
/*    */   public void method_25419() {
/* 89 */     Onyx.Companion.getMC().method_1507(MenuScreen.Companion.getINSTANCE());
/* 90 */     this.layout.resetCursor();
/*    */     
/* 92 */     for (BoxWrapper w : this.boxes) {
/* 93 */       UiModule module = w.getModule();
/* 94 */       w.setOldHeight(module.getHeight() - module.getHeight() / 2);
/* 95 */       w.setOldWidth(module.getWidth() - module.getHeight() / 2);
/*    */     }  } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\r\n\002\020\013\n\002\b\003\n\002\020\016\n\002\b\r\b\b\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\006\032\0020\004\022\006\020\b\032\0020\007¢\006\004\b\t\020\nJ\020\020\013\032\0020\002HÆ\003¢\006\004\b\013\020\fJ\020\020\r\032\0020\004HÆ\003¢\006\004\b\r\020\016J\020\020\017\032\0020\004HÆ\003¢\006\004\b\017\020\016J\020\020\020\032\0020\007HÆ\003¢\006\004\b\020\020\021J8\020\022\032\0020\0002\b\b\002\020\003\032\0020\0022\b\b\002\020\005\032\0020\0042\b\b\002\020\006\032\0020\0042\b\b\002\020\b\032\0020\007HÆ\001¢\006\004\b\022\020\023J\032\020\026\032\0020\0252\b\020\024\032\004\030\0010\001HÖ\003¢\006\004\b\026\020\027J\020\020\030\032\0020\004HÖ\001¢\006\004\b\030\020\016J\020\020\032\032\0020\031HÖ\001¢\006\004\b\032\020\033R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\034\032\004\b\035\020\fR\027\020\b\032\0020\0078\006¢\006\f\n\004\b\b\020\036\032\004\b\037\020\021R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020 \032\004\b!\020\016\"\004\b\"\020#R\"\020\006\032\0020\0048\006@\006X\016¢\006\022\n\004\b\006\020 \032\004\b$\020\016\"\004\b%\020#¨\006&"}, d2 = {"Lnet/integr/rendering/screens/UiMoveScreen$BoxWrapper;", "", "Lnet/integr/rendering/uisystem/MovableBox;", "box", "", "oldHeight", "oldWidth", "Lnet/integr/modules/management/UiModule;", "module", "<init>", "(Lnet/integr/rendering/uisystem/MovableBox;IILnet/integr/modules/management/UiModule;)V", "component1", "()Lnet/integr/rendering/uisystem/MovableBox;", "component2", "()I", "component3", "component4", "()Lnet/integr/modules/management/UiModule;", "copy", "(Lnet/integr/rendering/uisystem/MovableBox;IILnet/integr/modules/management/UiModule;)Lnet/integr/rendering/screens/UiMoveScreen$BoxWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/MovableBox;", "getBox", "Lnet/integr/modules/management/UiModule;", "getModule", "I", "getOldHeight", "setOldHeight", "(I)V", "getOldWidth", "setOldWidth", "onyx2"})
/*    */   public static final class BoxWrapper { @NotNull
/*    */     private final MovableBox box; private int oldHeight; private int oldWidth; @NotNull
/* 99 */     private final UiModule module; public BoxWrapper(@NotNull MovableBox box, int oldHeight, int oldWidth, @NotNull UiModule module) { this.box = box; this.oldHeight = oldHeight; this.oldWidth = oldWidth; this.module = module; } @NotNull public final MovableBox getBox() { return this.box; } public final int getOldHeight() { return this.oldHeight; } public final void setOldHeight(int <set-?>) { this.oldHeight = <set-?>; } public final int getOldWidth() { return this.oldWidth; } public final void setOldWidth(int <set-?>) { this.oldWidth = <set-?>; } @NotNull public final UiModule getModule() { return this.module; }
/*    */ 
/*    */     
/*    */     @NotNull
/*    */     public final MovableBox component1() {
/*    */       return this.box;
/*    */     }
/*    */     
/*    */     public final int component2() {
/*    */       return this.oldHeight;
/*    */     }
/*    */     
/*    */     public final int component3() {
/*    */       return this.oldWidth;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public final UiModule component4() {
/*    */       return this.module;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public final BoxWrapper copy(@NotNull MovableBox box, int oldHeight, int oldWidth, @NotNull UiModule module) {
/*    */       Intrinsics.checkNotNullParameter(box, "box");
/*    */       Intrinsics.checkNotNullParameter(module, "module");
/*    */       return new BoxWrapper(box, oldHeight, oldWidth, module);
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     public String toString() {
/*    */       return "BoxWrapper(box=" + this.box + ", oldHeight=" + this.oldHeight + ", oldWidth=" + this.oldWidth + ", module=" + this.module + ")";
/*    */     }
/*    */     
/*    */     public int hashCode() {
/*    */       result = this.box.hashCode();
/*    */       result = result * 31 + Integer.hashCode(this.oldHeight);
/*    */       result = result * 31 + Integer.hashCode(this.oldWidth);
/*    */       return result * 31 + this.module.hashCode();
/*    */     }
/*    */     
/*    */     public boolean equals(@Nullable Object other) {
/*    */       if (this == other)
/*    */         return true; 
/*    */       if (!(other instanceof BoxWrapper))
/*    */         return false; 
/*    */       BoxWrapper boxWrapper = (BoxWrapper)other;
/*    */       return !Intrinsics.areEqual(this.box, boxWrapper.box) ? false : ((this.oldHeight != boxWrapper.oldHeight) ? false : ((this.oldWidth != boxWrapper.oldWidth) ? false : (!!Intrinsics.areEqual(this.module, boxWrapper.module))));
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\UiMoveScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */