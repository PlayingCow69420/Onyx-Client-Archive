/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.modules.filters.Filter;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.modules.management.ModuleManager;
/*     */ import net.integr.rendering.uisystem.Box;
/*     */ import net.integr.rendering.uisystem.IconButton;
/*     */ import net.integr.rendering.uisystem.ModuleButton;
/*     */ import net.integr.rendering.uisystem.ToggleButton;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000r\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\020\b\n\002\b\006\n\002\020\013\n\002\b\003\n\002\020\016\n\000\n\002\020 \n\002\b\003\n\002\020\006\n\002\b\013\n\002\030\002\n\000\n\002\020\007\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\020!\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\007\030\000 H2\0020\001:\002HIB\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\003J\027\020\b\032\0020\0062\006\020\007\032\0020\006H\002¢\006\004\b\b\020\tJ'\020\016\032\0020\r2\006\020\n\032\0020\0062\006\020\013\032\0020\0062\006\020\f\032\0020\006H\026¢\006\004\b\016\020\017J'\020\020\032\0020\r2\006\020\n\032\0020\0062\006\020\013\032\0020\0062\006\020\f\032\0020\006H\026¢\006\004\b\020\020\017J%\020\025\032\0020\r2\006\020\022\032\0020\0212\f\020\024\032\b\022\004\022\0020\0210\023H\002¢\006\004\b\025\020\026J'\020\033\032\0020\r2\006\020\030\032\0020\0272\006\020\031\032\0020\0272\006\020\032\032\0020\006H\026¢\006\004\b\033\020\034J'\020\035\032\0020\r2\006\020\030\032\0020\0272\006\020\031\032\0020\0272\006\020\032\032\0020\006H\026¢\006\004\b\035\020\034J/\020 \032\0020\r2\006\020\030\032\0020\0272\006\020\031\032\0020\0272\006\020\036\032\0020\0272\006\020\037\032\0020\027H\026¢\006\004\b \020!J\017\020\"\032\0020\004H\002¢\006\004\b\"\020\003J/\020'\032\0020\0042\006\020$\032\0020#2\006\020\030\032\0020\0062\006\020\031\032\0020\0062\006\020&\032\0020%H\026¢\006\004\b'\020(J1\020)\032\0020\0042\b\020$\032\004\030\0010#2\006\020\030\032\0020\0062\006\020\031\032\0020\0062\006\020&\032\0020%H\026¢\006\004\b)\020(R\030\020+\032\004\030\0010*8\002@\002X\016¢\006\006\n\004\b+\020,R\030\020-\032\004\030\0010*8\002@\002X\016¢\006\006\n\004\b-\020,R\026\020.\032\0020\0068\002@\002X\016¢\006\006\n\004\b.\020/R\030\0201\032\004\030\001008\002@\002X\016¢\006\006\n\004\b1\0202R\030\0203\032\004\030\0010*8\002@\002X\016¢\006\006\n\004\b3\020,R\034\0206\032\b\022\004\022\00205048\002@\002X\016¢\006\006\n\004\b6\0207R\030\0208\032\004\030\001008\002@\002X\016¢\006\006\n\004\b8\0202R\024\020:\032\002098\002X\004¢\006\006\n\004\b:\020;R\032\020<\032\b\022\004\022\00205048\002X\004¢\006\006\n\004\b<\0207R\030\020=\032\004\030\001008\002@\002X\016¢\006\006\n\004\b=\0202R\026\020>\032\0020\0068\002@\002X\016¢\006\006\n\004\b>\020/R\026\020?\032\0020\0068\002@\002X\016¢\006\006\n\004\b?\020/R\026\020@\032\0020\0068\002@\002X\016¢\006\006\n\004\b@\020/R\026\020\022\032\0020\0218\002@\002X\016¢\006\006\n\004\b\022\020AR\030\020B\032\004\030\0010*8\002@\002X\016¢\006\006\n\004\bB\020,R\034\020D\032\b\022\004\022\0020C048\002@\002X\016¢\006\006\n\004\bD\0207R\030\020E\032\004\030\001008\002@\002X\016¢\006\006\n\004\bE\0202R\026\020F\032\0020\r8\002@\002X\016¢\006\006\n\004\bF\020G¨\006J"}, d2 = {"Lnet/integr/rendering/screens/MenuScreen;", "Lnet/minecraft/class_437;", "<init>", "()V", "", "close", "", "index", "getXFromIndex", "(I)I", "keyCode", "scanCode", "modifiers", "", "keyPressed", "(III)Z", "keyReleased", "", "search", "", "tags", "matchesSearchingPredicate", "(Ljava/lang/String;Ljava/util/List;)Z", "", "mouseX", "mouseY", "button", "mouseClicked", "(DDI)Z", "mouseReleased", "horizontalAmount", "verticalAmount", "mouseScrolled", "(DDDD)Z", "reloadList", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderBackground", "Lnet/integr/rendering/uisystem/Box;", "actionRowBox", "Lnet/integr/rendering/uisystem/Box;", "backgroundBox", "currentScrollPaneY", "I", "Lnet/integr/rendering/uisystem/IconButton;", "exportButton", "Lnet/integr/rendering/uisystem/IconButton;", "filterRowBox", "", "Lnet/integr/rendering/screens/MenuScreen$PosWrapper;", "filters", "Ljava/util/List;", "importButton", "Lnet/integr/rendering/uisystem/UiLayout;", "layout", "Lnet/integr/rendering/uisystem/UiLayout;", "modules", "moveButton", "oldHeight", "preInitSizeX", "preInitSizeY", "Ljava/lang/String;", "searchBar", "Lnet/integr/modules/filters/Filter;", "selectedFilters", "settingsButton", "shiftDown", "Z", "Companion", "PosWrapper", "onyx2"})
/*     */ @SourceDebugExtension({"SMAP\nMenuScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MenuScreen.kt\nnet/integr/rendering/screens/MenuScreen\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,338:1\n1774#2,4:339\n766#2:343\n857#2,2:344\n429#3:346\n502#3,5:347\n*S KotlinDebug\n*F\n+ 1 MenuScreen.kt\nnet/integr/rendering/screens/MenuScreen\n*L\n181#1:339,4\n265#1:343\n265#1:344,2\n277#1:346\n277#1:347,5\n*E\n"})
/*     */ public final class MenuScreen extends class_437 {
/*     */   public MenuScreen() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ldc 'Onyx Menu'
/*     */     //   3: invokestatic method_43470 : (Ljava/lang/String;)Lnet/minecraft/class_5250;
/*     */     //   6: checkcast net/minecraft/class_2561
/*     */     //   9: invokespecial <init> : (Lnet/minecraft/class_2561;)V
/*     */     //   12: aload_0
/*     */     //   13: new net/integr/rendering/uisystem/UiLayout
/*     */     //   16: dup
/*     */     //   17: invokespecial <init> : ()V
/*     */     //   20: putfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   23: aload_0
/*     */     //   24: sipush #620
/*     */     //   27: putfield preInitSizeX : I
/*     */     //   30: aload_0
/*     */     //   31: ldc ''
/*     */     //   33: putfield search : Ljava/lang/String;
/*     */     //   36: aload_0
/*     */     //   37: new java/util/ArrayList
/*     */     //   40: dup
/*     */     //   41: invokespecial <init> : ()V
/*     */     //   44: checkcast java/util/List
/*     */     //   47: putfield selectedFilters : Ljava/util/List;
/*     */     //   50: aload_0
/*     */     //   51: new java/util/ArrayList
/*     */     //   54: dup
/*     */     //   55: invokespecial <init> : ()V
/*     */     //   58: checkcast java/util/List
/*     */     //   61: putfield filters : Ljava/util/List;
/*     */     //   64: aload_0
/*     */     //   65: new java/util/ArrayList
/*     */     //   68: dup
/*     */     //   69: invokespecial <init> : ()V
/*     */     //   72: checkcast java/util/List
/*     */     //   75: putfield modules : Ljava/util/List;
/*     */     //   78: nop
/*     */     //   79: aload_0
/*     */     //   80: aload_0
/*     */     //   81: getfield field_22790 : I
/*     */     //   84: iconst_2
/*     */     //   85: idiv
/*     */     //   86: putfield preInitSizeY : I
/*     */     //   89: iconst_5
/*     */     //   90: istore_1
/*     */     //   91: iconst_0
/*     */     //   92: istore_2
/*     */     //   93: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   96: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   99: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   104: astore_3
/*     */     //   105: aload_3
/*     */     //   106: invokeinterface hasNext : ()Z
/*     */     //   111: ifeq -> 289
/*     */     //   114: aload_3
/*     */     //   115: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   120: checkcast net/integr/modules/management/Module
/*     */     //   123: astore #4
/*     */     //   125: aload_0
/*     */     //   126: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   129: new net/integr/rendering/uisystem/ModuleButton
/*     */     //   132: dup
/*     */     //   133: aload_0
/*     */     //   134: getfield field_22789 : I
/*     */     //   137: iconst_2
/*     */     //   138: idiv
/*     */     //   139: aload_0
/*     */     //   140: getfield preInitSizeX : I
/*     */     //   143: iconst_2
/*     */     //   144: idiv
/*     */     //   145: isub
/*     */     //   146: aload_0
/*     */     //   147: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   150: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   153: aload #4
/*     */     //   155: invokeinterface indexOf : (Ljava/lang/Object;)I
/*     */     //   160: iconst_3
/*     */     //   161: irem
/*     */     //   162: invokespecial getXFromIndex : (I)I
/*     */     //   165: iadd
/*     */     //   166: aload_0
/*     */     //   167: getfield field_22790 : I
/*     */     //   170: iconst_2
/*     */     //   171: idiv
/*     */     //   172: aload_0
/*     */     //   173: getfield preInitSizeY : I
/*     */     //   176: iconst_2
/*     */     //   177: idiv
/*     */     //   178: isub
/*     */     //   179: iload_1
/*     */     //   180: iadd
/*     */     //   181: sipush #200
/*     */     //   184: bipush #20
/*     */     //   186: aload #4
/*     */     //   188: invokevirtual getDisplayName : ()Ljava/lang/String;
/*     */     //   191: iconst_1
/*     */     //   192: aload #4
/*     */     //   194: invokevirtual getToolTip : ()Ljava/lang/String;
/*     */     //   197: iconst_0
/*     */     //   198: aload #4
/*     */     //   200: aload_0
/*     */     //   201: <illegal opcode> run : (Lnet/integr/rendering/screens/MenuScreen;)Ljava/lang/Runnable;
/*     */     //   206: invokespecial <init> : (IIIILjava/lang/String;ZLjava/lang/String;ZLnet/integr/modules/management/Module;Ljava/lang/Runnable;)V
/*     */     //   209: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   212: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   215: astore #5
/*     */     //   217: aload_0
/*     */     //   218: getfield modules : Ljava/util/List;
/*     */     //   221: checkcast java/util/Collection
/*     */     //   224: new net/integr/rendering/screens/MenuScreen$PosWrapper
/*     */     //   227: dup
/*     */     //   228: aload #5
/*     */     //   230: aload_0
/*     */     //   231: getstatic net/integr/modules/management/ModuleManager.Companion : Lnet/integr/modules/management/ModuleManager$Companion;
/*     */     //   234: invokevirtual getModules : ()Ljava/util/List;
/*     */     //   237: aload #4
/*     */     //   239: invokeinterface indexOf : (Ljava/lang/Object;)I
/*     */     //   244: iconst_3
/*     */     //   245: irem
/*     */     //   246: invokespecial getXFromIndex : (I)I
/*     */     //   249: iload_1
/*     */     //   250: aload #4
/*     */     //   252: invokevirtual getFilter : ()Lnet/integr/modules/filters/Filter;
/*     */     //   255: aload #4
/*     */     //   257: invokevirtual getSearchingTags : ()Ljava/util/List;
/*     */     //   260: invokespecial <init> : (Lnet/integr/rendering/uisystem/base/HelixUiElement;IILnet/integr/modules/filters/Filter;Ljava/util/List;)V
/*     */     //   263: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   268: pop
/*     */     //   269: iload_2
/*     */     //   270: iconst_2
/*     */     //   271: if_icmpne -> 283
/*     */     //   274: iinc #1, 25
/*     */     //   277: nop
/*     */     //   278: iconst_0
/*     */     //   279: istore_2
/*     */     //   280: goto -> 105
/*     */     //   283: iinc #2, 1
/*     */     //   286: goto -> 105
/*     */     //   289: iconst_5
/*     */     //   290: istore_3
/*     */     //   291: invokestatic getEntries : ()Lkotlin/enums/EnumEntries;
/*     */     //   294: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   299: astore #4
/*     */     //   301: aload #4
/*     */     //   303: invokeinterface hasNext : ()Z
/*     */     //   308: ifeq -> 444
/*     */     //   311: aload #4
/*     */     //   313: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   318: checkcast net/integr/modules/filters/Filter
/*     */     //   321: astore #5
/*     */     //   323: aload_0
/*     */     //   324: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   327: new net/integr/rendering/uisystem/ToggleButton
/*     */     //   330: dup
/*     */     //   331: aload_0
/*     */     //   332: getfield field_22789 : I
/*     */     //   335: iconst_2
/*     */     //   336: idiv
/*     */     //   337: aload_0
/*     */     //   338: getfield preInitSizeX : I
/*     */     //   341: iconst_2
/*     */     //   342: idiv
/*     */     //   343: isub
/*     */     //   344: iload_3
/*     */     //   345: iadd
/*     */     //   346: aload_0
/*     */     //   347: getfield field_22790 : I
/*     */     //   350: iconst_2
/*     */     //   351: idiv
/*     */     //   352: aload_0
/*     */     //   353: getfield preInitSizeY : I
/*     */     //   356: iconst_2
/*     */     //   357: idiv
/*     */     //   358: isub
/*     */     //   359: bipush #45
/*     */     //   361: isub
/*     */     //   362: iconst_5
/*     */     //   363: isub
/*     */     //   364: bipush #65
/*     */     //   366: bipush #20
/*     */     //   368: aload #5
/*     */     //   370: invokevirtual name : ()Ljava/lang/String;
/*     */     //   373: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   378: iconst_1
/*     */     //   379: ldc_w 'Select a filter'
/*     */     //   382: iconst_1
/*     */     //   383: new net/integr/rendering/screens/MenuScreen$fil$1
/*     */     //   386: dup
/*     */     //   387: aload_0
/*     */     //   388: aload #5
/*     */     //   390: invokespecial <init> : (Lnet/integr/rendering/screens/MenuScreen;Lnet/integr/modules/filters/Filter;)V
/*     */     //   393: checkcast kotlin/jvm/functions/Function1
/*     */     //   396: invokespecial <init> : (IIIILjava/lang/String;ZLjava/lang/String;ZLkotlin/jvm/functions/Function1;)V
/*     */     //   399: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   402: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   405: astore #6
/*     */     //   407: aload_0
/*     */     //   408: getfield filters : Ljava/util/List;
/*     */     //   411: checkcast java/util/Collection
/*     */     //   414: new net/integr/rendering/screens/MenuScreen$PosWrapper
/*     */     //   417: dup
/*     */     //   418: aload #6
/*     */     //   420: iload_3
/*     */     //   421: bipush #-40
/*     */     //   423: aconst_null
/*     */     //   424: aconst_null
/*     */     //   425: bipush #24
/*     */     //   427: aconst_null
/*     */     //   428: invokespecial <init> : (Lnet/integr/rendering/uisystem/base/HelixUiElement;IILnet/integr/modules/filters/Filter;Ljava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   431: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   436: pop
/*     */     //   437: iinc #3, 70
/*     */     //   440: nop
/*     */     //   441: goto -> 301
/*     */     //   444: aload_0
/*     */     //   445: aload_0
/*     */     //   446: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   449: new net/integr/rendering/uisystem/Box
/*     */     //   452: dup
/*     */     //   453: aload_0
/*     */     //   454: getfield field_22789 : I
/*     */     //   457: iconst_2
/*     */     //   458: idiv
/*     */     //   459: aload_0
/*     */     //   460: getfield preInitSizeX : I
/*     */     //   463: iconst_2
/*     */     //   464: idiv
/*     */     //   465: isub
/*     */     //   466: aload_0
/*     */     //   467: getfield field_22790 : I
/*     */     //   470: iconst_2
/*     */     //   471: idiv
/*     */     //   472: aload_0
/*     */     //   473: getfield preInitSizeY : I
/*     */     //   476: iconst_2
/*     */     //   477: idiv
/*     */     //   478: isub
/*     */     //   479: aload_0
/*     */     //   480: getfield preInitSizeX : I
/*     */     //   483: aload_0
/*     */     //   484: getfield preInitSizeY : I
/*     */     //   487: aconst_null
/*     */     //   488: iconst_0
/*     */     //   489: iconst_0
/*     */     //   490: iconst_0
/*     */     //   491: sipush #192
/*     */     //   494: aconst_null
/*     */     //   495: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   498: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   501: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   504: dup
/*     */     //   505: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   508: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   511: checkcast net/integr/rendering/uisystem/Box
/*     */     //   514: putfield backgroundBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   517: aload_0
/*     */     //   518: aload_0
/*     */     //   519: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   522: new net/integr/rendering/uisystem/Box
/*     */     //   525: dup
/*     */     //   526: aload_0
/*     */     //   527: getfield field_22789 : I
/*     */     //   530: iconst_2
/*     */     //   531: idiv
/*     */     //   532: aload_0
/*     */     //   533: getfield preInitSizeX : I
/*     */     //   536: iconst_2
/*     */     //   537: idiv
/*     */     //   538: isub
/*     */     //   539: aload_0
/*     */     //   540: getfield field_22790 : I
/*     */     //   543: iconst_2
/*     */     //   544: idiv
/*     */     //   545: aload_0
/*     */     //   546: getfield preInitSizeY : I
/*     */     //   549: iconst_2
/*     */     //   550: idiv
/*     */     //   551: isub
/*     */     //   552: bipush #45
/*     */     //   554: isub
/*     */     //   555: bipush #40
/*     */     //   557: isub
/*     */     //   558: aload_0
/*     */     //   559: getfield preInitSizeX : I
/*     */     //   562: bipush #20
/*     */     //   564: ldc_w 'Onyx'
/*     */     //   567: iconst_0
/*     */     //   568: iconst_0
/*     */     //   569: iconst_0
/*     */     //   570: sipush #192
/*     */     //   573: aconst_null
/*     */     //   574: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   577: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   580: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   583: dup
/*     */     //   584: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   587: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   590: checkcast net/integr/rendering/uisystem/Box
/*     */     //   593: putfield actionRowBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   596: aload_0
/*     */     //   597: aload_0
/*     */     //   598: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   601: new net/integr/rendering/uisystem/Box
/*     */     //   604: dup
/*     */     //   605: aload_0
/*     */     //   606: getfield field_22789 : I
/*     */     //   609: iconst_2
/*     */     //   610: idiv
/*     */     //   611: aload_0
/*     */     //   612: getfield preInitSizeX : I
/*     */     //   615: iconst_2
/*     */     //   616: idiv
/*     */     //   617: isub
/*     */     //   618: aload_0
/*     */     //   619: getfield field_22790 : I
/*     */     //   622: iconst_2
/*     */     //   623: idiv
/*     */     //   624: aload_0
/*     */     //   625: getfield preInitSizeY : I
/*     */     //   628: iconst_2
/*     */     //   629: idiv
/*     */     //   630: isub
/*     */     //   631: bipush #45
/*     */     //   633: isub
/*     */     //   634: aload_0
/*     */     //   635: getfield preInitSizeX : I
/*     */     //   638: bipush #30
/*     */     //   640: aconst_null
/*     */     //   641: iconst_0
/*     */     //   642: iconst_0
/*     */     //   643: iconst_0
/*     */     //   644: sipush #192
/*     */     //   647: aconst_null
/*     */     //   648: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   651: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   654: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   657: dup
/*     */     //   658: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   661: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   664: checkcast net/integr/rendering/uisystem/Box
/*     */     //   667: putfield filterRowBox : Lnet/integr/rendering/uisystem/Box;
/*     */     //   670: aload_0
/*     */     //   671: aload_0
/*     */     //   672: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   675: new net/integr/rendering/uisystem/Box
/*     */     //   678: dup
/*     */     //   679: aload_0
/*     */     //   680: getfield field_22789 : I
/*     */     //   683: iconst_2
/*     */     //   684: idiv
/*     */     //   685: aload_0
/*     */     //   686: getfield preInitSizeX : I
/*     */     //   689: iconst_2
/*     */     //   690: idiv
/*     */     //   691: iadd
/*     */     //   692: sipush #155
/*     */     //   695: isub
/*     */     //   696: aload_0
/*     */     //   697: getfield field_22790 : I
/*     */     //   700: iconst_2
/*     */     //   701: idiv
/*     */     //   702: aload_0
/*     */     //   703: getfield preInitSizeY : I
/*     */     //   706: iconst_2
/*     */     //   707: idiv
/*     */     //   708: isub
/*     */     //   709: bipush #45
/*     */     //   711: isub
/*     */     //   712: iconst_5
/*     */     //   713: iadd
/*     */     //   714: sipush #150
/*     */     //   717: bipush #20
/*     */     //   719: getstatic net/minecraft/class_124.field_1056 : Lnet/minecraft/class_124;
/*     */     //   722: <illegal opcode> makeConcatWithConstants : (Lnet/minecraft/class_124;)Ljava/lang/String;
/*     */     //   727: iconst_0
/*     */     //   728: iconst_0
/*     */     //   729: iconst_1
/*     */     //   730: bipush #64
/*     */     //   732: aconst_null
/*     */     //   733: invokespecial <init> : (IIIILjava/lang/String;ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V
/*     */     //   736: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   739: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   742: dup
/*     */     //   743: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.Box'
/*     */     //   746: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   749: checkcast net/integr/rendering/uisystem/Box
/*     */     //   752: putfield searchBar : Lnet/integr/rendering/uisystem/Box;
/*     */     //   755: aload_0
/*     */     //   756: aload_0
/*     */     //   757: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   760: new net/integr/rendering/uisystem/IconButton
/*     */     //   763: dup
/*     */     //   764: aload_0
/*     */     //   765: getfield field_22789 : I
/*     */     //   768: iconst_2
/*     */     //   769: idiv
/*     */     //   770: aload_0
/*     */     //   771: getfield preInitSizeX : I
/*     */     //   774: iconst_2
/*     */     //   775: idiv
/*     */     //   776: iadd
/*     */     //   777: bipush #19
/*     */     //   779: isub
/*     */     //   780: aload_0
/*     */     //   781: getfield field_22790 : I
/*     */     //   784: iconst_2
/*     */     //   785: idiv
/*     */     //   786: aload_0
/*     */     //   787: getfield preInitSizeY : I
/*     */     //   790: iconst_2
/*     */     //   791: idiv
/*     */     //   792: isub
/*     */     //   793: bipush #45
/*     */     //   795: isub
/*     */     //   796: bipush #40
/*     */     //   798: isub
/*     */     //   799: bipush #20
/*     */     //   801: bipush #20
/*     */     //   803: ldc_w '⌂'
/*     */     //   806: ldc_w 'Move the UI elements'
/*     */     //   809: aload_0
/*     */     //   810: <illegal opcode> run : (Lnet/integr/rendering/screens/MenuScreen;)Ljava/lang/Runnable;
/*     */     //   815: invokespecial <init> : (IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
/*     */     //   818: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   821: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   824: dup
/*     */     //   825: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.IconButton'
/*     */     //   828: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   831: checkcast net/integr/rendering/uisystem/IconButton
/*     */     //   834: putfield moveButton : Lnet/integr/rendering/uisystem/IconButton;
/*     */     //   837: aload_0
/*     */     //   838: aload_0
/*     */     //   839: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   842: new net/integr/rendering/uisystem/IconButton
/*     */     //   845: dup
/*     */     //   846: aload_0
/*     */     //   847: getfield field_22789 : I
/*     */     //   850: iconst_2
/*     */     //   851: idiv
/*     */     //   852: aload_0
/*     */     //   853: getfield preInitSizeX : I
/*     */     //   856: iconst_2
/*     */     //   857: idiv
/*     */     //   858: iadd
/*     */     //   859: bipush #43
/*     */     //   861: isub
/*     */     //   862: aload_0
/*     */     //   863: getfield field_22790 : I
/*     */     //   866: iconst_2
/*     */     //   867: idiv
/*     */     //   868: aload_0
/*     */     //   869: getfield preInitSizeY : I
/*     */     //   872: iconst_2
/*     */     //   873: idiv
/*     */     //   874: isub
/*     */     //   875: bipush #45
/*     */     //   877: isub
/*     */     //   878: bipush #40
/*     */     //   880: isub
/*     */     //   881: bipush #20
/*     */     //   883: bipush #20
/*     */     //   885: ldc_w '≡'
/*     */     //   888: ldc_w 'Open the general settings'
/*     */     //   891: aload_0
/*     */     //   892: <illegal opcode> run : (Lnet/integr/rendering/screens/MenuScreen;)Ljava/lang/Runnable;
/*     */     //   897: invokespecial <init> : (IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
/*     */     //   900: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   903: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   906: dup
/*     */     //   907: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.IconButton'
/*     */     //   910: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   913: checkcast net/integr/rendering/uisystem/IconButton
/*     */     //   916: putfield settingsButton : Lnet/integr/rendering/uisystem/IconButton;
/*     */     //   919: aload_0
/*     */     //   920: aload_0
/*     */     //   921: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   924: new net/integr/rendering/uisystem/IconButton
/*     */     //   927: dup
/*     */     //   928: aload_0
/*     */     //   929: getfield field_22789 : I
/*     */     //   932: iconst_2
/*     */     //   933: idiv
/*     */     //   934: aload_0
/*     */     //   935: getfield preInitSizeX : I
/*     */     //   938: iconst_2
/*     */     //   939: idiv
/*     */     //   940: iadd
/*     */     //   941: bipush #43
/*     */     //   943: isub
/*     */     //   944: bipush #24
/*     */     //   946: isub
/*     */     //   947: aload_0
/*     */     //   948: getfield field_22790 : I
/*     */     //   951: iconst_2
/*     */     //   952: idiv
/*     */     //   953: aload_0
/*     */     //   954: getfield preInitSizeY : I
/*     */     //   957: iconst_2
/*     */     //   958: idiv
/*     */     //   959: isub
/*     */     //   960: bipush #45
/*     */     //   962: isub
/*     */     //   963: bipush #40
/*     */     //   965: isub
/*     */     //   966: bipush #20
/*     */     //   968: bipush #20
/*     */     //   970: ldc_w '↑'
/*     */     //   973: ldc_w 'Export your config'
/*     */     //   976: <illegal opcode> run : ()Ljava/lang/Runnable;
/*     */     //   981: invokespecial <init> : (IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
/*     */     //   984: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   987: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   990: dup
/*     */     //   991: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.IconButton'
/*     */     //   994: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   997: checkcast net/integr/rendering/uisystem/IconButton
/*     */     //   1000: putfield exportButton : Lnet/integr/rendering/uisystem/IconButton;
/*     */     //   1003: aload_0
/*     */     //   1004: aload_0
/*     */     //   1005: getfield layout : Lnet/integr/rendering/uisystem/UiLayout;
/*     */     //   1008: new net/integr/rendering/uisystem/IconButton
/*     */     //   1011: dup
/*     */     //   1012: aload_0
/*     */     //   1013: getfield field_22789 : I
/*     */     //   1016: iconst_2
/*     */     //   1017: idiv
/*     */     //   1018: aload_0
/*     */     //   1019: getfield preInitSizeX : I
/*     */     //   1022: iconst_2
/*     */     //   1023: idiv
/*     */     //   1024: iadd
/*     */     //   1025: bipush #43
/*     */     //   1027: isub
/*     */     //   1028: bipush #24
/*     */     //   1030: isub
/*     */     //   1031: bipush #24
/*     */     //   1033: isub
/*     */     //   1034: aload_0
/*     */     //   1035: getfield field_22790 : I
/*     */     //   1038: iconst_2
/*     */     //   1039: idiv
/*     */     //   1040: aload_0
/*     */     //   1041: getfield preInitSizeY : I
/*     */     //   1044: iconst_2
/*     */     //   1045: idiv
/*     */     //   1046: isub
/*     */     //   1047: bipush #45
/*     */     //   1049: isub
/*     */     //   1050: bipush #40
/*     */     //   1052: isub
/*     */     //   1053: bipush #20
/*     */     //   1055: bipush #20
/*     */     //   1057: ldc_w '↓'
/*     */     //   1060: ldc_w 'Import a config'
/*     */     //   1063: <illegal opcode> run : ()Ljava/lang/Runnable;
/*     */     //   1068: invokespecial <init> : (IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
/*     */     //   1071: checkcast net/integr/rendering/uisystem/base/HelixUiElement
/*     */     //   1074: invokevirtual add : (Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   1077: dup
/*     */     //   1078: ldc_w 'null cannot be cast to non-null type net.integr.rendering.uisystem.IconButton'
/*     */     //   1081: invokestatic checkNotNull : (Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   1084: checkcast net/integr/rendering/uisystem/IconButton
/*     */     //   1087: putfield importButton : Lnet/integr/rendering/uisystem/IconButton;
/*     */     //   1090: nop
/*     */     //   1091: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #35	-> 0
/*     */     //   #40	-> 12
/*     */     //   #43	-> 23
/*     */     //   #50	-> 30
/*     */     //   #59	-> 36
/*     */     //   #59	-> 47
/*     */     //   #60	-> 50
/*     */     //   #60	-> 61
/*     */     //   #62	-> 64
/*     */     //   #62	-> 75
/*     */     //   #185	-> 78
/*     */     //   #186	-> 79
/*     */     //   #188	-> 89
/*     */     //   #189	-> 91
/*     */     //   #191	-> 93
/*     */     //   #192	-> 125
/*     */     //   #197	-> 217
/*     */     //   #199	-> 269
/*     */     //   #200	-> 277
/*     */     //   #201	-> 278
/*     */     //   #202	-> 283
/*     */     //   #205	-> 289
/*     */     //   #207	-> 291
/*     */     //   #208	-> 323
/*     */     //   #212	-> 407
/*     */     //   #214	-> 440
/*     */     //   #217	-> 444
/*     */     //   #219	-> 517
/*     */     //   #220	-> 596
/*     */     //   #222	-> 670
/*     */     //   #224	-> 755
/*     */     //   #229	-> 837
/*     */     //   #234	-> 919
/*     */     //   #238	-> 1003
/*     */     //   #241	-> 1090
/*     */     //   #35	-> 1091
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   217	69	5	b	Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   125	161	4	m	Lnet/integr/modules/management/Module;
/*     */     //   407	34	6	fil	Lnet/integr/rendering/uisystem/base/HelixUiElement;
/*     */     //   323	118	5	f	Lnet/integr/modules/filters/Filter;
/*     */     //   91	999	1	currY	I
/*     */     //   93	997	2	mCount	I
/*     */     //   291	799	3	currX	I
/*     */     //   0	1092	0	this	Lnet/integr/rendering/screens/MenuScreen;
/*     */   }
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/MenuScreen$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_437;", "INSTANCE", "Lnet/minecraft/class_437;", "getINSTANCE", "()Lnet/minecraft/class_437;", "onyx2"})
/*     */   public static final class Companion { private Companion() {}
/*     */     
/*     */     @NotNull
/*  37 */     public final class_437 getINSTANCE() { return MenuScreen.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @NotNull private final UiLayout layout; private int preInitSizeY; private int preInitSizeX; @Nullable private Box backgroundBox; @Nullable private Box actionRowBox; @Nullable private Box filterRowBox; @Nullable private Box searchBar; @NotNull private String search; private boolean shiftDown; @Nullable private IconButton moveButton; @Nullable private IconButton settingsButton; @Nullable private IconButton exportButton; @Nullable private IconButton importButton; @NotNull private List<Filter> selectedFilters; @NotNull private List<PosWrapper> filters; @NotNull private final List<PosWrapper> modules; private int currentScrollPaneY; private int oldHeight; @NotNull private static final class_437 INSTANCE = new MenuScreen();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  69 */     Intrinsics.checkNotNullParameter(context, "context"); int nHeight = RenderLerper.Companion.lerpWithDefDelta(this.oldHeight, this.field_22790);
/*  70 */     this.oldHeight = nHeight;
/*     */     
/*  72 */     this.preInitSizeY = (int)(nHeight / 1.8D);
/*     */     
/*  74 */     Intrinsics.checkNotNull(this.backgroundBox); this.backgroundBox.setYSize(this.preInitSizeY);
/*     */     
/*  76 */     Intrinsics.checkNotNull(this.backgroundBox); this.backgroundBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2).method_25394(context, mouseX, mouseY, delta);
/*  77 */     Intrinsics.checkNotNull(this.actionRowBox); this.actionRowBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2 - 45 - 40).method_25394(context, mouseX, mouseY, delta);
/*  78 */     Intrinsics.checkNotNull(this.filterRowBox); this.filterRowBox.update(this.field_22789 / 2 - this.preInitSizeX / 2, nHeight / 2 - this.preInitSizeY / 2 - 45).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  80 */     Intrinsics.checkNotNull(this.moveButton); this.moveButton.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 19, nHeight / 2 - this.preInitSizeY / 2 - 45 - 40).method_25394(context, mouseX, mouseY, delta);
/*  81 */     Intrinsics.checkNotNull(this.settingsButton); this.settingsButton.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 43, nHeight / 2 - this.preInitSizeY / 2 - 45 - 40).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  83 */     Intrinsics.checkNotNull(this.exportButton); this.exportButton.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 43 - 24, nHeight / 2 - this.preInitSizeY / 2 - 45 - 40).method_25394(context, mouseX, mouseY, delta);
/*  84 */     Intrinsics.checkNotNull(this.importButton); this.importButton.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 43 - 24 - 24, nHeight / 2 - this.preInitSizeY / 2 - 45 - 40).method_25394(context, mouseX, mouseY, delta);
/*     */ 
/*     */     
/*  87 */     Intrinsics.checkNotNull(this.searchBar); this.searchBar.update(this.field_22789 / 2 + this.preInitSizeX / 2 - 155, nHeight / 2 - this.preInitSizeY / 2 - 45 + 5).method_25394(context, mouseX, mouseY, delta);
/*     */     
/*  89 */     reloadList();
/*     */     
/*  91 */     boolean shouldCursorReset = true;
/*     */     
/*  93 */     for (PosWrapper f : this.filters) {
/*  94 */       f.getElement().update(this.field_22789 / 2 - this.preInitSizeX / 2 + f.getXO(), nHeight / 2 - this.preInitSizeY / 2 + f.getYO()).method_25394(context, mouseX, mouseY, delta);
/*     */     }
/*     */     
/*  97 */     for (PosWrapper f : this.filters) {
/*  98 */       if (f.getElement().renderTooltip(context, mouseX, mouseY, delta)) shouldCursorReset = false;
/*     */     
/*     */     } 
/* 101 */     for (PosWrapper l : this.modules) {
/* 102 */       for (Filter f : this.selectedFilters) { if (l.getFilter() != f) {
/* 103 */           this.layout.lock(l.getElement());
/* 104 */           this.layout.mark(l.getElement());
/*     */         }  }
/*     */ 
/*     */       
/* 108 */       if (!matchesSearchingPredicate(this.search, l.getSearchingTags())) {
/* 109 */         this.layout.lock(l.getElement());
/* 110 */         this.layout.mark(l.getElement());
/*     */         
/*     */         continue;
/*     */       } 
/* 114 */       int cTop = nHeight / 2 - this.preInitSizeY / 2 + l.getYO() - this.currentScrollPaneY;
/* 115 */       Intrinsics.checkNotNull(l.getElement(), "null cannot be cast to non-null type net.integr.rendering.uisystem.ModuleButton"); int cBottom = nHeight / 2 - this.preInitSizeY / 2 + l.getYO() + ((ModuleButton)l.getElement()).getYSize() - this.currentScrollPaneY;
/*     */       
/* 117 */       Intrinsics.checkNotNull(this.backgroundBox); if (cBottom < nHeight / 2 - this.preInitSizeY / 2 + 5 || cTop > nHeight / 2 - this.preInitSizeY / 2 + this.backgroundBox.getYSize() - 5) {
/* 118 */         this.layout.lock(l.getElement());
/*     */       } else {
/* 120 */         this.layout.unLock(l.getElement());
/* 121 */         this.layout.unMark(l.getElement());
/*     */       } 
/*     */       
/* 124 */       Intrinsics.checkNotNull(this.backgroundBox); Intrinsics.checkNotNull(this.backgroundBox); context.method_44379(this.field_22789 / 2 - this.preInitSizeX / 2 + 5, nHeight / 2 - this.preInitSizeY / 2 + 5, this.field_22789 / 2 - this.preInitSizeX / 2 + this.backgroundBox.getXSize() - 5, nHeight / 2 - this.preInitSizeY / 2 + this.backgroundBox.getYSize() - 5);
/* 125 */       ((ModuleButton)l.getElement()).update(this.field_22789 / 2 - this.preInitSizeX / 2 + l.getXO(), nHeight / 2 - this.preInitSizeY / 2 + l.getYO() - this.currentScrollPaneY).method_25394(context, mouseX, mouseY, delta);
/* 126 */       context.method_44380();
/*     */     } 
/*     */     
/* 129 */     label67: for (PosWrapper l : this.modules) {
/* 130 */       for (Filter f : this.selectedFilters) { if (l.getFilter() != f)
/*     */           continue label67;  }
/* 132 */        if (matchesSearchingPredicate(this.search, l.getSearchingTags())) {
/*     */         
/* 134 */         int cTop = nHeight / 2 - this.preInitSizeY / 2 + l.getYO() - this.currentScrollPaneY;
/* 135 */         Intrinsics.checkNotNull(l.getElement(), "null cannot be cast to non-null type net.integr.rendering.uisystem.ModuleButton"); int cBottom = nHeight / 2 - this.preInitSizeY / 2 + l.getYO() + ((ModuleButton)l.getElement()).getYSize() - this.currentScrollPaneY;
/*     */         
/* 137 */         Intrinsics.checkNotNull(this.backgroundBox); if (cBottom < nHeight / 2 - this.preInitSizeY / 2 + 5 || cTop > nHeight / 2 - this.preInitSizeY / 2 + this.backgroundBox.getYSize() - 5) {
/*     */           continue;
/*     */         }
/*     */         
/* 141 */         if (l.getElement().renderTooltip(context, mouseX, mouseY, delta)) shouldCursorReset = false; 
/*     */       } 
/*     */     } 
/* 144 */     Intrinsics.checkNotNull(this.moveButton); if (this.moveButton.renderTooltip(context, mouseX, mouseY, delta)) shouldCursorReset = false; 
/* 145 */     Intrinsics.checkNotNull(this.settingsButton); if (this.settingsButton.renderTooltip(context, mouseX, mouseY, delta)) shouldCursorReset = false;
/*     */     
/* 147 */     Intrinsics.checkNotNull(this.exportButton); if (this.exportButton.renderTooltip(context, mouseX, mouseY, delta)) shouldCursorReset = false; 
/* 148 */     Intrinsics.checkNotNull(this.importButton); if (this.importButton.renderTooltip(context, mouseX, mouseY, delta)) shouldCursorReset = false;
/*     */     
/* 150 */     if (shouldCursorReset) this.layout.resetCursor(); 
/*     */   }
/*     */   
/*     */   private final int getXFromIndex(int index) {
/* 154 */     switch (index) { case 0: case 1: case 2:  }  return 
/*     */ 
/*     */ 
/*     */       
/* 158 */       1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_25420(@Nullable class_332 context, int mouseX, int mouseY, float delta) {}
/*     */ 
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 167 */     this.layout.onClick(mouseX, mouseY, button);
/* 168 */     return true;
/*     */   }
/*     */   
/*     */   public boolean method_25406(double mouseX, double mouseY, int button) {
/* 172 */     this.layout.onRelease(mouseX, mouseY, button);
/* 173 */     return true;
/*     */   } private static final void _init_$lambda$1(MenuScreen this$0) { Intrinsics.checkNotNullParameter(this$0, "this$0"); this$0.currentScrollPaneY = 0; this$0.oldHeight = 0; } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\016\n\002\030\002\n\000\n\002\020\002\n\002\b\003\020\005\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Lnet/integr/rendering/uisystem/ToggleButton;", "it", "", "invoke", "(Lnet/integr/rendering/uisystem/ToggleButton;)V", "<anonymous>"}) static final class MenuScreen$fil$1 extends Lambda implements Function1<ToggleButton, Unit> {
/*     */     public final void invoke(@NotNull ToggleButton it) { Intrinsics.checkNotNullParameter(it, "it"); if (it.getEnabled()) { MenuScreen.this.selectedFilters.add(this.$f); } else { MenuScreen.this.selectedFilters.remove(this.$f); }  } MenuScreen$fil$1(Filter $f) { super(1); } } private static final void _init_$lambda$2(MenuScreen this$0) { Intrinsics.checkNotNullParameter(this$0, "this$0"); Onyx.Companion.getMC().method_1507(UiMoveScreen.Companion.getINSTANCE()); this$0.oldHeight = 0; }
/*     */   private static final void _init_$lambda$3(MenuScreen this$0) { Intrinsics.checkNotNullParameter(this$0, "this$0"); Onyx.Companion.getMC().method_1507(new SettingsScreen()); this$0.oldHeight = 0; }
/* 177 */   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) { this.currentScrollPaneY -= (int)verticalAmount * 10;
/*     */     
/* 179 */     if (this.currentScrollPaneY <= 0) this.currentScrollPaneY = 0;
/*     */     
/* 181 */     int i = this.currentScrollPaneY, j = 0; List list = ModuleManager.Companion.getModules(); MenuScreen menuScreen = this; int $i$f$count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     int count$iv = 0;
/* 341 */     for (Object element$iv : list) { Module it = (Module)element$iv; int $i$a$-count-MenuScreen$mouseScrolled$1 = 0; if (matchesSearchingPredicate(this.search, it.getSearchingTags()) && ++count$iv < 0) CollectionsKt.throwCountOverflow();  }
/* 342 */      byte b = (list instanceof Collection && list.isEmpty()) ? 0 : count$iv; int k = (b / 3 + 2) * 25 - this.preInitSizeY; j = Math.max(j, k); menuScreen.currentScrollPaneY = Math.min(i, j); return true; }
/* 343 */   private static final void _init_$lambda$4() { ModuleManager.Companion.saveToOCG(); } private static final void _init_$lambda$5() { ModuleManager.Companion.loadFromOCG(); } private final void reloadList() { int currY = 5; int mCount = 0; for (PosWrapper pw : this.modules) { if (!this.layout.isMarked(pw.getElement())) { List<PosWrapper> list1 = this.modules; MenuScreen menuScreen = this; PosWrapper posWrapper = pw; int $i$f$filter = 0; List<PosWrapper> list2 = list1; Collection<Object> destination$iv$iv = new ArrayList(); int $i$f$filterTo = 0;
/* 344 */         for (PosWrapper element$iv$iv : list2) { PosWrapper it = element$iv$iv; int $i$a$-filter-MenuScreen$reloadList$1 = 0; if (!this.layout.isMarked(it.getElement())) destination$iv$iv.add(element$iv$iv);  }
/* 345 */          List list = (List)destination$iv$iv; posWrapper.setXO(menuScreen.getXFromIndex(list.indexOf(pw) % 3)); pw.setYO(currY); if (mCount == 2) { currY += 25; mCount = 0; continue; }  mCount++; }  }  } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\020 \n\002\020\016\n\002\b\017\n\002\020\013\n\002\b\022\b\b\030\0002\0020\001B;\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\006\032\0020\004\022\n\b\002\020\b\032\004\030\0010\007\022\016\b\002\020\013\032\b\022\004\022\0020\n0\t¢\006\004\b\f\020\rJ\020\020\016\032\0020\002HÆ\003¢\006\004\b\016\020\017J\020\020\020\032\0020\004HÆ\003¢\006\004\b\020\020\021J\020\020\022\032\0020\004HÆ\003¢\006\004\b\022\020\021J\022\020\023\032\004\030\0010\007HÆ\003¢\006\004\b\023\020\024J\026\020\025\032\b\022\004\022\0020\n0\tHÆ\003¢\006\004\b\025\020\026JJ\020\027\032\0020\0002\b\b\002\020\003\032\0020\0022\b\b\002\020\005\032\0020\0042\b\b\002\020\006\032\0020\0042\n\b\002\020\b\032\004\030\0010\0072\016\b\002\020\013\032\b\022\004\022\0020\n0\tHÆ\001¢\006\004\b\027\020\030J\032\020\033\032\0020\0322\b\020\031\032\004\030\0010\001HÖ\003¢\006\004\b\033\020\034J\020\020\035\032\0020\004HÖ\001¢\006\004\b\035\020\021J\020\020\036\032\0020\nHÖ\001¢\006\004\b\036\020\037R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020 \032\004\b!\020\017R\031\020\b\032\004\030\0010\0078\006¢\006\f\n\004\b\b\020\"\032\004\b#\020\024R\035\020\013\032\b\022\004\022\0020\n0\t8\006¢\006\f\n\004\b\013\020$\032\004\b%\020\026R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020&\032\004\b'\020\021\"\004\b(\020)R\"\020\006\032\0020\0048\006@\006X\016¢\006\022\n\004\b\006\020&\032\004\b*\020\021\"\004\b+\020)¨\006,"}, d2 = {"Lnet/integr/rendering/screens/MenuScreen$PosWrapper;", "", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "element", "", "xO", "yO", "Lnet/integr/modules/filters/Filter;", "filter", "", "", "searchingTags", "<init>", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;IILnet/integr/modules/filters/Filter;Ljava/util/List;)V", "component1", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "component2", "()I", "component3", "component4", "()Lnet/integr/modules/filters/Filter;", "component5", "()Ljava/util/List;", "copy", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;IILnet/integr/modules/filters/Filter;Ljava/util/List;)Lnet/integr/rendering/screens/MenuScreen$PosWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getElement", "Lnet/integr/modules/filters/Filter;", "getFilter", "Ljava/util/List;", "getSearchingTags", "I", "getXO", "setXO", "(I)V", "getYO", "setYO", "onyx2"}) public static final class PosWrapper {
/* 346 */     @NotNull private final HelixUiElement element; private int xO; private int yO; @Nullable private final Filter filter; @NotNull private final List<String> searchingTags; public PosWrapper(@NotNull HelixUiElement element, int xO, int yO, @Nullable Filter filter, @NotNull List<String> searchingTags) { this.element = element; this.xO = xO; this.yO = yO; this.filter = filter; this.searchingTags = searchingTags; } @NotNull public final HelixUiElement getElement() { return this.element; } public final int getXO() { return this.xO; } public final void setXO(int <set-?>) { this.xO = <set-?>; } public final int getYO() { return this.yO; } public final void setYO(int <set-?>) { this.yO = <set-?>; } @Nullable public final Filter getFilter() { return this.filter; } @NotNull public final List<String> getSearchingTags() { return this.searchingTags; } @NotNull public final HelixUiElement component1() { return this.element; } public final int component2() { return this.xO; } public final int component3() { return this.yO; } @Nullable public final Filter component4() { return this.filter; } @NotNull public final List<String> component5() { return this.searchingTags; } @NotNull public final PosWrapper copy(@NotNull HelixUiElement element, int xO, int yO, @Nullable Filter filter, @NotNull List<String> searchingTags) { Intrinsics.checkNotNullParameter(element, "element"); Intrinsics.checkNotNullParameter(searchingTags, "searchingTags"); return new PosWrapper(element, xO, yO, filter, searchingTags); } @NotNull public String toString() { return "PosWrapper(element=" + this.element + ", xO=" + this.xO + ", yO=" + this.yO + ", filter=" + this.filter + ", searchingTags=" + this.searchingTags + ")"; } public int hashCode() { result = this.element.hashCode(); result = result * 31 + Integer.hashCode(this.xO); result = result * 31 + Integer.hashCode(this.yO); result = result * 31 + ((this.filter == null) ? 0 : this.filter.hashCode()); return result * 31 + this.searchingTags.hashCode(); } public boolean equals(@Nullable Object other) { if (this == other) return true;  if (!(other instanceof PosWrapper)) return false;  PosWrapper posWrapper = (PosWrapper)other; return !Intrinsics.areEqual(this.element, posWrapper.element) ? false : ((this.xO != posWrapper.xO) ? false : ((this.yO != posWrapper.yO) ? false : ((this.filter != posWrapper.filter) ? false : (!!Intrinsics.areEqual(this.searchingTags, posWrapper.searchingTags))))); } } public void method_25419() { Onyx.Companion.getMC().method_1507(null); this.layout.resetCursor(); this.oldHeight = 0; } private final boolean matchesSearchingPredicate(String search, List tags) { for (String ta : tags) { Intrinsics.checkNotNullExpressionValue(search.toLowerCase(Locale.ROOT), "toLowerCase(...)"); String str1 = search.toLowerCase(Locale.ROOT); CharSequence charSequence2 = ta; int $i$f$filter = 0; CharSequence charSequence1 = str1; Appendable destination$iv$iv = new StringBuilder(); int $i$f$filterTo = 0;
/* 347 */       for (int index$iv$iv = 0, i = charSequence1.length(); index$iv$iv < i; index$iv$iv++) {
/* 348 */         char element$iv$iv = charSequence1.charAt(index$iv$iv);
/* 349 */         char it = element$iv$iv; int $i$a$-filter-MenuScreen$matchesSearchingPredicate$1 = 0; if ((it != ' ')) destination$iv$iv.append(element$iv$iv); 
/*     */       } 
/* 351 */       Intrinsics.checkNotNullExpressionValue(((StringBuilder)destination$iv$iv).toString(), "toString(...)"); if (StringsKt.contains$default(charSequence2, ((StringBuilder)destination$iv$iv).toString(), false, 2, null))
/*     */         return true;  }
/*     */     
/*     */     return false; }
/*     */ 
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/*     */     String kn;
/*     */     switch (keyCode) {
/*     */       case 259:
/*     */         if ((((CharSequence)this.search).length() > 0)) {
/*     */           Intrinsics.checkNotNullExpressionValue(this.search.substring(0, this.search.length() - 1), "substring(...)");
/*     */           this.search = this.search.substring(0, this.search.length() - 1);
/*     */         } 
/*     */         break;
/*     */       case 344:
/*     */         this.shiftDown = true;
/*     */         break;
/*     */       case 340:
/*     */         this.shiftDown = true;
/*     */         break;
/*     */       case 256:
/*     */         this.search = "";
/*     */         this.currentScrollPaneY = 0;
/*     */         break;
/*     */       case 32:
/*     */         this.search += " ";
/*     */         break;
/*     */       default:
/*     */         if (this.shiftDown) {
/*     */           String str = GLFW.glfwGetKeyName(keyCode, scanCode);
/*     */           if (str != null) {
/*     */             Intrinsics.checkNotNullExpressionValue(str.toUpperCase(Locale.ROOT), "toUpperCase(...)");
/*     */             this.search += this.search;
/*     */           } 
/*     */           break;
/*     */         } 
/*     */         kn = GLFW.glfwGetKeyName(keyCode, scanCode);
/*     */         if (kn != null)
/*     */           this.search += this.search; 
/*     */         break;
/*     */     } 
/*     */     if (Intrinsics.areEqual(this.search, "")) {
/*     */       Intrinsics.checkNotNull(this.searchBar);
/*     */       this.searchBar.setText("" + class_124.field_1056 + "Search modules...");
/*     */     } else {
/*     */       Intrinsics.checkNotNull(this.searchBar);
/*     */       this.searchBar.setText(this.search);
/*     */     } 
/*     */     return super.method_25404(keyCode, scanCode, modifiers);
/*     */   }
/*     */   
/*     */   public boolean method_16803(int keyCode, int scanCode, int modifiers) {
/*     */     switch (keyCode) {
/*     */       case 344:
/*     */         this.shiftDown = false;
/*     */         break;
/*     */       case 340:
/*     */         this.shiftDown = false;
/*     */         break;
/*     */     } 
/*     */     return super.method_16803(keyCode, scanCode, modifiers);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\MenuScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */