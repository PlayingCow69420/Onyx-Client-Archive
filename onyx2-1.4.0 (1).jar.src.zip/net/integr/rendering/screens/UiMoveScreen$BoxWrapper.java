/*    */ package net.integr.rendering.screens;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.modules.management.UiModule;
/*    */ import net.integr.rendering.uisystem.MovableBox;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000.\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\r\n\002\020\013\n\002\b\003\n\002\020\016\n\002\b\r\b\b\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\006\032\0020\004\022\006\020\b\032\0020\007¢\006\004\b\t\020\nJ\020\020\013\032\0020\002HÆ\003¢\006\004\b\013\020\fJ\020\020\r\032\0020\004HÆ\003¢\006\004\b\r\020\016J\020\020\017\032\0020\004HÆ\003¢\006\004\b\017\020\016J\020\020\020\032\0020\007HÆ\003¢\006\004\b\020\020\021J8\020\022\032\0020\0002\b\b\002\020\003\032\0020\0022\b\b\002\020\005\032\0020\0042\b\b\002\020\006\032\0020\0042\b\b\002\020\b\032\0020\007HÆ\001¢\006\004\b\022\020\023J\032\020\026\032\0020\0252\b\020\024\032\004\030\0010\001HÖ\003¢\006\004\b\026\020\027J\020\020\030\032\0020\004HÖ\001¢\006\004\b\030\020\016J\020\020\032\032\0020\031HÖ\001¢\006\004\b\032\020\033R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\034\032\004\b\035\020\fR\027\020\b\032\0020\0078\006¢\006\f\n\004\b\b\020\036\032\004\b\037\020\021R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020 \032\004\b!\020\016\"\004\b\"\020#R\"\020\006\032\0020\0048\006@\006X\016¢\006\022\n\004\b\006\020 \032\004\b$\020\016\"\004\b%\020#¨\006&"}, d2 = {"Lnet/integr/rendering/screens/UiMoveScreen$BoxWrapper;", "", "Lnet/integr/rendering/uisystem/MovableBox;", "box", "", "oldHeight", "oldWidth", "Lnet/integr/modules/management/UiModule;", "module", "<init>", "(Lnet/integr/rendering/uisystem/MovableBox;IILnet/integr/modules/management/UiModule;)V", "component1", "()Lnet/integr/rendering/uisystem/MovableBox;", "component2", "()I", "component3", "component4", "()Lnet/integr/modules/management/UiModule;", "copy", "(Lnet/integr/rendering/uisystem/MovableBox;IILnet/integr/modules/management/UiModule;)Lnet/integr/rendering/screens/UiMoveScreen$BoxWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/MovableBox;", "getBox", "Lnet/integr/modules/management/UiModule;", "getModule", "I", "getOldHeight", "setOldHeight", "(I)V", "getOldWidth", "setOldWidth", "onyx2"})
/*    */ public final class BoxWrapper
/*    */ {
/*    */   @NotNull
/*    */   private final MovableBox box;
/*    */   private int oldHeight;
/*    */   private int oldWidth;
/*    */   @NotNull
/*    */   private final UiModule module;
/*    */   
/*    */   public BoxWrapper(@NotNull MovableBox box, int oldHeight, int oldWidth, @NotNull UiModule module) {
/* 99 */     this.box = box; this.oldHeight = oldHeight; this.oldWidth = oldWidth; this.module = module; } @NotNull public final MovableBox getBox() { return this.box; } public final int getOldHeight() { return this.oldHeight; } public final void setOldHeight(int <set-?>) { this.oldHeight = <set-?>; } public final int getOldWidth() { return this.oldWidth; } public final void setOldWidth(int <set-?>) { this.oldWidth = <set-?>; } @NotNull public final UiModule getModule() { return this.module; }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public final MovableBox component1() {
/*    */     return this.box;
/*    */   }
/*    */   
/*    */   public final int component2() {
/*    */     return this.oldHeight;
/*    */   }
/*    */   
/*    */   public final int component3() {
/*    */     return this.oldWidth;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final UiModule component4() {
/*    */     return this.module;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public final BoxWrapper copy(@NotNull MovableBox box, int oldHeight, int oldWidth, @NotNull UiModule module) {
/*    */     Intrinsics.checkNotNullParameter(box, "box");
/*    */     Intrinsics.checkNotNullParameter(module, "module");
/*    */     return new BoxWrapper(box, oldHeight, oldWidth, module);
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String toString() {
/*    */     return "BoxWrapper(box=" + this.box + ", oldHeight=" + this.oldHeight + ", oldWidth=" + this.oldWidth + ", module=" + this.module + ")";
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     result = this.box.hashCode();
/*    */     result = result * 31 + Integer.hashCode(this.oldHeight);
/*    */     result = result * 31 + Integer.hashCode(this.oldWidth);
/*    */     return result * 31 + this.module.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/*    */     if (this == other)
/*    */       return true; 
/*    */     if (!(other instanceof BoxWrapper))
/*    */       return false; 
/*    */     BoxWrapper boxWrapper = (BoxWrapper)other;
/*    */     return !Intrinsics.areEqual(this.box, boxWrapper.box) ? false : ((this.oldHeight != boxWrapper.oldHeight) ? false : ((this.oldWidth != boxWrapper.oldWidth) ? false : (!!Intrinsics.areEqual(this.module, boxWrapper.module))));
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\UiMoveScreen$BoxWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */