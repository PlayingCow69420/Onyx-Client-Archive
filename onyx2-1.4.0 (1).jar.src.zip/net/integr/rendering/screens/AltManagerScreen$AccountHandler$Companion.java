/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*     */ import com.mojang.authlib.minecraft.UserApiService;
/*     */ import com.mojang.authlib.yggdrasil.ProfileResult;
/*     */ import com.mojang.authlib.yggdrasil.ServicesKeyType;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.mixin.MinecraftClientAccessor;
/*     */ import net.integr.mixin.YggdrasilAuthenticationServiceAccessor;
/*     */ import net.integr.mixin.YggdrasilMinecraftSessionServiceAccessor;
/*     */ import net.minecraft.class_156;
/*     */ import net.minecraft.class_320;
/*     */ import net.minecraft.class_5520;
/*     */ import net.minecraft.class_7500;
/*     */ import net.minecraft.class_7569;
/*     */ import net.minecraft.class_7574;
/*     */ import net.minecraft.class_7853;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006¢\006\004\b\t\020\nJ\025\020\r\032\0020\b2\006\020\f\032\0020\013¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\002¢\006\004\b\020\020\021J\r\020\022\032\0020\b¢\006\004\b\022\020\003J\r\020\023\032\0020\b¢\006\004\b\023\020\003J\017\020\024\032\0020\bH\002¢\006\004\b\024\020\003R\030\020\025\032\004\030\0010\0048\002@\002X\016¢\006\006\n\004\b\025\020\026R\030\020\027\032\004\030\0010\0138\002@\002X\016¢\006\006\n\004\b\027\020\030R\030\020\031\032\004\030\0010\0068\002@\002X\016¢\006\006\n\004\b\031\020\032¨\006\033"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$Companion;", "", "<init>", "()V", "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;", "authService", "Lcom/mojang/authlib/minecraft/MinecraftSessionService;", "sessService", "", "applyLoginEnvironment", "(Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;Lcom/mojang/authlib/minecraft/MinecraftSessionService;)V", "Lnet/minecraft/class_320;", "session", "applySession", "(Lnet/minecraft/class_320;)V", "", "canLoadSavedEnvironment", "()Z", "loadSavedEnvironment", "runEnvironmentPreserver", "saveEnvironment", "originalAuthService", "Lcom/mojang/authlib/yggdrasil/YggdrasilAuthenticationService;", "originalSession", "Lnet/minecraft/class_320;", "originalSessionService", "Lcom/mojang/authlib/minecraft/MinecraftSessionService;", "onyx2"})
/*     */ public final class Companion
/*     */ {
/*     */   private Companion() {}
/*     */   
/*     */   public final void runEnvironmentPreserver() {
/* 121 */     if (!canLoadSavedEnvironment()) saveEnvironment(); 
/*     */   }
/*     */   
/*     */   private final void saveEnvironment() {
/* 125 */     AltManagerScreen.AccountHandler.access$setOriginalSession$cp(Onyx.Companion.getMC().method_1548());
/*     */     
/* 127 */     Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/* 128 */     AltManagerScreen.AccountHandler.access$setOriginalAuthService$cp(mca.getAuthenticationService());
/* 129 */     AltManagerScreen.AccountHandler.access$setOriginalSessionService$cp(Onyx.Companion.getMC().method_1495());
/*     */   }
/*     */   
/*     */   private final boolean canLoadSavedEnvironment() {
/* 133 */     return (AltManagerScreen.AccountHandler.access$getOriginalSession$cp() != null && AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp() != null && AltManagerScreen.AccountHandler.access$getOriginalSessionService$cp() != null);
/*     */   }
/*     */   
/*     */   public final void loadSavedEnvironment() {
/* 137 */     if (!canLoadSavedEnvironment())
/*     */       return; 
/* 139 */     Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp(), "null cannot be cast to non-null type net.integr.mixin.YggdrasilAuthenticationServiceAccessor"); YggdrasilAuthenticationServiceAccessor accessedService = (YggdrasilAuthenticationServiceAccessor)AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp();
/* 140 */     Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp()); Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp()); Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp()); Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp().getServicesKeySet(), AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp().getProxy(), accessedService.getEnvironment()), "createYggdrasilMinecraftSessionService(...)"); applyLoginEnvironment(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp(), (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp().getServicesKeySet(), AltManagerScreen.AccountHandler.access$getOriginalAuthService$cp().getProxy(), accessedService.getEnvironment()));
/* 141 */     Intrinsics.checkNotNull(AltManagerScreen.AccountHandler.access$getOriginalSession$cp()); applySession(AltManagerScreen.AccountHandler.access$getOriginalSession$cp());
/*     */   }
/*     */   
/*     */   public final void applySession(@NotNull class_320 session) {
/* 145 */     Intrinsics.checkNotNullParameter(session, "session"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/* 146 */     mca.setSession(session);
/* 147 */     UserApiService apiService = null;
/*     */     
/*     */     try {
/* 150 */       Intrinsics.checkNotNullExpressionValue(mca.getAuthenticationService().createUserApiService(session.method_1674()), "createUserApiService(...)"); apiService = mca.getAuthenticationService().createUserApiService(session.method_1674());
/*     */       
/* 152 */       mca.setUserApiService(apiService);
/* 153 */       mca.setSocialInteractionsManager(new class_5520(Onyx.Companion.getMC(), apiService));
/* 154 */       mca.setProfileKeys(class_7853.method_46532(apiService, session, (Onyx.Companion.getMC()).field_1697.toPath()));
/* 155 */       mca.setAbuseReportContext(class_7574.method_44599(class_7569.method_44586(), apiService));
/* 156 */       mca.setGameProfileFuture(CompletableFuture.supplyAsync(Companion::applySession$lambda$0, 
/*     */             
/* 158 */             class_156.method_27958()));
/* 159 */     } catch (AuthenticationException e) {
/* 160 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void applyLoginEnvironment(@NotNull YggdrasilAuthenticationService authService, @NotNull MinecraftSessionService sessService) {
/* 165 */     Intrinsics.checkNotNullParameter(authService, "authService"); Intrinsics.checkNotNullParameter(sessService, "sessService"); Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); MinecraftClientAccessor mca = (MinecraftClientAccessor)Onyx.Companion.getMC();
/* 166 */     mca.setAuthenticationService(authService);
/* 167 */     class_7500.method_44172(authService.getServicesKeySet(), ServicesKeyType.PROFILE_KEY);
/* 168 */     mca.setSessionService(sessService);
/*     */   }
/*     */   
/*     */   private static final ProfileResult applySession$lambda$0() {
/*     */     return Onyx.Companion.getMC().method_1495().fetchProfile(Onyx.Companion.getMC().method_1548().method_44717(), true);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\AltManagerScreen$AccountHandler$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */