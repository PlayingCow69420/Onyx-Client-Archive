/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.modules.management.settings.Setting;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\f\n\002\020\013\n\002\b\003\n\002\020\016\n\002\b\t\b\b\030\0002\0020\001B!\022\006\020\003\032\0020\002\022\b\020\005\032\004\030\0010\004\022\006\020\007\032\0020\006¢\006\004\b\b\020\tJ\020\020\n\032\0020\002HÆ\003¢\006\004\b\n\020\013J\022\020\f\032\004\030\0010\004HÆ\003¢\006\004\b\f\020\rJ\020\020\016\032\0020\006HÆ\003¢\006\004\b\016\020\017J0\020\020\032\0020\0002\b\b\002\020\003\032\0020\0022\n\b\002\020\005\032\004\030\0010\0042\b\b\002\020\007\032\0020\006HÆ\001¢\006\004\b\020\020\021J\032\020\024\032\0020\0232\b\020\022\032\004\030\0010\001HÖ\003¢\006\004\b\024\020\025J\020\020\026\032\0020\006HÖ\001¢\006\004\b\026\020\017J\020\020\030\032\0020\027HÖ\001¢\006\004\b\030\020\031R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\032\032\004\b\033\020\013R\031\020\005\032\004\030\0010\0048\006¢\006\f\n\004\b\005\020\034\032\004\b\035\020\rR\027\020\007\032\0020\0068\006¢\006\f\n\004\b\007\020\036\032\004\b\037\020\017¨\006 "}, d2 = {"Lnet/integr/rendering/screens/ModuleScreen$PosWrapper;", "", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "element", "Lnet/integr/modules/management/settings/Setting;", "setting", "", "yO", "<init>", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)V", "component1", "()Lnet/integr/rendering/uisystem/base/HelixUiElement;", "component2", "()Lnet/integr/modules/management/settings/Setting;", "component3", "()I", "copy", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;Lnet/integr/modules/management/settings/Setting;I)Lnet/integr/rendering/screens/ModuleScreen$PosWrapper;", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "", "toString", "()Ljava/lang/String;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "getElement", "Lnet/integr/modules/management/settings/Setting;", "getSetting", "I", "getYO", "onyx2"})
/*     */ public final class PosWrapper
/*     */ {
/*     */   @NotNull
/*     */   private final HelixUiElement element;
/*     */   @Nullable
/*     */   private final Setting setting;
/*     */   private final int yO;
/*     */   
/*     */   public PosWrapper(@NotNull HelixUiElement element, @Nullable Setting setting, int yO) {
/* 160 */     this.element = element; this.setting = setting; this.yO = yO; } @NotNull public final HelixUiElement getElement() { return this.element; } @Nullable public final Setting getSetting() { return this.setting; } public final int getYO() { return this.yO; }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final HelixUiElement component1() {
/*     */     return this.element;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public final Setting component2() {
/*     */     return this.setting;
/*     */   }
/*     */   
/*     */   public final int component3() {
/*     */     return this.yO;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final PosWrapper copy(@NotNull HelixUiElement element, @Nullable Setting setting, int yO) {
/*     */     Intrinsics.checkNotNullParameter(element, "element");
/*     */     return new PosWrapper(element, setting, yO);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String toString() {
/*     */     return "PosWrapper(element=" + this.element + ", setting=" + this.setting + ", yO=" + this.yO + ")";
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     result = this.element.hashCode();
/*     */     result = result * 31 + ((this.setting == null) ? 0 : this.setting.hashCode());
/*     */     return result * 31 + Integer.hashCode(this.yO);
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other) {
/*     */     if (this == other)
/*     */       return true; 
/*     */     if (!(other instanceof PosWrapper))
/*     */       return false; 
/*     */     PosWrapper posWrapper = (PosWrapper)other;
/*     */     return !Intrinsics.areEqual(this.element, posWrapper.element) ? false : (!Intrinsics.areEqual(this.setting, posWrapper.setting) ? false : (!(this.yO != posWrapper.yO)));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\ModuleScreen$PosWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */