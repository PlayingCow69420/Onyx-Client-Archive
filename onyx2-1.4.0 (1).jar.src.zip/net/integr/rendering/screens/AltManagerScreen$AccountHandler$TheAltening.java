/*     */ package net.integr.rendering.screens;
/*     */ 
/*     */ import com.mojang.authlib.Environment;
/*     */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*     */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*     */ import de.florianmichael.waybackauthlib.WaybackAuthLib;
/*     */ import java.util.Optional;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.mixin.MinecraftClientAccessor;
/*     */ import net.integr.mixin.YggdrasilMinecraftSessionServiceAccessor;
/*     */ import net.minecraft.class_320;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class TheAltening
/*     */ {
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Lnet/integr/rendering/screens/AltManagerScreen$AccountHandler$TheAltening$Companion;", "", "<init>", "()V", "", "token", "", "login", "(Ljava/lang/String;)V", "onyx2"})
/*     */   public static final class Companion
/*     */   {
/*     */     private Companion() {}
/*     */     
/*     */     public final void login(@NotNull String token) {
/*  98 */       Intrinsics.checkNotNullParameter(token, "token"); AltManagerScreen.AccountHandler.Companion.runEnvironmentPreserver();
/*     */       
/* 100 */       Environment environment = new Environment("http://sessionserver.thealtening.com", "http://authserver.thealtening.com", "The Altening");
/* 101 */       Intrinsics.checkNotNull(Onyx.Companion.getMC(), "null cannot be cast to non-null type net.integr.mixin.MinecraftClientAccessor"); YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(((MinecraftClientAccessor)Onyx.Companion.getMC()).getProxy(), environment);
/*     */       
/* 103 */       WaybackAuthLib auth = new WaybackAuthLib(environment.servicesHost());
/*     */       
/* 105 */       auth.setUsername(token);
/* 106 */       auth.setPassword("Woah!");
/*     */       
/* 108 */       Intrinsics.checkNotNullExpressionValue(YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment), "createYggdrasilMinecraftSessionService(...)"); AltManagerScreen.AccountHandler.Companion.applyLoginEnvironment(service, (MinecraftSessionService)YggdrasilMinecraftSessionServiceAccessor.createYggdrasilMinecraftSessionService(service.getServicesKeySet(), service.getProxy(), environment));
/* 109 */       auth.logIn();
/* 110 */       AltManagerScreen.AccountHandler.Companion.applySession(new class_320(auth.getCurrentProfile().getName(), auth.getCurrentProfile().getId(), auth.getAccessToken(), Optional.empty(), Optional.empty(), class_320.class_321.field_1988));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\screens\AltManagerScreen$AccountHandler$TheAltening.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */