package net.integr.rendering.shader;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

@Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\002\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()V", "<anonymous>"})
final class PostProcessShader$renderCall$1 extends Lambda implements Function0<Unit> {
  public static final PostProcessShader$renderCall$1 INSTANCE = new PostProcessShader$renderCall$1();
  
  PostProcessShader$renderCall$1() {
    super(0);
  }
  
  public final void invoke() {}
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\PostProcessShader$renderCall$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */