/*    */ package net.integr.rendering.shader.management;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.event.DrawOutlineFrameBufferEvent;
/*    */ import net.integr.event.ResizeScreenEvent;
/*    */ import net.integr.eventsystem.EventListen;
/*    */ import net.integr.rendering.shader.PostProcessShader;
/*    */ import net.minecraft.class_310;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\004\030\000 \f2\0020\001:\001\fB\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\tH\007¢\006\004\b\n\020\013¨\006\r"}, d2 = {"Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "", "<init>", "()V", "Lnet/integr/event/DrawOutlineFrameBufferEvent;", "event", "", "onDrawBuffer", "(Lnet/integr/event/DrawOutlineFrameBufferEvent;)V", "Lnet/integr/event/ResizeScreenEvent;", "onResized", "(Lnet/integr/event/ResizeScreenEvent;)V", "Companion", "onyx2"})
/*    */ public final class PostProcessShaderManager
/*    */ {
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003R\027\020\007\032\0020\0068\006¢\006\f\n\004\b\007\020\b\032\004\b\t\020\n¨\006\013"}, d2 = {"Lnet/integr/rendering/shader/management/PostProcessShaderManager$Companion;", "", "<init>", "()V", "", "initShaders", "Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "INSTANCE", "Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "getINSTANCE", "()Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final void initShaders() {}
/*    */     
/*    */     @NotNull
/*    */     public final PostProcessShaderManager getINSTANCE() {
/* 28 */       return PostProcessShaderManager.INSTANCE; } } @NotNull public static final Companion Companion = new Companion(null); @NotNull private static final PostProcessShaderManager INSTANCE = new PostProcessShaderManager();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventListen
/*    */   public final void onDrawBuffer(@NotNull DrawOutlineFrameBufferEvent event) {
/* 38 */     Intrinsics.checkNotNullParameter(event, "event");
/*    */   }
/*    */   @EventListen
/*    */   public final void onResized(@NotNull ResizeScreenEvent event) {
/* 42 */     Intrinsics.checkNotNullParameter(event, "event"); if (PostProcessShader.Companion.getSwapBuffer() == null)
/*    */       return; 
/* 44 */     Intrinsics.checkNotNull(PostProcessShader.Companion.getSwapBuffer()); PostProcessShader.Companion.getSwapBuffer().method_1234(event.width, event.height, class_310.field_1703);
/* 45 */     Intrinsics.checkNotNull(PostProcessShader.Companion.getSwapBuffer2()); PostProcessShader.Companion.getSwapBuffer2().method_1234(event.width, event.height, class_310.field_1703);
/* 46 */     Intrinsics.checkNotNull(PostProcessShader.Companion.getSwapBuffer3()); PostProcessShader.Companion.getSwapBuffer3().method_1234(event.width, event.height, class_310.field_1703);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\management\PostProcessShaderManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */