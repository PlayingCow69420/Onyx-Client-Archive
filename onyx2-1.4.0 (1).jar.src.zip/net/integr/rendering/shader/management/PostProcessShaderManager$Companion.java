/*    */ package net.integr.rendering.shader.management;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003R\027\020\007\032\0020\0068\006¢\006\f\n\004\b\007\020\b\032\004\b\t\020\n¨\006\013"}, d2 = {"Lnet/integr/rendering/shader/management/PostProcessShaderManager$Companion;", "", "<init>", "()V", "", "initShaders", "Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "INSTANCE", "Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "getINSTANCE", "()Lnet/integr/rendering/shader/management/PostProcessShaderManager;", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final PostProcessShaderManager getINSTANCE() {
/* 28 */     return PostProcessShaderManager.access$getINSTANCE$cp();
/*    */   }
/*    */   
/*    */   public final void initShaders() {}
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\management\PostProcessShaderManager$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */