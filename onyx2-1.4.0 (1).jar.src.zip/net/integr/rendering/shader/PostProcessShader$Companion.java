/*    */ package net.integr.rendering.shader;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import net.integr.rendering.shader.impl.CopyShader;
/*    */ import net.minecraft.class_6367;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\r\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR$\020\n\032\004\030\0010\t8\006@\006X\016¢\006\022\n\004\b\n\020\013\032\004\b\f\020\r\"\004\b\016\020\017R$\020\020\032\004\030\0010\t8\006@\006X\016¢\006\022\n\004\b\020\020\013\032\004\b\021\020\r\"\004\b\022\020\017R$\020\023\032\004\030\0010\t8\006@\006X\016¢\006\022\n\004\b\023\020\013\032\004\b\024\020\r\"\004\b\025\020\017¨\006\026"}, d2 = {"Lnet/integr/rendering/shader/PostProcessShader$Companion;", "", "<init>", "()V", "Lnet/integr/rendering/shader/impl/CopyShader;", "COPY", "Lnet/integr/rendering/shader/impl/CopyShader;", "getCOPY", "()Lnet/integr/rendering/shader/impl/CopyShader;", "Lnet/minecraft/class_6367;", "swapBuffer", "Lnet/minecraft/class_6367;", "getSwapBuffer", "()Lnet/minecraft/class_6367;", "setSwapBuffer", "(Lnet/minecraft/class_6367;)V", "swapBuffer2", "getSwapBuffer2", "setSwapBuffer2", "swapBuffer3", "getSwapBuffer3", "setSwapBuffer3", "onyx2"})
/*    */ public final class Companion
/*    */ {
/*    */   private Companion() {}
/*    */   
/*    */   @NotNull
/*    */   public final CopyShader getCOPY() {
/* 47 */     return PostProcessShader.access$getCOPY$cp(); } @Nullable
/* 48 */   public final class_6367 getSwapBuffer() { return PostProcessShader.access$getSwapBuffer$cp(); } public final void setSwapBuffer(@Nullable class_6367 <set-?>) { PostProcessShader.access$setSwapBuffer$cp(<set-?>); } @Nullable
/* 49 */   public final class_6367 getSwapBuffer2() { return PostProcessShader.access$getSwapBuffer2$cp(); } public final void setSwapBuffer2(@Nullable class_6367 <set-?>) { PostProcessShader.access$setSwapBuffer2$cp(<set-?>); } @Nullable
/* 50 */   public final class_6367 getSwapBuffer3() { return PostProcessShader.access$getSwapBuffer3$cp(); } public final void setSwapBuffer3(@Nullable class_6367 <set-?>) { PostProcessShader.access$setSwapBuffer3$cp(<set-?>); }
/*    */ 
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\PostProcessShader$Companion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */