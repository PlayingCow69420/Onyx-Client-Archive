/*    */ package net.integr.rendering.shader.impl;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function0;
/*    */ import kotlin.jvm.internal.Lambda;
/*    */ import net.integr.rendering.shader.PostProcessShader;
/*    */ import net.minecraft.class_1297;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\024¢\006\004\b\005\020\003J\017\020\007\032\0020\006H\026¢\006\004\b\007\020\bJ\031\020\007\032\0020\0062\b\020\n\032\004\030\0010\tH\026¢\006\004\b\007\020\013¨\006\f"}, d2 = {"Lnet/integr/rendering/shader/impl/CopyShader;", "Lnet/integr/rendering/shader/PostProcessShader;", "<init>", "()V", "", "setUniforms", "", "shouldDraw", "()Z", "Lnet/minecraft/class_1297;", "entity", "(Lnet/minecraft/class_1297;)Z", "onyx2"})
/*    */ public final class CopyShader
/*    */   extends PostProcessShader
/*    */ {
/*    */   public CopyShader() {
/* 25 */     init("copy", null.INSTANCE);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean shouldDraw() {
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public boolean shouldDraw(@Nullable class_1297 entity) {
/* 35 */     return shouldDraw();
/*    */   }
/*    */   
/*    */   protected void setUniforms() {}
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\impl\CopyShader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */