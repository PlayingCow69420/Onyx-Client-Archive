/*     */ package net.integr.rendering.shader;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.text.StringsKt;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.rendering.shader.impl.CopyShader;
/*     */ import net.integr.utilities.LogUtils;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_276;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_4618;
/*     */ import net.minecraft.class_6367;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000R\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\016\n\000\n\002\030\002\n\002\b\006\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\b\b&\030\000 32\0020\001:\0013B\007¢\006\004\b\002\020\003J\037\020\b\032\0020\0072\006\020\005\032\0020\0042\006\020\006\032\0020\004H\002¢\006\004\b\b\020\tJ\035\020\r\032\0020\0072\006\020\013\032\0020\n2\006\020\f\032\0020\n¢\006\004\b\r\020\016J#\020\023\032\0020\0072\006\020\020\032\0020\0172\f\020\022\032\b\022\004\022\0020\0070\021¢\006\004\b\023\020\024J\r\020\025\032\0020\007¢\006\004\b\025\020\003J\035\020\026\032\0020\0072\006\020\013\032\0020\n2\006\020\f\032\0020\n¢\006\004\b\026\020\016J\017\020\027\032\0020\007H$¢\006\004\b\027\020\003J\017\020\031\032\0020\030H&¢\006\004\b\031\020\032J\031\020\031\032\0020\0302\b\020\034\032\004\030\0010\033H&¢\006\004\b\031\020\035J\027\020\036\032\0020\0072\006\020\006\032\0020\004H\002¢\006\004\b\036\020\037R(\020\022\032\b\022\004\022\0020\0070\0218\006@\006X\016¢\006\022\n\004\b\022\020 \032\004\b!\020\"\"\004\b#\020$R$\020&\032\004\030\0010%8\006@\006X\016¢\006\022\n\004\b&\020'\032\004\b(\020)\"\004\b*\020+R$\020-\032\004\030\0010,8\006@\006X\016¢\006\022\n\004\b-\020.\032\004\b/\0200\"\004\b1\0202¨\0064"}, d2 = {"Lnet/integr/rendering/shader/PostProcessShader;", "", "<init>", "()V", "", "i", "slot", "", "bindTexture", "(II)V", "Lnet/minecraft/class_276;", "input", "output", "copyToBuffer", "(Lnet/minecraft/class_276;Lnet/minecraft/class_276;)V", "", "frag", "Lkotlin/Function0;", "renderCall", "init", "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "render", "renderOnBuffer", "setUniforms", "", "shouldDraw", "()Z", "Lnet/minecraft/class_1297;", "entity", "(Lnet/minecraft/class_1297;)Z", "unbindTexture", "(I)V", "Lkotlin/jvm/functions/Function0;", "getRenderCall", "()Lkotlin/jvm/functions/Function0;", "setRenderCall", "(Lkotlin/jvm/functions/Function0;)V", "Lnet/integr/rendering/shader/Shader;", "shader", "Lnet/integr/rendering/shader/Shader;", "getShader", "()Lnet/integr/rendering/shader/Shader;", "setShader", "(Lnet/integr/rendering/shader/Shader;)V", "Lnet/minecraft/class_4618;", "vertexConsumerProvider", "Lnet/minecraft/class_4618;", "getVertexConsumerProvider", "()Lnet/minecraft/class_4618;", "setVertexConsumerProvider", "(Lnet/minecraft/class_4618;)V", "Companion", "onyx2"})
/*     */ public abstract class PostProcessShader
/*     */ {
/*     */   @Nullable
/*     */   public final class_4618 getVertexConsumerProvider() {
/*  41 */     return this.vertexConsumerProvider; } public final void setVertexConsumerProvider(@Nullable class_4618 <set-?>) { this.vertexConsumerProvider = <set-?>; } @Nullable
/*  42 */   public final Shader getShader() { return this.shader; } public final void setShader(@Nullable Shader <set-?>) { this.shader = <set-?>; }
/*     */    @NotNull
/*  44 */   private Function0<Unit> renderCall = PostProcessShader$renderCall$1.INSTANCE; @NotNull public final Function0<Unit> getRenderCall() { return this.renderCall; } public final void setRenderCall(@NotNull Function0<Unit> <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.renderCall = <set-?>; } @Metadata(mv = {1, 9, 0}, k = 3, xi = 48, d1 = {"\000\b\n\002\020\002\n\002\b\003\020\003\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "invoke", "()V", "<anonymous>"}) static final class PostProcessShader$renderCall$1 extends Lambda implements Function0<Unit> {
/*     */     public static final PostProcessShader$renderCall$1 INSTANCE = new PostProcessShader$renderCall$1(); PostProcessShader$renderCall$1() { super(0); } public final void invoke() {}
/*     */   } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\r\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR$\020\n\032\004\030\0010\t8\006@\006X\016¢\006\022\n\004\b\n\020\013\032\004\b\f\020\r\"\004\b\016\020\017R$\020\020\032\004\030\0010\t8\006@\006X\016¢\006\022\n\004\b\020\020\013\032\004\b\021\020\r\"\004\b\022\020\017R$\020\023\032\004\030\0010\t8\006@\006X\016¢\006\022\n\004\b\023\020\013\032\004\b\024\020\r\"\004\b\025\020\017¨\006\026"}, d2 = {"Lnet/integr/rendering/shader/PostProcessShader$Companion;", "", "<init>", "()V", "Lnet/integr/rendering/shader/impl/CopyShader;", "COPY", "Lnet/integr/rendering/shader/impl/CopyShader;", "getCOPY", "()Lnet/integr/rendering/shader/impl/CopyShader;", "Lnet/minecraft/class_6367;", "swapBuffer", "Lnet/minecraft/class_6367;", "getSwapBuffer", "()Lnet/minecraft/class_6367;", "setSwapBuffer", "(Lnet/minecraft/class_6367;)V", "swapBuffer2", "getSwapBuffer2", "setSwapBuffer2", "swapBuffer3", "getSwapBuffer3", "setSwapBuffer3", "onyx2"}) public static final class Companion { @NotNull
/*  47 */     public final CopyShader getCOPY() { return PostProcessShader.COPY; } private Companion() {} @Nullable
/*  48 */     public final class_6367 getSwapBuffer() { return PostProcessShader.swapBuffer; } public final void setSwapBuffer(@Nullable class_6367 <set-?>) { PostProcessShader.swapBuffer = <set-?>; } @Nullable
/*  49 */     public final class_6367 getSwapBuffer2() { return PostProcessShader.swapBuffer2; } public final void setSwapBuffer2(@Nullable class_6367 <set-?>) { PostProcessShader.swapBuffer2 = <set-?>; } @Nullable
/*  50 */     public final class_6367 getSwapBuffer3() { return PostProcessShader.swapBuffer3; } public final void setSwapBuffer3(@Nullable class_6367 <set-?>) { PostProcessShader.swapBuffer3 = <set-?>; } } @NotNull public static final Companion Companion = new Companion(null); @NotNull private static final CopyShader COPY = new CopyShader(); @Nullable private class_4618 vertexConsumerProvider; @Nullable
/*     */   private Shader shader; @Nullable
/*     */   private static class_6367 swapBuffer; @Nullable
/*     */   private static class_6367 swapBuffer2; @Nullable
/*  54 */   private static class_6367 swapBuffer3; public final void init(@NotNull String frag, @NotNull Function0<Unit> renderCall) { Intrinsics.checkNotNullParameter(frag, "frag"); Intrinsics.checkNotNullParameter(renderCall, "renderCall"); this.vertexConsumerProvider = new class_4618(Onyx.Companion.getMC().method_22940().method_23000());
/*     */     
/*  56 */     this.shader = new Shader("post/vert/base.vert", "post/frag/" + frag + ".frag");
/*     */     
/*  58 */     this.renderCall = renderCall;
/*     */     
/*  60 */     Intrinsics.checkNotNull(Onyx.Companion.getMC().method_22683()); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_22683()); swapBuffer = new class_6367(Onyx.Companion.getMC().method_22683().method_4489(), Onyx.Companion.getMC().method_22683().method_4506(), true, class_310.field_1703);
/*  61 */     Intrinsics.checkNotNull(swapBuffer); swapBuffer.method_1236(0.0F, 0.0F, 0.0F, 0.0F);
/*     */     
/*  63 */     Intrinsics.checkNotNull(Onyx.Companion.getMC().method_22683()); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_22683()); swapBuffer2 = new class_6367(Onyx.Companion.getMC().method_22683().method_4489(), Onyx.Companion.getMC().method_22683().method_4506(), true, class_310.field_1703);
/*  64 */     Intrinsics.checkNotNull(swapBuffer2); swapBuffer2.method_1236(0.0F, 0.0F, 0.0F, 0.0F);
/*     */     
/*  66 */     Intrinsics.checkNotNull(Onyx.Companion.getMC().method_22683()); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_22683()); swapBuffer3 = new class_6367(Onyx.Companion.getMC().method_22683().method_4489(), Onyx.Companion.getMC().method_22683().method_4506(), true, class_310.field_1703);
/*  67 */     Intrinsics.checkNotNull(swapBuffer3); swapBuffer3.method_1236(0.0F, 0.0F, 0.0F, 0.0F); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void render() {
/*  77 */     if (!shouldDraw())
/*     */       return; 
/*  79 */     this.renderCall.invoke();
/*     */   }
/*     */   
/*     */   public final void copyToBuffer(@NotNull class_276 input, @NotNull class_276 output) {
/*  83 */     Intrinsics.checkNotNullParameter(input, "input"); Intrinsics.checkNotNullParameter(output, "output"); COPY.renderOnBuffer(input, output);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void renderOnBuffer(@NotNull class_276 input, @NotNull class_276 output) {
/*  89 */     Intrinsics.checkNotNullParameter(input, "input"); Intrinsics.checkNotNullParameter(output, "output"); input.method_1240();
/*  90 */     float f = output.field_1482;
/*  91 */     float g = output.field_1481;
/*  92 */     RenderSystem.viewport(0, 0, (int)f, (int)g);
/*     */     
/*  94 */     bindTexture(input.method_30277(), 0);
/*     */     
/*  96 */     Intrinsics.checkNotNull(this.shader); this.shader.bind();
/*     */     
/*  98 */     Intrinsics.checkNotNull(this.shader); this.shader.set("u_Size", Onyx.Companion.getMC().method_22683().method_4489(), Onyx.Companion.getMC().method_22683().method_4506());
/*  99 */     Intrinsics.checkNotNull(this.shader); this.shader.set("u_Texture", 0);
/* 100 */     Intrinsics.checkNotNull(this.shader); this.shader.set("u_Time", (float)GLFW.glfwGetTime());
/* 101 */     Intrinsics.checkNotNull(this.shader); Intrinsics.checkNotNullExpressionValue(RenderSystem.getProjectionMatrix(), "getProjectionMatrix(...)"); this.shader.set("u_Proj", RenderSystem.getProjectionMatrix());
/* 102 */     Intrinsics.checkNotNull(this.shader); Intrinsics.checkNotNullExpressionValue(RenderSystem.getModelViewStack(), "getModelViewStack(...)"); this.shader.set("u_ModelView", (Matrix4f)RenderSystem.getModelViewStack());
/*     */     
/* 104 */     setUniforms();
/*     */     
/* 106 */     output.method_1230(class_310.field_1703);
/* 107 */     output.method_1235(false);
/*     */     
/* 109 */     RenderSystem.enableBlend();
/* 110 */     GL11.glBlendFunc(1, 0);
/* 111 */     RenderSystem.depthFunc(519);
/*     */     
/* 113 */     class_289 tessellator = class_289.method_1348();
/* 114 */     class_287 bufferBuilder = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 115 */     bufferBuilder.method_22912(-1.0F, -1.0F, 0.0F);
/* 116 */     bufferBuilder.method_22912(1.0F, -1.0F, 0.0F);
/* 117 */     bufferBuilder.method_22912(1.0F, 1.0F, 0.0F);
/* 118 */     bufferBuilder.method_22912(-1.0F, 1.0F, 0.0F);
/*     */     
/* 120 */     Intrinsics.checkNotNull(this.shader); String lg = GlStateManager.glGetProgramInfoLog(this.shader.getId(), 512);
/* 121 */     CharSequence charSequence = lg; if (!((charSequence == null || StringsKt.isBlank(charSequence)) ? 1 : 0)) { Intrinsics.checkNotNull(lg); LogUtils.Companion.sendLog(lg); }
/*     */     
/* 123 */     class_286.method_43437(bufferBuilder.method_60800());
/* 124 */     RenderSystem.depthFunc(515);
/* 125 */     RenderSystem.disableBlend();
/* 126 */     Intrinsics.checkNotNull(this.shader); this.shader.unBind();
/* 127 */     unbindTexture(0);
/*     */     
/* 129 */     output.method_1240();
/* 130 */     input.method_1242();
/*     */   }
/*     */   
/*     */   private final void bindTexture(int i, int slot) {
/* 134 */     GlStateManager.glActiveTexture(33984 + slot);
/* 135 */     GlStateManager._bindTexture(i);
/*     */   }
/*     */   
/*     */   private final void unbindTexture(int slot) {
/* 139 */     GlStateManager.glActiveTexture(33984 + slot);
/* 140 */     GlStateManager._bindTexture(0);
/*     */   }
/*     */   
/*     */   public abstract boolean shouldDraw();
/*     */   
/*     */   public abstract boolean shouldDraw(@Nullable class_1297 paramclass_1297);
/*     */   
/*     */   protected abstract void setUniforms();
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\PostProcessShader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */