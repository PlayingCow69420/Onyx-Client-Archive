/*     */ package net.integr.rendering.shader;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import it.unimi.dsi.fastutil.objects.Object2IntMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
/*     */ import java.awt.Color;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.collections.CollectionsKt;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.utilities.resourceload.ResourceLoader;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL32C;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000P\n\002\030\002\n\002\020\000\n\002\020\016\n\002\b\004\n\002\020\002\n\002\b\002\n\002\020\b\n\002\b\020\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\007\n\002\b\005\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002¢\006\004\b\005\020\006J\r\020\b\032\0020\007¢\006\004\b\b\020\tJ\031\020\f\032\004\030\0010\0022\006\020\013\032\0020\nH\002¢\006\004\b\f\020\rJ\017\020\016\032\0020\nH\002¢\006\004\b\016\020\017J\027\020\021\032\0020\n2\006\020\020\032\0020\002H\002¢\006\004\b\021\020\022J)\020\026\032\004\030\0010\0022\006\020\023\032\0020\n2\006\020\024\032\0020\n2\006\020\025\032\0020\nH\002¢\006\004\b\026\020\027J\027\020\031\032\0020\0022\006\020\030\032\0020\002H\002¢\006\004\b\031\020\032J\035\020\035\032\0020\0072\006\020\020\032\0020\0022\006\020\034\032\0020\033¢\006\004\b\035\020\036J\035\020\035\032\0020\0072\006\020\020\032\0020\0022\006\020 \032\0020\037¢\006\004\b\035\020!J\035\020\035\032\0020\0072\006\020\020\032\0020\0022\006\020 \032\0020\"¢\006\004\b\035\020#J%\020\035\032\0020\0072\006\020\020\032\0020\0022\006\020$\032\0020\"2\006\020%\032\0020\"¢\006\004\b\035\020&J\035\020\035\032\0020\0072\006\020\020\032\0020\0022\006\020 \032\0020\n¢\006\004\b\035\020'J\035\020\035\032\0020\0072\006\020\020\032\0020\0022\006\020)\032\0020(¢\006\004\b\035\020*J\r\020+\032\0020\007¢\006\004\b+\020\tJ\037\020-\032\0020\0072\006\020,\032\0020\n2\006\020 \032\0020(H\002¢\006\004\b-\020.R\"\020/\032\0020\n8\006@\006X\016¢\006\022\n\004\b/\0200\032\004\b1\020\017\"\004\b2\0203R\024\0205\032\002048\002X\004¢\006\006\n\004\b5\0206R\032\0208\032\b\022\004\022\0020\002078\002X\004¢\006\006\n\004\b8\0209¨\006:"}, d2 = {"Lnet/integr/rendering/shader/Shader;", "", "", "vertPath", "fragPath", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "", "bind", "()V", "", "shader", "compileShader", "(I)Ljava/lang/String;", "createProgram", "()I", "name", "getLocation", "(Ljava/lang/String;)I", "program", "vertShader", "fragShader", "linkProgram", "(III)Ljava/lang/String;", "path", "read", "(Ljava/lang/String;)Ljava/lang/String;", "Ljava/awt/Color;", "color", "set", "(Ljava/lang/String;Ljava/awt/Color;)V", "", "v", "(Ljava/lang/String;Z)V", "", "(Ljava/lang/String;F)V", "v1", "v2", "(Ljava/lang/String;FF)V", "(Ljava/lang/String;I)V", "Lorg/joml/Matrix4f;", "mat", "(Ljava/lang/String;Lorg/joml/Matrix4f;)V", "unBind", "location", "uniformMatrix", "(ILorg/joml/Matrix4f;)V", "id", "I", "getId", "setId", "(I)V", "Ljava/nio/FloatBuffer;", "matrix", "Ljava/nio/FloatBuffer;", "Lit/unimi/dsi/fastutil/objects/Object2IntMap;", "uniformLocations", "Lit/unimi/dsi/fastutil/objects/Object2IntMap;", "onyx2"})
/*     */ public final class Shader
/*     */ {
/*     */   private int id;
/*     */   
/*     */   public final int getId() {
/*  35 */     return this.id; } public final void setId(int <set-?>) { this.id = <set-?>; } @NotNull
/*  36 */   private final Object2IntMap<String> uniformLocations = (Object2IntMap<String>)new Object2IntOpenHashMap(); @NotNull
/*     */   private final FloatBuffer matrix;
/*     */   
/*  39 */   public Shader(@NotNull String vertPath, @NotNull String fragPath) { int vert = GlStateManager.glCreateShader(35633);
/*     */     
/*  41 */     GlStateManager.glShaderSource(vert, CollectionsKt.listOf(read(vertPath)));
/*     */     
/*  43 */     String vertError = compileShader(vert);
/*  44 */     if (vertError != null) {
/*  45 */       throw new RuntimeException("Failed to compile vertex shader (" + vertPath + "): " + vertError);
/*     */     }
/*     */     
/*  48 */     int frag = GlStateManager.glCreateShader(35632);
/*  49 */     GlStateManager.glShaderSource(frag, CollectionsKt.listOf(read(fragPath)));
/*     */     
/*  51 */     String fragError = compileShader(frag);
/*  52 */     if (fragError != null) {
/*  53 */       throw new RuntimeException("Failed to compile fragment shader (" + fragPath + "): " + fragError);
/*     */     }
/*     */     
/*  56 */     this.id = createProgram();
/*     */     
/*  58 */     String programError = linkProgram(this.id, vert, frag);
/*  59 */     if (programError != null) {
/*  60 */       throw new RuntimeException("Failed to link program: " + programError);
/*     */     }
/*     */     
/*  63 */     GlStateManager.glDeleteShader(frag);
/*  64 */     GlStateManager.glDeleteShader(vert);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     Intrinsics.checkNotNullExpressionValue(BufferUtils.createFloatBuffer(16), "createFloatBuffer(...)"); this.matrix = BufferUtils.createFloatBuffer(16); }
/*     */   
/*     */   private final void uniformMatrix(int location, Matrix4f v) {
/* 151 */     v.get(this.matrix);
/* 152 */     GlStateManager._glUniformMatrix4(location, false, this.matrix);
/*     */   }
/*     */   
/*     */   private final String read(String path) {
/*     */     try {
/*     */       InputStream r = ResourceLoader.Companion.loadResourceAsStream("assets/onyx/shaders/" + path);
/*     */       Intrinsics.checkNotNullExpressionValue(IOUtils.toString(r, StandardCharsets.UTF_8), "toString(...)");
/*     */       return IOUtils.toString(r, StandardCharsets.UTF_8);
/*     */     } catch (IOException e) {
/*     */       throw new IllegalStateException("Could not read shader '" + path + "'", (Throwable)e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private final String compileShader(int shader) {
/*     */     GlStateManager.glCompileShader(shader);
/*     */     if (GlStateManager.glGetShaderi(shader, 35713) == 0)
/*     */       return GlStateManager.glGetShaderInfoLog(shader, 512); 
/*     */     return null;
/*     */   }
/*     */   
/*     */   private final int createProgram() {
/*     */     return GlStateManager.glCreateProgram();
/*     */   }
/*     */   
/*     */   private final String linkProgram(int program, int vertShader, int fragShader) {
/*     */     GlStateManager.glAttachShader(program, vertShader);
/*     */     GlStateManager.glAttachShader(program, fragShader);
/*     */     GlStateManager.glLinkProgram(program);
/*     */     if (GlStateManager.glGetProgrami(program, 35714) == 0)
/*     */       return GlStateManager.glGetProgramInfoLog(program, 512); 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public final void bind() {
/*     */     GlStateManager._glUseProgram(this.id);
/*     */   }
/*     */   
/*     */   public final void unBind() {
/*     */     GlStateManager._glUseProgram(0);
/*     */   }
/*     */   
/*     */   private final int getLocation(String name) {
/*     */     if (this.uniformLocations.containsKey(name))
/*     */       return this.uniformLocations.getInt(name); 
/*     */     int location = GlStateManager._glGetUniformLocation(this.id, name);
/*     */     this.uniformLocations.put(name, location);
/*     */     return location;
/*     */   }
/*     */   
/*     */   public final void set(@NotNull String name, boolean v) {
/*     */     Intrinsics.checkNotNullParameter(name, "name");
/*     */     GlStateManager._glUniform1i(getLocation(name), v ? 1 : 0);
/*     */   }
/*     */   
/*     */   public final void set(@NotNull String name, int v) {
/*     */     Intrinsics.checkNotNullParameter(name, "name");
/*     */     GlStateManager._glUniform1i(getLocation(name), v);
/*     */   }
/*     */   
/*     */   public final void set(@NotNull String name, float v) {
/*     */     Intrinsics.checkNotNullParameter(name, "name");
/*     */     GL32C.glUniform1f(getLocation(name), v);
/*     */   }
/*     */   
/*     */   public final void set(@NotNull String name, float v1, float v2) {
/*     */     Intrinsics.checkNotNullParameter(name, "name");
/*     */     GL32C.glUniform2f(getLocation(name), v1, v2);
/*     */   }
/*     */   
/*     */   public final void set(@NotNull String name, @NotNull Color color) {
/*     */     Intrinsics.checkNotNullParameter(name, "name");
/*     */     Intrinsics.checkNotNullParameter(color, "color");
/*     */     GL32C.glUniform4f(getLocation(name), color.getRed() / 'ÿ', color.getGreen() / 'ÿ', color.getBlue() / 'ÿ', color.getAlpha() / 'ÿ');
/*     */   }
/*     */   
/*     */   public final void set(@NotNull String name, @NotNull Matrix4f mat) {
/*     */     Intrinsics.checkNotNullParameter(name, "name");
/*     */     Intrinsics.checkNotNullParameter(mat, "mat");
/*     */     uniformMatrix(getLocation(name), mat);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\shader\Shader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */