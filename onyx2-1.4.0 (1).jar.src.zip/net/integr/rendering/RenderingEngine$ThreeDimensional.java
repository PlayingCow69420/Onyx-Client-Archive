/*     */ package net.integr.rendering;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5944;
/*     */ import net.minecraft.class_757;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/RenderingEngine$ThreeDimensional;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class ThreeDimensional
/*     */ {
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000Z\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\006\n\002\b\002\n\002\020\007\n\000\n\002\020\013\n\002\b\b\n\002\030\002\n\002\030\002\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J'\020\n\032\0020\t2\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\006H\002¢\006\004\b\n\020\013J-\020\r\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b\r\020\021J%\020\r\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b\r\020\022J'\020\026\032\0020\t2\006\020\023\032\0020\f2\006\020\005\032\0020\0042\006\020\025\032\0020\024H\002¢\006\004\b\026\020\027J'\020\030\032\0020\t2\006\020\023\032\0020\f2\006\020\005\032\0020\0042\006\020\025\032\0020\024H\002¢\006\004\b\030\020\027JE\020!\032\0020\t2\006\020\031\032\0020\0162\006\020\033\032\0020\0322\006\020\034\032\0020\0322\006\020\036\032\0020\0352\006\020 \032\0020\0372\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b!\020\"J%\020#\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b#\020\022J-\020&\032\0020\t2\006\020$\032\0020\0162\006\020%\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b&\020'J5\020+\032\0020\t2\026\020*\032\022\022\004\022\0020\0160(j\b\022\004\022\0020\016`)2\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b+\020,J-\020-\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b-\020\021J%\020-\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b-\020\022J-\020.\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b.\020\021J%\020.\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b.\020\022¨\006/"}, d2 = {"Lnet/integr/rendering/RenderingEngine$ThreeDimensional$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_4587;", "matrixStack", "", "regionX", "regionZ", "", "applyRegionalRenderOffset", "(Lnet/minecraft/class_4587;II)V", "Lnet/minecraft/class_238;", "box", "Lnet/minecraft/class_243;", "block", "color", "(Lnet/minecraft/class_238;Lnet/minecraft/class_243;Lnet/minecraft/class_4587;I)V", "(Lnet/minecraft/class_243;Lnet/minecraft/class_4587;I)V", "bb", "Lnet/minecraft/class_287;", "bufferBuilder", "boxFill", "(Lnet/minecraft/class_238;Lnet/minecraft/class_4587;Lnet/minecraft/class_287;)V", "boxLines", "position", "", "precision", "radius", "", "offsetMid", "", "fill", "circle", "(Lnet/minecraft/class_243;DDFZLnet/minecraft/class_4587;I)V", "floorQuad", "position1", "position2", "line", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lnet/minecraft/class_4587;I)V", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "blocks", "multiBlock", "(Ljava/util/ArrayList;Lnet/minecraft/class_4587;I)V", "outlinedBox", "sideBox", "onyx2"})
/*     */   public static final class Companion {
/*     */     private Companion() {}
/*     */     
/*     */     private static final class_5944 circle$lambda$0() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */     
/*     */     public final void circle(@NotNull class_243 position, double precision, double radius, float offsetMid, boolean fill, @NotNull class_4587 matrixStack, int color) {
/*  41 */       Intrinsics.checkNotNullParameter(position, "position"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); class_243 pos = position;
/*  42 */       GL11.glEnable(3042);
/*  43 */       GL11.glBlendFunc(770, 771);
/*  44 */       GL11.glEnable(2884);
/*  45 */       GL11.glDisable(2929);
/*  46 */       RenderSystem.setShader(Companion::circle$lambda$0);
/*  47 */       matrixStack.method_22903();
/*  48 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/*  49 */       int regionX = camPos.method_10263();
/*  50 */       int regionZ = camPos.method_10260();
/*     */       
/*  52 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/*  53 */       Intrinsics.checkNotNullExpressionValue(pos.method_1023(regionX, 0.0D, regionZ), "subtract(...)"); pos = pos.method_1023(regionX, 0.0D, regionZ);
/*     */       
/*  55 */       RenderSystem.setShader(Companion::circle$lambda$1);
/*  56 */       Color col = new Color(color);
/*     */       
/*  58 */       RenderSystem.setShaderColor(
/*  59 */           col.getRed() / 255.0F, 
/*  60 */           col.getGreen() / 255.0F, 
/*  61 */           col.getBlue() / 255.0F, 
/*  62 */           0.5F);
/*     */       
/*  64 */       Matrix4f matrix = matrixStack.method_23760().method_23761();
/*  65 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */ 
/*     */       
/*  68 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/*     */       
/*  70 */       double prevX = Math.cos(0.0D) * radius;
/*  71 */       double prevZ = Math.sin(0.0D) * radius;
/*     */       
/*  73 */       double angle = 0.0D;
/*  74 */       while (angle <= 6.283185307179586D) {
/*  75 */         double x = Math.cos(angle) * radius;
/*  76 */         double z = Math.sin(angle) * radius;
/*     */         
/*  78 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/*  79 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)x, (float)pos.method_10214(), (float)pos.method_10215() + (float)z);
/*     */         
/*  81 */         prevX = x;
/*  82 */         prevZ = z;
/*     */         
/*  84 */         angle += precision;
/*     */       } 
/*     */       
/*  87 */       bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)Math.cos(0.0D) * (float)radius, (float)pos.method_10214(), (float)pos.method_10215() + (float)Math.sin(0.0D) * (float)radius);
/*  88 */       bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/*     */       
/*  90 */       if (fill) {
/*  91 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/*  93 */         prevX = Math.cos(0.0D) * radius;
/*  94 */         prevZ = Math.sin(0.0D) * radius;
/*     */         
/*  96 */         GL11.glDisable(2884);
/*     */         
/*  98 */         RenderSystem.setShaderColor(
/*  99 */             col.getRed() / 255.0F, 
/* 100 */             col.getGreen() / 255.0F, 
/* 101 */             col.getBlue() / 255.0F, 
/* 102 */             0.3F);
/*     */ 
/*     */         
/* 105 */         bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27379, class_290.field_1592);
/*     */         
/* 107 */         angle = 0.0D;
/* 108 */         while (angle <= 6.283185307179586D) {
/* 109 */           double x = Math.cos(angle) * radius;
/* 110 */           double z = Math.sin(angle) * radius;
/*     */           
/* 112 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/* 113 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)x, (float)pos.method_10214(), (float)pos.method_10215() + (float)z);
/* 114 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216(), (float)pos.method_10214() + offsetMid, (float)pos.method_10215());
/*     */           
/* 116 */           prevX = x;
/* 117 */           prevZ = z;
/*     */           
/* 119 */           angle += precision;
/*     */         } 
/*     */         
/* 122 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)Math.cos(0.0D) * (float)radius, (float)pos.method_10214(), (float)pos.method_10215() + (float)Math.sin(0.0D) * (float)radius);
/* 123 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/* 124 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216(), (float)pos.method_10214() + offsetMid, (float)pos.method_10215());
/*     */       } 
/*     */ 
/*     */       
/* 128 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 131 */       matrixStack.method_22909();
/* 132 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 133 */       GL11.glEnable(2929);
/* 134 */       GL11.glDisable(3042);
/* 135 */       GL11.glEnable(2884);
/*     */     }
/*     */     private static final class_5944 circle$lambda$1() {
/*     */       return class_757.method_34539();
/* 139 */     } public final void line(@NotNull class_243 position1, @NotNull class_243 position2, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(position1, "position1"); Intrinsics.checkNotNullParameter(position2, "position2"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); class_243 pos1 = position1;
/* 140 */       class_243 pos2 = position2;
/*     */       
/* 142 */       GL11.glEnable(3042);
/* 143 */       GL11.glBlendFunc(770, 771);
/* 144 */       GL11.glEnable(2884);
/* 145 */       GL11.glDisable(2929);
/*     */       
/* 147 */       RenderSystem.setShader(Companion::line$lambda$2);
/* 148 */       matrixStack.method_22903();
/*     */       
/* 150 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 151 */       int regionX = camPos.method_10263();
/* 152 */       int regionZ = camPos.method_10260();
/*     */       
/* 154 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 155 */       Intrinsics.checkNotNullExpressionValue(pos1.method_1023(regionX, 0.0D, regionZ), "subtract(...)"); pos1 = pos1.method_1023(regionX, 0.0D, regionZ);
/* 156 */       Intrinsics.checkNotNullExpressionValue(pos2.method_1023(regionX, 0.0D, regionZ), "subtract(...)"); pos2 = pos2.method_1023(regionX, 0.0D, regionZ);
/*     */       
/* 158 */       Color col = new Color(color);
/* 159 */       RenderSystem.setShaderColor(
/* 160 */           col.getRed() / 255.0F, 
/* 161 */           col.getGreen() / 255.0F, 
/* 162 */           col.getBlue() / 255.0F, 
/* 163 */           1.0F);
/*     */       
/* 165 */       Matrix4f matrix = matrixStack.method_23760().method_23761();
/* 166 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */ 
/*     */       
/* 169 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 170 */       bufferBuilder.method_22918(matrix, (float)pos1.method_10216(), (float)pos1.method_10214(), (float)pos1.method_10215());
/* 171 */       bufferBuilder.method_22918(matrix, (float)pos2.method_10216(), (float)pos2.method_10214(), (float)pos2.method_10215());
/*     */ 
/*     */       
/* 174 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 177 */       matrixStack.method_22909();
/* 178 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 179 */       GL11.glEnable(2929);
/* 180 */       GL11.glDisable(3042); }
/*     */     private static final class_5944 line$lambda$2() { return class_757.method_34539(); } private static final class_5944 outlinedBox$lambda$3() {
/*     */       return class_757.method_34539();
/*     */     } public final void outlinedBox(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) {
/* 184 */       Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 185 */       GL11.glBlendFunc(770, 771);
/* 186 */       GL11.glEnable(2884);
/* 187 */       GL11.glDisable(2929);
/* 188 */       RenderSystem.setShader(Companion::outlinedBox$lambda$3);
/* 189 */       matrixStack.method_22903();
/* 190 */       class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 1.0D, 0.5D);
/* 191 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 192 */       int regionX = camPos.method_10263();
/* 193 */       int regionZ = camPos.method_10260();
/*     */       
/* 195 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 196 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 197 */       RenderSystem.setShader(Companion::outlinedBox$lambda$4);
/* 198 */       Color col = new Color(color);
/*     */       
/* 200 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 202 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 203 */       RenderSystem.setShaderColor(
/* 204 */           col.getRed() / 255.0F, 
/* 205 */           col.getGreen() / 255.0F, 
/* 206 */           col.getBlue() / 255.0F, 
/* 207 */           1.0F);
/*     */ 
/*     */       
/* 210 */       Intrinsics.checkNotNull(bufferBuilder); boxLines(bb, matrixStack, bufferBuilder);
/* 211 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */       
/* 213 */       matrixStack.method_22909();
/* 214 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 215 */       GL11.glEnable(2929);
/* 216 */       GL11.glDisable(3042);
/*     */     } private static final class_5944 outlinedBox$lambda$4() {
/*     */       return class_757.method_34539();
/*     */     } public final void sideBox(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) {
/* 220 */       Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 221 */       GL11.glBlendFunc(770, 771);
/* 222 */       GL11.glEnable(2884);
/* 223 */       GL11.glDisable(2929);
/* 224 */       RenderSystem.setShader(Companion::sideBox$lambda$5);
/* 225 */       matrixStack.method_22903();
/* 226 */       class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 1.0D, 0.5D);
/* 227 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 228 */       int regionX = camPos.method_10263();
/* 229 */       int regionZ = camPos.method_10260();
/*     */       
/* 231 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 232 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 233 */       RenderSystem.setShader(Companion::sideBox$lambda$6);
/* 234 */       Color col = new Color(color);
/*     */       
/* 236 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 238 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 239 */       RenderSystem.setShaderColor(
/* 240 */           col.getRed() / 255.0F, 
/* 241 */           col.getGreen() / 255.0F, 
/* 242 */           col.getBlue() / 255.0F, 
/* 243 */           0.3F);
/*     */       
/* 245 */       Intrinsics.checkNotNull(bufferBuilder); boxFill(bb, matrixStack, bufferBuilder);
/* 246 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 249 */       matrixStack.method_22909();
/* 250 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 251 */       GL11.glEnable(2929);
/* 252 */       GL11.glDisable(3042); } private static final class_5944 sideBox$lambda$5() {
/*     */       return class_757.method_34539();
/*     */     } private static final class_5944 sideBox$lambda$6() {
/*     */       return class_757.method_34539();
/*     */     }
/* 257 */     public final void box(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 258 */       GL11.glBlendFunc(770, 771);
/* 259 */       GL11.glEnable(2884);
/* 260 */       GL11.glDisable(2929);
/* 261 */       RenderSystem.setShader(Companion::box$lambda$7);
/* 262 */       matrixStack.method_22903();
/* 263 */       class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 1.0D, 0.5D);
/* 264 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 265 */       int regionX = camPos.method_10263();
/* 266 */       int regionZ = camPos.method_10260();
/*     */       
/* 268 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 269 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 270 */       RenderSystem.setShader(Companion::box$lambda$8);
/* 271 */       Color col = new Color(color);
/*     */       
/* 273 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 275 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 276 */       RenderSystem.setShaderColor(
/* 277 */           col.getRed() / 255.0F, 
/* 278 */           col.getGreen() / 255.0F, 
/* 279 */           col.getBlue() / 255.0F, 
/* 280 */           1.0F);
/*     */       
/* 282 */       class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(bb, matrixStack, class_2871);
/* 283 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 286 */       bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 287 */       RenderSystem.setShaderColor(
/* 288 */           col.getRed() / 255.0F, 
/* 289 */           col.getGreen() / 255.0F, 
/* 290 */           col.getBlue() / 255.0F, 
/* 291 */           0.3F);
/*     */       
/* 293 */       class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(bb, matrixStack, class_2871);
/* 294 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 297 */       matrixStack.method_22909();
/* 298 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 299 */       GL11.glEnable(2929);
/* 300 */       GL11.glDisable(3042); } private static final class_5944 box$lambda$7() { return class_757.method_34539(); }
/*     */     private static final class_5944 box$lambda$8() {
/*     */       return class_757.method_34539();
/*     */     }
/* 304 */     public final void box(@NotNull class_238 box, @NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 305 */       GL11.glBlendFunc(770, 771);
/* 306 */       GL11.glEnable(2884);
/* 307 */       GL11.glDisable(2929);
/* 308 */       RenderSystem.setShader(Companion::box$lambda$9);
/* 309 */       matrixStack.method_22903();
/* 310 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 311 */       int regionX = camPos.method_10263();
/* 312 */       int regionZ = camPos.method_10260();
/*     */       
/* 314 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 315 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 316 */       RenderSystem.setShader(Companion::box$lambda$10);
/* 317 */       Color col = new Color(color);
/*     */       
/* 319 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 321 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 322 */       RenderSystem.setShaderColor(
/* 323 */           col.getRed() / 255.0F, 
/* 324 */           col.getGreen() / 255.0F, 
/* 325 */           col.getBlue() / 255.0F, 
/* 326 */           1.0F);
/*     */       
/* 328 */       class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(box, matrixStack, class_2871);
/* 329 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 332 */       bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 333 */       RenderSystem.setShaderColor(
/* 334 */           col.getRed() / 255.0F, 
/* 335 */           col.getGreen() / 255.0F, 
/* 336 */           col.getBlue() / 255.0F, 
/* 337 */           0.3F);
/*     */       
/* 339 */       class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(box, matrixStack, class_2871);
/* 340 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 343 */       matrixStack.method_22909();
/* 344 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 345 */       GL11.glEnable(2929);
/* 346 */       GL11.glDisable(3042); } private static final class_5944 box$lambda$9() { return class_757.method_34539(); }
/*     */     private static final class_5944 box$lambda$10() {
/*     */       return class_757.method_34539();
/*     */     }
/* 350 */     public final void sideBox(@NotNull class_238 box, @NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 351 */       GL11.glBlendFunc(770, 771);
/* 352 */       GL11.glEnable(2884);
/* 353 */       GL11.glDisable(2929);
/* 354 */       RenderSystem.setShader(Companion::sideBox$lambda$11);
/* 355 */       matrixStack.method_22903();
/* 356 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 357 */       int regionX = camPos.method_10263();
/* 358 */       int regionZ = camPos.method_10260();
/*     */       
/* 360 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 361 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 362 */       RenderSystem.setShader(Companion::sideBox$lambda$12);
/* 363 */       Color col = new Color(color);
/*     */       
/* 365 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 367 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 368 */       RenderSystem.setShaderColor(
/* 369 */           col.getRed() / 255.0F, 
/* 370 */           col.getGreen() / 255.0F, 
/* 371 */           col.getBlue() / 255.0F, 
/* 372 */           0.3F);
/*     */       
/* 374 */       Intrinsics.checkNotNull(bufferBuilder); boxFill(box, matrixStack, bufferBuilder);
/* 375 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 378 */       matrixStack.method_22909();
/* 379 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 380 */       GL11.glEnable(2929);
/* 381 */       GL11.glDisable(3042); } private static final class_5944 sideBox$lambda$11() { return class_757.method_34539(); }
/*     */     private static final class_5944 sideBox$lambda$12() {
/*     */       return class_757.method_34539();
/*     */     }
/* 385 */     public final void outlinedBox(@NotNull class_238 box, @NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 386 */       GL11.glBlendFunc(770, 771);
/* 387 */       GL11.glEnable(2884);
/* 388 */       GL11.glDisable(2929);
/* 389 */       RenderSystem.setShader(Companion::outlinedBox$lambda$13);
/* 390 */       matrixStack.method_22903();
/* 391 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 392 */       int regionX = camPos.method_10263();
/* 393 */       int regionZ = camPos.method_10260();
/*     */       
/* 395 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 396 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 397 */       RenderSystem.setShader(Companion::outlinedBox$lambda$14);
/* 398 */       Color col = new Color(color);
/*     */       
/* 400 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 402 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 403 */       RenderSystem.setShaderColor(
/* 404 */           col.getRed() / 255.0F, 
/* 405 */           col.getGreen() / 255.0F, 
/* 406 */           col.getBlue() / 255.0F, 
/* 407 */           1.0F);
/*     */       
/* 409 */       Intrinsics.checkNotNull(bufferBuilder); boxLines(box, matrixStack, bufferBuilder);
/* 410 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 413 */       matrixStack.method_22909();
/* 414 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 415 */       GL11.glEnable(2929);
/* 416 */       GL11.glDisable(3042); } private static final class_5944 outlinedBox$lambda$13() { return class_757.method_34539(); }
/*     */     private static final class_5944 outlinedBox$lambda$14() {
/*     */       return class_757.method_34539();
/*     */     }
/* 420 */     public final void multiBlock(@NotNull ArrayList blocks, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(blocks, "blocks"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 421 */       GL11.glBlendFunc(770, 771);
/* 422 */       GL11.glEnable(2884);
/* 423 */       GL11.glDisable(2929);
/* 424 */       RenderSystem.setShader(Companion::multiBlock$lambda$15);
/* 425 */       matrixStack.method_22903();
/* 426 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 427 */       int regionX = camPos.method_10263();
/* 428 */       int regionZ = camPos.method_10260();
/*     */       
/* 430 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/*     */       
/* 432 */       RenderSystem.setShader(Companion::multiBlock$lambda$16);
/* 433 */       Color col = new Color(color);
/*     */       
/* 435 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 437 */       double sizeX = Math.abs(CoordinateUtils.Companion.getHighestX(blocks) - CoordinateUtils.Companion.getLowestX(blocks));
/* 438 */       double sizeY = Math.abs(CoordinateUtils.Companion.getHighestY(blocks) - CoordinateUtils.Companion.getLowestY(blocks)) + true;
/* 439 */       double sizeZ = Math.abs(CoordinateUtils.Companion.getHighestZ(blocks) - CoordinateUtils.Companion.getLowestZ(blocks));
/*     */       
/* 441 */       class_238 bb = new class_238(-(sizeX / 2 + 0.5D), 0.0D, -(sizeZ / 2 + 0.5D), sizeX / 2 + 0.5D, sizeY, sizeZ / 2 + 0.5D);
/*     */       
/* 443 */       class_243 center = new class_243(
/* 444 */           CoordinateUtils.Companion.getLowestX(blocks) + sizeX / 2, 
/* 445 */           CoordinateUtils.Companion.getLowestY(blocks) + sizeY / 2, 
/* 446 */           CoordinateUtils.Companion.getLowestZ(blocks) + sizeZ / 2);
/*     */ 
/*     */       
/* 449 */       matrixStack.method_22904(center.method_10216() - regionX, center.method_10214() - sizeY / 2, center.method_10215() - regionZ);
/*     */       
/* 451 */       RenderSystem.setShaderColor(
/* 452 */           col.getRed() / 255.0F, 
/* 453 */           col.getGreen() / 255.0F, 
/* 454 */           col.getBlue() / 255.0F, 
/* 455 */           0.5F);
/*     */ 
/*     */       
/* 458 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 459 */       class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(bb, matrixStack, class_2871);
/*     */       
/* 461 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 464 */       RenderSystem.setShaderColor(
/* 465 */           col.getRed() / 255.0F, 
/* 466 */           col.getGreen() / 255.0F, 
/* 467 */           col.getBlue() / 255.0F, 
/* 468 */           0.03F);
/*     */ 
/*     */       
/* 471 */       bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 472 */       class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(bb, matrixStack, class_2871);
/*     */       
/* 474 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 477 */       matrixStack.method_22909();
/* 478 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 479 */       GL11.glEnable(2929);
/* 480 */       GL11.glDisable(3042); } private static final class_5944 multiBlock$lambda$15() { return class_757.method_34539(); }
/*     */     private static final class_5944 multiBlock$lambda$16() {
/*     */       return class_757.method_34539();
/*     */     }
/* 484 */     public final void floorQuad(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 485 */       GL11.glBlendFunc(770, 771);
/* 486 */       GL11.glEnable(2884);
/* 487 */       GL11.glDisable(2929);
/* 488 */       RenderSystem.setShader(Companion::floorQuad$lambda$17);
/* 489 */       matrixStack.method_22903();
/* 490 */       class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 0.0D, 0.5D);
/* 491 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 492 */       int regionX = camPos.method_10263();
/* 493 */       int regionZ = camPos.method_10260();
/*     */       
/* 495 */       applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 496 */       matrixStack.method_22904(block.method_10216() - regionX, block.method_10214() - 0.5D, block.method_10215() - regionZ);
/* 497 */       RenderSystem.setShader(Companion::floorQuad$lambda$18);
/* 498 */       Color col = new Color(color);
/*     */       
/* 500 */       class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */       
/* 502 */       class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 503 */       RenderSystem.setShaderColor(
/* 504 */           col.getRed() / 255.0F, 
/* 505 */           col.getGreen() / 255.0F, 
/* 506 */           col.getBlue() / 255.0F, 
/* 507 */           1.0F);
/*     */       
/* 509 */       class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(bb, matrixStack, class_2871);
/* 510 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 513 */       bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 514 */       RenderSystem.setShaderColor(
/* 515 */           col.getRed() / 255.0F, 
/* 516 */           col.getGreen() / 255.0F, 
/* 517 */           col.getBlue() / 255.0F, 
/* 518 */           0.3F);
/*     */       
/* 520 */       class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(bb, matrixStack, class_2871);
/* 521 */       class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */       
/* 524 */       matrixStack.method_22909();
/* 525 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 526 */       GL11.glEnable(2929);
/* 527 */       GL11.glDisable(3042); } private static final class_5944 floorQuad$lambda$17() { return class_757.method_34539(); } private static final class_5944 floorQuad$lambda$18() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */     private final void applyRegionalRenderOffset(class_4587 matrixStack, int regionX, int regionZ) {
/* 531 */       Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19326(), "getPos(...)"); class_243 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19326();
/* 532 */       matrixStack.method_22904(regionX - camPos.field_1352, -camPos.field_1351, regionZ - camPos.field_1350);
/*     */     }
/*     */     
/*     */     private final void boxLines(class_238 bb, class_4587 matrixStack, class_287 bufferBuilder) {
/* 536 */       Matrix4f matrix = matrixStack.method_23760().method_23761();
/*     */ 
/*     */       
/* 539 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 540 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/*     */       
/* 542 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 543 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/*     */       
/* 545 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 546 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/*     */       
/* 548 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 549 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/*     */       
/* 551 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 552 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/*     */       
/* 554 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 555 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/*     */       
/* 557 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 558 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/*     */       
/* 560 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 561 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/*     */       
/* 563 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/* 564 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/*     */       
/* 566 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/* 567 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/*     */       
/* 569 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 570 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/*     */       
/* 572 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/* 573 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final void boxFill(class_238 bb, class_4587 matrixStack, class_287 bufferBuilder) {
/* 579 */       Matrix4f matrix = matrixStack.method_23760().method_23761();
/* 580 */       RenderSystem.setShader(Companion::boxFill$lambda$19);
/*     */       
/* 582 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 583 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 584 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 585 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/*     */       
/* 587 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/* 588 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/* 589 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 590 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/*     */       
/* 592 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 593 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/* 594 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/* 595 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/*     */       
/* 597 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 598 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/* 599 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 600 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/*     */       
/* 602 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 603 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 604 */       bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 605 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/*     */       
/* 607 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 608 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 609 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/* 610 */       bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/*     */     }
/*     */     
/*     */     private static final class_5944 boxFill$lambda$19() {
/*     */       return class_757.method_34539();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\RenderingEngine$ThreeDimensional.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */