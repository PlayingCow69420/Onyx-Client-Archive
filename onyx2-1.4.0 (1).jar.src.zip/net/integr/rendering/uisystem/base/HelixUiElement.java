package net.integr.rendering.uisystem.base;

import kotlin.Metadata;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

@Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\020\006\n\002\b\002\n\002\020\b\n\000\n\002\020\002\n\002\b\005\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\002\b\n\bf\030\0002\0020\001J'\020\b\032\0020\0072\006\020\003\032\0020\0022\006\020\004\032\0020\0022\006\020\006\032\0020\005H&¢\006\004\b\b\020\tJ'\020\016\032\0020\r2\006\020\n\032\0020\0052\006\020\013\032\0020\0052\006\020\f\032\0020\005H&¢\006\004\b\016\020\017J'\020\020\032\0020\0072\006\020\003\032\0020\0022\006\020\004\032\0020\0022\006\020\006\032\0020\005H&¢\006\004\b\020\020\tJ/\020\025\032\0020\0072\006\020\022\032\0020\0212\006\020\003\032\0020\0052\006\020\004\032\0020\0052\006\020\024\032\0020\023H&¢\006\004\b\025\020\026J/\020\027\032\0020\r2\006\020\022\032\0020\0212\006\020\003\032\0020\0052\006\020\004\032\0020\0052\006\020\024\032\0020\023H&¢\006\004\b\027\020\030J\037\020\033\032\0020\0002\006\020\031\032\0020\0052\006\020\032\032\0020\005H&¢\006\004\b\033\020\034¨\006\035"}, d2 = {"Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "", "mouseX", "mouseY", "", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "xPos", "yPos", "update", "(II)Lnet/integr/rendering/uisystem/base/HelixUiElement;", "onyx2"})
public interface HelixUiElement {
  void onClick(double paramDouble1, double paramDouble2, int paramInt);
  
  boolean onKey(int paramInt1, int paramInt2, int paramInt3);
  
  void onRelease(double paramDouble1, double paramDouble2, int paramInt);
  
  @NotNull
  HelixUiElement update(int paramInt1, int paramInt2);
  
  void method_25394(@NotNull class_332 paramclass_332, int paramInt1, int paramInt2, float paramFloat);
  
  boolean renderTooltip(@NotNull class_332 paramclass_332, int paramInt1, int paramInt2, float paramFloat);
}


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\base\HelixUiElement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */