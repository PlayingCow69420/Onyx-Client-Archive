/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\002\b\003\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\005\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\002\b'\030\0002\0020\0012\0020\002B/\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J'\020\021\032\0020\0202\006\020\r\032\0020\f2\006\020\016\032\0020\f2\006\020\017\032\0020\003H\026¢\006\004\b\021\020\022J'\020\027\032\0020\0262\006\020\023\032\0020\0032\006\020\024\032\0020\0032\006\020\025\032\0020\003H\026¢\006\004\b\027\020\030J'\020\031\032\0020\0202\006\020\r\032\0020\f2\006\020\016\032\0020\f2\006\020\017\032\0020\003H\026¢\006\004\b\031\020\022J/\020\036\032\0020\0202\006\020\033\032\0020\0322\006\020\r\032\0020\0032\006\020\016\032\0020\0032\006\020\035\032\0020\034H\026¢\006\004\b\036\020\037J/\020 \032\0020\0262\006\020\033\032\0020\0322\006\020\r\032\0020\0032\006\020\016\032\0020\0032\006\020\035\032\0020\034H\026¢\006\004\b \020!J\037\020\"\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b\"\020#R\"\020$\032\0020\f8\006@\006X\016¢\006\022\n\004\b$\020%\032\004\b&\020'\"\004\b(\020)R\"\020*\032\0020\f8\006@\006X\016¢\006\022\n\004\b*\020%\032\004\b+\020'\"\004\b,\020)R\"\020-\032\0020\0268\006@\006X\016¢\006\022\n\004\b-\020.\032\004\b/\0200\"\004\b1\0202R\"\020\t\032\0020\b8\006@\006X\016¢\006\022\n\004\b\t\0203\032\004\b4\0205\"\004\b6\0207R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\0208\032\004\b9\020:\"\004\b;\020<R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\0208\032\004\b=\020:\"\004\b>\020<R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\0208\032\004\b?\020:\"\004\b@\020<R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\0208\032\004\bA\020:\"\004\bB\020<¨\006C"}, d2 = {"Lnet/integr/rendering/uisystem/MovableBox;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "<init>", "(IIIILjava/lang/String;)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/MovableBox;", "dragOffsetX", "D", "getDragOffsetX", "()D", "setDragOffsetX", "(D)V", "dragOffsetY", "getDragOffsetY", "setDragOffsetY", "dragging", "Z", "getDragging", "()Z", "setDragging", "(Z)V", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "I", "getXPos", "()I", "setXPos", "(I)V", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class MovableBox
/*     */   implements class_4068, HelixUiElement {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @NotNull
/*     */   private String text;
/*     */   private boolean dragging;
/*     */   private double dragOffsetX;
/*     */   private double dragOffsetY;
/*     */   
/*     */   public MovableBox(int xPos, int yPos, int xSize, int ySize, @NotNull String text) {
/*  33 */     this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @NotNull public final String getText() { return this.text; } public final void setText(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.text = <set-?>; }
/*  34 */   public final boolean getDragging() { return this.dragging; } public final void setDragging(boolean <set-?>) { this.dragging = <set-?>; }
/*  35 */   public final double getDragOffsetX() { return this.dragOffsetX; } public final void setDragOffsetX(double <set-?>) { this.dragOffsetX = <set-?>; }
/*  36 */   public final double getDragOffsetY() { return this.dragOffsetY; } public final void setDragOffsetY(double <set-?>) { this.dragOffsetY = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  39 */     Intrinsics.checkNotNullParameter(context, "context"); int color = Variables.Companion.getGuiBack();
/*  40 */     int textColor = Variables.Companion.getGuiColor();
/*     */     
/*  42 */     if (this.dragging) {
/*  43 */       this.xPos = class_3532.method_15340((int)(mouseX - this.dragOffsetX), 5, context.method_51421() - this.xSize - 5);
/*  44 */       this.yPos = class_3532.method_15340((int)(mouseY - this.dragOffsetY), 5, context.method_51443() - this.ySize - 5);
/*     */     } 
/*     */     
/*  47 */     int x1 = this.xPos;
/*  48 */     int x2 = this.xPos + this.xSize;
/*  49 */     int y1 = this.yPos;
/*  50 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  52 */     RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, x1, y1, x2, y2, color, textColor, context, 0.1F, 9.0F, false, 512, null);
/*     */     
/*  54 */     RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, textColor);
/*     */   }
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  58 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/*  59 */     int x2 = this.xPos + this.xSize;
/*  60 */     int y1 = this.yPos;
/*  61 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  63 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  64 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221193));
/*     */       
/*  66 */       return true;
/*     */     } 
/*     */     
/*  69 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/*  73 */     if (button == 0) {
/*  74 */       int x1 = this.xPos;
/*  75 */       int x2 = this.xPos + this.xSize;
/*  76 */       int y1 = this.yPos;
/*  77 */       int y2 = this.yPos + this.ySize;
/*     */ 
/*     */       
/*  80 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  81 */         this.dragging = true;
/*  82 */         this.dragOffsetX = mouseX - this.xPos;
/*  83 */         this.dragOffsetY = mouseY - this.yPos;
/*  84 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/*  91 */     return false;
/*     */   }
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {
/*  95 */     if (button == 0 && 
/*  96 */       this.dragging) {
/*  97 */       this.dragging = false;
/*     */     }
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public MovableBox update(int xPos, int yPos) {
/* 103 */     this.xPos = xPos;
/* 104 */     this.yPos = yPos;
/*     */     
/* 106 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\MovableBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */