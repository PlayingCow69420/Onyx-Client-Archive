/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000L\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\b\n\002\030\002\n\000\n\002\020\007\n\002\b'\030\0002\0020\0012\0020\002BW\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\n\b\001\020\t\032\004\030\0010\b\022\006\020\013\032\0020\n\022\006\020\f\032\0020\b\022\006\020\r\032\0020\n\022\n\020\020\032\0060\016j\002`\017¢\006\004\b\021\020\022J'\020\030\032\0020\0272\006\020\024\032\0020\0232\006\020\025\032\0020\0232\006\020\026\032\0020\003H\026¢\006\004\b\030\020\031J'\020\035\032\0020\n2\006\020\032\032\0020\0032\006\020\033\032\0020\0032\006\020\034\032\0020\003H\026¢\006\004\b\035\020\036J'\020\037\032\0020\0272\006\020\024\032\0020\0232\006\020\025\032\0020\0232\006\020\026\032\0020\003H\026¢\006\004\b\037\020\031J/\020$\032\0020\0272\006\020!\032\0020 2\006\020\024\032\0020\0032\006\020\025\032\0020\0032\006\020#\032\0020\"H\026¢\006\004\b$\020%J/\020&\032\0020\n2\006\020!\032\0020 2\006\020\024\032\0020\0032\006\020\025\032\0020\0032\006\020#\032\0020\"H\026¢\006\004\b&\020'J\037\020(\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b(\020)R\033\020\020\032\0060\016j\002`\0178\006¢\006\f\n\004\b\020\020*\032\004\b+\020,R\"\020\r\032\0020\n8\006@\006X\016¢\006\022\n\004\b\r\020-\032\004\b.\020/\"\004\b0\0201R$\020\t\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\b\t\0202\032\004\b3\0204\"\004\b5\0206R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\020-\032\004\b7\020/\"\004\b8\0201R\"\0209\032\0020\0038\006@\006X\016¢\006\022\n\004\b9\020:\032\004\b;\020<\"\004\b=\020>R\"\020\f\032\0020\b8\006@\006X\016¢\006\022\n\004\b\f\0202\032\004\b?\0204\"\004\b@\0206R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\020:\032\004\bA\020<\"\004\bB\020>R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\020:\032\004\bC\020<\"\004\bD\020>R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\020:\032\004\bE\020<\"\004\bF\020>R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\020:\032\004\bG\020<\"\004\bH\020>¨\006I"}, d2 = {"Lnet/integr/rendering/uisystem/Button;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "tooltip", "outlined", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "action", "<init>", "(IIIILjava/lang/String;ZLjava/lang/String;ZLjava/lang/Runnable;)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/Button;", "Ljava/lang/Runnable;", "getAction", "()Ljava/lang/Runnable;", "Z", "getOutlined", "()Z", "setOutlined", "(Z)V", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "getTextCentered", "setTextCentered", "textColor", "I", "getTextColor", "()I", "setTextColor", "(I)V", "getTooltip", "setTooltip", "getXPos", "setXPos", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class Button implements class_4068, HelixUiElement {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @Nullable
/*     */   private String text;
/*     */   private boolean textCentered;
/*     */   @NotNull
/*     */   private String tooltip;
/*     */   private boolean outlined;
/*     */   @NotNull
/*     */   private final Runnable action;
/*     */   private int textColor;
/*     */   
/*  34 */   public Button(int xPos, int yPos, int xSize, int ySize, @Nullable String text, boolean textCentered, @NotNull String tooltip, boolean outlined, @NotNull Runnable action) { this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.tooltip = tooltip; this.outlined = outlined; this.action = action; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @Nullable public final String getText() { return this.text; } public final void setText(@Nullable String <set-?>) { this.text = <set-?>; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } public final boolean getOutlined() { return this.outlined; } public final void setOutlined(boolean <set-?>) { this.outlined = <set-?>; } @NotNull public final Runnable getAction() { return this.action; }
/*  35 */   public final int getTextColor() { return this.textColor; } public final void setTextColor(int <set-?>) { this.textColor = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  38 */     Intrinsics.checkNotNullParameter(context, "context"); int colorEnabled = Variables.Companion.getGuiColor();
/*  39 */     this.textColor = Variables.Companion.getGuiBack();
/*     */     
/*  41 */     int x1 = this.xPos;
/*  42 */     int x2 = this.xPos + this.xSize;
/*  43 */     int y1 = this.yPos;
/*  44 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  46 */     if (this.outlined) {
/*  47 */       RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, x1, y1, x2, y2, this.textColor, colorEnabled, context, 0.1F, 9.0F, false, 512, null);
/*     */     } else {
/*  49 */       RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, colorEnabled, context, 0.1F, 9.0F);
/*     */     } 
/*     */     
/*  52 */     if (this.text != null) {
/*  53 */       if (this.outlined) {
/*  54 */         if (this.textCentered) {
/*  55 */           Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, colorEnabled);
/*     */         } else {
/*  57 */           Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 2, y1 + this.ySize / 2 - 4, colorEnabled);
/*     */         }
/*     */       
/*  60 */       } else if (this.textCentered) {
/*  61 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } else {
/*  63 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 2, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  70 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/*  71 */     int x2 = this.xPos + this.xSize;
/*  72 */     int y1 = this.yPos;
/*  73 */     int y2 = this.yPos + this.ySize;
/*     */ 
/*     */     
/*  76 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  77 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221188));
/*     */       
/*  79 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/*  80 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*     */       
/*  82 */       explainingBox.setXPos(mouseX + 10);
/*  83 */       explainingBox.setYPos(mouseY);
/*  84 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*     */       
/*  86 */       return true;
/*     */     } 
/*     */     
/*  89 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/*  93 */     if (button == 0) {
/*  94 */       int x1 = this.xPos;
/*  95 */       int x2 = this.xPos + this.xSize;
/*  96 */       int y1 = this.yPos;
/*  97 */       int y2 = this.yPos + this.ySize;
/*     */ 
/*     */       
/* 100 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 101 */         this.action.run();
/* 102 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {}
/*     */   
/*     */   @NotNull
/*     */   public Button update(int xPos, int yPos) {
/* 117 */     this.xPos = xPos;
/* 118 */     this.yPos = yPos;
/*     */     
/* 120 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\Button.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */