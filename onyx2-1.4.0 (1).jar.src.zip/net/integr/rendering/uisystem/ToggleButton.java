/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\020\002\n\002\b\003\n\002\020\006\n\002\b\013\n\002\030\002\n\000\n\002\020\007\n\002\b+\030\0002\0020\0012\0020\002Be\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\n\b\001\020\t\032\004\030\0010\b\022\006\020\013\032\0020\n\022\006\020\f\032\0020\b\022\b\b\002\020\r\032\0020\n\022\026\b\002\020\020\032\020\022\004\022\0020\000\022\004\022\0020\017\030\0010\016¢\006\004\b\021\020\022J'\020\027\032\0020\0172\006\020\024\032\0020\0232\006\020\025\032\0020\0232\006\020\026\032\0020\003H\026¢\006\004\b\027\020\030J'\020\034\032\0020\n2\006\020\031\032\0020\0032\006\020\032\032\0020\0032\006\020\033\032\0020\003H\026¢\006\004\b\034\020\035J'\020\036\032\0020\0172\006\020\024\032\0020\0232\006\020\025\032\0020\0232\006\020\026\032\0020\003H\026¢\006\004\b\036\020\030J/\020#\032\0020\0172\006\020 \032\0020\0372\006\020\024\032\0020\0032\006\020\025\032\0020\0032\006\020\"\032\0020!H\026¢\006\004\b#\020$J/\020%\032\0020\n2\006\020 \032\0020\0372\006\020\024\032\0020\0032\006\020\025\032\0020\0032\006\020\"\032\0020!H\026¢\006\004\b%\020&J\037\020'\032\0020\0022\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b'\020(R\026\020)\032\0020\0038\002@\002X\016¢\006\006\n\004\b)\020*R\"\020+\032\0020\n8\006@\006X\016¢\006\022\n\004\b+\020,\032\004\b-\020.\"\004\b/\0200R0\020\020\032\020\022\004\022\0020\000\022\004\022\0020\017\030\0010\0168\006@\006X\016¢\006\022\n\004\b\020\0201\032\004\b2\0203\"\004\b4\0205R\"\020\r\032\0020\n8\006@\006X\016¢\006\022\n\004\b\r\020,\032\004\b6\020.\"\004\b7\0200R$\020\t\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\b\t\0208\032\004\b9\020:\"\004\b;\020<R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\020,\032\004\b=\020.\"\004\b>\0200R\026\020?\032\0020\0038\002@\002X\016¢\006\006\n\004\b?\020*R\"\020\f\032\0020\b8\006@\006X\016¢\006\022\n\004\b\f\0208\032\004\b@\020:\"\004\bA\020<R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\020*\032\004\bB\020C\"\004\bD\020ER\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\020*\032\004\bF\020C\"\004\bG\020ER\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\020*\032\004\bH\020C\"\004\bI\020ER\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\020*\032\004\bJ\020C\"\004\bK\020E¨\006L"}, d2 = {"Lnet/integr/rendering/uisystem/ToggleButton;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "tooltip", "icon", "Lkotlin/Function1;", "", "executable", "<init>", "(IIIILjava/lang/String;ZLjava/lang/String;ZLkotlin/jvm/functions/Function1;)V", "", "mouseX", "mouseY", "button", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/base/HelixUiElement;", "color", "I", "enabled", "Z", "getEnabled", "()Z", "setEnabled", "(Z)V", "Lkotlin/jvm/functions/Function1;", "getExecutable", "()Lkotlin/jvm/functions/Function1;", "setExecutable", "(Lkotlin/jvm/functions/Function1;)V", "getIcon", "setIcon", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "getTextCentered", "setTextCentered", "textColor", "getTooltip", "setTooltip", "getXPos", "()I", "setXPos", "(I)V", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class ToggleButton implements class_4068, HelixUiElement {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @Nullable
/*     */   private String text;
/*     */   private boolean textCentered;
/*     */   
/*     */   public ToggleButton(int xPos, int yPos, int xSize, int ySize, @Nullable String text, boolean textCentered, @NotNull String tooltip, boolean icon, @Nullable Function1<? super ToggleButton, Unit> executable) {
/*  33 */     this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.tooltip = tooltip; this.icon = icon; this.executable = executable; } @NotNull private String tooltip; private boolean icon; @Nullable private Function1<? super ToggleButton, Unit> executable; private int color; private int textColor; private boolean enabled; public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @Nullable public final String getText() { return this.text; } public final void setText(@Nullable String <set-?>) { this.text = <set-?>; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } public final boolean getIcon() { return this.icon; } public final void setIcon(boolean <set-?>) { this.icon = <set-?>; } @Nullable public final Function1<ToggleButton, Unit> getExecutable() { return (Function1)this.executable; } public final void setExecutable(@Nullable Function1<? super ToggleButton, Unit> <set-?>) { this.executable = <set-?>; }
/*     */ 
/*     */   
/*  36 */   public final boolean getEnabled() { return this.enabled; } public final void setEnabled(boolean <set-?>) { this.enabled = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  39 */     Intrinsics.checkNotNullParameter(context, "context"); this.textColor = Variables.Companion.getGuiBack();
/*     */     
/*  41 */     int colorEnabled = Variables.Companion.getGuiColor();
/*  42 */     int colorDisabled = Variables.Companion.getGuiDisabled();
/*     */     
/*  44 */     this.color = this.enabled ? 
/*  45 */       colorEnabled : 
/*  46 */       colorDisabled;
/*     */     
/*  48 */     int x1 = this.xPos;
/*  49 */     int x2 = this.xPos + this.xSize;
/*  50 */     int y1 = this.yPos;
/*  51 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  53 */     RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, this.color, context, 0.1F, 9.0F);
/*     */     
/*  55 */     if (this.text != null) {
/*  56 */       if (this.textCentered) {
/*  57 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } else {
/*  59 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 2, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } 
/*     */     }
/*     */     
/*  63 */     if (this.enabled && this.icon) {
/*  64 */       RenderingEngine.Text.Companion.draw(context, "✔", x1 + this.xSize - 15, y1 + this.ySize / 2 - 4, this.textColor);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  69 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/*  70 */     int x2 = this.xPos + this.xSize;
/*  71 */     int y1 = this.yPos;
/*  72 */     int y2 = this.yPos + this.ySize;
/*     */ 
/*     */     
/*  75 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  76 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221188));
/*     */       
/*  78 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/*  79 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*     */       
/*  81 */       explainingBox.setXPos(mouseX + 10);
/*  82 */       explainingBox.setYPos(mouseY);
/*  83 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*     */       
/*  85 */       return true;
/*     */     } 
/*     */     
/*  88 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/*  92 */     if (button == 0) {
/*  93 */       int x1 = this.xPos;
/*  94 */       int x2 = this.xPos + this.xSize;
/*  95 */       int y1 = this.yPos;
/*  96 */       int y2 = this.yPos + this.ySize;
/*     */ 
/*     */       
/*  99 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 100 */         this.enabled = !this.enabled;
/* 101 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */         
/* 103 */         if (this.executable != null) { this.executable.invoke(this); }
/*     */         else
/*     */         {  }
/*     */       
/*     */       } 
/*     */     } 
/*     */   } public boolean onKey(int keyCode, int scanCode, int modifiers) {
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {}
/*     */   
/*     */   @NotNull
/*     */   public HelixUiElement update(int xPos, int yPos) {
/* 118 */     this.xPos = xPos;
/* 119 */     this.yPos = yPos;
/*     */     
/* 121 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\ToggleButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */