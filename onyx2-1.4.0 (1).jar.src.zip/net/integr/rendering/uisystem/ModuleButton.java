/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.modules.management.Module;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.screens.ModuleScreen;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_124;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000N\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\b\n\002\030\002\n\000\n\002\020\007\n\002\b.\030\0002\0020\0012\0020\002B[\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\n\b\001\020\t\032\004\030\0010\b\022\006\020\013\032\0020\n\022\006\020\f\032\0020\b\022\006\020\r\032\0020\n\022\006\020\017\032\0020\016\022\006\020\021\032\0020\020¢\006\004\b\022\020\023J'\020\031\032\0020\0302\006\020\025\032\0020\0242\006\020\026\032\0020\0242\006\020\027\032\0020\003H\026¢\006\004\b\031\020\032J'\020\036\032\0020\n2\006\020\033\032\0020\0032\006\020\034\032\0020\0032\006\020\035\032\0020\003H\026¢\006\004\b\036\020\037J'\020 \032\0020\0302\006\020\025\032\0020\0242\006\020\026\032\0020\0242\006\020\027\032\0020\003H\026¢\006\004\b \020\032J/\020%\032\0020\0302\006\020\"\032\0020!2\006\020\025\032\0020\0032\006\020\026\032\0020\0032\006\020$\032\0020#H\026¢\006\004\b%\020&J/\020'\032\0020\n2\006\020\"\032\0020!2\006\020\025\032\0020\0032\006\020\026\032\0020\0032\006\020$\032\0020#H\026¢\006\004\b'\020(J\037\020)\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b)\020*R\"\020\017\032\0020\0168\006@\006X\016¢\006\022\n\004\b\017\020+\032\004\b,\020-\"\004\b.\020/R\"\020\r\032\0020\n8\006@\006X\016¢\006\022\n\004\b\r\0200\032\004\b1\0202\"\004\b3\0204R\"\020\021\032\0020\0208\006@\006X\016¢\006\022\n\004\b\021\0205\032\004\b6\0207\"\004\b8\0209R$\020\t\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\b\t\020:\032\004\b;\020<\"\004\b=\020>R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\0200\032\004\b?\0202\"\004\b@\0204R\"\020A\032\0020\0038\006@\006X\016¢\006\022\n\004\bA\020B\032\004\bC\020D\"\004\bE\020FR\"\020\f\032\0020\b8\006@\006X\016¢\006\022\n\004\b\f\020:\032\004\bG\020<\"\004\bH\020>R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\020B\032\004\bI\020D\"\004\bJ\020FR\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\020B\032\004\bK\020D\"\004\bL\020FR\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\020B\032\004\bM\020D\"\004\bN\020FR\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\020B\032\004\bO\020D\"\004\bP\020F¨\006Q"}, d2 = {"Lnet/integr/rendering/uisystem/ModuleButton;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "tooltip", "outlined", "Lnet/integr/modules/management/Module;", "module", "Ljava/lang/Runnable;", "runnable", "<init>", "(IIIILjava/lang/String;ZLjava/lang/String;ZLnet/integr/modules/management/Module;Ljava/lang/Runnable;)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/ModuleButton;", "Lnet/integr/modules/management/Module;", "getModule", "()Lnet/integr/modules/management/Module;", "setModule", "(Lnet/integr/modules/management/Module;)V", "Z", "getOutlined", "()Z", "setOutlined", "(Z)V", "Ljava/lang/Runnable;", "getRunnable", "()Ljava/lang/Runnable;", "setRunnable", "(Ljava/lang/Runnable;)V", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "getTextCentered", "setTextCentered", "textColor", "I", "getTextColor", "()I", "setTextColor", "(I)V", "getTooltip", "setTooltip", "getXPos", "setXPos", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class ModuleButton
/*     */   implements class_4068, HelixUiElement
/*     */ {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @Nullable
/*     */   private String text;
/*     */   
/*     */   public ModuleButton(int xPos, int yPos, int xSize, int ySize, @Nullable String text, boolean textCentered, @NotNull String tooltip, boolean outlined, @NotNull Module module, @NotNull Runnable runnable) {
/*  36 */     this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.tooltip = tooltip; this.outlined = outlined; this.module = module; this.runnable = runnable; } private boolean textCentered; @NotNull private String tooltip; private boolean outlined; @NotNull private Module module; @NotNull private Runnable runnable; private int textColor; public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @Nullable public final String getText() { return this.text; } public final void setText(@Nullable String <set-?>) { this.text = <set-?>; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } public final boolean getOutlined() { return this.outlined; } public final void setOutlined(boolean <set-?>) { this.outlined = <set-?>; } @NotNull public final Module getModule() { return this.module; } public final void setModule(@NotNull Module <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.module = <set-?>; } @NotNull public final Runnable getRunnable() { return this.runnable; } public final void setRunnable(@NotNull Runnable <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.runnable = <set-?>; }
/*  37 */   public final int getTextColor() { return this.textColor; } public final void setTextColor(int <set-?>) { this.textColor = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  40 */     Intrinsics.checkNotNullParameter(context, "context"); int colorEnabled = this.module.getEnabled() ? Variables.Companion.getGuiColor() : Variables.Companion.getGuiDisabled();
/*  41 */     this.textColor = Variables.Companion.getGuiBack();
/*     */     
/*  43 */     int x1 = this.xPos;
/*  44 */     int x2 = this.xPos + this.xSize;
/*  45 */     int y1 = this.yPos;
/*  46 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  48 */     if (this.outlined) {
/*  49 */       RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, x1, y1, x2, y2, this.textColor, colorEnabled, context, 0.1F, 9.0F, false, 512, null);
/*     */     } else {
/*  51 */       RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, colorEnabled, context, 0.1F, 9.0F);
/*     */     } 
/*     */     
/*  54 */     if (this.text != null) {
/*  55 */       if (this.outlined) {
/*  56 */         if (this.textCentered) {
/*  57 */           Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, colorEnabled);
/*     */         } else {
/*  59 */           Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 2, y1 + this.ySize / 2 - 4, colorEnabled);
/*     */         }
/*     */       
/*  62 */       } else if (this.textCentered) {
/*  63 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } else {
/*  65 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 2, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } 
/*     */ 
/*     */       
/*  69 */       if (!this.module.getSettings().getOptions().isEmpty()) RenderingEngine.Text.Companion.draw(context, "" + class_124.field_1067 + "⁝", x1 + this.xSize - 15, y1 + this.ySize / 2 - 4, this.textColor); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  74 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/*  75 */     int x2 = this.xPos + this.xSize;
/*  76 */     int y1 = this.yPos;
/*  77 */     int y2 = this.yPos + this.ySize;
/*     */ 
/*     */     
/*  80 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  81 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221188));
/*     */       
/*  83 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/*  84 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*     */       
/*  86 */       explainingBox.setXPos(mouseX + 10);
/*  87 */       explainingBox.setYPos(mouseY);
/*  88 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*     */       
/*  90 */       return true;
/*     */     } 
/*     */     
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/*  97 */     int x1 = this.xPos;
/*  98 */     int x2 = this.xPos + this.xSize;
/*  99 */     int y1 = this.yPos;
/* 100 */     int y2 = this.yPos + this.ySize;
/*     */     
/* 102 */     int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 103 */       switch (button) { case 0:
/* 104 */           this.module.setState(!this.module.getEnabled());
/* 105 */           Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F)); break;
/*     */         case 1:
/* 107 */           if (!this.module.getSettings().getOptions().isEmpty()) {
/* 108 */             this.runnable.run();
/* 109 */             Onyx.Companion.getMC().method_1507((class_437)new ModuleScreen(this.module));
/* 110 */             Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */           } 
/*     */           break; }
/*     */     
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {}
/*     */   
/*     */   @NotNull
/*     */   public ModuleButton update(int xPos, int yPos) {
/* 126 */     this.xPos = xPos;
/* 127 */     this.yPos = yPos;
/*     */     
/* 129 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\ModuleButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */