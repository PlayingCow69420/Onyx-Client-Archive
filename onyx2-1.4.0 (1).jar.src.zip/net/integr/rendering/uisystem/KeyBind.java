/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000@\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\004\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\b\n\002\030\002\n\000\n\002\020\007\n\002\b.\030\0002\0020\0012\0020\002BC\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\n\b\001\020\t\032\004\030\0010\b\022\006\020\013\032\0020\n\022\006\020\f\032\0020\b¢\006\004\b\r\020\016J'\020\024\032\0020\0232\006\020\020\032\0020\0172\006\020\021\032\0020\0172\006\020\022\032\0020\003H\026¢\006\004\b\024\020\025J'\020\031\032\0020\n2\006\020\026\032\0020\0032\006\020\027\032\0020\0032\006\020\030\032\0020\003H\026¢\006\004\b\031\020\032J'\020\033\032\0020\0232\006\020\020\032\0020\0172\006\020\021\032\0020\0172\006\020\022\032\0020\003H\026¢\006\004\b\033\020\025J/\020 \032\0020\0232\006\020\035\032\0020\0342\006\020\020\032\0020\0032\006\020\021\032\0020\0032\006\020\037\032\0020\036H\026¢\006\004\b \020!J/\020\"\032\0020\n2\006\020\035\032\0020\0342\006\020\020\032\0020\0032\006\020\021\032\0020\0032\006\020\037\032\0020\036H\026¢\006\004\b\"\020#J\037\020$\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b$\020%R$\020&\032\004\030\0010\0038\006@\006X\016¢\006\022\n\004\b&\020'\032\004\b(\020)\"\004\b*\020+R\"\020,\032\0020\b8\006@\006X\016¢\006\022\n\004\b,\020-\032\004\b.\020/\"\004\b0\0201R\"\0202\032\0020\n8\006@\006X\016¢\006\022\n\004\b2\0203\032\004\b4\0205\"\004\b6\0207R$\020\t\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\b\t\020-\032\004\b8\020/\"\004\b9\0201R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\0203\032\004\b:\0205\"\004\b;\0207R\"\020<\032\0020\0038\006@\006X\016¢\006\022\n\004\b<\020=\032\004\b>\020?\"\004\b@\020AR\"\020\f\032\0020\b8\006@\006X\016¢\006\022\n\004\b\f\020-\032\004\bB\020/\"\004\bC\0201R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\020=\032\004\bD\020?\"\004\bE\020AR\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\020=\032\004\bF\020?\"\004\bG\020AR\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\020=\032\004\bH\020?\"\004\bI\020AR\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\020=\032\004\bJ\020?\"\004\bK\020A¨\006L"}, d2 = {"Lnet/integr/rendering/uisystem/KeyBind;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "tooltip", "<init>", "(IIIILjava/lang/String;ZLjava/lang/String;)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/KeyBind;", "bind", "Ljava/lang/Integer;", "getBind", "()Ljava/lang/Integer;", "setBind", "(Ljava/lang/Integer;)V", "bindText", "Ljava/lang/String;", "getBindText", "()Ljava/lang/String;", "setBindText", "(Ljava/lang/String;)V", "listening", "Z", "getListening", "()Z", "setListening", "(Z)V", "getText", "setText", "getTextCentered", "setTextCentered", "textColor", "I", "getTextColor", "()I", "setTextColor", "(I)V", "getTooltip", "setTooltip", "getXPos", "setXPos", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class KeyBind implements class_4068, HelixUiElement {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @Nullable
/*     */   private String text;
/*     */   private boolean textCentered;
/*     */   @NotNull
/*     */   private String tooltip;
/*     */   private int textColor;
/*     */   private boolean listening;
/*     */   @Nullable
/*     */   private Integer bind;
/*     */   @NotNull
/*     */   private String bindText;
/*     */   
/*  33 */   public KeyBind(int xPos, int yPos, int xSize, int ySize, @Nullable String text, boolean textCentered, @NotNull String tooltip) { this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.tooltip = tooltip;
/*     */ 
/*     */ 
/*     */     
/*  37 */     this.bindText = "None"; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @Nullable public final String getText() { return this.text; } public final void setText(@Nullable String <set-?>) { this.text = <set-?>; } @NotNull public final String getBindText() { return this.bindText; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } public final int getTextColor() { return this.textColor; } public final void setTextColor(int <set-?>) { this.textColor = <set-?>; } public final boolean getListening() { return this.listening; } public final void setListening(boolean <set-?>) { this.listening = <set-?>; } @Nullable public final Integer getBind() { return this.bind; } public final void setBind(@Nullable Integer <set-?>) { this.bind = <set-?>; } public final void setBindText(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.bindText = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  40 */     Intrinsics.checkNotNullParameter(context, "context"); int colorEnabled = Variables.Companion.getGuiColor();
/*  41 */     this.textColor = Variables.Companion.getGuiBack();
/*     */     
/*  43 */     int x1 = this.xPos;
/*  44 */     int x2 = this.xPos + this.xSize;
/*  45 */     int y1 = this.yPos;
/*  46 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  48 */     RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, colorEnabled, context, 0.1F, 9.0F);
/*     */     
/*  50 */     if (this.text != null) {
/*  51 */       if (this.textCentered) {
/*  52 */         Intrinsics.checkNotNull(this.text); Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text + this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text + this.text) / 2 - 4, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } else {
/*  54 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text + this.text, x1 + 2, y1 + this.ySize / 2 - 4, this.textColor);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  60 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/*  61 */     int x2 = this.xPos + this.xSize;
/*  62 */     int y1 = this.yPos;
/*  63 */     int y2 = this.yPos + this.ySize;
/*     */ 
/*     */     
/*  66 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  67 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221188));
/*     */       
/*  69 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/*  70 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*     */       
/*  72 */       explainingBox.setXPos(mouseX + 10);
/*  73 */       explainingBox.setYPos(mouseY);
/*  74 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*     */       
/*  76 */       return true;
/*     */     } 
/*     */     
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/*  83 */     if (button == 0) {
/*  84 */       int x1 = this.xPos;
/*  85 */       int x2 = this.xPos + this.xSize;
/*  86 */       int y1 = this.yPos;
/*  87 */       int y2 = this.yPos + this.ySize;
/*     */ 
/*     */       
/*  90 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  91 */         this.listening = true;
/*  92 */         this.bindText = "Listening...";
/*  93 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/*  99 */     if (this.listening) {
/* 100 */       String kn = GLFW.glfwGetKeyName(keyCode, scanCode);
/*     */       
/* 102 */       if (keyCode == 256) {
/* 103 */         this.listening = false;
/* 104 */         this.bind = null;
/* 105 */         this.bindText = "None";
/* 106 */         return true;
/*     */       } 
/*     */       
/* 109 */       if (keyCode == 2) {
/* 110 */         this.listening = false;
/* 111 */         this.bind = Integer.valueOf(keyCode);
/* 112 */         this.bindText = "Middle Mouse";
/* 113 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */       
/* 116 */       if (kn != null) {
/* 117 */         this.listening = false;
/* 118 */         this.bind = Integer.valueOf(keyCode);
/* 119 */         Intrinsics.checkNotNullExpressionValue(kn.toUpperCase(Locale.ROOT), "toUpperCase(...)"); this.bindText = kn.toUpperCase(Locale.ROOT);
/* 120 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */     } 
/*     */     
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {}
/*     */   
/*     */   @NotNull
/*     */   public KeyBind update(int xPos, int yPos) {
/* 132 */     this.xPos = xPos;
/* 133 */     this.yPos = yPos;
/*     */     
/* 135 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\KeyBind.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */