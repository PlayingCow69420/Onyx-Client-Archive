/*    */ package net.integr.rendering.uisystem;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Variables;
/*    */ import net.integr.rendering.RenderingEngine;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_4068;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000@\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\005\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\b\n\002\030\002\n\000\n\002\020\007\n\002\b!\030\0002\0020\0012\0020\002BO\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\n\b\001\020\t\032\004\030\0010\b\022\006\020\013\032\0020\n\022\b\b\002\020\f\032\0020\n\022\b\b\002\020\r\032\0020\n¢\006\004\b\016\020\017J'\020\025\032\0020\0242\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\023\032\0020\003H\026¢\006\004\b\025\020\026J'\020\032\032\0020\n2\006\020\027\032\0020\0032\006\020\030\032\0020\0032\006\020\031\032\0020\003H\026¢\006\004\b\032\020\033J'\020\034\032\0020\0242\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\023\032\0020\003H\026¢\006\004\b\034\020\026J/\020!\032\0020\0242\006\020\036\032\0020\0352\006\020\021\032\0020\0032\006\020\022\032\0020\0032\006\020 \032\0020\037H\026¢\006\004\b!\020\"J/\020#\032\0020\n2\006\020\036\032\0020\0352\006\020\021\032\0020\0032\006\020\022\032\0020\0032\006\020 \032\0020\037H\026¢\006\004\b#\020$J\037\020%\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b%\020&R\"\020\r\032\0020\n8\006@\006X\016¢\006\022\n\004\b\r\020'\032\004\b(\020)\"\004\b*\020+R\"\020\f\032\0020\n8\006@\006X\016¢\006\022\n\004\b\f\020'\032\004\b,\020)\"\004\b-\020+R$\020\t\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\b\t\020.\032\004\b/\0200\"\004\b1\0202R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\020'\032\004\b3\020)\"\004\b4\020+R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\0205\032\004\b6\0207\"\004\b8\0209R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\0205\032\004\b:\0207\"\004\b;\0209R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\0205\032\004\b<\0207\"\004\b=\0209R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\0205\032\004\b>\0207\"\004\b?\0209¨\006@"}, d2 = {"Lnet/integr/rendering/uisystem/Box;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "outlined", "innerIsDisabled", "<init>", "(IIIILjava/lang/String;ZZZ)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/Box;", "Z", "getInnerIsDisabled", "()Z", "setInnerIsDisabled", "(Z)V", "getOutlined", "setOutlined", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "getTextCentered", "setTextCentered", "I", "getXPos", "()I", "setXPos", "(I)V", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*    */ public final class Box implements class_4068, HelixUiElement {
/*    */   private int xPos;
/*    */   private int yPos;
/*    */   private int xSize;
/*    */   private int ySize;
/*    */   @Nullable
/*    */   private String text;
/*    */   private boolean textCentered;
/*    */   private boolean outlined;
/*    */   private boolean innerIsDisabled;
/*    */   
/*    */   public Box(int xPos, int yPos, int xSize, int ySize, @Nullable String text, boolean textCentered, boolean outlined, boolean innerIsDisabled) {
/* 28 */     this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.outlined = outlined; this.innerIsDisabled = innerIsDisabled; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @Nullable public final String getText() { return this.text; } public final void setText(@Nullable String <set-?>) { this.text = <set-?>; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } public final boolean getOutlined() { return this.outlined; } public final void setOutlined(boolean <set-?>) { this.outlined = <set-?>; } public final boolean getInnerIsDisabled() { return this.innerIsDisabled; } public final void setInnerIsDisabled(boolean <set-?>) { this.innerIsDisabled = <set-?>; }
/*    */    public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/* 30 */     Intrinsics.checkNotNullParameter(context, "context"); int color = Variables.Companion.getGuiBack();
/* 31 */     int textColor = Variables.Companion.getGuiColor();
/* 32 */     int x1 = this.xPos;
/* 33 */     int x2 = this.xPos + this.xSize;
/* 34 */     int y1 = this.yPos;
/* 35 */     int y2 = this.yPos + this.ySize;
/*    */     
/* 37 */     if (this.outlined)
/* 38 */     { if (this.innerIsDisabled)
/* 39 */       { RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, x1, y1, x2, y2, Variables.Companion.getGuiDisabled(), textColor, context, 0.1F, 9.0F, false, 512, null); }
/* 40 */       else { RenderingEngine.TwoDimensional.Companion.fillRound$default(RenderingEngine.TwoDimensional.Companion, x1, y1, x2, y2, color, textColor, context, 0.1F, 9.0F, false, 512, null); }
/*    */        }
/* 42 */     else { RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, color, context, 0.1F, 9.0F); }
/*    */ 
/*    */     
/* 45 */     if (this.text != null) {
/* 46 */       if (this.textCentered) {
/* 47 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, textColor);
/*    */       }
/* 49 */       else if (this.outlined) {
/* 50 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 7, y1 + this.ySize / 2 - 4, textColor);
/*    */       } else {
/* 52 */         Intrinsics.checkNotNull(this.text); RenderingEngine.Text.Companion.draw(context, this.text, x1 + 2, y1 + this.ySize / 2 - 4, textColor);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/* 60 */     Intrinsics.checkNotNullParameter(context, "context"); return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClick(double mouseX, double mouseY, int button) {}
/*    */ 
/*    */   
/*    */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/* 69 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRelease(double mouseX, double mouseY, int button) {}
/*    */   
/*    */   @NotNull
/*    */   public Box update(int xPos, int yPos) {
/* 77 */     this.xPos = xPos;
/* 78 */     this.yPos = yPos;
/*    */     
/* 80 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\Box.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */