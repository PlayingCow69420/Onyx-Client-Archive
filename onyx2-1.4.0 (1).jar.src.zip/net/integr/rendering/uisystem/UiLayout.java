/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Pair;
/*     */ import kotlin.TuplesKt;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Reflection;
/*     */ import kotlin.reflect.KClass;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000J\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\002\n\000\n\002\020\013\n\002\b\005\n\002\030\002\n\002\b\004\n\002\020\006\n\002\b\002\n\002\020\b\n\002\b\016\n\002\020%\n\002\030\002\n\002\030\002\n\002\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\025\020\006\032\0020\0042\006\020\005\032\0020\004¢\006\004\b\006\020\007J\r\020\t\032\0020\b¢\006\004\b\t\020\003J\025\020\013\032\0020\n2\006\020\005\032\0020\004¢\006\004\b\013\020\fJ\025\020\r\032\0020\n2\006\020\005\032\0020\004¢\006\004\b\r\020\fJ\025\020\016\032\0020\b2\006\020\005\032\0020\004¢\006\004\b\016\020\017J\031\020\022\032\0020\b2\n\020\021\032\006\022\002\b\0030\020¢\006\004\b\022\020\023J\025\020\024\032\0020\b2\006\020\005\032\0020\004¢\006\004\b\024\020\017J%\020\032\032\0020\b2\006\020\026\032\0020\0252\006\020\027\032\0020\0252\006\020\031\032\0020\030¢\006\004\b\032\020\033J%\020\037\032\0020\n2\006\020\034\032\0020\0302\006\020\035\032\0020\0302\006\020\036\032\0020\030¢\006\004\b\037\020 J%\020!\032\0020\b2\006\020\026\032\0020\0252\006\020\027\032\0020\0252\006\020\031\032\0020\030¢\006\004\b!\020\033J\031\020\"\032\0020\b2\n\020\021\032\006\022\002\b\0030\020¢\006\004\b\"\020\023J\r\020#\032\0020\b¢\006\004\b#\020\003J\025\020$\032\0020\b2\006\020\005\032\0020\004¢\006\004\b$\020\017J\031\020%\032\0020\b2\n\020\021\032\006\022\002\b\0030\020¢\006\004\b%\020\023J\025\020&\032\0020\b2\006\020\005\032\0020\004¢\006\004\b&\020\017R,\020*\032\032\022\004\022\0020\004\022\020\022\016\022\004\022\0020)\022\004\022\0020)0(0'8\002X\004¢\006\006\n\004\b*\020+¨\006,"}, d2 = {"Lnet/integr/rendering/uisystem/UiLayout;", "", "<init>", "()V", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "obj", "add", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "clear", "", "isLocked", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)Z", "isMarked", "lock", "(Lnet/integr/rendering/uisystem/base/HelixUiElement;)V", "Lkotlin/reflect/KClass;", "klass", "lockAll", "(Lkotlin/reflect/KClass;)V", "mark", "", "mouseX", "mouseY", "", "button", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "removeAll", "resetCursor", "unLock", "unLockAll", "unMark", "", "Lkotlin/Pair;", "Ljava/util/concurrent/atomic/AtomicBoolean;", "l", "Ljava/util/Map;", "onyx2"})
/*     */ public final class UiLayout
/*     */ {
/*     */   @NotNull
/*  28 */   private final Map<HelixUiElement, Pair<AtomicBoolean, AtomicBoolean>> l = new LinkedHashMap<>();
/*     */   @NotNull
/*     */   public final HelixUiElement add(@NotNull HelixUiElement obj) {
/*  31 */     Intrinsics.checkNotNullParameter(obj, "obj"); this.l.put(obj, TuplesKt.to(new AtomicBoolean(false), new AtomicBoolean(false)));
/*     */     
/*  33 */     return obj;
/*     */   }
/*     */   
/*     */   public final void clear() {
/*  37 */     this.l.clear();
/*     */   }
/*     */   
/*     */   public final boolean isLocked(@NotNull HelixUiElement obj) {
/*  41 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNull(this.l.get(obj)); return ((AtomicBoolean)this.l.get(obj).getFirst()).get();
/*     */   }
/*     */   
/*     */   public final boolean isMarked(@NotNull HelixUiElement obj) {
/*  45 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNull(this.l.get(obj)); return ((AtomicBoolean)this.l.get(obj).getSecond()).get();
/*     */   }
/*     */   
/*     */   public final void onClick(double mouseX, double mouseY, int button) {
/*  49 */     for (Map.Entry<HelixUiElement, Pair<AtomicBoolean, AtomicBoolean>> entry : this.l.entrySet()) { HelixUiElement e = (HelixUiElement)entry.getKey(); Pair lo = (Pair)entry.getValue();
/*  50 */       if (!((AtomicBoolean)lo.getFirst()).get())
/*  51 */         e.onClick(mouseX, mouseY, button);  }
/*     */   
/*     */   }
/*     */   
/*     */   public final void onRelease(double mouseX, double mouseY, int button) {
/*  56 */     for (Map.Entry<HelixUiElement, Pair<AtomicBoolean, AtomicBoolean>> entry : this.l.entrySet()) { HelixUiElement e = (HelixUiElement)entry.getKey(); Pair lo = (Pair)entry.getValue();
/*  57 */       if (!((AtomicBoolean)lo.getFirst()).get())
/*  58 */         e.onRelease(mouseX, mouseY, button);  }
/*     */   
/*     */   }
/*     */   
/*     */   public final boolean onKey(int keyCode, int scanCode, int modifiers) {
/*  63 */     for (Map.Entry<HelixUiElement, Pair<AtomicBoolean, AtomicBoolean>> entry : this.l.entrySet()) { HelixUiElement e = (HelixUiElement)entry.getKey(); Pair lo = (Pair)entry.getValue();
/*  64 */       if (!((AtomicBoolean)lo.getFirst()).get() && 
/*  65 */         e.onKey(keyCode, scanCode, modifiers)) return true;
/*     */        }
/*     */     
/*  68 */     return false;
/*     */   }
/*     */   
/*     */   public final void removeAll(@NotNull KClass klass) {
/*  72 */     Intrinsics.checkNotNullParameter(klass, "klass"); for (HelixUiElement e : this.l.keySet()) {
/*  73 */       if (Intrinsics.areEqual(Reflection.getOrCreateKotlinClass(e.getClass()), klass)) this.l.remove(e); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void lock(@NotNull HelixUiElement obj) {
/*  78 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNull(this.l.get(obj)); ((AtomicBoolean)this.l.get(obj).getFirst()).set(true);
/*     */   }
/*     */   
/*     */   public final void unLock(@NotNull HelixUiElement obj) {
/*  82 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNull(this.l.get(obj)); ((AtomicBoolean)this.l.get(obj).getFirst()).set(false);
/*     */   }
/*     */   
/*     */   public final void mark(@NotNull HelixUiElement obj) {
/*  86 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNull(this.l.get(obj)); ((AtomicBoolean)this.l.get(obj).getSecond()).set(true);
/*     */   }
/*     */   
/*     */   public final void unMark(@NotNull HelixUiElement obj) {
/*  90 */     Intrinsics.checkNotNullParameter(obj, "obj"); Intrinsics.checkNotNull(this.l.get(obj)); ((AtomicBoolean)this.l.get(obj).getSecond()).set(false);
/*     */   }
/*     */   
/*     */   public final void lockAll(@NotNull KClass klass) {
/*  94 */     Intrinsics.checkNotNullParameter(klass, "klass"); for (HelixUiElement e : this.l.keySet()) {
/*  95 */       if (Intrinsics.areEqual(Reflection.getOrCreateKotlinClass(this.l.getClass()), klass)) lock(e); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public final void unLockAll(@NotNull KClass klass) {
/* 100 */     Intrinsics.checkNotNullParameter(klass, "klass"); for (HelixUiElement e : this.l.keySet()) {
/* 101 */       if (Intrinsics.areEqual(Reflection.getOrCreateKotlinClass(this.l.getClass()), klass)) unLock(e);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void resetCursor() {
/* 108 */     GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221185));
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\UiLayout.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */