/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import java.util.List;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000H\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\002\n\002\020!\n\002\b\003\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\b\n\002\030\002\n\000\n\002\020\007\n\002\b(\030\0002\0020\0012\0020\002BM\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\t\032\0020\b\022\006\020\013\032\0020\n\022\006\020\f\032\0020\b\022\f\020\016\032\b\022\004\022\0020\b0\r¢\006\004\b\017\020\020J'\020\026\032\0020\0252\006\020\022\032\0020\0212\006\020\023\032\0020\0212\006\020\024\032\0020\003H\026¢\006\004\b\026\020\027J'\020\033\032\0020\n2\006\020\030\032\0020\0032\006\020\031\032\0020\0032\006\020\032\032\0020\003H\026¢\006\004\b\033\020\034J'\020\035\032\0020\0252\006\020\022\032\0020\0212\006\020\023\032\0020\0212\006\020\024\032\0020\003H\026¢\006\004\b\035\020\027J/\020\"\032\0020\0252\006\020\037\032\0020\0362\006\020\022\032\0020\0032\006\020\023\032\0020\0032\006\020!\032\0020 H\026¢\006\004\b\"\020#J/\020$\032\0020\n2\006\020\037\032\0020\0362\006\020\022\032\0020\0032\006\020\023\032\0020\0032\006\020!\032\0020 H\026¢\006\004\b$\020%J\037\020&\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b&\020'R\"\020(\032\0020\0038\006@\006X\016¢\006\022\n\004\b(\020)\032\004\b*\020+\"\004\b,\020-R\035\020\016\032\b\022\004\022\0020\b0\r8\006¢\006\f\n\004\b\016\020.\032\004\b/\0200R\"\020\t\032\0020\b8\006@\006X\016¢\006\022\n\004\b\t\0201\032\004\b2\0203\"\004\b4\0205R\"\0206\032\0020\b8\006@\006X\016¢\006\022\n\004\b6\0201\032\004\b7\0203\"\004\b8\0205R\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\0209\032\004\b:\020;\"\004\b<\020=R\"\020\f\032\0020\b8\006@\006X\016¢\006\022\n\004\b\f\0201\032\004\b>\0203\"\004\b?\0205R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\020)\032\004\b@\020+\"\004\bA\020-R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\020)\032\004\bB\020+\"\004\bC\020-R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\020)\032\004\bD\020+\"\004\bE\020-R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\020)\032\004\bF\020+\"\004\bG\020-¨\006H"}, d2 = {"Lnet/integr/rendering/uisystem/Cycler;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "tooltip", "", "items", "<init>", "(IIIILjava/lang/String;ZLjava/lang/String;Ljava/util/List;)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/Cycler;", "currentIndex", "I", "getCurrentIndex", "()I", "setCurrentIndex", "(I)V", "Ljava/util/List;", "getItems", "()Ljava/util/List;", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "text2", "getText2", "setText2", "Z", "getTextCentered", "()Z", "setTextCentered", "(Z)V", "getTooltip", "setTooltip", "getXPos", "setXPos", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class Cycler implements class_4068, HelixUiElement {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @NotNull
/*     */   private String text;
/*     */   private boolean textCentered;
/*     */   @NotNull
/*     */   private String tooltip;
/*     */   @NotNull
/*     */   private final List<String> items;
/*     */   private int currentIndex;
/*     */   @NotNull
/*     */   private String text2;
/*     */   
/*  32 */   public Cycler(int xPos, int yPos, int xSize, int ySize, @NotNull String text, boolean textCentered, @NotNull String tooltip, @NotNull List<String> items) { this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.tooltip = tooltip; this.items = items;
/*     */     
/*  34 */     this.text2 = this.text; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @NotNull public final String getText2() { return this.text2; } @NotNull public final String getText() { return this.text; } public final void setText(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.text = <set-?>; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } @NotNull public final List<String> getItems() { return this.items; } public final int getCurrentIndex() { return this.currentIndex; } public final void setCurrentIndex(int <set-?>) { this.currentIndex = <set-?>; } public final void setText2(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.text2 = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  37 */     Intrinsics.checkNotNullParameter(context, "context"); int color = Variables.Companion.getGuiColor();
/*  38 */     int textColor = Variables.Companion.getGuiBack();
/*  39 */     int x1 = this.xPos;
/*  40 */     int x2 = this.xPos + this.xSize;
/*  41 */     int y1 = this.yPos;
/*  42 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  44 */     RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, color, context, 0.1F, 9.0F);
/*     */     
/*  46 */     if (this.textCentered) {
/*  47 */       RenderingEngine.Text.Companion.draw(context, this.text2, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text2) / 2 - 4, y1 + this.ySize / 2 - 4, textColor);
/*     */     } else {
/*  49 */       RenderingEngine.Text.Companion.draw(context, this.text2, x1 + 2, y1 + this.ySize / 2 - 4, textColor);
/*     */     } 
/*     */     
/*  52 */     RenderingEngine.Text.Companion.draw(context, "→", x1 + this.xSize - 15, y1 + this.ySize / 2 - 4, textColor);
/*     */   }
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  56 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/*  57 */     int x2 = this.xPos + this.xSize;
/*  58 */     int y1 = this.yPos;
/*  59 */     int y2 = this.yPos + this.ySize;
/*     */ 
/*     */     
/*  62 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  63 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221188));
/*     */       
/*  65 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/*  66 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*     */       
/*  68 */       explainingBox.setXPos(mouseX + 10);
/*  69 */       explainingBox.setYPos(mouseY);
/*  70 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*     */       
/*  72 */       return true;
/*     */     } 
/*     */     
/*  75 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/*  79 */     if (button == 0) {
/*  80 */       int x1 = this.xPos;
/*  81 */       int x2 = this.xPos + this.xSize;
/*  82 */       int y1 = this.yPos;
/*  83 */       int y2 = this.yPos + this.ySize;
/*     */ 
/*     */       
/*  86 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/*  87 */         if (this.currentIndex == this.items.size() - 1) { this.currentIndex = 0; } else { i = this.currentIndex; this.currentIndex = i + 1; }
/*  88 */          this.text2 = this.text + this.text;
/*  89 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {}
/*     */   
/*     */   @NotNull
/*     */   public Cycler update(int xPos, int yPos) {
/* 104 */     this.xPos = xPos;
/* 105 */     this.yPos = yPos;
/*     */     
/* 107 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\Cycler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */