/*    */ package net.integr.rendering.uisystem.util;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*    */ import net.minecraft.class_3532;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/uisystem/util/RenderLerper;", "", "<init>", "()V", "Companion", "onyx2"})
/*    */ public final class RenderLerper
/*    */ {
/*    */   @NotNull
/*    */   public static final Companion Companion = new Companion(null);
/*    */   
/*    */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\006\n\002\b\004\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\007\032\0020\0042\006\020\005\032\0020\0042\006\020\006\032\0020\004¢\006\004\b\007\020\bJ\035\020\007\032\0020\t2\006\020\005\032\0020\t2\006\020\006\032\0020\t¢\006\004\b\007\020\n¨\006\013"}, d2 = {"Lnet/integr/rendering/uisystem/util/RenderLerper$Companion;", "", "<init>", "()V", "", "old", "new", "lerpWithDefDelta", "(DD)D", "", "(II)I", "onyx2"})
/*    */   public static final class Companion
/*    */   {
/*    */     private Companion() {}
/*    */     
/*    */     public final double lerpWithDefDelta(double old, double new) {
/* 24 */       return class_3532.method_16436(0.5D, old, new);
/*    */     }
/*    */     
/*    */     public final int lerpWithDefDelta(int old, int new) {
/* 28 */       return (int)class_3532.method_16436(0.5D, old, new) + 1;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisyste\\util\RenderLerper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */