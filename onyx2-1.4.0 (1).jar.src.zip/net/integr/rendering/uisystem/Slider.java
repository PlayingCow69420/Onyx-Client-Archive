/*     */ package net.integr.rendering.uisystem;
/*     */ 
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Variables;
/*     */ import net.integr.rendering.RenderingEngine;
/*     */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*     */ import net.integr.rendering.uisystem.util.RenderLerper;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4068;
/*     */ import net.minecraft.class_6880;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000@\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\002\n\002\020\006\n\002\b\007\n\002\020\002\n\002\b\b\n\002\030\002\n\000\n\002\020\007\n\002\b4\030\0002\0020\0012\0020\002BS\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\n\b\001\020\t\032\004\030\0010\b\022\006\020\013\032\0020\n\022\006\020\f\032\0020\b\022\006\020\016\032\0020\r\022\006\020\017\032\0020\r¢\006\004\b\020\020\021J'\020\026\032\0020\0252\006\020\022\032\0020\r2\006\020\023\032\0020\r2\006\020\024\032\0020\003H\026¢\006\004\b\026\020\027J'\020\033\032\0020\n2\006\020\030\032\0020\0032\006\020\031\032\0020\0032\006\020\032\032\0020\003H\026¢\006\004\b\033\020\034J'\020\035\032\0020\0252\006\020\022\032\0020\r2\006\020\023\032\0020\r2\006\020\024\032\0020\003H\026¢\006\004\b\035\020\027J/\020\"\032\0020\0252\006\020\037\032\0020\0362\006\020\022\032\0020\0032\006\020\023\032\0020\0032\006\020!\032\0020 H\026¢\006\004\b\"\020#J/\020$\032\0020\n2\006\020\037\032\0020\0362\006\020\022\032\0020\0032\006\020\023\032\0020\0032\006\020!\032\0020 H\026¢\006\004\b$\020%J\025\020'\032\0020\0252\006\020&\032\0020\r¢\006\004\b'\020(J\037\020)\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b)\020*J\r\020+\032\0020\r¢\006\004\b+\020,J\025\020-\032\0020\0032\006\020&\032\0020\r¢\006\004\b-\020.R\026\020/\032\0020\n8\002@\002X\016¢\006\006\n\004\b/\0200R\"\0201\032\0020\0038\006@\006X\016¢\006\022\n\004\b1\0202\032\004\b3\0204\"\004\b5\0206R\"\020\017\032\0020\r8\006@\006X\016¢\006\022\n\004\b\017\0207\032\004\b8\020,\"\004\b9\020(R\027\020\016\032\0020\r8\006¢\006\f\n\004\b\016\0207\032\004\b:\020,R\"\020;\032\0020\0038\006@\006X\016¢\006\022\n\004\b;\0202\032\004\b<\0204\"\004\b=\0206R$\020\t\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\b\t\020>\032\004\b?\020@\"\004\bA\020BR$\020C\032\004\030\0010\b8\006@\006X\016¢\006\022\n\004\bC\020>\032\004\bD\020@\"\004\bE\020BR\"\020\013\032\0020\n8\006@\006X\016¢\006\022\n\004\b\013\0200\032\004\bF\020G\"\004\bH\020IR\"\020\f\032\0020\b8\006@\006X\016¢\006\022\n\004\b\f\020>\032\004\bJ\020@\"\004\bK\020BR\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\0202\032\004\bL\0204\"\004\bM\0206R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\0202\032\004\bN\0204\"\004\bO\0206R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\0202\032\004\bP\0204\"\004\bQ\0206R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\0202\032\004\bR\0204\"\004\bS\0206¨\006T"}, d2 = {"Lnet/integr/rendering/uisystem/Slider;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "", "textCentered", "tooltip", "", "min", "max", "<init>", "(IIIILjava/lang/String;ZLjava/lang/String;DD)V", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "value", "setValue", "(D)V", "update", "(II)Lnet/integr/rendering/uisystem/Slider;", "valueFromFillX", "()D", "xFillFromValue", "(D)I", "dragging", "Z", "fillX", "I", "getFillX", "()I", "setFillX", "(I)V", "D", "getMax", "setMax", "getMin", "oldFill", "getOldFill", "setOldFill", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "text2", "getText2", "setText2", "getTextCentered", "()Z", "setTextCentered", "(Z)V", "getTooltip", "setTooltip", "getXPos", "setXPos", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*     */ public final class Slider implements class_4068, HelixUiElement {
/*     */   private int xPos;
/*     */   private int yPos;
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   @Nullable
/*     */   private String text;
/*     */   private boolean textCentered;
/*     */   @NotNull
/*     */   private String tooltip;
/*     */   private final double min;
/*     */   private double max;
/*     */   private boolean dragging;
/*     */   private int fillX;
/*     */   @Nullable
/*     */   private String text2;
/*     */   private int oldFill;
/*     */   
/*  37 */   public Slider(int xPos, int yPos, int xSize, int ySize, @Nullable String text, boolean textCentered, @NotNull String tooltip, double min, double max) { this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.textCentered = textCentered; this.tooltip = tooltip; this.min = min; this.max = max;
/*     */ 
/*     */     
/*  40 */     this.text2 = this.text;
/*     */     
/*  42 */     this.oldFill = this.fillX; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @Nullable public final String getText() { return this.text; } public final void setText(@Nullable String <set-?>) { this.text = <set-?>; } public final int getOldFill() { return this.oldFill; } public final boolean getTextCentered() { return this.textCentered; } public final void setTextCentered(boolean <set-?>) { this.textCentered = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } public final double getMin() { return this.min; } public final double getMax() { return this.max; } public final void setMax(double <set-?>) { this.max = <set-?>; } public final int getFillX() { return this.fillX; } public final void setFillX(int <set-?>) { this.fillX = <set-?>; } @Nullable public final String getText2() { return this.text2; } public final void setText2(@Nullable String <set-?>) { this.text2 = <set-?>; } public final void setOldFill(int <set-?>) { this.oldFill = <set-?>; }
/*     */   
/*     */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/*  45 */     Intrinsics.checkNotNullParameter(context, "context"); int color = Variables.Companion.getGuiColor();
/*  46 */     int textColor = Variables.Companion.getGuiBack();
/*  47 */     int disabledColor = Variables.Companion.getGuiDisabled();
/*  48 */     int x1 = this.xPos;
/*  49 */     int x2 = this.xPos + this.xSize;
/*  50 */     int y1 = this.yPos;
/*  51 */     int y2 = this.yPos + this.ySize;
/*     */     
/*  53 */     if (this.dragging) {
/*  54 */       this.fillX = mouseX - x1;
/*  55 */       this.text2 = this.text + this.text;
/*     */     } 
/*     */     
/*  58 */     int lerpedFill = RenderLerper.Companion.lerpWithDefDelta(this.oldFill, this.fillX);
/*  59 */     this.oldFill = lerpedFill;
/*     */     
/*  61 */     RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, x2, y2, disabledColor, context, 0.1F, 9.0F);
/*  62 */     boolean shouldNotShow = (((ExtensionsKt.round(valueFromFillX(), 1) == 0.0D)) && ((this.min == 0.0D)));
/*  63 */     if (!shouldNotShow) RenderingEngine.TwoDimensional.Companion.fillRoundNoOutline(x1, y1, class_3532.method_15340(x1 + lerpedFill, x1 + 20, x2), y2, color, context, 0.1F, 9.0F);
/*     */     
/*  65 */     if (this.text != null) {
/*  66 */       if (this.textCentered) {
/*  67 */         Intrinsics.checkNotNull(this.text2); RenderingEngine.Text.Companion.draw(context, this.text2, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text2) / 2 - 4, y1 + this.ySize / 2 - 4, textColor);
/*     */       } else {
/*  69 */         Intrinsics.checkNotNull(this.text2); RenderingEngine.Text.Companion.draw(context, this.text2, x1 + 2, y1 + this.ySize / 2 - 4, textColor);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public final void setValue(double value) {
/*  75 */     this.fillX = xFillFromValue(value);
/*  76 */     this.text2 = this.text + this.text;
/*     */   }
/*     */   
/*     */   public final double valueFromFillX() {
/*  80 */     double lowerBound = this.min;
/*  81 */     double upperBound = this.max;
/*     */     
/*  83 */     int sectionCount = this.xSize;
/*     */     
/*  85 */     double valueRange = upperBound - lowerBound;
/*     */     
/*  87 */     double sectionValue = valueRange / sectionCount;
/*     */     
/*  89 */     return class_3532.method_15350(this.fillX * sectionValue + this.min, this.min, this.max);
/*     */   }
/*     */   
/*     */   public final int xFillFromValue(double value) {
/*  93 */     double lowerBound = this.min;
/*  94 */     double upperBound = this.max;
/*     */     
/*  96 */     int sectionCount = this.xSize;
/*     */     
/*  98 */     double valueRange = upperBound - lowerBound;
/*     */     
/* 100 */     double sectionValue = valueRange / sectionCount;
/*     */     
/* 102 */     if ((sectionValue == 0.0D)) return 0;
/*     */     
/* 104 */     return (int)((value - this.min) / sectionValue);
/*     */   }
/*     */   
/*     */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/* 108 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/* 109 */     int x2 = this.xPos + this.xSize;
/* 110 */     int y1 = this.yPos;
/* 111 */     int y2 = this.yPos + this.ySize;
/*     */ 
/*     */     
/* 114 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 115 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221189));
/*     */       
/* 117 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/* 118 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*     */       
/* 120 */       explainingBox.setXPos(mouseX + 10);
/* 121 */       explainingBox.setYPos(mouseY);
/* 122 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*     */       
/* 124 */       return true;
/*     */     } 
/*     */     
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public void onClick(double mouseX, double mouseY, int button) {
/* 131 */     if (button == 0) {
/* 132 */       int x1 = this.xPos;
/* 133 */       int x2 = this.xPos + this.xSize;
/* 134 */       int y1 = this.yPos;
/* 135 */       int y2 = this.yPos + this.ySize;
/*     */ 
/*     */       
/* 138 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 139 */         this.dragging = true;
/* 140 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onRelease(double mouseX, double mouseY, int button) {
/* 146 */     if (button == 0 && 
/* 147 */       this.dragging) {
/* 148 */       this.dragging = false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/* 155 */     return false;
/*     */   }
/*     */   @NotNull
/*     */   public Slider update(int xPos, int yPos) {
/* 159 */     this.xPos = xPos;
/* 160 */     this.yPos = yPos;
/*     */     
/* 162 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\Slider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */