/*    */ package net.integr.rendering.uisystem;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import net.integr.Onyx;
/*    */ import net.integr.Variables;
/*    */ import net.integr.rendering.RenderingEngine;
/*    */ import net.integr.rendering.uisystem.base.HelixUiElement;
/*    */ import net.minecraft.class_1109;
/*    */ import net.minecraft.class_1113;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_3417;
/*    */ import net.minecraft.class_4068;
/*    */ import net.minecraft.class_6880;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.lwjgl.glfw.GLFW;
/*    */ 
/*    */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000N\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\004\n\002\020\016\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\006\n\002\b\003\n\002\020\002\n\002\b\005\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\002\b\035\030\0002\0020\0012\0020\002BC\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\t\032\0020\b\022\006\020\n\032\0020\b\022\n\020\r\032\0060\013j\002`\f¢\006\004\b\016\020\017J'\020\025\032\0020\0242\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\023\032\0020\003H\026¢\006\004\b\025\020\026J'\020\033\032\0020\0322\006\020\027\032\0020\0032\006\020\030\032\0020\0032\006\020\031\032\0020\003H\026¢\006\004\b\033\020\034J'\020\035\032\0020\0242\006\020\021\032\0020\0202\006\020\022\032\0020\0202\006\020\023\032\0020\003H\026¢\006\004\b\035\020\026J/\020\"\032\0020\0242\006\020\037\032\0020\0362\006\020\021\032\0020\0032\006\020\022\032\0020\0032\006\020!\032\0020 H\026¢\006\004\b\"\020#J/\020$\032\0020\0322\006\020\037\032\0020\0362\006\020\021\032\0020\0032\006\020\022\032\0020\0032\006\020!\032\0020 H\026¢\006\004\b$\020%J\037\020&\032\0020\0002\006\020\004\032\0020\0032\006\020\005\032\0020\003H\026¢\006\004\b&\020'R\033\020\r\032\0060\013j\002`\f8\006¢\006\f\n\004\b\r\020(\032\004\b)\020*R\"\020\t\032\0020\b8\006@\006X\016¢\006\022\n\004\b\t\020+\032\004\b,\020-\"\004\b.\020/R\"\020\n\032\0020\b8\006@\006X\016¢\006\022\n\004\b\n\020+\032\004\b0\020-\"\004\b1\020/R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b\004\0202\032\004\b3\0204\"\004\b5\0206R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b\006\0202\032\004\b7\0204\"\004\b8\0206R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b\005\0202\032\004\b9\0204\"\004\b:\0206R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b\007\0202\032\004\b;\0204\"\004\b<\0206¨\006="}, d2 = {"Lnet/integr/rendering/uisystem/IconButton;", "Lnet/minecraft/class_4068;", "Lnet/integr/rendering/uisystem/base/HelixUiElement;", "", "xPos", "yPos", "xSize", "ySize", "", "text", "tooltip", "Ljava/lang/Runnable;", "Lkotlinx/coroutines/Runnable;", "action", "<init>", "(IIIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V", "", "mouseX", "mouseY", "button", "", "onClick", "(DDI)V", "keyCode", "scanCode", "modifiers", "", "onKey", "(III)Z", "onRelease", "Lnet/minecraft/class_332;", "context", "", "delta", "render", "(Lnet/minecraft/class_332;IIF)V", "renderTooltip", "(Lnet/minecraft/class_332;IIF)Z", "update", "(II)Lnet/integr/rendering/uisystem/IconButton;", "Ljava/lang/Runnable;", "getAction", "()Ljava/lang/Runnable;", "Ljava/lang/String;", "getText", "()Ljava/lang/String;", "setText", "(Ljava/lang/String;)V", "getTooltip", "setTooltip", "I", "getXPos", "()I", "setXPos", "(I)V", "getXSize", "setXSize", "getYPos", "setYPos", "getYSize", "setYSize", "onyx2"})
/*    */ public final class IconButton
/*    */   implements class_4068, HelixUiElement {
/*    */   private int xPos;
/*    */   private int yPos;
/*    */   private int xSize;
/*    */   private int ySize;
/*    */   @NotNull
/*    */   private String text;
/*    */   @NotNull
/*    */   private String tooltip;
/*    */   @NotNull
/*    */   private final Runnable action;
/*    */   
/*    */   public IconButton(int xPos, int yPos, int xSize, int ySize, @NotNull String text, @NotNull String tooltip, @NotNull Runnable action) {
/* 33 */     this.xPos = xPos; this.yPos = yPos; this.xSize = xSize; this.ySize = ySize; this.text = text; this.tooltip = tooltip; this.action = action; } public final int getXPos() { return this.xPos; } public final void setXPos(int <set-?>) { this.xPos = <set-?>; } public final int getYPos() { return this.yPos; } public final void setYPos(int <set-?>) { this.yPos = <set-?>; } public final int getXSize() { return this.xSize; } public final void setXSize(int <set-?>) { this.xSize = <set-?>; } public final int getYSize() { return this.ySize; } public final void setYSize(int <set-?>) { this.ySize = <set-?>; } @NotNull public final String getText() { return this.text; } public final void setText(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.text = <set-?>; } @NotNull public final String getTooltip() { return this.tooltip; } public final void setTooltip(@NotNull String <set-?>) { Intrinsics.checkNotNullParameter(<set-?>, "<set-?>"); this.tooltip = <set-?>; } @NotNull public final Runnable getAction() { return this.action; }
/*    */   
/*    */   public void method_25394(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/* 36 */     Intrinsics.checkNotNullParameter(context, "context"); int colorEnabled = Variables.Companion.getGuiColor();
/*    */     
/* 38 */     int x1 = this.xPos;
/* 39 */     int y1 = this.yPos;
/*    */     
/* 41 */     RenderingEngine.Text.Companion.draw(context, this.text, x1 + this.xSize / 2 - (Onyx.Companion.getMC()).field_1772.method_1727(this.text) / 2 - 4, y1 + this.ySize / 2 - 4, colorEnabled);
/*    */   }
/*    */   
/*    */   public boolean renderTooltip(@NotNull class_332 context, int mouseX, int mouseY, float delta) {
/* 45 */     Intrinsics.checkNotNullParameter(context, "context"); int x1 = this.xPos;
/* 46 */     int x2 = this.xPos + this.xSize;
/* 47 */     int y1 = this.yPos;
/* 48 */     int y2 = this.yPos + this.ySize;
/*    */ 
/*    */     
/* 51 */     if (((x1 + 1 <= mouseX) ? ((mouseX < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 52 */       GLFW.glfwSetCursor(Onyx.Companion.getMC().method_22683().method_4490(), GLFW.glfwCreateStandardCursor(221188));
/*    */       
/* 54 */       int explainXSize = (Onyx.Companion.getMC()).field_1772.method_1727(this.tooltip) + 30;
/* 55 */       Box explainingBox = new Box(this.xPos, this.yPos, explainXSize, this.ySize, this.tooltip, true, false, false, 192, null);
/*    */       
/* 57 */       explainingBox.setXPos(mouseX + 10);
/* 58 */       explainingBox.setYPos(mouseY);
/* 59 */       explainingBox.method_25394(context, mouseX, mouseY, delta);
/*    */       
/* 61 */       return true;
/*    */     } 
/*    */     
/* 64 */     return false;
/*    */   }
/*    */   
/*    */   public void onClick(double mouseX, double mouseY, int button) {
/* 68 */     if (button == 0) {
/* 69 */       int x1 = this.xPos;
/* 70 */       int x2 = this.xPos + this.xSize;
/* 71 */       int y1 = this.yPos;
/* 72 */       int y2 = this.yPos + this.ySize;
/*    */ 
/*    */       
/* 75 */       int i = x1 + 1, j = (int)mouseX; if (((i <= j) ? ((j < x2)) : false) && mouseY > y1 && mouseY < y2) {
/* 76 */         this.action.run();
/* 77 */         Onyx.Companion.getMC().method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0F));
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onRelease(double mouseX, double mouseY, int button) {}
/*    */ 
/*    */   
/*    */   public boolean onKey(int keyCode, int scanCode, int modifiers) {
/* 88 */     return false;
/*    */   }
/*    */   @NotNull
/*    */   public IconButton update(int xPos, int yPos) {
/* 92 */     this.xPos = xPos;
/* 93 */     this.yPos = yPos;
/*    */     
/* 95 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\renderin\\uisystem\IconButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */