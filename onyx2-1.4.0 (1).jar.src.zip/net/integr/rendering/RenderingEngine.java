/*     */ package net.integr.rendering;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Settings;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import net.integr.utilities.game.CoordinateUtils;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_4588;
/*     */ import net.minecraft.class_5253;
/*     */ import net.minecraft.class_5944;
/*     */ import net.minecraft.class_757;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\007\030\0002\0020\001:\004\004\005\006\007B\007¢\006\004\b\002\020\003¨\006\b"}, d2 = {"Lnet/integr/rendering/RenderingEngine;", "", "<init>", "()V", "Misc", "Text", "ThreeDimensional", "TwoDimensional", "onyx2"})
/*     */ public final class RenderingEngine {
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/RenderingEngine$ThreeDimensional;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */   public static final class ThreeDimensional { @NotNull
/*     */     public static final Companion Companion = new Companion(null);
/*     */     
/*     */     @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000Z\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\006\n\002\b\002\n\002\020\007\n\000\n\002\020\013\n\002\b\b\n\002\030\002\n\002\030\002\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J'\020\n\032\0020\t2\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\b\032\0020\006H\002¢\006\004\b\n\020\013J-\020\r\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b\r\020\021J%\020\r\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b\r\020\022J'\020\026\032\0020\t2\006\020\023\032\0020\f2\006\020\005\032\0020\0042\006\020\025\032\0020\024H\002¢\006\004\b\026\020\027J'\020\030\032\0020\t2\006\020\023\032\0020\f2\006\020\005\032\0020\0042\006\020\025\032\0020\024H\002¢\006\004\b\030\020\027JE\020!\032\0020\t2\006\020\031\032\0020\0162\006\020\033\032\0020\0322\006\020\034\032\0020\0322\006\020\036\032\0020\0352\006\020 \032\0020\0372\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b!\020\"J%\020#\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b#\020\022J-\020&\032\0020\t2\006\020$\032\0020\0162\006\020%\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b&\020'J5\020+\032\0020\t2\026\020*\032\022\022\004\022\0020\0160(j\b\022\004\022\0020\016`)2\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b+\020,J-\020-\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b-\020\021J%\020-\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b-\020\022J-\020.\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b.\020\021J%\020.\032\0020\t2\006\020\017\032\0020\0162\006\020\005\032\0020\0042\006\020\020\032\0020\006¢\006\004\b.\020\022¨\006/"}, d2 = {"Lnet/integr/rendering/RenderingEngine$ThreeDimensional$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_4587;", "matrixStack", "", "regionX", "regionZ", "", "applyRegionalRenderOffset", "(Lnet/minecraft/class_4587;II)V", "Lnet/minecraft/class_238;", "box", "Lnet/minecraft/class_243;", "block", "color", "(Lnet/minecraft/class_238;Lnet/minecraft/class_243;Lnet/minecraft/class_4587;I)V", "(Lnet/minecraft/class_243;Lnet/minecraft/class_4587;I)V", "bb", "Lnet/minecraft/class_287;", "bufferBuilder", "boxFill", "(Lnet/minecraft/class_238;Lnet/minecraft/class_4587;Lnet/minecraft/class_287;)V", "boxLines", "position", "", "precision", "radius", "", "offsetMid", "", "fill", "circle", "(Lnet/minecraft/class_243;DDFZLnet/minecraft/class_4587;I)V", "floorQuad", "position1", "position2", "line", "(Lnet/minecraft/class_243;Lnet/minecraft/class_243;Lnet/minecraft/class_4587;I)V", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "blocks", "multiBlock", "(Ljava/util/ArrayList;Lnet/minecraft/class_4587;I)V", "outlinedBox", "sideBox", "onyx2"})
/*     */     public static final class Companion { private Companion() {}
/*     */       
/*  41 */       public final void circle(@NotNull class_243 position, double precision, double radius, float offsetMid, boolean fill, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(position, "position"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); class_243 pos = position;
/*  42 */         GL11.glEnable(3042);
/*  43 */         GL11.glBlendFunc(770, 771);
/*  44 */         GL11.glEnable(2884);
/*  45 */         GL11.glDisable(2929);
/*  46 */         RenderSystem.setShader(Companion::circle$lambda$0);
/*  47 */         matrixStack.method_22903();
/*  48 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/*  49 */         int regionX = camPos.method_10263();
/*  50 */         int regionZ = camPos.method_10260();
/*     */         
/*  52 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/*  53 */         Intrinsics.checkNotNullExpressionValue(pos.method_1023(regionX, 0.0D, regionZ), "subtract(...)"); pos = pos.method_1023(regionX, 0.0D, regionZ);
/*     */         
/*  55 */         RenderSystem.setShader(Companion::circle$lambda$1);
/*  56 */         Color col = new Color(color);
/*     */         
/*  58 */         RenderSystem.setShaderColor(
/*  59 */             col.getRed() / 255.0F, 
/*  60 */             col.getGreen() / 255.0F, 
/*  61 */             col.getBlue() / 255.0F, 
/*  62 */             0.5F);
/*     */         
/*  64 */         Matrix4f matrix = matrixStack.method_23760().method_23761();
/*  65 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */ 
/*     */         
/*  68 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/*     */         
/*  70 */         double prevX = Math.cos(0.0D) * radius;
/*  71 */         double prevZ = Math.sin(0.0D) * radius;
/*     */         
/*  73 */         double angle = 0.0D;
/*  74 */         while (angle <= 6.283185307179586D) {
/*  75 */           double x = Math.cos(angle) * radius;
/*  76 */           double z = Math.sin(angle) * radius;
/*     */           
/*  78 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/*  79 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)x, (float)pos.method_10214(), (float)pos.method_10215() + (float)z);
/*     */           
/*  81 */           prevX = x;
/*  82 */           prevZ = z;
/*     */           
/*  84 */           angle += precision;
/*     */         } 
/*     */         
/*  87 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)Math.cos(0.0D) * (float)radius, (float)pos.method_10214(), (float)pos.method_10215() + (float)Math.sin(0.0D) * (float)radius);
/*  88 */         bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/*     */         
/*  90 */         if (fill) {
/*  91 */           class_286.method_43433(bufferBuilder.method_60800());
/*     */           
/*  93 */           prevX = Math.cos(0.0D) * radius;
/*  94 */           prevZ = Math.sin(0.0D) * radius;
/*     */           
/*  96 */           GL11.glDisable(2884);
/*     */           
/*  98 */           RenderSystem.setShaderColor(
/*  99 */               col.getRed() / 255.0F, 
/* 100 */               col.getGreen() / 255.0F, 
/* 101 */               col.getBlue() / 255.0F, 
/* 102 */               0.3F);
/*     */ 
/*     */           
/* 105 */           bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27379, class_290.field_1592);
/*     */           
/* 107 */           angle = 0.0D;
/* 108 */           while (angle <= 6.283185307179586D) {
/* 109 */             double x = Math.cos(angle) * radius;
/* 110 */             double z = Math.sin(angle) * radius;
/*     */             
/* 112 */             bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/* 113 */             bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)x, (float)pos.method_10214(), (float)pos.method_10215() + (float)z);
/* 114 */             bufferBuilder.method_22918(matrix, (float)pos.method_10216(), (float)pos.method_10214() + offsetMid, (float)pos.method_10215());
/*     */             
/* 116 */             prevX = x;
/* 117 */             prevZ = z;
/*     */             
/* 119 */             angle += precision;
/*     */           } 
/*     */           
/* 122 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)Math.cos(0.0D) * (float)radius, (float)pos.method_10214(), (float)pos.method_10215() + (float)Math.sin(0.0D) * (float)radius);
/* 123 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216() + (float)prevX, (float)pos.method_10214(), (float)pos.method_10215() + (float)prevZ);
/* 124 */           bufferBuilder.method_22918(matrix, (float)pos.method_10216(), (float)pos.method_10214() + offsetMid, (float)pos.method_10215());
/*     */         } 
/*     */ 
/*     */         
/* 128 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 131 */         matrixStack.method_22909();
/* 132 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 133 */         GL11.glEnable(2929);
/* 134 */         GL11.glDisable(3042);
/* 135 */         GL11.glEnable(2884); }
/*     */       
/*     */       private static final class_5944 circle$lambda$0() {
/*     */         return class_757.method_34539();
/* 139 */       } public final void line(@NotNull class_243 position1, @NotNull class_243 position2, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(position1, "position1"); Intrinsics.checkNotNullParameter(position2, "position2"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); class_243 pos1 = position1;
/* 140 */         class_243 pos2 = position2;
/*     */         
/* 142 */         GL11.glEnable(3042);
/* 143 */         GL11.glBlendFunc(770, 771);
/* 144 */         GL11.glEnable(2884);
/* 145 */         GL11.glDisable(2929);
/*     */         
/* 147 */         RenderSystem.setShader(Companion::line$lambda$2);
/* 148 */         matrixStack.method_22903();
/*     */         
/* 150 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 151 */         int regionX = camPos.method_10263();
/* 152 */         int regionZ = camPos.method_10260();
/*     */         
/* 154 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 155 */         Intrinsics.checkNotNullExpressionValue(pos1.method_1023(regionX, 0.0D, regionZ), "subtract(...)"); pos1 = pos1.method_1023(regionX, 0.0D, regionZ);
/* 156 */         Intrinsics.checkNotNullExpressionValue(pos2.method_1023(regionX, 0.0D, regionZ), "subtract(...)"); pos2 = pos2.method_1023(regionX, 0.0D, regionZ);
/*     */         
/* 158 */         Color col = new Color(color);
/* 159 */         RenderSystem.setShaderColor(
/* 160 */             col.getRed() / 255.0F, 
/* 161 */             col.getGreen() / 255.0F, 
/* 162 */             col.getBlue() / 255.0F, 
/* 163 */             1.0F);
/*     */         
/* 165 */         Matrix4f matrix = matrixStack.method_23760().method_23761();
/* 166 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */ 
/*     */         
/* 169 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 170 */         bufferBuilder.method_22918(matrix, (float)pos1.method_10216(), (float)pos1.method_10214(), (float)pos1.method_10215());
/* 171 */         bufferBuilder.method_22918(matrix, (float)pos2.method_10216(), (float)pos2.method_10214(), (float)pos2.method_10215());
/*     */ 
/*     */         
/* 174 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 177 */         matrixStack.method_22909();
/* 178 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 179 */         GL11.glEnable(2929);
/* 180 */         GL11.glDisable(3042); }
/*     */       private static final class_5944 circle$lambda$1() { return class_757.method_34539(); } private static final class_5944 line$lambda$2() {
/*     */         return class_757.method_34539();
/*     */       } public final void outlinedBox(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) {
/* 184 */         Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 185 */         GL11.glBlendFunc(770, 771);
/* 186 */         GL11.glEnable(2884);
/* 187 */         GL11.glDisable(2929);
/* 188 */         RenderSystem.setShader(Companion::outlinedBox$lambda$3);
/* 189 */         matrixStack.method_22903();
/* 190 */         class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 1.0D, 0.5D);
/* 191 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 192 */         int regionX = camPos.method_10263();
/* 193 */         int regionZ = camPos.method_10260();
/*     */         
/* 195 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 196 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 197 */         RenderSystem.setShader(Companion::outlinedBox$lambda$4);
/* 198 */         Color col = new Color(color);
/*     */         
/* 200 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 202 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 203 */         RenderSystem.setShaderColor(
/* 204 */             col.getRed() / 255.0F, 
/* 205 */             col.getGreen() / 255.0F, 
/* 206 */             col.getBlue() / 255.0F, 
/* 207 */             1.0F);
/*     */ 
/*     */         
/* 210 */         Intrinsics.checkNotNull(bufferBuilder); boxLines(bb, matrixStack, bufferBuilder);
/* 211 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/* 213 */         matrixStack.method_22909();
/* 214 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 215 */         GL11.glEnable(2929);
/* 216 */         GL11.glDisable(3042); } private static final class_5944 outlinedBox$lambda$3() { return class_757.method_34539(); }
/*     */       private static final class_5944 outlinedBox$lambda$4() {
/*     */         return class_757.method_34539();
/*     */       }
/* 220 */       public final void sideBox(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 221 */         GL11.glBlendFunc(770, 771);
/* 222 */         GL11.glEnable(2884);
/* 223 */         GL11.glDisable(2929);
/* 224 */         RenderSystem.setShader(Companion::sideBox$lambda$5);
/* 225 */         matrixStack.method_22903();
/* 226 */         class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 1.0D, 0.5D);
/* 227 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 228 */         int regionX = camPos.method_10263();
/* 229 */         int regionZ = camPos.method_10260();
/*     */         
/* 231 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 232 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 233 */         RenderSystem.setShader(Companion::sideBox$lambda$6);
/* 234 */         Color col = new Color(color);
/*     */         
/* 236 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 238 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 239 */         RenderSystem.setShaderColor(
/* 240 */             col.getRed() / 255.0F, 
/* 241 */             col.getGreen() / 255.0F, 
/* 242 */             col.getBlue() / 255.0F, 
/* 243 */             0.3F);
/*     */         
/* 245 */         Intrinsics.checkNotNull(bufferBuilder); boxFill(bb, matrixStack, bufferBuilder);
/* 246 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 249 */         matrixStack.method_22909();
/* 250 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 251 */         GL11.glEnable(2929);
/* 252 */         GL11.glDisable(3042); } private static final class_5944 sideBox$lambda$5() {
/*     */         return class_757.method_34539();
/*     */       } private static final class_5944 sideBox$lambda$6() {
/*     */         return class_757.method_34539();
/*     */       }
/* 257 */       public final void box(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 258 */         GL11.glBlendFunc(770, 771);
/* 259 */         GL11.glEnable(2884);
/* 260 */         GL11.glDisable(2929);
/* 261 */         RenderSystem.setShader(Companion::box$lambda$7);
/* 262 */         matrixStack.method_22903();
/* 263 */         class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 1.0D, 0.5D);
/* 264 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 265 */         int regionX = camPos.method_10263();
/* 266 */         int regionZ = camPos.method_10260();
/*     */         
/* 268 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 269 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 270 */         RenderSystem.setShader(Companion::box$lambda$8);
/* 271 */         Color col = new Color(color);
/*     */         
/* 273 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 275 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 276 */         RenderSystem.setShaderColor(
/* 277 */             col.getRed() / 255.0F, 
/* 278 */             col.getGreen() / 255.0F, 
/* 279 */             col.getBlue() / 255.0F, 
/* 280 */             1.0F);
/*     */         
/* 282 */         class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(bb, matrixStack, class_2871);
/* 283 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 286 */         bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 287 */         RenderSystem.setShaderColor(
/* 288 */             col.getRed() / 255.0F, 
/* 289 */             col.getGreen() / 255.0F, 
/* 290 */             col.getBlue() / 255.0F, 
/* 291 */             0.3F);
/*     */         
/* 293 */         class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(bb, matrixStack, class_2871);
/* 294 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 297 */         matrixStack.method_22909();
/* 298 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 299 */         GL11.glEnable(2929);
/* 300 */         GL11.glDisable(3042); } private static final class_5944 box$lambda$7() { return class_757.method_34539(); }
/*     */       private static final class_5944 box$lambda$8() {
/*     */         return class_757.method_34539();
/*     */       }
/* 304 */       public final void box(@NotNull class_238 box, @NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 305 */         GL11.glBlendFunc(770, 771);
/* 306 */         GL11.glEnable(2884);
/* 307 */         GL11.glDisable(2929);
/* 308 */         RenderSystem.setShader(Companion::box$lambda$9);
/* 309 */         matrixStack.method_22903();
/* 310 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 311 */         int regionX = camPos.method_10263();
/* 312 */         int regionZ = camPos.method_10260();
/*     */         
/* 314 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 315 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 316 */         RenderSystem.setShader(Companion::box$lambda$10);
/* 317 */         Color col = new Color(color);
/*     */         
/* 319 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 321 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 322 */         RenderSystem.setShaderColor(
/* 323 */             col.getRed() / 255.0F, 
/* 324 */             col.getGreen() / 255.0F, 
/* 325 */             col.getBlue() / 255.0F, 
/* 326 */             1.0F);
/*     */         
/* 328 */         class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(box, matrixStack, class_2871);
/* 329 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 332 */         bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 333 */         RenderSystem.setShaderColor(
/* 334 */             col.getRed() / 255.0F, 
/* 335 */             col.getGreen() / 255.0F, 
/* 336 */             col.getBlue() / 255.0F, 
/* 337 */             0.3F);
/*     */         
/* 339 */         class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(box, matrixStack, class_2871);
/* 340 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 343 */         matrixStack.method_22909();
/* 344 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 345 */         GL11.glEnable(2929);
/* 346 */         GL11.glDisable(3042); } private static final class_5944 box$lambda$9() { return class_757.method_34539(); }
/*     */       private static final class_5944 box$lambda$10() {
/*     */         return class_757.method_34539();
/*     */       }
/* 350 */       public final void sideBox(@NotNull class_238 box, @NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 351 */         GL11.glBlendFunc(770, 771);
/* 352 */         GL11.glEnable(2884);
/* 353 */         GL11.glDisable(2929);
/* 354 */         RenderSystem.setShader(Companion::sideBox$lambda$11);
/* 355 */         matrixStack.method_22903();
/* 356 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 357 */         int regionX = camPos.method_10263();
/* 358 */         int regionZ = camPos.method_10260();
/*     */         
/* 360 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 361 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 362 */         RenderSystem.setShader(Companion::sideBox$lambda$12);
/* 363 */         Color col = new Color(color);
/*     */         
/* 365 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 367 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 368 */         RenderSystem.setShaderColor(
/* 369 */             col.getRed() / 255.0F, 
/* 370 */             col.getGreen() / 255.0F, 
/* 371 */             col.getBlue() / 255.0F, 
/* 372 */             0.3F);
/*     */         
/* 374 */         Intrinsics.checkNotNull(bufferBuilder); boxFill(box, matrixStack, bufferBuilder);
/* 375 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 378 */         matrixStack.method_22909();
/* 379 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 380 */         GL11.glEnable(2929);
/* 381 */         GL11.glDisable(3042); } private static final class_5944 sideBox$lambda$11() { return class_757.method_34539(); }
/*     */       private static final class_5944 sideBox$lambda$12() {
/*     */         return class_757.method_34539();
/*     */       }
/* 385 */       public final void outlinedBox(@NotNull class_238 box, @NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(box, "box"); Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 386 */         GL11.glBlendFunc(770, 771);
/* 387 */         GL11.glEnable(2884);
/* 388 */         GL11.glDisable(2929);
/* 389 */         RenderSystem.setShader(Companion::outlinedBox$lambda$13);
/* 390 */         matrixStack.method_22903();
/* 391 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 392 */         int regionX = camPos.method_10263();
/* 393 */         int regionZ = camPos.method_10260();
/*     */         
/* 395 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 396 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214(), block.method_10215() - regionZ);
/* 397 */         RenderSystem.setShader(Companion::outlinedBox$lambda$14);
/* 398 */         Color col = new Color(color);
/*     */         
/* 400 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 402 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 403 */         RenderSystem.setShaderColor(
/* 404 */             col.getRed() / 255.0F, 
/* 405 */             col.getGreen() / 255.0F, 
/* 406 */             col.getBlue() / 255.0F, 
/* 407 */             1.0F);
/*     */         
/* 409 */         Intrinsics.checkNotNull(bufferBuilder); boxLines(box, matrixStack, bufferBuilder);
/* 410 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 413 */         matrixStack.method_22909();
/* 414 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 415 */         GL11.glEnable(2929);
/* 416 */         GL11.glDisable(3042); } private static final class_5944 outlinedBox$lambda$13() { return class_757.method_34539(); }
/*     */       private static final class_5944 outlinedBox$lambda$14() {
/*     */         return class_757.method_34539();
/*     */       }
/* 420 */       public final void multiBlock(@NotNull ArrayList blocks, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(blocks, "blocks"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 421 */         GL11.glBlendFunc(770, 771);
/* 422 */         GL11.glEnable(2884);
/* 423 */         GL11.glDisable(2929);
/* 424 */         RenderSystem.setShader(Companion::multiBlock$lambda$15);
/* 425 */         matrixStack.method_22903();
/* 426 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 427 */         int regionX = camPos.method_10263();
/* 428 */         int regionZ = camPos.method_10260();
/*     */         
/* 430 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/*     */         
/* 432 */         RenderSystem.setShader(Companion::multiBlock$lambda$16);
/* 433 */         Color col = new Color(color);
/*     */         
/* 435 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 437 */         double sizeX = Math.abs(CoordinateUtils.Companion.getHighestX(blocks) - CoordinateUtils.Companion.getLowestX(blocks));
/* 438 */         double sizeY = Math.abs(CoordinateUtils.Companion.getHighestY(blocks) - CoordinateUtils.Companion.getLowestY(blocks)) + true;
/* 439 */         double sizeZ = Math.abs(CoordinateUtils.Companion.getHighestZ(blocks) - CoordinateUtils.Companion.getLowestZ(blocks));
/*     */         
/* 441 */         class_238 bb = new class_238(-(sizeX / 2 + 0.5D), 0.0D, -(sizeZ / 2 + 0.5D), sizeX / 2 + 0.5D, sizeY, sizeZ / 2 + 0.5D);
/*     */         
/* 443 */         class_243 center = new class_243(
/* 444 */             CoordinateUtils.Companion.getLowestX(blocks) + sizeX / 2, 
/* 445 */             CoordinateUtils.Companion.getLowestY(blocks) + sizeY / 2, 
/* 446 */             CoordinateUtils.Companion.getLowestZ(blocks) + sizeZ / 2);
/*     */ 
/*     */         
/* 449 */         matrixStack.method_22904(center.method_10216() - regionX, center.method_10214() - sizeY / 2, center.method_10215() - regionZ);
/*     */         
/* 451 */         RenderSystem.setShaderColor(
/* 452 */             col.getRed() / 255.0F, 
/* 453 */             col.getGreen() / 255.0F, 
/* 454 */             col.getBlue() / 255.0F, 
/* 455 */             0.5F);
/*     */ 
/*     */         
/* 458 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 459 */         class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(bb, matrixStack, class_2871);
/*     */         
/* 461 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 464 */         RenderSystem.setShaderColor(
/* 465 */             col.getRed() / 255.0F, 
/* 466 */             col.getGreen() / 255.0F, 
/* 467 */             col.getBlue() / 255.0F, 
/* 468 */             0.03F);
/*     */ 
/*     */         
/* 471 */         bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 472 */         class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(bb, matrixStack, class_2871);
/*     */         
/* 474 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 477 */         matrixStack.method_22909();
/* 478 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 479 */         GL11.glEnable(2929);
/* 480 */         GL11.glDisable(3042); } private static final class_5944 multiBlock$lambda$15() { return class_757.method_34539(); }
/*     */       private static final class_5944 multiBlock$lambda$16() {
/*     */         return class_757.method_34539();
/*     */       }
/* 484 */       public final void floorQuad(@NotNull class_243 block, @NotNull class_4587 matrixStack, int color) { Intrinsics.checkNotNullParameter(block, "block"); Intrinsics.checkNotNullParameter(matrixStack, "matrixStack"); GL11.glEnable(3042);
/* 485 */         GL11.glBlendFunc(770, 771);
/* 486 */         GL11.glEnable(2884);
/* 487 */         GL11.glDisable(2929);
/* 488 */         RenderSystem.setShader(Companion::floorQuad$lambda$17);
/* 489 */         matrixStack.method_22903();
/* 490 */         class_238 bb = new class_238(-0.5D, 0.0D, -0.5D, 0.5D, 0.0D, 0.5D);
/* 491 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19328(), "getBlockPos(...)"); class_2338 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19328();
/* 492 */         int regionX = camPos.method_10263();
/* 493 */         int regionZ = camPos.method_10260();
/*     */         
/* 495 */         applyRegionalRenderOffset(matrixStack, regionX, regionZ);
/* 496 */         matrixStack.method_22904(block.method_10216() - regionX, block.method_10214() - 0.5D, block.method_10215() - regionZ);
/* 497 */         RenderSystem.setShader(Companion::floorQuad$lambda$18);
/* 498 */         Color col = new Color(color);
/*     */         
/* 500 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 502 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/* 503 */         RenderSystem.setShaderColor(
/* 504 */             col.getRed() / 255.0F, 
/* 505 */             col.getGreen() / 255.0F, 
/* 506 */             col.getBlue() / 255.0F, 
/* 507 */             1.0F);
/*     */         
/* 509 */         class_287 class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxLines(bb, matrixStack, class_2871);
/* 510 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 513 */         bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 514 */         RenderSystem.setShaderColor(
/* 515 */             col.getRed() / 255.0F, 
/* 516 */             col.getGreen() / 255.0F, 
/* 517 */             col.getBlue() / 255.0F, 
/* 518 */             0.3F);
/*     */         
/* 520 */         class_2871 = bufferBuilder; Intrinsics.checkNotNull(class_2871); boxFill(bb, matrixStack, class_2871);
/* 521 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */ 
/*     */         
/* 524 */         matrixStack.method_22909();
/* 525 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 526 */         GL11.glEnable(2929);
/* 527 */         GL11.glDisable(3042); } private static final class_5944 floorQuad$lambda$17() { return class_757.method_34539(); } private static final class_5944 floorQuad$lambda$18() {
/*     */         return class_757.method_34539();
/*     */       }
/*     */       private final void applyRegionalRenderOffset(class_4587 matrixStack, int regionX, int regionZ) {
/* 531 */         Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC()).field_1773.method_19418().method_19326(), "getPos(...)"); class_243 camPos = (Onyx.Companion.getMC()).field_1773.method_19418().method_19326();
/* 532 */         matrixStack.method_22904(regionX - camPos.field_1352, -camPos.field_1351, regionZ - camPos.field_1350);
/*     */       }
/*     */       
/*     */       private final void boxLines(class_238 bb, class_4587 matrixStack, class_287 bufferBuilder) {
/* 536 */         Matrix4f matrix = matrixStack.method_23760().method_23761();
/*     */ 
/*     */         
/* 539 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 540 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/*     */         
/* 542 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 543 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/*     */         
/* 545 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 546 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/*     */         
/* 548 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 549 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/*     */         
/* 551 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 552 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/*     */         
/* 554 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 555 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/*     */         
/* 557 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 558 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/*     */         
/* 560 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 561 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/*     */         
/* 563 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/* 564 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/*     */         
/* 566 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/* 567 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/*     */         
/* 569 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 570 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/*     */         
/* 572 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/* 573 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/*     */       }
/*     */       private static final class_5944 boxFill$lambda$19() {
/*     */         return class_757.method_34539();
/*     */       }
/*     */       private final void boxFill(class_238 bb, class_4587 matrixStack, class_287 bufferBuilder) {
/* 579 */         Matrix4f matrix = matrixStack.method_23760().method_23761();
/* 580 */         RenderSystem.setShader(Companion::boxFill$lambda$19);
/*     */         
/* 582 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 583 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 584 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 585 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/*     */         
/* 587 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/* 588 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/* 589 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 590 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/*     */         
/* 592 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 593 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/* 594 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/* 595 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/*     */         
/* 597 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1321);
/* 598 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1321);
/* 599 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 600 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/*     */         
/* 602 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 603 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1322, (float)bb.field_1324);
/* 604 */         bufferBuilder.method_22918(matrix, (float)bb.field_1320, (float)bb.field_1325, (float)bb.field_1324);
/* 605 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/*     */         
/* 607 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1321);
/* 608 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1322, (float)bb.field_1324);
/* 609 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1324);
/* 610 */         bufferBuilder.method_22918(matrix, (float)bb.field_1323, (float)bb.field_1325, (float)bb.field_1321);
/*     */       } } }
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/RenderingEngine$TwoDimensional;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */   public static final class TwoDimensional { @NotNull
/*     */     public static final Companion Companion = new Companion(null);
/*     */     @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\007\n\002\b\004\n\002\020\b\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\f\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J?\020\016\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\b\020\f\032\004\030\0010\013¢\006\004\b\016\020\017J_\020\027\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\020\032\0020\t2\006\020\022\032\0020\0212\006\020\023\032\0020\0042\006\020\024\032\0020\0042\b\b\002\020\026\032\0020\025¢\006\004\b\027\020\030JW\020\032\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\031\032\0020\t2\006\020\023\032\0020\0042\006\020\024\032\0020\0042\006\020\f\032\0020\013H\002¢\006\004\b\032\020\033JM\020\034\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\022\032\0020\0212\006\020\023\032\0020\0042\006\020\024\032\0020\004¢\006\004\b\034\020\035JO\020\036\032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\023\032\0020\0042\006\020\024\032\0020\0042\006\020\f\032\0020\013H\002¢\006\004\b\036\020\037J=\020 \032\0020\r2\006\020\005\032\0020\0042\006\020\006\032\0020\0042\006\020\007\032\0020\0042\006\020\b\032\0020\0042\006\020\n\032\0020\t2\006\020\f\032\0020\013¢\006\004\b \020\017¨\006!"}, d2 = {"Lnet/integr/rendering/RenderingEngine$TwoDimensional$Companion;", "", "<init>", "()V", "", "xp1", "yp1", "xp2", "yp2", "", "color", "Lorg/joml/Matrix4f;", "matrix4f", "", "fill", "(FFFFILorg/joml/Matrix4f;)V", "outlineColor", "Lnet/minecraft/class_332;", "context", "precision", "radius", "", "glow", "fillRound", "(FFFFIILnet/minecraft/class_332;FFZ)V", "colorOutline", "fillRoundM4f", "(FFFFIIFFLorg/joml/Matrix4f;)V", "fillRoundNoOutline", "(FFFFILnet/minecraft/class_332;FF)V", "fillRoundNoOutlineM4f", "(FFFFIFFLorg/joml/Matrix4f;)V", "line", "onyx2"})
/*     */     public static final class Companion { private Companion() {}
/*     */       public final void line(float xp1, float yp1, float xp2, float yp2, int color, @NotNull Matrix4f matrix4f) {
/* 618 */         Intrinsics.checkNotNullParameter(matrix4f, "matrix4f"); float x1 = xp1;
/* 619 */         float y1 = yp1;
/* 620 */         float x2 = xp2;
/* 621 */         float y2 = yp2;
/* 622 */         GL11.glDisable(2929);
/*     */         
/* 624 */         float i = 0.0F;
/* 625 */         if (x1 < x2) {
/* 626 */           i = x1;
/* 627 */           x1 = x2;
/* 628 */           x2 = i;
/*     */         } 
/*     */         
/* 631 */         if (y1 < y2) {
/* 632 */           i = y1;
/* 633 */           y1 = y2;
/* 634 */           y2 = i;
/*     */         } 
/*     */         
/* 637 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 639 */         RenderSystem.setShader(Companion::line$lambda$0);
/* 640 */         Color col = new Color(color);
/*     */         
/* 642 */         RenderSystem.setShaderColor(
/* 643 */             col.getRed() / 255.0F, 
/* 644 */             col.getGreen() / 255.0F, 
/* 645 */             col.getBlue() / 255.0F, 
/* 646 */             0.5F);
/*     */ 
/*     */         
/* 649 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
/*     */ 
/*     */         
/* 652 */         bufferBuilder.method_22918(matrix4f, x1, y1, 0.0F);
/* 653 */         bufferBuilder.method_22918(matrix4f, x2, y2, 0.0F);
/*     */ 
/*     */         
/* 656 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/* 658 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 659 */         GL11.glEnable(2929);
/*     */       } private static final class_5944 line$lambda$0() {
/*     */         return class_757.method_34539();
/*     */       } private final void fillRoundM4f(float xp1, float yp1, float xp2, float yp2, int color, int colorOutline, float precision, float radius, Matrix4f matrix4f) {
/* 663 */         float x1 = xp1;
/* 664 */         float y1 = yp1;
/* 665 */         float x2 = xp2;
/* 666 */         float y2 = yp2;
/*     */         
/* 668 */         GL11.glEnable(3042);
/*     */         
/* 670 */         GL11.glEnable(2848);
/* 671 */         GL11.glEnable(2881);
/*     */         
/* 673 */         float i = 0.0F;
/* 674 */         if (x1 < x2) {
/* 675 */           i = x1;
/* 676 */           x1 = x2;
/* 677 */           x2 = i;
/*     */         } 
/*     */         
/* 680 */         if (y1 < y2) {
/* 681 */           i = y1;
/* 682 */           y1 = y2;
/* 683 */           y2 = i;
/*     */         } 
/*     */         
/* 686 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 688 */         RenderSystem.setShader(Companion::fillRoundM4f$lambda$1);
/* 689 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */         
/* 691 */         Color colOut = new Color(colorOutline);
/* 692 */         RenderSystem.setShaderColor(
/* 693 */             colOut.getRed() / 255.0F, 
/* 694 */             colOut.getGreen() / 255.0F, 
/* 695 */             colOut.getBlue() / 255.0F, 
/* 696 */             colOut.getAlpha() / 255.0F);
/*     */ 
/*     */         
/* 699 */         double angle = 0.0D;
/* 700 */         while (angle <= 6.283185307179586D) {
/* 701 */           float x = (float)Math.cos(angle) * radius;
/* 702 */           float y = (float)Math.sin(angle) * radius;
/* 703 */           bufferBuilder.method_22918(matrix4f, x1 + 1.2F - radius + x, y1 + 1.2F - radius + y, 0.0F);
/* 704 */           bufferBuilder.method_22918(matrix4f, x1 + 1.2F - radius + x, y2 - 1.2F + radius - y, 0.0F);
/* 705 */           bufferBuilder.method_22918(matrix4f, x2 - 1.2F + radius - x, y2 - 1.2F + radius - y, 0.0F);
/* 706 */           bufferBuilder.method_22918(matrix4f, x2 - 1.2F + radius - x, y1 + 1.2F - radius + y, 0.0F);
/* 707 */           angle += precision;
/*     */         } 
/*     */         
/* 710 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/* 712 */         bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */         
/* 714 */         Color col = new Color(color);
/* 715 */         RenderSystem.setShaderColor(
/* 716 */             col.getRed() / 255.0F, 
/* 717 */             col.getGreen() / 255.0F, 
/* 718 */             col.getBlue() / 255.0F, 
/* 719 */             col.getAlpha() / 255.0F);
/*     */ 
/*     */         
/* 722 */         angle = 0.0D;
/* 723 */         while (angle <= 6.283185307179586D) {
/* 724 */           float x = (float)Math.cos(angle) * radius;
/* 725 */           float y = (float)Math.sin(angle) * radius;
/* 726 */           bufferBuilder.method_22918(matrix4f, x1 - radius + x, y1 - radius + y, 0.0F);
/* 727 */           bufferBuilder.method_22918(matrix4f, x1 - radius + x, y2 + radius - y, 0.0F);
/* 728 */           bufferBuilder.method_22918(matrix4f, x2 + radius - x, y2 + radius - y, 0.0F);
/* 729 */           bufferBuilder.method_22918(matrix4f, x2 + radius - x, y1 - radius + y, 0.0F);
/* 730 */           angle += precision;
/*     */         } 
/*     */         
/* 733 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/* 735 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 736 */         GL11.glDisable(2848);
/* 737 */         GL11.glDisable(2881);
/*     */         
/* 739 */         GL11.glDisable(3042);
/*     */       } private static final class_5944 fillRoundM4f$lambda$1() {
/*     */         return class_757.method_34539();
/*     */       }
/*     */       private final void fillRoundNoOutlineM4f(float xp1, float yp1, float xp2, float yp2, int color, float precision, float radius, Matrix4f matrix4f) {
/* 744 */         float x1 = xp1;
/* 745 */         float y1 = yp1;
/* 746 */         float x2 = xp2;
/* 747 */         float y2 = yp2;
/*     */         
/* 749 */         GL11.glEnable(3042);
/*     */         
/* 751 */         GL11.glEnable(2848);
/* 752 */         GL11.glEnable(2881);
/*     */         
/* 754 */         float i = 0.0F;
/* 755 */         if (x1 < x2) {
/* 756 */           i = x1;
/* 757 */           x1 = x2;
/* 758 */           x2 = i;
/*     */         } 
/*     */         
/* 761 */         if (y1 < y2) {
/* 762 */           i = y1;
/* 763 */           y1 = y2;
/* 764 */           y2 = i;
/*     */         } 
/*     */         
/* 767 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 769 */         RenderSystem.setShader(Companion::fillRoundNoOutlineM4f$lambda$2);
/* 770 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */         
/* 772 */         Color col = new Color(color);
/* 773 */         RenderSystem.setShaderColor(
/* 774 */             col.getRed() / 255.0F, 
/* 775 */             col.getGreen() / 255.0F, 
/* 776 */             col.getBlue() / 255.0F, 
/* 777 */             col.getAlpha() / 255.0F);
/*     */ 
/*     */         
/* 780 */         double angle = 0.0D;
/* 781 */         while (angle <= 6.283185307179586D) {
/* 782 */           float x = (float)Math.cos(angle) * radius;
/* 783 */           float y = (float)Math.sin(angle) * radius;
/* 784 */           bufferBuilder.method_22918(matrix4f, x1 - radius + x, y1 - radius + y, 0.0F);
/* 785 */           bufferBuilder.method_22918(matrix4f, x1 - radius + x, y2 + radius - y, 0.0F);
/* 786 */           bufferBuilder.method_22918(matrix4f, x2 + radius - x, y2 + radius - y, 0.0F);
/* 787 */           bufferBuilder.method_22918(matrix4f, x2 + radius - x, y1 - radius + y, 0.0F);
/* 788 */           angle += precision;
/*     */         } 
/*     */         
/* 791 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/* 793 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 794 */         GL11.glDisable(2848);
/* 795 */         GL11.glDisable(2881);
/*     */         
/* 797 */         GL11.glDisable(3042);
/*     */       } private static final class_5944 fillRoundNoOutlineM4f$lambda$2() {
/*     */         return class_757.method_34539();
/*     */       }
/*     */       public final void fill(float xp1, float yp1, float xp2, float yp2, int color, @Nullable Matrix4f matrix4f) {
/* 802 */         float x1 = xp1;
/* 803 */         float y1 = yp1;
/* 804 */         float x2 = xp2;
/* 805 */         float y2 = yp2;
/* 806 */         GL11.glDisable(2929);
/*     */         
/* 808 */         float i = 0.0F;
/* 809 */         if (x1 < x2) {
/* 810 */           i = x1;
/* 811 */           x1 = x2;
/* 812 */           x2 = i;
/*     */         } 
/*     */         
/* 815 */         if (y1 < y2) {
/* 816 */           i = y1;
/* 817 */           y1 = y2;
/* 818 */           y2 = i;
/*     */         } 
/*     */         
/* 821 */         class_289 tesselator = RenderSystem.renderThreadTesselator();
/*     */         
/* 823 */         RenderSystem.setShader(Companion::fill$lambda$3);
/* 824 */         Color col = new Color(color);
/* 825 */         RenderSystem.setShaderColor(
/* 826 */             col.getRed() / 255.0F, 
/* 827 */             col.getGreen() / 255.0F, 
/* 828 */             col.getBlue() / 255.0F, 
/* 829 */             0.5F);
/*     */ 
/*     */         
/* 832 */         class_287 bufferBuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */         
/* 834 */         bufferBuilder.method_22918(matrix4f, x1, y1, 0.0F);
/* 835 */         bufferBuilder.method_22918(matrix4f, x1, y2, 0.0F);
/* 836 */         bufferBuilder.method_22918(matrix4f, x2, y2, 0.0F);
/* 837 */         bufferBuilder.method_22918(matrix4f, x2, y1, 0.0F);
/*     */         
/* 839 */         class_286.method_43433(bufferBuilder.method_60800());
/*     */         
/* 841 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 842 */         GL11.glEnable(2929);
/*     */       } private static final class_5944 fill$lambda$3() {
/*     */         return class_757.method_34539();
/*     */       } public final void fillRoundNoOutline(float xp1, float yp1, float xp2, float yp2, int color, @NotNull class_332 context, float precision, float radius) {
/* 846 */         Intrinsics.checkNotNullParameter(context, "context"); float x1 = xp1;
/* 847 */         float y1 = yp1;
/* 848 */         float x2 = xp2;
/* 849 */         float y2 = yp2;
/*     */         
/* 851 */         Matrix4f matrix4f = context.method_51448().method_23760().method_23761();
/* 852 */         GL11.glEnable(2881);
/* 853 */         GL11.glEnable(3042);
/* 854 */         GL11.glBlendFunc(770, 1);
/* 855 */         GL11.glHint(3155, 4354);
/*     */         
/* 857 */         float i = 0.0F;
/* 858 */         if (x1 < x2) {
/* 859 */           i = x1;
/* 860 */           x1 = x2;
/* 861 */           x2 = i;
/*     */         } 
/*     */         
/* 864 */         if (y1 < y2) {
/* 865 */           i = y1;
/* 866 */           y1 = y2;
/* 867 */           y2 = i;
/*     */         } 
/*     */         
/* 870 */         float f = class_5253.class_5254.method_27762(color) / 255.0F;
/* 871 */         float g = class_5253.class_5254.method_27765(color) / 255.0F;
/* 872 */         float h = class_5253.class_5254.method_27766(color) / 255.0F;
/* 873 */         float j = class_5253.class_5254.method_27767(color) / 255.0F;
/* 874 */         class_4588 vertexConsumer = context.method_51450().getBuffer(class_1921.method_51784());
/*     */         
/* 876 */         double angle = 0.0D;
/* 877 */         while (angle <= 6.283185307179586D) {
/* 878 */           float x = (float)Math.cos(angle) * radius;
/* 879 */           float y = (float)Math.sin(angle) * radius;
/* 880 */           vertexConsumer.method_22918(matrix4f, x1 - radius + x, y1 - radius + y, 0.0F).method_22915(g, h, j, f);
/* 881 */           vertexConsumer.method_22918(matrix4f, x1 - radius + x, y2 + radius - y, 0.0F).method_22915(g, h, j, f);
/* 882 */           vertexConsumer.method_22918(matrix4f, x2 + radius - x, y2 + radius - y, 0.0F).method_22915(g, h, j, f);
/* 883 */           vertexConsumer.method_22918(matrix4f, x2 + radius - x, y1 - radius + y, 0.0F).method_22915(g, h, j, f);
/* 884 */           angle += precision;
/*     */         } 
/*     */         
/* 887 */         context.method_51452();
/*     */         
/* 889 */         GL11.glDisable(2881);
/* 890 */         GL11.glDisable(3042);
/*     */       }
/*     */ 
/*     */       
/*     */       public final void fillRound(float xp1, float yp1, float xp2, float yp2, int color, int outlineColor, @NotNull class_332 context, float precision, float radius, boolean glow) {
/* 895 */         Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("glow")); if (glow && ((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("glow")).getEnabled()) {
/* 896 */           Color tColor = new Color(outlineColor);
/* 897 */           Color colorC = new Color(tColor.getRed(), tColor.getGreen(), tColor.getBlue(), 4);
/*     */           
/* 899 */           int i = 2, j = ProgressionUtilKt.getProgressionLastElement(2, 32, 4); if (i <= j)
/* 900 */             while (true) { int v = 1 + i / 10;
/* 901 */               fillRoundNoOutline(xp1 - v, yp1 - v, xp2 + v, yp2 + v, colorC.getRGB(), context, precision, radius); if (i != j) {
/*     */                 i += 4; continue;
/*     */               }  break; }
/*     */              
/* 905 */         }  fillRoundNoOutline(xp1 - 1.1F, yp1 - 1.1F, xp2 + 1.1F, yp2 + 1.1F, outlineColor, context, precision, radius);
/*     */         
/* 907 */         fillRoundNoOutline(xp1, yp1, xp2, yp2, color, context, precision, radius);
/*     */       } } } @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/RenderingEngine$Misc;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */   public static final class Misc { @NotNull
/*     */     public static final Companion Companion = new Companion(null);
/*     */     @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\024\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Lnet/integr/rendering/RenderingEngine$Misc$Companion;", "", "<init>", "()V", "", "getRainbowColor", "()[F", "onyx2"})
/*     */     public static final class Companion { private Companion() {}
/*     */       @NotNull
/*     */       public final float[] getRainbowColor() {
/* 915 */         float x = (float)(System.currentTimeMillis() % 2000L) / 1000.0F;
/* 916 */         float pi = 3.1415927F;
/*     */         
/* 918 */         float[] rainbow = new float[3];
/* 919 */         rainbow[0] = 0.5F + 0.5F * class_3532.method_15374(x * pi);
/* 920 */         rainbow[1] = 0.5F + 0.5F * class_3532.method_15374((x + 1.3333334F) * pi);
/* 921 */         rainbow[2] = 0.5F + 0.5F * class_3532.method_15374((x + 2.6666667F) * pi);
/* 922 */         return rainbow;
/*     */       } } }
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/rendering/RenderingEngine$Text;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */   public static final class Text { @NotNull
/*     */     public static final Companion Companion = new Companion(null);
/*     */     @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\b\n\002\b\003\n\002\020\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J5\020\r\032\0020\f2\006\020\005\032\0020\0042\006\020\007\032\0020\0062\006\020\t\032\0020\b2\006\020\n\032\0020\b2\006\020\013\032\0020\b¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lnet/integr/rendering/RenderingEngine$Text$Companion;", "", "<init>", "()V", "Lnet/minecraft/class_332;", "context", "", "text", "", "x", "y", "color", "", "draw", "(Lnet/minecraft/class_332;Ljava/lang/String;III)V", "onyx2"})
/*     */     public static final class Companion { private Companion() {}
/*     */       public final void draw(@NotNull class_332 context, @NotNull String text, int x, int y, int color) {
/* 930 */         Intrinsics.checkNotNullParameter(context, "context"); Intrinsics.checkNotNullParameter(text, "text"); context.method_51433((Onyx.Companion.getMC()).field_1772, text, x, y, color, false);
/*     */       } }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\rendering\RenderingEngine.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */