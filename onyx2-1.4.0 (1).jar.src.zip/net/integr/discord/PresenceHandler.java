/*     */ package net.integr.discord;
/*     */ 
/*     */ import club.minnced.discord.rpc.DiscordEventHandlers;
/*     */ import club.minnced.discord.rpc.DiscordRPC;
/*     */ import club.minnced.discord.rpc.DiscordRichPresence;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.jvm.internal.DefaultConstructorMarker;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import net.integr.Onyx;
/*     */ import net.integr.Settings;
/*     */ import net.integr.modules.management.settings.impl.BooleanSetting;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\004\030\000 \0042\0020\001:\001\004B\007¢\006\004\b\002\020\003¨\006\005"}, d2 = {"Lnet/integr/discord/PresenceHandler;", "", "<init>", "()V", "Companion", "onyx2"})
/*     */ public final class PresenceHandler
/*     */ {
/*     */   @NotNull
/*     */   public static final Companion Companion = new Companion(null);
/*     */   private static long start;
/*     */   
/*     */   @Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\002\b\004\n\002\020\016\n\000\n\002\020\b\n\002\b\007\n\002\020\t\n\002\b\002\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\003J\017\020\006\032\0020\004H\002¢\006\004\b\006\020\003J\r\020\007\032\0020\004¢\006\004\b\007\020\003J\017\020\b\032\0020\004H\002¢\006\004\b\b\020\003J'\020\016\032\0020\0042\006\020\n\032\0020\t2\006\020\f\032\0020\0132\006\020\r\032\0020\013H\002¢\006\004\b\016\020\017J\017\020\020\032\0020\004H\002¢\006\004\b\020\020\003J\r\020\021\032\0020\004¢\006\004\b\021\020\003J\r\020\022\032\0020\004¢\006\004\b\022\020\003R\026\020\021\032\0020\0238\002@\002X\016¢\006\006\n\004\b\021\020\024¨\006\025"}, d2 = {"Lnet/integr/discord/PresenceHandler$Companion;", "", "<init>", "()V", "", "clear", "init", "setDynamically", "setMenu", "", "server", "", "maxPlayers", "players", "setServer", "(Ljava/lang/String;II)V", "setSinglePlayer", "start", "stop", "", "J", "onyx2"})
/*     */   public static final class Companion
/*     */   {
/*     */     private Companion() {}
/*     */     
/*     */     private final void setServer(String server, int maxPlayers, int players) {
/*  31 */       DiscordRichPresence pres = new DiscordRichPresence();
/*     */       
/*  33 */       pres.largeImageKey = "logo";
/*  34 */       pres.smallImageKey = "integr";
/*  35 */       pres.details = "Playing " + server;
/*  36 */       pres.state = "Online";
/*  37 */       pres.partyMax = maxPlayers;
/*  38 */       pres.partySize = players;
/*  39 */       pres.startTimestamp = PresenceHandler.start;
/*  40 */       pres.smallImageText = "by Integr";
/*  41 */       pres.largeImageText = "Onyx [" + Onyx.Companion.getVERSION() + "]";
/*     */       
/*  43 */       DiscordRPC.INSTANCE.Discord_UpdatePresence(pres);
/*     */     }
/*     */     
/*     */     private final void setMenu() {
/*  47 */       DiscordRichPresence pres = new DiscordRichPresence();
/*     */       
/*  49 */       pres.largeImageKey = "logo";
/*  50 */       pres.smallImageKey = "integr";
/*  51 */       pres.details = "In Menu";
/*  52 */       pres.startTimestamp = PresenceHandler.start;
/*  53 */       pres.smallImageText = "by Integr";
/*  54 */       pres.largeImageText = "Onyx [" + Onyx.Companion.getVERSION() + "]";
/*     */       
/*  56 */       DiscordRPC.INSTANCE.Discord_UpdatePresence(pres);
/*     */     }
/*     */     
/*     */     private final void setSinglePlayer() {
/*  60 */       DiscordRichPresence pres = new DiscordRichPresence();
/*     */       
/*  62 */       pres.largeImageKey = "logo";
/*  63 */       pres.smallImageKey = "integr";
/*  64 */       pres.details = "Playing Singleplayer";
/*  65 */       pres.startTimestamp = PresenceHandler.start;
/*  66 */       pres.smallImageText = "by Integr";
/*  67 */       pres.largeImageText = "Onyx [" + Onyx.Companion.getVERSION() + "]";
/*     */       
/*  69 */       DiscordRPC.INSTANCE.Discord_UpdatePresence(pres);
/*     */     }
/*     */     
/*     */     private final void init() {
/*  73 */       DiscordEventHandlers handlers = new DiscordEventHandlers();
/*     */       
/*  75 */       DiscordRPC.INSTANCE.Discord_Initialize("1246381680084910100", handlers, true, "");
/*     */     }
/*     */     
/*     */     public final void stop() {
/*  79 */       clear();
/*  80 */       DiscordRPC.INSTANCE.Discord_Shutdown();
/*     */     }
/*     */     
/*     */     public final void start() {
/*  84 */       PresenceHandler.start = System.currentTimeMillis();
/*  85 */       init();
/*     */     }
/*     */     
/*     */     private final void clear() {
/*  89 */       DiscordRPC.INSTANCE.Discord_ClearPresence();
/*     */     }
/*     */     
/*     */     public final void setDynamically() {
/*  93 */       Intrinsics.checkNotNull(Settings.Companion.getINSTANCE().getSettings().getById("discordRpc")); if (((BooleanSetting)Settings.Companion.getINSTANCE().getSettings().getById("discordRpc")).isEnabled())
/*  94 */       { if ((Onyx.Companion.getMC()).field_1724 != null && (Onyx.Companion.getMC()).field_1687 != null) {
/*  95 */           Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1558()); if (!Onyx.Companion.getMC().method_1496() && Onyx.Companion.getMC().method_1558() != null && (Onyx.Companion.getMC().method_1558()).field_41861 != null) {
/*  96 */             Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1558()); Intrinsics.checkNotNullExpressionValue((Onyx.Companion.getMC().method_1558()).field_3761, "address"); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1558()); Intrinsics.checkNotNull((Onyx.Companion.getMC().method_1558()).field_41861); Intrinsics.checkNotNull(Onyx.Companion.getMC().method_1558()); Intrinsics.checkNotNull((Onyx.Companion.getMC().method_1558()).field_41861); setServer((Onyx.Companion.getMC().method_1558()).field_3761, (Onyx.Companion.getMC().method_1558()).field_41861.comp_1279(), (Onyx.Companion.getMC().method_1558()).field_41861.comp_1280());
/*  97 */           } else if (Onyx.Companion.getMC().method_1496()) {
/*  98 */             setSinglePlayer();
/*     */           } 
/*     */         } else {
/* 101 */           setMenu();
/*     */         }  }
/* 103 */       else { clear(); }
/*     */     
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\OneDrive\Desktop\onyx client most versions\onyx2-1.4.0 (1).jar!\net\integr\discord\PresenceHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */